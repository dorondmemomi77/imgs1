import cv2
import os

import sklearn.neighbors
import plotly.graph_objects as go
from sklearn import preprocessing
os.getcwd()
import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
from sklearn.neighbors import KNeighborsClassifier

WHITE=(255,255,255)
BLACK=(0,0,0)

def display_and_save_image(address,image):
    cv2.imshow('image', image)
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    if address!=0:
        cv2.imwrite(address, image)

def calculate_linear_equation(x1, y1, x2, y2):
    M = ((y2 - y1) / (x2 - x1))  ##M N-equation of Lower line
    N = y2 - (M * x2)
    return M,N

def mask_background_image(image,M, N, bool, color):
    # Mask the upper line- bool=1
    # Mask the lower line- bool=0
    # Iterate over the rows and columns of the image
    size=image.shape
    y=size[0]
    x=size[1]
    counter=0
    for i in range(x):
        for j in range(y):
            y0 = (M * i) + N
            # Check if j is less than or greater than y0 depending on the value of bool
            if bool:
                if (j < y0):
                    image[j, counter] = color
            elif not bool:
                if (j > y0):
                    image[j, counter] = color
        counter = counter+1
    return image

def min_max_lines(lines):## to delete
    # find_highest_and_lowest_lines
    xMax=lines[0][0][1]
    xLow=lines[0][0][1]
    for i in range(0, len(lines)):
        if (lines[i][0][1] > xMax):
            xMax = lines[i][0][1]
            x1, y1, x2, y2 = lines[i][0]
        if (lines[i][0][1] < xLow):
            xLow = lines[i][0][1]
            x3, y3, x4, y4 = lines[i][0]
    Max_line=x1,y1,x2,y2
    Min_line=x3,y3,x4,y4
    return [Max_line,Min_line]


def min_max_optimal_lines(lines):
    optimal_lines=[]
    # find_highest_and_lowest_lines
    min_line=lines[0]
    max_line=lines[0]
    yMax=max_line[1]
    yLow=min_line[1]
    for i in range(1, len(lines)):
        if (lines[i][1] > yLow):
            yMax = lines[i][1]
            max_line = lines[i]
        if (lines[i][1] < yLow):
            yLow = lines[i][1]
            min_line = lines[i]
    optimal_lines.append(max_line)
    optimal_lines.append(min_line)
    return optimal_lines

def finding_largest_area(white_mask,contours):
    # finding the second largest contour
    gray_white_mask= cv2.imread("white_mask.jpg",0)
    mask_tmp = np.zeros(gray_white_mask.shape, np.uint8)
    largest_areas = sorted(contours, key=cv2.contourArea)
    cnt = largest_areas[-2]
    img_contour_tmp = cv2.drawContours(mask_tmp, [cnt], 0, (255, 255, 255, 255), -1)
    frame = cv2.bitwise_and(white_mask, white_mask, mask=img_contour_tmp)
    display_and_save_image("frame.jpg", frame)
    return frame

def photo_rescale(address):
    image = cv2.imread(address, cv2.IMREAD_UNCHANGED)
    siz_ = image.shape
    while(siz_[0]>=1000 and siz_[1]>=1000):
        scale_factor = 2
        dim_size = (siz_[1] // scale_factor, siz_[0] // scale_factor)
        img = cv2.resize(image, dim_size)
        siz_ = img.shape
    display_and_save_image("dside.jpg", img)
    return img,dim_size

def mask_background(image):
    glass_black_mask = cv2.inRange(image, np.array([245, 245, 245]), np.array([255, 255, 255]))
    # mask glass's background
    black_mask = cv2.bitwise_not(glass_black_mask)  # mask glass's background
    glasses = cv2.bitwise_and(image, image, mask=black_mask)
    display_and_save_image("glassesblack.jpg",glasses)
    return glasses,black_mask

def improve_image_contours(address,laplacian=False,threshold=False):
    gray = cv2.imread(address, 0)
    # improve photo's contours with laplacian
    if laplacian:
        gray=is_laplacian(gray)
    # improve photo's contours
    ret, thresh = cv2.threshold(gray, 150, 155, cv2.THRESH_BINARY)
    adap_thresh = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY, 7, 9)
    if threshold:
       thresh=adap_thresh
    contours, hierarchy = cv2.findContours(thresh, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
    edges = cv2.Canny(adap_thresh, 100, 150)
    return contours,adap_thresh,edges,hierarchy

def is_laplacian(image):
    laplacian = cv2.Laplacian(image, cv2.CV_64F)
    # remove noise from Laplacian
    glass = cv2.bitwise_and(laplacian, laplacian, mask=black_mask)
    glass = np.array((glass)).astype(np.uint8)
    # glass-photo without noise
    cv2.imwrite("glass.jpg", glass)
    gray = cv2.imread("glass.jpg", 0)
    return gray

def mask_by_horizontal_lines(edges,original_images):
    lines = cv2.HoughLinesP(edges, 1, np.pi / 180, 50, minLineLength=100, maxLineGap=100)
    optimal_lines_from_angel=find_optimal_lines_from_angel(lines,original_images)
    lines_deep_learning=k_means_clustering(optimal_lines_from_angel,original_images)
    optimal_lines=average_color_of_the_line(optimal_lines_from_angel,original_images)
    # drawing the border lines
    x1, y1, x2, y2 =  optimal_lines[0]  ## x1,y1 starting point, x2,y2 ending point lower line
    x3, y3, x4, y4 =  optimal_lines[1]  ## x3,y3 starting point, x4,y4 ending point Upper line
    # y=Mx+N, Finding M,N:
    M0, N0 = calculate_linear_equation(x3, y3, x4, y4)
    M1, N1 = calculate_linear_equation(x1, y1, x2, y2)
    # Mask the upper line- bool=1
    white_mask = mask_background_image(original_images, M0, N0, 1, WHITE)
    # Mask the lawer line- bool=0
    white_mask = mask_background_image(white_mask,M1, N1, 0, WHITE)
    # handle with noise
    display_and_save_image("white_mask.jpg", white_mask)
    return white_mask

def find_optimal_lines_from_angel(lines,tresh=0.15):
    optimal_lines=[]
    for i in range(0, len(lines)):
        x1, y1, x2, y2 = lines[i][0]  ## x1,y1 starting point, x2,y2 ending point
        p1 = x2 - x1
        p2 = y2 - y1
        vector = p2 / p1
        angle = np.arctan(vector)
        if (angle < 0.15):
            optimal_lines.append(lines[i][0])
    return optimal_lines


def k_means_clustering(optimal_lines_from_angel,image):
    range_pixel=[]
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    size = gray.shape
    y,x = size[:2]
    range_y = []
    xn=x/2

    for i in range(0,y):
        if(gray[i,int(xn)] != 255):
            range_pixel.append(gray[i,int(xn)])
            range_y.append(i)

    # clf = KNeighborsClassifier(n_neighbors=k, weights='uniform', algorithm='auto', leaf_size=30, p=2, metric='minkowski', metric_params=None, n_jobs=None)
    # clf.fit(data)
    # xx, yy = np.meshgrid(range_pixel, range_y)
    #
    # Z = clf.predict_proba(np.c_[xx.ravel(), yy.ravel()])[:, 1]
    # Z = Z.reshape(xx.shape)
    #
    # # Plot the figure
    # fig = go.Figure(data=[go.Contour(x=range_pixel,y=range_y,z=Z,olorscale='RdBu')])
    # fig.show()
    normalized_range_pixel = (preprocessing.normalize([range_pixel])).squeeze()
    normalized_range_y = (preprocessing.normalize([range_y])).squeeze()
    data = np.array(list(zip(normalized_range_pixel, normalized_range_y)))   # marge 2 list to 1 list (x,level gray)
    data_without_liers=detect_outliers(data)
    k = calculate_optimal_k(data)
    kmeans = KMeans(n_clusters=k,init='random', random_state=0, n_init=10)
    kmeans.fit(data)
    plt.xlabel("gray level")
    plt.ylabel("y")
    plt.scatter(normalized_range_pixel, normalized_range_y, c=kmeans.labels_)
    plt.show()
    kmeans = KMeans(n_clusters=k, random_state=0, n_init="auto").fit(np.array(data).reshape(-1, 1))
    clusters = kmeans.cluster_centers_
    low_handle_cluster_index = np.argmax(clusters)
    low_handle_cluster_value = clusters[low_handle_cluster_index]
    print(low_handle_cluster_value)


def detect_outliers(data):
    #outliers=[]
    treshold=3
    mean=np.mean(data) #Compute the arithmetic mean along the specified axis.
    std=np.std(data) #Compute the standard deviation along the specified axis.
    for i in range(0,len(data)):
        z_score=((data[i][0])-mean)/std
        if np.abs(z_score)>treshold:
            data.remove(data[i][0])

    return data

def calculate_optimal_k(data):
    score_=0
    optimal_k=0
    silhouette_scores = dict()
    range_of_k = range(2,10)
    for k in range_of_k :
        untrained_model = KMeans(n_clusters=k)
        trained_model=untrained_model.fit(data)
        cluster_labels = trained_model.labels_
        score=silhouette_score(data, cluster_labels)
        silhouette_scores[k]=score
        if score>score_:
            optimal_k=k
            score_=score
    silhouette_scores_list = silhouette_scores.items()
    silhouette_scores_list = sorted(silhouette_scores_list)
    n_clusters, score = zip(*silhouette_scores_list)
    #plt.xlabel("n_clusters=K")
    #plt.ylabel("score")
    #plt.plot(n_clusters, score )
    #plt.show()
    #print("The optimal K is:",optimal_k)
    return optimal_k


def average_color_of_the_line(optimal_lines_from_angel,image):
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    average_color_of_image=color_of_image(image)
    optimal_lines=[]
    list_line_average_color=[]
    list_line_average_color_up=[]
    list_line_average_color_down=[]
    count=0
    list_sum_all_lines=[]
    image_copy=image.copy()
    for i in range(0, len(optimal_lines_from_angel)):
        line=optimal_lines_from_angel[i]
        color=0
        color_up=0
        color_down=0
        x1, y1, x2, y2=line
        M1, N1 = calculate_linear_equation(x1, y1, x2, y2)
        for j in range(x1+int(x1/3),x2-int(x2/3)):
            z =int( (M1 * j) + N1)
            # display_and_save_image(0,tmp)
            color=gray[z,j] +color#(255,255,255)+color
            color_up = gray[z -5, j]+color_up
            color_down = gray[z +5, j]+color_down
            count=count+1
            break
        line_average_color=np.floor_divide(color, count)
        line_average_color_up=np.floor_divide(color_up, count)
        line_average_color_down=np.floor_divide(color_down, count)
        list_line_average_color.append(line_average_color)
        list_line_average_color_up.append(line_average_color_up)
        list_line_average_color_down.append(line_average_color_down)
        sum_lines=line_average_color+line_average_color_up+line_average_color_down
        list_sum_all_lines.append(sum_lines)
        #if sum_lines>average_color_of_image:
        optimal_lines.append(line)

    optimal_lines=min_max_optimal_lines(optimal_lines)
    for p in range(0, len(optimal_lines)):
        x1, y1, x2, y2 = optimal_lines[p]  ## x1,y1 starting point, x2,y2 ending point
        cv2.line(image_copy, (x1, y1), (x2, y2), (255, 0, 255), 1, cv2.LINE_AA)
        cv2.imshow("Image line",image_copy)
        cv2.waitKey(0)
    return optimal_lines


def color_of_image(image):
    masked_image,black_mask=mask_background(image)
    gray = cv2.cvtColor(masked_image, cv2.COLOR_BGR2GRAY)
    avg_color=np.mean((gray))
    print(avg_color)
    return avg_color

def frame_cut_improvment(edges,image):
    lines = cv2.HoughLinesP(edges, 1, np.pi / 180, 50, minLineLength=400, maxLineGap=100)
    side_copy = np.copy(image)
    # finding the min line and the max line
    max_line, min_line = min_max_lines(lines)
    x1, y1, x2, y2 = max_line
    x3, y3, x4, y4 = min_line
    cv2.line(side_copy, (x3, y3), (x4, y4), (0, 0, 255), 1, cv2.LINE_AA)  # lower line
    cv2.line(side_copy, (x1, y1), (x2, y2), (0, 0, 255), 1, cv2.LINE_AA)  # upper line
    M0, N0 = calculate_linear_equation(x3, y3, x4, y4)
    M1, N1 = calculate_linear_equation(x1, y1, x2, y2)
    # Mask
    Xn = (x1 + x2) / 4
    noiseless_frame = mask_background_image(image, Xn, y, M1, N1, 0, BLACK)
    noiseless_frame = mask_background_image(noiseless_frame, x, y, M0, N0, 1, BLACK)
    display_and_save_image("Noiseless_frame.jpg", noiseless_frame)
    return noiseless_frame

def find_vertical_lines(image,gray_image):
    #image improvment contour
    adap_thresh = cv2.adaptiveThreshold(gray_image, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY, 7, 3)
    adap_thresh_INV = cv2.bitwise_not(adap_thresh)
    #build image copy
    size= image.shape
    x=size[1]
    side_copy = np.copy(image) #(KEY FOR DEVELOPERS),has no contribut to the algoritem
    #detect lines in image
    lines = cv2.HoughLinesP(adap_thresh_INV, 1, np.pi / 180, 15, minLineLength=30, maxLineGap=5)
    new_lines=convert_3D_array_to_2D(lines)
    vertical_lines = []
    for i in range(new_lines.shape[0]):
        x1, y1, x2, y2 = new_lines[i]
        M, N = calculate_linear_equation(x1, y1, x2, y2)
        if (M >3) and (x1<int(x/2)):
            vertical_lines.append(new_lines[i])
            #line represent (KEY FOR DEVELOPERS),has no contribut to the algoritem
            cv2.line(side_copy, (x1, y1), (x2, y2), (0, 0, 255), 2)
            cv2.imshow('Image with Vertical Lines ', side_copy)
            cv2.waitKey(0)
    M1,N1=detect_optimal_vertical_line(vertical_lines)
    return M1,N1

def convert_3D_array_to_2D(lines):
    num_lines=lines.shape[0]
    vector=lines.shape[2]
    new_lines=[]
    for i in range(len(lines)):
        new_lines.append(lines[i][0])
    new_lines=np.array(lines)
    new_lines=new_lines.reshape(num_lines,vector)
    return new_lines


def detect_optimal_vertical_line(vertical_lines):
    lines=np.array(vertical_lines)
    m_lines = 0
    for i in range (lines.shape[0]-1):
        if (lines[m_lines][0]<lines[i+1][0]):
            m_lines=i+1
    x_start_ver,y_start_ver,x_end_ver,y_end_ver=vertical_lines[m_lines]
    M1,N1 = calculate_linear_equation(x_start_ver,y_start_ver,x_end_ver,y_end_ver)
    return M1,N1




#Change photo scale
side_C,dim_size=photo_rescale("side.jpg")

#size of the photo
x,y=dim_size

#mask glass's background
glasses,black_mask=mask_background(side_C)

#improve image contours
contours,adap_thresh,edges,hierarchy=improve_image_contours("glassesblack.jpg",True,True)

#finding lines in the photo
white_mask=mask_by_horizontal_lines(edges,side_C)

#Drew Largest Area
contours, adap_thresh,edges,hierarchy = improve_image_contours("white_mask.jpg")

frame=finding_largest_area(white_mask,contours)

#improving the glass's frame cutting
noiseless_frame=frame_cut_improvment(edges,frame)
gray_noiseless_frame=cv2.imread("noiseless_frame.jpg",0)

#find vertical lines
M,N=find_vertical_lines(frame,gray_noiseless_frame)
final_frame=mask_background_image(frame,x,y,M,N,0,BLACK)

display_and_save_image("final_frame.jpg",final_frame)