import cv2
import os
os.getcwd()
import numpy as np

WHITE=(255,255,255)
BLACK=(0,0,0)

def display_and_save_image(address, image):
    cv2.imshow('image', image)
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    if address!=0:
        cv2.imwrite(address, image)

def calculate_linear_equation(x1, y1, x2, y2):
    M = ((y2 - y1) / (x2 - x1))  ##M N-equation of Lower line
    N = y2 - (M * x2)
    return M,N

def mask_background_image(image, x, y, M, N, bool, color):
    # Mask the upper line- bool=1
    # Mask the lower line- bool=0
    # Iterate over the rows and columns of the image
    for row, i in enumerate(range(int(x))):
        for col, j in enumerate(range(y)):
            y0 = (M * i) + N
            # Check if j is less than or greater than y0 depending on the value of bool
            if bool:
                if (j < y0):
                    image[col, row] = color
            elif not bool:
                if (j > y0):
                    image[col, row] = color
    return image


def min_max_lines(lines):
    # find_highest_and_lowest_lines
    xMax=lines[0][0][1]
    xLow=lines[0][0][1]
    for i in range(0, 10):
        if (lines[i][0][1] > xMax):
            xMax = lines[i][0][1]
            x1, y1, x2, y2 = lines[i][0]
        if (lines[i][0][1] < xLow):
            xLow = lines[i][0][1]
            x3, y3, x4, y4 = lines[i][0]
    Max_line=x1,y1,x2,y2
    Min_line=x3,y3,x4,y4
    return [Max_line,Min_line]

def finding_largest_area(white_mask,contours):
    # finding the second largest contour
    gray_white_mask= cv2.imread("white_mask.jpg",0)
    mask_tmp = np.zeros(gray_white_mask.shape, np.uint8)
    largest_areas = sorted(contours, key=cv2.contourArea)
    cnt = largest_areas[-2]
    img_contour_tmp = cv2.drawContours(mask_tmp, [cnt], 0, (255, 255, 255, 255), -1)
    frame = cv2.bitwise_and(white_mask, white_mask, mask=img_contour_tmp)
    display_and_save_image("frame.jpg", frame)
    return frame


def photo_rescale(address):
    image = cv2.imread(address, cv2.IMREAD_UNCHANGED)
    siz_ = image.shape
    while(siz_[0]>=1000 and siz_[1]>=1000):
        scale_factor = 2
        dim_size = (siz_[1] // scale_factor, siz_[0] // scale_factor)
        img = cv2.resize(image, dim_size)
        siz_ = img.shape
    display_and_save_image("dside.jpg", img)
    return img,dim_size


def mask_background(image):
    GlassBlackMask = cv2.inRange(image, np.array([245, 245, 245]), np.array([255, 255, 255]))
    # mask glass's background
    black_mask = cv2.bitwise_not(GlassBlackMask)  # mask glass's background
    glasses = cv2.bitwise_and(image, image, mask=black_mask)
    display_and_save_image("glassesblack.jpg",glasses)
    return glasses,black_mask


def improve_image_contours(address,laplacian=False,threshold=False):
    gray = cv2.imread(address, 0)
    # improve photo's contours with laplacian
    if laplacian:
        gray=is_laplacian(gray)
    # improve photo's contours
    ret, thresh = cv2.threshold(gray, 150, 155, cv2.THRESH_BINARY)
    adap_thresh = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY, 7, 9)
    if threshold:
       thresh=adap_thresh
    contours, hierarchy = cv2.findContours(thresh, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
    edges = cv2.Canny(adap_thresh, 100, 150)
    return contours,adap_thresh,edges

def is_laplacian(image):
    laplacian = cv2.Laplacian(image, cv2.CV_64F)
    # remove noise from Laplacian
    glass = cv2.bitwise_and(laplacian, laplacian, mask=black_mask)
    glass = np.array((glass)).astype(np.uint8)
    # glass-photo without noise
    cv2.imwrite("glass.jpg", glass)
    gray = cv2.imread("glass.jpg", 0)
    return gray

def mask_by_horizontal_lines(edges,original_images):
    lines = cv2.HoughLinesP(edges, 1, np.pi / 180, 50, minLineLength=400, maxLineGap=100)
    # drawing the border lines
    x1, y1, x2, y2 = lines[0][0]  ## x1,y1 starting point, x2,y2 ending point lower line
    x3, y3, x4, y4 = lines[1][0]  ## x3,y3 starting point, x4,y4 ending point Upper line
    # y=Mx+N, Finding M,N:
    M0, N0 = calculate_linear_equation(x3, y3, x4, y4)
    M1, N1 = calculate_linear_equation(x1, y1, x2, y2)
    # Mask the upper line- bool=1
    white_mask = mask_background_image(original_images, x, y, M0, N0, 1, WHITE)
    # Mask the lawer line- bool=0
    white_mask = mask_background_image(white_mask, int((x2 + x1) / 2), y, M1, N1, 0, WHITE)
    # handle with noise
    display_and_save_image("white_mask.jpg", white_mask)
    return white_mask

def frame_cut_improvment(edges,image):
    lines = cv2.HoughLinesP(edges, 1, np.pi / 180, 50, minLineLength=400, maxLineGap=100)
    side_copy = np.copy(image)
    # finding the min line and the max line
    max_line, min_line = min_max_lines(lines)
    x1, y1, x2, y2 = max_line
    x3, y3, x4, y4 = min_line
    cv2.line(side_copy, (x3, y3), (x4, y4), (0, 0, 255), 1, cv2.LINE_AA)  # lawer line
    cv2.line(side_copy, (x1, y1), (x2, y2), (0, 0, 255), 1, cv2.LINE_AA)  # upper line
    M0, N0 = calculate_linear_equation(x3, y3, x4, y4)
    M1, N1 = calculate_linear_equation(x1, y1, x2, y2)
    # Mask
    Xn = (x1 + x2) / 4
    noiseless_frame = mask_background_image(image, Xn, y, M1, N1, 0, BLACK)
    noiseless_frame = mask_background_image(noiseless_frame, x, y, M0, N0, 1, BLACK)
    display_and_save_image("Noiseless_frame.jpg", noiseless_frame)
    return noiseless_frame

def find_vertical_lines(image,gray_image):
    adap_thresh = cv2.adaptiveThreshold(gray_image, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY, 5, 3)
    adap_thresh_INV = cv2.bitwise_not(adap_thresh)
    side_copy = np.copy(image)
    lines = cv2.HoughLinesP(adap_thresh_INV, 1, np.pi / 180, 15, minLineLength=30, maxLineGap=5)
    vertical_lines = []
    for line in lines:
        x1, y1, x2, y2 = line[0]
        M, N = calculate_linear_equation(x1, y1, x2, y2)
        if (M > 3):
            vertical_lines.append(line)
    for line in vertical_lines:
        x1, y1, x2, y2 = vertical_lines[3][0]
        M, N = calculate_linear_equation(x1, y1, x2, y2)
        cv2.line(side_copy, (x1, y1), (x2, y2), (0, 0, 255), 2)
        cv2.imshow('Image with Vertical Lines ', side_copy)
        cv2.waitKey(0)
        break
    return M,N


#Change photo scale
side_C,dim_size=photo_rescale("side.jpg")

#size of the photo
x,y=dim_size

#mask glass's background
glasses,black_mask=mask_background(side_C)

#improve image contours
contours,adap_thresh,edges=improve_image_contours("glassesblack.jpg",True,True)

#finding lines in the photo
white_mask=mask_by_horizontal_lines(edges,side_C)

#Drew Largest Area
contours, adap_thresh, edges = improve_image_contours("white_mask.jpg")
frame=finding_largest_area(white_mask,contours)

#improving the glass's frame cutting
noiseless_frame=frame_cut_improvment(edges,frame)
gray_noiseless_frame=cv2.imread("noiseless_frame.jpg",0)

#find vertical lines
M,N=find_vertical_lines(frame,gray_noiseless_frame)
final_frame=mask_background_image(frame,x,y,M,N,0,BLACK)

display_and_save_image(0,final_frame)
