﻿Imports System.Runtime.Intrinsics.X86

Public Class CCurve1
    Public a_coef As Double = 2
    Public b_coef As Double = 0
    Public Function create_aproximation_polynom_to_curve(curve_pixels_arr1 As ArrayList)
        Dim start_x1 As Double = 4
        Dim end_x1 As Double = 8

        Dim start_y_val1 As Double = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pixels_arr1, 0)(1)
        Dim end_y_val1 As Double = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pixels_arr1, curve_pixels_arr1.Count - 1)(1)

        Dim polynom_start_y_val1 As Double = -get_y_polynom_value1(start_x1)
        Dim polynom_end_y_val1 As Double = -get_y_polynom_value1(end_x1)

        Dim to_stop1 As Integer = 0
        While to_stop1 = 0
            If start_y_val1 < end_y_val1 And polynom_start_y_val1 < polynom_end_y_val1 Then
                to_stop1 = 1
            Else
                end_x1 += 1
            End If
        End While
    End Function

    Public Function get_y_polynom_value1(x_val1 As Double)
        Dim y_val1 As Double = a_coef * Math.Pow(x_val1, 2) + b_coef

        Return y_val1
    End Function


    Public Function create_polynom_curve_pxl_arr1(start_x1 As Double, end_x1 As Double, range_width1 As Integer, max_width1 As Integer)

        Dim img_width1 As Integer = range_width1
        Dim x1 As Double
        Dim y1 As Integer
        Dim curve_obj1 As CCurve1 = New CCurve1()
        Dim max_y1 As Double = -99999
        Dim min_y1 As Double = 99999
        Dim y_vals_arr1 As ArrayList = New ArrayList()
        Dim x_vals_arr1 As ArrayList = New ArrayList()

        Dim x_ind1 As Integer = 0
        Dim polynom_obj1 As CPolynom1 = New CPolynom1()
        polynom_obj1.polynom_name1 = "1"
        polynom_obj1.coef_arr1.Add(-2.8)
        polynom_obj1.coef_arr1.Add(0)
        Dim polynom_obj2 As CPolynom1 = New CPolynom1()
        polynom_obj2.polynom_name1 = "2"
        polynom_obj2.coef_arr1.Add(-3.7)
        polynom_obj2.coef_arr1.Add(0)


        Dim polynom_obj3 As CPolynom1 = New CPolynom1()
        polynom_obj3.polynom_name1 = "3"
        polynom_obj3.coef_arr1.Add(-5)
        polynom_obj3.coef_arr1.Add(0)

        'For x1 = start_x1 To end_x1
        x1 = start_x1
        Dim current_polynom_obj1 As CPolynom1 = polynom_obj1
        Dim delta_x1 As Double = 0
        For ind_x1 = 0 To max_width1 - 1 'img_width1 - 1
            Dim y_val1 As Double = current_polynom_obj1.get_y_polynom_value1(x1 - delta_x1)
            Dim derivate_val1 As Double = current_polynom_obj1.get_polynom_derivate_value1(x1 - delta_x1)
            If ind_x1 = 300 And current_polynom_obj1.polynom_name1 = "1a" Then
                Dim x_val2 As Double = polynom_obj2.get_x_val_by_derivate1(derivate_val1)
                delta_x1 = x1 - x_val2
                polynom_obj2.change_coef_2_by_val(x1 - delta_x1, y_val1)
                current_polynom_obj1 = polynom_obj2

            End If

            If ind_x1 = 860 And current_polynom_obj1.polynom_name1 = "2a" Then
                Dim x_val2 As Double = polynom_obj3.get_x_val_by_derivate1(derivate_val1)
                delta_x1 = x1 - x_val2
                polynom_obj3.change_coef_2_by_val(x1 - delta_x1, y_val1)
                current_polynom_obj1 = polynom_obj3

            End If


            'bmp1.SetPixel(x1, 2000 - y_val1, Color.FromArgb(100, 50, 100))
            y_vals_arr1.Add(y_val1)
            If max_y1 < y_val1 Then
                max_y1 = y_val1
            End If

            If min_y1 > y_val1 Then
                min_y1 = y_val1
            End If
            x_vals_arr1.Add(x1)
            x1 += (end_x1 - start_x1) / img_width1
        Next

        Dim div_y_range1 As Double = 1 '(img_height1 - 50) / Math.Abs(min_y1 - max_y1)
        Dim div_x_range1 As Double = (img_width1 - 50) / Math.Abs(end_x1 - start_x1)


        Dim new_y_arr1 As ArrayList = New ArrayList()
        Dim add_y1 As Double = -1
        'If min_y1 < 0 Then
        'add_y1 = -min_y1
        'End If
        add_y1 = -min_y1
        Dim polynom_curve1 As ArrayList = New ArrayList()

        'For x1 = start_x1 To end_x1
        For ind_x1 = 0 To max_width1 - 1 ' img_width1 - 1

            'Next
            Dim y_val1 As Integer = y_vals_arr1(ind_x1) + add_y1 'y_vals_arr1(ind_x1) * div_y_range1 - (y_vals_arr1(0) * div_y_range1)
            Dim x_val1 As Integer = ind_x1 'x1 * div_x_range1 - (start_x1 * div_x_range1)
            new_y_arr1.Add(y_val1)


            x_ind1 += 1

            polynom_curve1.Add(x_val1.ToString() + "," + y_val1.ToString())
            'x1 += (end_x1 - start_x1) / img_width1

        Next

        Return polynom_curve1
    End Function


    Public Function create_polynom_curve_pxl_arr2(start_x1 As Double, end_x1 As Double, range_width1 As Integer, max_x_steps1 As Integer, coef1 As Double)

        Dim img_width1 As Integer = range_width1
        Dim x1 As Double
        Dim y1 As Integer
        Dim curve_obj1 As CCurve1 = New CCurve1()
        Dim max_y1 As Double = -99999
        Dim min_y1 As Double = 99999
        Dim y_vals_arr1 As ArrayList = New ArrayList()
        Dim x_vals_arr1 As ArrayList = New ArrayList()

        Dim x_ind1 As Integer = 0
        Dim polynom_obj1 As CPolynom1 = New CPolynom1()
        polynom_obj1.polynom_name1 = "1"
        polynom_obj1.coef_arr1.Add(coef1)
        polynom_obj1.coef_arr1.Add(0)

        'For x1 = start_x1 To end_x1
        x1 = start_x1
        Dim current_polynom_obj1 As CPolynom1 = polynom_obj1
        Dim delta_x1 As Double = 0
        Dim last_y_val1 As Double = -1
        Dim polynom_curve1 As ArrayList = New ArrayList()
        Dim to_stop1 As Integer = 0
        While to_stop1 = 0
            Dim y_val1 As Double = current_polynom_obj1.get_y_polynom_value1(x1 - delta_x1)
            Dim derivate_val1 As Double = current_polynom_obj1.get_polynom_derivate_value1(x1 - delta_x1)



            'bmp1.SetPixel(x1, 2000 - y_val1, Color.FromArgb(100, 50, 100))
            y_vals_arr1.Add(y_val1)
            If max_y1 < y_val1 Then
                max_y1 = y_val1
            End If

            If min_y1 > y_val1 Then
                min_y1 = y_val1
            End If
            x_vals_arr1.Add(x1)
            x1 += (end_x1 - start_x1) / max_x_steps1
            'x1 += range_width1 / max_x_steps1
            If polynom_curve1.Count >= max_x_steps1 Then ' (x1 - delta_x1) >= max_x_val1 Then
                to_stop1 = 1
            Else
                polynom_curve1.Add(x1.ToString() + "," + y_val1.ToString())
            End If
            last_y_val1 = y_val1
        End While


        Dim div_y_range1 As Double = 1 '(img_height1 - 50) / Math.Abs(min_y1 - max_y1)
        Dim div_x_range1 As Double = (img_width1 - 50) / Math.Abs(end_x1 - start_x1)


        Dim new_y_arr1 As ArrayList = New ArrayList()
        Dim add_y1 As Double = -1
        'If min_y1 < 0 Then
        'add_y1 = -min_y1
        'End If
        add_y1 = -min_y1

        For ind_x1 = 0 To polynom_curve1.Count - 1
            Dim cord_xy1 As Double() = CGlobals1.get_double_cord_xy_in_pixels_arr2(polynom_curve1, ind_x1)
            cord_xy1(1) += add_y1
            polynom_curve1(ind_x1) = cord_xy1(0).ToString() + "," + cord_xy1(1).ToString()

        Next
        Return polynom_curve1

        'For x1 = start_x1 To end_x1
        For ind_x1 = 0 To range_width1 - 1 ' img_width1 - 1

            'Next
            Dim y_val1 As Integer = y_vals_arr1(ind_x1) + add_y1 'y_vals_arr1(ind_x1) * div_y_range1 - (y_vals_arr1(0) * div_y_range1)
            Dim x_val1 As Integer = ind_x1 'x1 * div_x_range1 - (start_x1 * div_x_range1)
            new_y_arr1.Add(y_val1)


            x_ind1 += 1

            polynom_curve1.Add(x_val1.ToString() + "," + y_val1.ToString())
            'x1 += (end_x1 - start_x1) / img_width1

        Next

        Return polynom_curve1
    End Function


End Class
