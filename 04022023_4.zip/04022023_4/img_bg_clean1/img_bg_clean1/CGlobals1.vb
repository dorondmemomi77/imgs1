﻿Imports System.IO

Imports System.Text.Json


Public Class CGlobals1


    Public Shared poly_dec_add_range_factor1 As Double = 1
    Public Shared max_pixels_arr_length1 As Integer = -1
    Public Shared dict_sobel_pixels As Dictionary(Of Double, ArrayList) = New Dictionary(Of Double, ArrayList)
    Public Shared current_sobel_threshold As Integer
    Public Shared last_sobel_threshold As Integer
    Public Shared current_bmp1 As Bitmap

    Public Shared dir_arr1 As Integer(,) = {{-1, -1}, {0, -1}, {1, -1}, {1, 0}, {1, 1}, {0, 1}, {-1, 1}, {-1, 0}, {-1, -1}, {0, -1}, {1, -1}, {1, 0}, {1, 1}, {0, 1}, {-1, 1}, {-1, 0}}
    Public Shared dir_arr1_rev As Integer(,) = {{-1, -1}, {0, -1}, {1, -1}, {1, 0}, {1, 1}, {0, 1}, {-1, 1}, {-1, 0}, {-1, -1}, {0, -1}, {1, -1}, {1, 0}, {1, 1}, {0, 1}, {-1, 1}, {-1, 0}}
    Public Shared dir_arr2 As Integer(,) = {{-1, -1}, {0, -1}, {1, -1}, {1, 0}, {1, 1}, {0, 1}, {-1, 1}, {-1, 0}}

    Public Shared dir_arr4 As Integer(,) = {{-2, -2}, {-1, -2}, {0, -2}, {1, -2}, {2, -2}, {2, -1}, {2, 0}, {2, 1}, {2, 2}, {1, 2}, {0, 2}, {-1, 2}, {-2, 2}, {-2, 1}, {-2, 0}, {-2, -1}}
    Public Shared dir_arr3 As Integer(,) = {{0, -1}, {1, 0}, {0, 1}, {-1, 0}}

    Public Shared global_vars_dict1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)

    Public Shared global_suffix_file_name1 As String = ""
    Public Shared global_path1 As String = "D:\\glass_pics1\\"
    Public Shared sobel_pics_path1 As String = "sobel_pics1\\"
    Public Shared path_of_sobel_cache1 As String = "D:\\glass_pics1\\"

    Public Shared dict_3d_pnts_arrs1 As Dictionary(Of String, ArrayList) = New Dictionary(Of String, ArrayList)

    Public Shared current_start_x1 As Double
    Public Shared current_start_y1 As Double
    Public Shared dir_x1_to_sobel As Double
    Public Shared dir_m1_to_sobel As Double

    Public Shared step_num1 As Integer = 0
    Public Shared max_sobel_length_bmp1 As Bitmap

    Public Shared current_max_arr_sobel As ArrayList

    Public Shared max_dist_between_sobel_line1 As Double = 1 'המרחק המינימלי בין 2 היקפים של סובלים סמוכים שמביא לעצירה
    Public Shared min_pixel_arr_count1 As Integer = 200 'האורך המינימלי של ההיקף שעוברים על הסובל
    Public Shared min_pixel_x1 As Integer = -1 'האורך המינימלי של ההיקף שעוברים על הסובל
    Public Shared max_pixel_x1 As Integer = -1 'האורך המינימלי של ההיקף שעוברים על הסובל

    Public Shared ind1 As Integer = 0

    Public Shared last_dict_sobel_line_pixels1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)
    Public Shared max_count_pixels1 As Integer = -1
    Public Shared max_last_index_all_exist_in_prev_pixels1 As Integer = -1

    Public Shared current_max_sobel_ind1 As Integer = -1


    Public Shared form_obj1 As Form1
    Public Shared dict_mono_colors1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)


    Public Shared Function clear_all_caches1()
        dict_sobel_pixels.Clear()
        global_vars_dict1.Clear()
        last_dict_sobel_line_pixels1.Clear()
    End Function
    Public Shared Function update_label_progress(str1 As String)
        form_obj1.lbl_progress1.Text = str1
        Application.DoEvents()
    End Function

    Public Shared Function compare_colors1(color1 As Color, color2 As Color)
        If color1.R = color2.R And color1.G = color2.G And color1.B = color2.B Then
            Return 1
        End If

        Return 0
    End Function

    Public Shared Function copy_bitmap1(bmp1 As Bitmap)
        Dim bmp2 As Bitmap = New Bitmap(bmp1.Width, bmp1.Height)
        Dim gr As Graphics = Graphics.FromImage(bmp2)

        ' Get source and destination rectangles.
        'Dim fr_rect As New Rectangle(0, 0, 70, 50)
        Dim fr_rect As New Rectangle(0, 0, bmp1.Width, bmp1.Height)
        Dim to_rect As New Rectangle(0, 0, bmp2.Width, bmp2.Height)

        ' Draw from the source to the destination.
        gr.DrawImage(bmp1, to_rect, fr_rect, GraphicsUnit.Pixel)


        Return bmp2
    End Function

    Public Shared Function crop_bitmap(src_bmp1 As Bitmap, x_in_src1 As Integer, y_in_src1 As Integer, w_in_src1 As Integer, h_in_src1 As Integer)

        Dim bmp2 As Bitmap = New Bitmap(w_in_src1, h_in_src1)
        Dim gr As Graphics = Graphics.FromImage(bmp2)

        ' Get source and destination rectangles.
        'Dim fr_rect As New Rectangle(0, 0, 70, 50)
        Dim to_rect As New Rectangle(0, 0, w_in_src1, h_in_src1)
        Dim fr_rect As New Rectangle(x_in_src1, y_in_src1, w_in_src1, h_in_src1)

        ' Draw from the source to the destination.
        gr.DrawImage(src_bmp1, to_rect, fr_rect, GraphicsUnit.Pixel)


        Return bmp2
    End Function
    Public Shared Function copy_bitmap_2_bitmap1(src_bmp1 As Bitmap, trgt_bmp1 As Bitmap, x_in_trgt1 As Integer, y_in_trgt1 As Integer)

        'Dim bmp2 As Bitmap = New Bitmap(bmp1.Width, bmp1.Height)
        Dim gr As Graphics = Graphics.FromImage(src_bmp1)

        ' Get source and destination rectangles.
        'Dim fr_rect As New Rectangle(0, 0, 70, 50)
        Dim to_rect As New Rectangle(x_in_trgt1, y_in_trgt1, src_bmp1.Width, src_bmp1.Height)
        Dim fr_rect As New Rectangle(0, 0, src_bmp1.Width, src_bmp1.Height)

        ' Draw from the source to the destination.
        gr.DrawImage(trgt_bmp1, to_rect, fr_rect, GraphicsUnit.Pixel)


        Return src_bmp1
    End Function

    Public Shared Function save_pxl_arr_log1(pxls_arr1 As ArrayList, path_of_log_bmp1 As String)
        Dim bmp1 As Bitmap = CGlobals1.create_fill_bitmap(4000, 3000, Color.FromArgb(255, 255, 255))
        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(pxls_arr1, bmp1, Color.FromArgb(24, 230, 50))
        bmp1.Save(path_of_log_bmp1)
        Return bmp1
    End Function
    Public Shared Function create_fill_bitmap(w1 As Integer, h1 As Integer, fill_color1 As Color)
        Dim bmp1 As Bitmap = New Bitmap(w1, h1)

        Dim x1 As Integer
        Dim y1 As Integer



        Dim gfx As Graphics = Graphics.FromImage(bmp1)
        Dim brush As SolidBrush = New SolidBrush(fill_color1)
        gfx.FillRectangle(brush, 0, 0, w1, h1)
        Return bmp1

    End Function

    Public Function remove_item_by_val_in_arr1(arr1 As ArrayList, item_val_to_remove1 As String)
        Dim i1 As Integer = arr1.Count
        While i1 >= 0
            If arr1(i1) = item_val_to_remove1 Then
                arr1.RemoveAt(i1)
            Else
                i1 -= 1
            End If
        End While
    End Function

    Public Shared Function get_cord_xy_in_pixels_arr1(pixels_arr1 As ArrayList, cord_ind1 As Integer)
        Dim x1 As Integer = Double.Parse(pixels_arr1(cord_ind1).ToString().Split(",")(0))
        Dim y1 As Integer = Double.Parse(pixels_arr1(cord_ind1).ToString().Split(",")(1))
        Return {x1, y1}
    End Function

    Public Shared Function get_double_cord_xy_in_pixels_arr2(pixels_arr1 As ArrayList, cord_ind1 As Integer)
        Dim x1 As Double = Double.Parse(pixels_arr1(cord_ind1).ToString().Split(",")(0))
        Dim y1 As Double = Double.Parse(pixels_arr1(cord_ind1).ToString().Split(",")(1))
        Return {x1, y1}
    End Function
    Public Shared Function get_min_value_in_arraylist1(arr1 As ArrayList, Optional abs_value1 As Boolean = False)
        Dim i1 As Integer
        If arr1.Count <= 0 Then
            Return Nothing
        End If
        Dim min_value1 As Double = arr1(0)
        If abs_value1 = True Then
            min_value1 = Math.Abs(arr1(0))
        End If
        For i1 = 1 To arr1.Count - 1
            If abs_value1 = True Then
                If min_value1 > Math.Abs(arr1(i1)) Then
                    min_value1 = Math.Abs(arr1(i1))
                End If
            Else
                If min_value1 > arr1(i1) Then
                    min_value1 = arr1(i1)
                End If

            End If
        Next

        Return min_value1
    End Function


    Public Shared Function get_max_value_in_arraylist1(arr1 As ArrayList, Optional abs_value1 As Boolean = False)
        Dim i1 As Integer
        If arr1.Count <= 0 Then
            Return Nothing
        End If
        Dim max_value1 As Double = arr1(0)
        If abs_value1 = True Then
            max_value1 = Math.Abs(arr1(0))
        End If
        For i1 = 1 To arr1.Count - 1
            If abs_value1 = True Then
                If max_value1 < Math.Abs(arr1(i1)) Then
                    max_value1 = Math.Abs(arr1(i1))
                End If
            Else
                If max_value1 > arr1(i1) Then
                    max_value1 = arr1(i1)
                End If

            End If
        Next

        Return max_value1
    End Function


    Public Shared Function count_value_in_arraylist1(arr1 As ArrayList, min_value1 As Double, max_value1 As Double)
        Dim i1 As Integer
        Dim count_value1 As Integer = 0
        If arr1.Count <= 0 Then
            Return 0
        End If


        For i1 = 0 To arr1.Count - 1
            If arr1(i1) >= min_value1 And arr1(i1) <= max_value1 Then
                count_value1 += 1
            End If

        Next

        Return count_value1
    End Function

    Public Shared Function find_max_seq_that_val_between1(arr1 As ArrayList, min_value1 As Double, max_value1 As Double)

        Dim ind1 As Integer
        ind1 = 0
        Dim to_stop1 As Integer = 0
        Dim seq_arr1 As ArrayList = New ArrayList()
        If arr1.Count <= 20 Then
            Return seq_arr1
        End If
        While to_stop1 = 0

            While arr1(ind1) < min_value1 Or arr1(ind1) > max_value1 And ind1 < arr1.Count - 2

                ind1 += 1

                If ind1 >= arr1.Count - 1 Then
                    to_stop1 = 1
                    Return seq_arr1
                End If


            End While
            Dim ind2 As Integer = ind1
            While arr1(ind2) >= min_value1 And arr1(ind2) <= max_value1 And ind2 < arr1.Count - 2
                ind2 += 1
                If ind1 >= arr1.Count - 1 Then
                    to_stop1 = 1
                    Return seq_arr1
                End If
            End While
            seq_arr1.Add(ind1.ToString() + "," + ind2.ToString())
            ind1 = ind2

            If ind1 >= arr1.Count - 2 Then
                to_stop1 = 1
            End If

        End While
        Return seq_arr1

    End Function

    Public Shared Function sord_dict_by_key2(dict_obj1 As Object)
        'Dim sorted1 = From pair In dict_obj1
        'Order By pair.Value
        'Dim sortedDictionary1 = sorted1.ToDictionary(Function(p) p.Key, Function(p) p.Value)
        'dict_max_right_len1 = sortedDictionary1

    End Function


    Public Shared Function draw_sqr_around_pixels(bmp1 As Bitmap, x1 As Integer, y1 As Integer, sqr_radius1 As Integer, color1 As Color)
        Dim x1a As Integer
        Dim y1a As Integer
        Dim copy_bmp1 As Bitmap = CGlobals1.copy_bitmap1(bmp1)
        For x1a = x1 - sqr_radius1 To x1 + sqr_radius1
            For y1a = y1 - sqr_radius1 To y1 + sqr_radius1
                copy_bmp1.SetPixel(x1a, y1a, color1)
            Next

        Next

        Return copy_bmp1
    End Function

    Public Shared Function draw_sqr_around_pixels2(ByRef bmp1 As Bitmap, x1 As Integer, y1 As Integer, sqr_radius1 As Integer, color1 As Color)
        Dim x1a As Integer
        Dim y1a As Integer

        For x1a = x1 - sqr_radius1 To x1 + sqr_radius1
            For y1a = y1 - sqr_radius1 To y1 + sqr_radius1
                bmp1.SetPixel(x1a, y1a, color1)
            Next

        Next

        Return bmp1
    End Function

    Public Shared Function add_to_dict1(arr1 As ArrayList)
        Dim dict1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)
        Dim i1 As Integer

        For i1 = 0 To arr1.Count - 1
            dict1(arr1(i1)) = i1
        Next

        Return dict1
    End Function

    Public Shared Function arr_xy_to_dict2(arr1 As ArrayList)
        Dim dict1 As Dictionary(Of Integer, Integer) = New Dictionary(Of Integer, Integer)
        Dim i1 As Integer

        For i1 = 0 To arr1.Count - 1
            Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(arr1, i1)
            dict1(cord_xy1(0)) = cord_xy1(1)
        Next

        Return dict1
    End Function

    Public Shared Function dict_keys_to_arr1(dict_keys1 As Dictionary(Of String, Integer))

        Dim i1 As Integer
        Dim new_arr1 As ArrayList = New ArrayList()

        For i1 = 0 To dict_keys1.Keys.Count - 1
            new_arr1.Add(dict_keys1.Keys(i1))
        Next

        Return new_arr1
    End Function


    Public Shared Function convert_2darr_to_3d_arr(arr_2d As ArrayList)
        Dim i1 As Integer

        Dim new_3d_arr1 As ArrayList = New ArrayList()

        For i1 = 0 To arr_2d.Count - 1
            Dim point_3d_obj1 As point_3d1 = New point_3d1()
            point_3d_obj1.x1 = Double.Parse(arr_2d(i1).ToString().Split(",")(0).ToString())
            point_3d_obj1.y1 = Double.Parse(arr_2d(i1).ToString().Split(",")(1).ToString())
            point_3d_obj1.z1 = 0
            new_3d_arr1.Add(point_3d_obj1)

        Next
        Return new_3d_arr1
    End Function


    Public Shared Function get_arr_from_ind_to_ind1(arr1 As ArrayList, start_ind1 As Integer, end_ind1 As Integer)
        Dim new_arr1 As ArrayList = New ArrayList()
        If start_ind1 <= end_ind1 Then
            Dim i1 As Integer = start_ind1

            For i1 = start_ind1 To Math.Min(end_ind1, arr1.Count - 1)
                new_arr1.Add(arr1(i1))

            Next

        End If


        If end_ind1 < start_ind1 Then

            For i1 = start_ind1 To arr1.Count - 1
                new_arr1.Add(arr1(i1))

            Next


            For i1 = 0 To Math.Min(end_ind1, arr1.Count - 1) 'end_ind1
                new_arr1.Add(arr1(i1))

            Next

        End If

        Return new_arr1

    End Function
    Public Shared Function add_val_to_pxls_arr1(pxls_arr1 As ArrayList, add_x1 As Integer, add_y1 As Integer)
        Dim i1 As Integer
        Dim new_pxls_arr1 As ArrayList = New ArrayList()

        For i1 = 0 To pxls_arr1.Count - 1
            Dim cord_xy1 As Integer() = get_cord_xy_in_pixels_arr1(pxls_arr1, i1)
            cord_xy1(0) += add_x1
            cord_xy1(1) += add_y1
            new_pxls_arr1.Add(cord_xy1(0).ToString() + "," + cord_xy1(1).ToString())
        Next

        Return new_pxls_arr1
    End Function


    Public Shared Function read_int_if_exist(key_path1 As String, ByRef key_val1 As Integer)
        If System.IO.File.Exists(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_" + key_path1 + ".txt") Then
            key_val1 = Integer.Parse(System.IO.File.ReadAllText(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_" + key_path1 + ".txt"))
            Return key_val1
        End If
    End Function

    Public Shared Function write_int1(key_path1 As String, key_val1 As Integer)
        System.IO.File.WriteAllText(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_" + key_path1 + ".txt", key_val1.ToString())
        'If System.IO.File.Exists(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_" + key_path1 + ".txt") Then
        'Dim val1 As Integer = Integer.Parse(System.IO.File.ReadAllText(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_" + key_path1 + ".txt"))
        'Return val1
        'End If
    End Function

    Public Shared Function conv_2d_arr_to_2d_cords_dict1(arr1 As ArrayList)
        Dim i1 As Integer
        Dim dict_cords1 As Dictionary(Of Integer, Integer()) = New Dictionary(Of Integer, Integer())
        For i1 = 0 To arr1.Count - 1
            dict_cords1(i1) = CGlobals1.get_cord_xy_in_pixels_arr1(arr1, i1)
        Next

        Return dict_cords1
    End Function

    Public Shared Function is_pixels_arr_overlap_pixels_dict1(pixels_arr1 As ArrayList, pixels_dict As Dictionary(Of String, Integer))
        For i1 = 0 To pixels_arr1.Count - 1
            If pixels_dict.ContainsKey(pixels_arr1(i1)) = True Then
                Return 1
            End If
        Next

        Return 0
    End Function



    Public Shared Function delete_files1(path1 As String, pattern1 As String)
        Dim files1 As String() = System.IO.Directory.GetFiles(path1, pattern1)

        Dim i1 As Integer

        For i1 = 0 To files1.Length - 1
            System.IO.File.Delete(files1(i1))
        Next
    End Function

    Public Shared Function json_to_dict_prms1(json_str1 As String)
        Dim json_obj1 As System.Text.Json.JsonDocument
        Dim dict_res1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
        Try
            json_obj1 = System.Text.Json.JsonDocument.Parse(json_str1)


            Dim dict1 As Dictionary(Of String, String) = System.Text.Json.JsonSerializer.Deserialize(Of Dictionary(Of String, String))(json_obj1)

            Dim i1 As Integer


            While dict1.Keys.Count > 0
                If dict1.ContainsKey(dict1.Keys(0) + "_type1") Then
                    Dim type1 As String = dict1(dict1.Keys(0) + "_type1")
                    If type1.ToLower() = "system.double" Then
                        dict_res1(dict1.Keys(0)) = Double.Parse(dict1(dict1.Keys(0)))
                    End If
                    If type1.ToLower() = "system.string" Then
                        dict_res1(dict1.Keys(0)) = dict1(dict1.Keys(0))
                    End If
                    If type1.ToLower() = "system.integer" Then
                        dict_res1(dict1.Keys(0)) = Integer.Parse(dict1(dict1.Keys(0)))
                    End If
                    If type1.ToLower() = "system.int32" Then
                        dict_res1(dict1.Keys(0)) = Integer.Parse(dict1(dict1.Keys(0)))
                    End If




                    Dim key1 As String = dict1.Keys(0)
                    dict1.Remove(key1)
                    dict1.Remove(key1 + "_type1")
                End If
            End While

            Dim str1 As String = json_obj1.RootElement.GetProperty("error1").GetString()

            If str1.Trim() = "yes" Then
                Dim d3 As Integer = 1
            End If
            'Dim str1 As String = json_ele_obj1(0).GetRawText()
            Dim d1 As Integer = 1
        Catch ex As Exception
            Dim d1 As Integer = 1
        End Try

        Return dict_res1
    End Function
    Public Shared Function save_dict_prms1(dict_prm1 As Dictionary(Of String, Object), path_to_save1 As String)


        'json_to_dict_prms1(json_str1)

        System.IO.File.WriteAllText(path_to_save1, CGlobals1.dict_prm_to_json_str(dict_prm1))

    End Function

    Public Shared Function dict_prm_to_json_str(dict_prm1 As Dictionary(Of String, Object))
        Dim i1 As Integer
        Dim geresh_str1 As String = Chr(34)
        Dim geresh1 As String = Chr(34)
        Dim json_str1 As String = ""
        For i1 = 0 To dict_prm1.Keys.Count - 1
            Dim type1 As String = dict_prm1(dict_prm1.Keys(i1)).GetType.ToString()

            If type1.Contains("Dictionary") = True Then
                'save_dict_prms1(dict_prm1(dict_prm1.Keys(i1)))
            ElseIf type1 = "System.Double" Or type1 = "System.String" Or type1 = "System.Integer" Or type1 = "System.Int32" Then
                If json_str1 <> "" Then
                    json_str1 += ","
                End If
                json_str1 += geresh1 + dict_prm1.Keys(i1).ToString() + geresh1 + ":" + geresh1 + dict_prm1(dict_prm1.Keys(i1)).ToString() + geresh1
                If json_str1 <> "" Then
                    json_str1 += ","
                End If
                json_str1 += geresh1 + dict_prm1.Keys(i1).ToString() + "_type1" + geresh1 + ":" + geresh1 + dict_prm1(dict_prm1.Keys(i1)).GetType().ToString() + geresh1
            End If
            Dim d1 As Integer = 1
        Next
        'json_str1 = "{" + geresh1 + "root1" + geresh1 + ":{" + json_str1 + "}}"
        json_str1 = "{" + json_str1 + "}"

        Return json_str1
    End Function


    Public Shared Function zoom_curve1(curve_pxls_arr1 As ArrayList, mul_factor1 As Double)
        Dim i1 As Integer
        Dim new_curve_pxls_arr1 As ArrayList = New ArrayList()

        For i1 = 0 To curve_pxls_arr1.Count - 1
            new_curve_pxls_arr1.Add((CGlobals1.get_double_cord_xy_in_pixels_arr2(curve_pxls_arr1, i1)(0) * mul_factor1).ToString() + "," + (CGlobals1.get_double_cord_xy_in_pixels_arr2(curve_pxls_arr1, i1)(1) * mul_factor1).ToString())
        Next

        Return new_curve_pxls_arr1
    End Function


    Public Shared Function add_to_txt_log1(msg_str1 As String)
        CGlobals1.form_obj1.txtbox_log1.Text = msg_str1 + Chr(13) + Chr(10) + CGlobals1.form_obj1.txtbox_log1.Text
        Application.DoEvents()
    End Function

    Public Shared Function add_to_txt_log2(msg_str1 As String)
        CGlobals1.form_obj1.txtbox_log2.Text = msg_str1 + Chr(13) + Chr(10) + CGlobals1.form_obj1.txtbox_log2.Text
        Application.DoEvents()
    End Function

    Public Shared Function get_current_glass_folder1()
        Dim path1 As String = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1

        Dim path2 As String = path1.Substring(0, path1.LastIndexOf("\"))
        Return path2
    End Function
End Class
