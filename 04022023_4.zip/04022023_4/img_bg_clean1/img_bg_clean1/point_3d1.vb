﻿Public Class point_3d1
    Public x1 As Double
    Public y1 As Double
    Public z1 As Double

    Sub New(in_x1 As Double, in_y1 As Double, in_z1 As Double)
        x1 = in_x1
        y1 = in_y1
        z1 = in_z1
    End Sub

    Sub New()

    End Sub
    Public Function clone1()
        Dim new_point_3d As point_3d1 = New point_3d1(x1, y1, z1)


        Return new_point_3d
    End Function



    Public Function rotate_x1(rot_deg1 As Double)
        Dim rot_deg2 As Double = rot_deg1 * Math.PI / 180.0
        Dim new_y1 As Double = y1 * Math.Cos(rot_deg2) - z1 * Math.Sin(rot_deg2)
        Dim new_z1 As Double = y1 * Math.Sin(rot_deg2) + z1 * Math.Cos(rot_deg2)
        y1 = new_y1
        z1 = new_z1
    End Function


    Public Function rotate_y1(rot_deg1 As Double)
        Dim rot_deg2 As Double = rot_deg1 * Math.PI / 180.0
        Dim new_z1 As Double = z1 * Math.Cos(rot_deg2) - x1 * Math.Sin(rot_deg2)
        Dim new_x1 As Double = z1 * Math.Sin(rot_deg2) + x1 * Math.Cos(rot_deg2)
        z1 = new_z1
        x1 = new_x1
    End Function

    Public Function rotate_z1(rot_deg1 As Double)
        Dim rot_deg2 As Double = rot_deg1 * Math.PI / 180.0
        Dim new_x1 As Double = x1 * Math.Cos(rot_deg2) - y1 * Math.Sin(rot_deg2)
        Dim new_y1 As Double = x1 * Math.Sin(rot_deg2) + y1 * Math.Cos(rot_deg2)
        x1 = new_x1
        y1 = new_y1
    End Function






End Class
