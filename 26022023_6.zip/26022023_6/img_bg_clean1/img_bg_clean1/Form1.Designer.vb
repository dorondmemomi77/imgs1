﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.load_img_btn1 = New System.Windows.Forms.Button()
        Me.next_edge_pixel_btn1 = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.start_timer_btn1 = New System.Windows.Forms.Button()
        Me.txtbox_curent_sobel_threshold1 = New System.Windows.Forms.TextBox()
        Me.update_sobel_threshold_btn1 = New System.Windows.Forms.Button()
        Me.minus_sobel_btn1 = New System.Windows.Forms.Button()
        Me.plus_sobel_btn1 = New System.Windows.Forms.Button()
        Me.find_sobel_btn1 = New System.Windows.Forms.Button()
        Me.remove_bg_btn1 = New System.Windows.Forms.Button()
        Me.lbl_cur_path1 = New System.Windows.Forms.Label()
        Me.select_file_btn1 = New System.Windows.Forms.Button()
        Me.chkbox_compute_sobel = New System.Windows.Forms.CheckBox()
        Me.txtbox_sobel_factor1 = New System.Windows.Forms.TextBox()
        Me.save_cur_image_btn1 = New System.Windows.Forms.Button()
        Me.txtbox_last_cord1 = New System.Windows.Forms.TextBox()
        Me.lbl_root_path1 = New System.Windows.Forms.Label()
        Me.find_vertical_center_line1_btn1 = New System.Windows.Forms.Button()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.Main1ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FindCurveOfHandlesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FindFrameOfGlassesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CutHandlesFromFrameToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RemoveHandleAboveTheFrame1ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LoadSobelArrBySobelIndToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ShownextpixelToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FindLinesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LoadLinesArrBySobelIndToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FindMaxLineInGlassToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SobelOnSobelToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Preparedataset1ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SignSobelToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ShowCurvesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SearchForStartPoint1ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FilterCurve1ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TunningCurveToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Polynomfit1ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Printpolynoms1ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Backpixel1ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Nextpixel1ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Nextline1ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Nextcurve1ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ShowPrespetive3dToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddXDeg3dToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RemoveBgProcToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CreateSobelImgsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FindTheSobelValueToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RemoveBgToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Main2ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReplaceCurveWithPolynom1ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.txtbox_cur_pixel_ind1 = New System.Windows.Forms.TextBox()
        Me.lbl_progress1 = New System.Windows.Forms.Label()
        Me.add_end_x_polynom1 = New System.Windows.Forms.Button()
        Me.dec_end_x_polynom1 = New System.Windows.Forms.Button()
        Me.add_start_x_polynom1 = New System.Windows.Forms.Button()
        Me.dec_start_x_polynom1 = New System.Windows.Forms.Button()
        Me.txtbox_start_x_polynom1 = New System.Windows.Forms.TextBox()
        Me.txtbox_end_x_polynom1 = New System.Windows.Forms.TextBox()
        Me.txtbox_coef1 = New System.Windows.Forms.TextBox()
        Me.textbox_start_derivate1 = New System.Windows.Forms.TextBox()
        Me.textbox_end_derivate1 = New System.Windows.Forms.TextBox()
        Me.txtbox_ave_dist_curve_to_polynom1 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtbox_degree_two1 = New System.Windows.Forms.TextBox()
        Me.txtbox_log1 = New System.Windows.Forms.TextBox()
        Me.txtbox_log2 = New System.Windows.Forms.TextBox()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'load_img_btn1
        '
        Me.load_img_btn1.Location = New System.Drawing.Point(25, 78)
        Me.load_img_btn1.Margin = New System.Windows.Forms.Padding(1)
        Me.load_img_btn1.Name = "load_img_btn1"
        Me.load_img_btn1.Size = New System.Drawing.Size(79, 22)
        Me.load_img_btn1.TabIndex = 0
        Me.load_img_btn1.Text = "load_img1"
        Me.load_img_btn1.UseVisualStyleBackColor = True
        '
        'next_edge_pixel_btn1
        '
        Me.next_edge_pixel_btn1.Location = New System.Drawing.Point(251, 79)
        Me.next_edge_pixel_btn1.Name = "next_edge_pixel_btn1"
        Me.next_edge_pixel_btn1.Size = New System.Drawing.Size(179, 23)
        Me.next_edge_pixel_btn1.TabIndex = 1
        Me.next_edge_pixel_btn1.Text = "next_edge_pixel"
        Me.next_edge_pixel_btn1.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Location = New System.Drawing.Point(213, 183)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(767, 559)
        Me.PictureBox1.TabIndex = 2
        Me.PictureBox1.TabStop = False
        '
        'Timer1
        '
        '
        'start_timer_btn1
        '
        Me.start_timer_btn1.Location = New System.Drawing.Point(594, 78)
        Me.start_timer_btn1.Name = "start_timer_btn1"
        Me.start_timer_btn1.Size = New System.Drawing.Size(75, 23)
        Me.start_timer_btn1.TabIndex = 3
        Me.start_timer_btn1.Text = "start_timer1"
        Me.start_timer_btn1.UseVisualStyleBackColor = True
        '
        'txtbox_curent_sobel_threshold1
        '
        Me.txtbox_curent_sobel_threshold1.Location = New System.Drawing.Point(110, 130)
        Me.txtbox_curent_sobel_threshold1.Name = "txtbox_curent_sobel_threshold1"
        Me.txtbox_curent_sobel_threshold1.Size = New System.Drawing.Size(100, 23)
        Me.txtbox_curent_sobel_threshold1.TabIndex = 4
        '
        'update_sobel_threshold_btn1
        '
        Me.update_sobel_threshold_btn1.Location = New System.Drawing.Point(251, 118)
        Me.update_sobel_threshold_btn1.Name = "update_sobel_threshold_btn1"
        Me.update_sobel_threshold_btn1.Size = New System.Drawing.Size(175, 23)
        Me.update_sobel_threshold_btn1.TabIndex = 5
        Me.update_sobel_threshold_btn1.Text = "update_sobel_threshold"
        Me.update_sobel_threshold_btn1.UseVisualStyleBackColor = True
        '
        'minus_sobel_btn1
        '
        Me.minus_sobel_btn1.Location = New System.Drawing.Point(437, 118)
        Me.minus_sobel_btn1.Name = "minus_sobel_btn1"
        Me.minus_sobel_btn1.Size = New System.Drawing.Size(113, 23)
        Me.minus_sobel_btn1.TabIndex = 6
        Me.minus_sobel_btn1.Text = "minus_sobel"
        Me.minus_sobel_btn1.UseVisualStyleBackColor = True
        '
        'plus_sobel_btn1
        '
        Me.plus_sobel_btn1.Location = New System.Drawing.Point(577, 120)
        Me.plus_sobel_btn1.Name = "plus_sobel_btn1"
        Me.plus_sobel_btn1.Size = New System.Drawing.Size(75, 23)
        Me.plus_sobel_btn1.TabIndex = 7
        Me.plus_sobel_btn1.Text = "plus_sobel"
        Me.plus_sobel_btn1.UseVisualStyleBackColor = True
        '
        'find_sobel_btn1
        '
        Me.find_sobel_btn1.Location = New System.Drawing.Point(714, 81)
        Me.find_sobel_btn1.Name = "find_sobel_btn1"
        Me.find_sobel_btn1.Size = New System.Drawing.Size(104, 23)
        Me.find_sobel_btn1.TabIndex = 8
        Me.find_sobel_btn1.Text = "find_sobel1"
        Me.find_sobel_btn1.UseVisualStyleBackColor = True
        '
        'remove_bg_btn1
        '
        Me.remove_bg_btn1.Location = New System.Drawing.Point(714, 120)
        Me.remove_bg_btn1.Name = "remove_bg_btn1"
        Me.remove_bg_btn1.Size = New System.Drawing.Size(132, 23)
        Me.remove_bg_btn1.TabIndex = 9
        Me.remove_bg_btn1.Text = "remove_bg"
        Me.remove_bg_btn1.UseVisualStyleBackColor = True
        '
        'lbl_cur_path1
        '
        Me.lbl_cur_path1.AutoSize = True
        Me.lbl_cur_path1.Location = New System.Drawing.Point(110, 38)
        Me.lbl_cur_path1.Name = "lbl_cur_path1"
        Me.lbl_cur_path1.Size = New System.Drawing.Size(41, 15)
        Me.lbl_cur_path1.TabIndex = 10
        Me.lbl_cur_path1.Text = "Label1"
        '
        'select_file_btn1
        '
        Me.select_file_btn1.Location = New System.Drawing.Point(12, 34)
        Me.select_file_btn1.Name = "select_file_btn1"
        Me.select_file_btn1.Size = New System.Drawing.Size(75, 23)
        Me.select_file_btn1.TabIndex = 11
        Me.select_file_btn1.Text = "select file"
        Me.select_file_btn1.UseVisualStyleBackColor = True
        '
        'chkbox_compute_sobel
        '
        Me.chkbox_compute_sobel.AutoSize = True
        Me.chkbox_compute_sobel.Location = New System.Drawing.Point(128, 81)
        Me.chkbox_compute_sobel.Name = "chkbox_compute_sobel"
        Me.chkbox_compute_sobel.Size = New System.Drawing.Size(105, 19)
        Me.chkbox_compute_sobel.TabIndex = 12
        Me.chkbox_compute_sobel.Text = "compute sobel"
        Me.chkbox_compute_sobel.UseVisualStyleBackColor = True
        '
        'txtbox_sobel_factor1
        '
        Me.txtbox_sobel_factor1.Location = New System.Drawing.Point(437, 27)
        Me.txtbox_sobel_factor1.Name = "txtbox_sobel_factor1"
        Me.txtbox_sobel_factor1.Size = New System.Drawing.Size(100, 23)
        Me.txtbox_sobel_factor1.TabIndex = 13
        '
        'save_cur_image_btn1
        '
        Me.save_cur_image_btn1.Location = New System.Drawing.Point(25, 129)
        Me.save_cur_image_btn1.Name = "save_cur_image_btn1"
        Me.save_cur_image_btn1.Size = New System.Drawing.Size(75, 23)
        Me.save_cur_image_btn1.TabIndex = 14
        Me.save_cur_image_btn1.Text = "save cur image"
        Me.save_cur_image_btn1.UseVisualStyleBackColor = True
        '
        'txtbox_last_cord1
        '
        Me.txtbox_last_cord1.Location = New System.Drawing.Point(552, 30)
        Me.txtbox_last_cord1.Name = "txtbox_last_cord1"
        Me.txtbox_last_cord1.Size = New System.Drawing.Size(100, 23)
        Me.txtbox_last_cord1.TabIndex = 15
        '
        'lbl_root_path1
        '
        Me.lbl_root_path1.AutoSize = True
        Me.lbl_root_path1.Location = New System.Drawing.Point(110, 63)
        Me.lbl_root_path1.Name = "lbl_root_path1"
        Me.lbl_root_path1.Size = New System.Drawing.Size(41, 15)
        Me.lbl_root_path1.TabIndex = 16
        Me.lbl_root_path1.Text = "Label1"
        '
        'find_vertical_center_line1_btn1
        '
        Me.find_vertical_center_line1_btn1.Location = New System.Drawing.Point(643, 46)
        Me.find_vertical_center_line1_btn1.Name = "find_vertical_center_line1_btn1"
        Me.find_vertical_center_line1_btn1.Size = New System.Drawing.Size(189, 23)
        Me.find_vertical_center_line1_btn1.TabIndex = 17
        Me.find_vertical_center_line1_btn1.Text = "find_vertical_center_line1"
        Me.find_vertical_center_line1_btn1.UseVisualStyleBackColor = True
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(48, 48)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Main1ToolStripMenuItem, Me.Backpixel1ToolStripMenuItem, Me.Nextpixel1ToolStripMenuItem, Me.Nextline1ToolStripMenuItem, Me.Nextcurve1ToolStripMenuItem, Me.ShowPrespetive3dToolStripMenuItem, Me.AddXDeg3dToolStripMenuItem, Me.RemoveBgProcToolStripMenuItem, Me.Main2ToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1325, 24)
        Me.MenuStrip1.TabIndex = 18
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'Main1ToolStripMenuItem
        '
        Me.Main1ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FindCurveOfHandlesToolStripMenuItem, Me.FindFrameOfGlassesToolStripMenuItem, Me.CutHandlesFromFrameToolStripMenuItem, Me.RemoveHandleAboveTheFrame1ToolStripMenuItem, Me.LoadSobelArrBySobelIndToolStripMenuItem, Me.ShownextpixelToolStripMenuItem, Me.FindLinesToolStripMenuItem, Me.LoadLinesArrBySobelIndToolStripMenuItem, Me.FindMaxLineInGlassToolStripMenuItem, Me.SobelOnSobelToolStripMenuItem, Me.Preparedataset1ToolStripMenuItem, Me.SignSobelToolStripMenuItem, Me.ShowCurvesToolStripMenuItem, Me.SearchForStartPoint1ToolStripMenuItem, Me.FilterCurve1ToolStripMenuItem, Me.TunningCurveToolStripMenuItem, Me.Polynomfit1ToolStripMenuItem, Me.Printpolynoms1ToolStripMenuItem})
        Me.Main1ToolStripMenuItem.Name = "Main1ToolStripMenuItem"
        Me.Main1ToolStripMenuItem.Size = New System.Drawing.Size(52, 20)
        Me.Main1ToolStripMenuItem.Text = "main1"
        '
        'FindCurveOfHandlesToolStripMenuItem
        '
        Me.FindCurveOfHandlesToolStripMenuItem.Name = "FindCurveOfHandlesToolStripMenuItem"
        Me.FindCurveOfHandlesToolStripMenuItem.Size = New System.Drawing.Size(248, 22)
        Me.FindCurveOfHandlesToolStripMenuItem.Text = "find curve of handles"
        '
        'FindFrameOfGlassesToolStripMenuItem
        '
        Me.FindFrameOfGlassesToolStripMenuItem.Name = "FindFrameOfGlassesToolStripMenuItem"
        Me.FindFrameOfGlassesToolStripMenuItem.Size = New System.Drawing.Size(248, 22)
        Me.FindFrameOfGlassesToolStripMenuItem.Text = "find frame of glasses"
        '
        'CutHandlesFromFrameToolStripMenuItem
        '
        Me.CutHandlesFromFrameToolStripMenuItem.Name = "CutHandlesFromFrameToolStripMenuItem"
        Me.CutHandlesFromFrameToolStripMenuItem.Size = New System.Drawing.Size(248, 22)
        Me.CutHandlesFromFrameToolStripMenuItem.Text = "cut handles from frame"
        '
        'RemoveHandleAboveTheFrame1ToolStripMenuItem
        '
        Me.RemoveHandleAboveTheFrame1ToolStripMenuItem.Name = "RemoveHandleAboveTheFrame1ToolStripMenuItem"
        Me.RemoveHandleAboveTheFrame1ToolStripMenuItem.Size = New System.Drawing.Size(248, 22)
        Me.RemoveHandleAboveTheFrame1ToolStripMenuItem.Text = "remove handle above the frame1"
        '
        'LoadSobelArrBySobelIndToolStripMenuItem
        '
        Me.LoadSobelArrBySobelIndToolStripMenuItem.Name = "LoadSobelArrBySobelIndToolStripMenuItem"
        Me.LoadSobelArrBySobelIndToolStripMenuItem.Size = New System.Drawing.Size(248, 22)
        Me.LoadSobelArrBySobelIndToolStripMenuItem.Text = "load sobel arr by sobel ind"
        '
        'ShownextpixelToolStripMenuItem
        '
        Me.ShownextpixelToolStripMenuItem.Name = "ShownextpixelToolStripMenuItem"
        Me.ShownextpixelToolStripMenuItem.Size = New System.Drawing.Size(248, 22)
        Me.ShownextpixelToolStripMenuItem.Text = "show_next_pixel"
        '
        'FindLinesToolStripMenuItem
        '
        Me.FindLinesToolStripMenuItem.Name = "FindLinesToolStripMenuItem"
        Me.FindLinesToolStripMenuItem.Size = New System.Drawing.Size(248, 22)
        Me.FindLinesToolStripMenuItem.Text = "find lines"
        '
        'LoadLinesArrBySobelIndToolStripMenuItem
        '
        Me.LoadLinesArrBySobelIndToolStripMenuItem.Name = "LoadLinesArrBySobelIndToolStripMenuItem"
        Me.LoadLinesArrBySobelIndToolStripMenuItem.Size = New System.Drawing.Size(248, 22)
        Me.LoadLinesArrBySobelIndToolStripMenuItem.Text = "load lines arr by sobel ind"
        '
        'FindMaxLineInGlassToolStripMenuItem
        '
        Me.FindMaxLineInGlassToolStripMenuItem.Name = "FindMaxLineInGlassToolStripMenuItem"
        Me.FindMaxLineInGlassToolStripMenuItem.Size = New System.Drawing.Size(248, 22)
        Me.FindMaxLineInGlassToolStripMenuItem.Text = "find max line in glass"
        '
        'SobelOnSobelToolStripMenuItem
        '
        Me.SobelOnSobelToolStripMenuItem.Name = "SobelOnSobelToolStripMenuItem"
        Me.SobelOnSobelToolStripMenuItem.Size = New System.Drawing.Size(248, 22)
        Me.SobelOnSobelToolStripMenuItem.Text = "sobel on sobel"
        '
        'Preparedataset1ToolStripMenuItem
        '
        Me.Preparedataset1ToolStripMenuItem.Name = "Preparedataset1ToolStripMenuItem"
        Me.Preparedataset1ToolStripMenuItem.Size = New System.Drawing.Size(248, 22)
        Me.Preparedataset1ToolStripMenuItem.Text = "prepare_dataset1"
        '
        'SignSobelToolStripMenuItem
        '
        Me.SignSobelToolStripMenuItem.Name = "SignSobelToolStripMenuItem"
        Me.SignSobelToolStripMenuItem.Size = New System.Drawing.Size(248, 22)
        Me.SignSobelToolStripMenuItem.Text = "sign sobel"
        '
        'ShowCurvesToolStripMenuItem
        '
        Me.ShowCurvesToolStripMenuItem.Name = "ShowCurvesToolStripMenuItem"
        Me.ShowCurvesToolStripMenuItem.Size = New System.Drawing.Size(248, 22)
        Me.ShowCurvesToolStripMenuItem.Text = "show curves"
        '
        'SearchForStartPoint1ToolStripMenuItem
        '
        Me.SearchForStartPoint1ToolStripMenuItem.Name = "SearchForStartPoint1ToolStripMenuItem"
        Me.SearchForStartPoint1ToolStripMenuItem.Size = New System.Drawing.Size(248, 22)
        Me.SearchForStartPoint1ToolStripMenuItem.Text = "search for start point1"
        '
        'FilterCurve1ToolStripMenuItem
        '
        Me.FilterCurve1ToolStripMenuItem.Name = "FilterCurve1ToolStripMenuItem"
        Me.FilterCurve1ToolStripMenuItem.Size = New System.Drawing.Size(248, 22)
        Me.FilterCurve1ToolStripMenuItem.Text = "filter curve1"
        '
        'TunningCurveToolStripMenuItem
        '
        Me.TunningCurveToolStripMenuItem.Name = "TunningCurveToolStripMenuItem"
        Me.TunningCurveToolStripMenuItem.Size = New System.Drawing.Size(248, 22)
        Me.TunningCurveToolStripMenuItem.Text = "tunning curve"
        '
        'Polynomfit1ToolStripMenuItem
        '
        Me.Polynomfit1ToolStripMenuItem.Name = "Polynomfit1ToolStripMenuItem"
        Me.Polynomfit1ToolStripMenuItem.Size = New System.Drawing.Size(248, 22)
        Me.Polynomfit1ToolStripMenuItem.Text = "polynom_fit1"
        '
        'Printpolynoms1ToolStripMenuItem
        '
        Me.Printpolynoms1ToolStripMenuItem.Name = "Printpolynoms1ToolStripMenuItem"
        Me.Printpolynoms1ToolStripMenuItem.Size = New System.Drawing.Size(248, 22)
        Me.Printpolynoms1ToolStripMenuItem.Text = "print_polynoms1"
        '
        'Backpixel1ToolStripMenuItem
        '
        Me.Backpixel1ToolStripMenuItem.Name = "Backpixel1ToolStripMenuItem"
        Me.Backpixel1ToolStripMenuItem.Size = New System.Drawing.Size(80, 20)
        Me.Backpixel1ToolStripMenuItem.Text = "back_pixel1"
        '
        'Nextpixel1ToolStripMenuItem
        '
        Me.Nextpixel1ToolStripMenuItem.Name = "Nextpixel1ToolStripMenuItem"
        Me.Nextpixel1ToolStripMenuItem.Size = New System.Drawing.Size(78, 20)
        Me.Nextpixel1ToolStripMenuItem.Text = "next_pixel1"
        '
        'Nextline1ToolStripMenuItem
        '
        Me.Nextline1ToolStripMenuItem.Name = "Nextline1ToolStripMenuItem"
        Me.Nextline1ToolStripMenuItem.Size = New System.Drawing.Size(72, 20)
        Me.Nextline1ToolStripMenuItem.Text = "next_line1"
        '
        'Nextcurve1ToolStripMenuItem
        '
        Me.Nextcurve1ToolStripMenuItem.Name = "Nextcurve1ToolStripMenuItem"
        Me.Nextcurve1ToolStripMenuItem.Size = New System.Drawing.Size(82, 20)
        Me.Nextcurve1ToolStripMenuItem.Text = "next_curve1"
        '
        'ShowPrespetive3dToolStripMenuItem
        '
        Me.ShowPrespetive3dToolStripMenuItem.Name = "ShowPrespetive3dToolStripMenuItem"
        Me.ShowPrespetive3dToolStripMenuItem.Size = New System.Drawing.Size(120, 20)
        Me.ShowPrespetive3dToolStripMenuItem.Text = "show prespetive 3d"
        '
        'AddXDeg3dToolStripMenuItem
        '
        Me.AddXDeg3dToolStripMenuItem.Name = "AddXDeg3dToolStripMenuItem"
        Me.AddXDeg3dToolStripMenuItem.Size = New System.Drawing.Size(87, 20)
        Me.AddXDeg3dToolStripMenuItem.Text = "add x deg 3d"
        '
        'RemoveBgProcToolStripMenuItem
        '
        Me.RemoveBgProcToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CreateSobelImgsToolStripMenuItem, Me.FindTheSobelValueToolStripMenuItem, Me.RemoveBgToolStripMenuItem})
        Me.RemoveBgProcToolStripMenuItem.Name = "RemoveBgProcToolStripMenuItem"
        Me.RemoveBgProcToolStripMenuItem.Size = New System.Drawing.Size(103, 20)
        Me.RemoveBgProcToolStripMenuItem.Text = "remove bg proc"
        '
        'CreateSobelImgsToolStripMenuItem
        '
        Me.CreateSobelImgsToolStripMenuItem.Name = "CreateSobelImgsToolStripMenuItem"
        Me.CreateSobelImgsToolStripMenuItem.Size = New System.Drawing.Size(177, 22)
        Me.CreateSobelImgsToolStripMenuItem.Text = "create sobel imgs"
        '
        'FindTheSobelValueToolStripMenuItem
        '
        Me.FindTheSobelValueToolStripMenuItem.Name = "FindTheSobelValueToolStripMenuItem"
        Me.FindTheSobelValueToolStripMenuItem.Size = New System.Drawing.Size(177, 22)
        Me.FindTheSobelValueToolStripMenuItem.Text = "find the sobel value"
        '
        'RemoveBgToolStripMenuItem
        '
        Me.RemoveBgToolStripMenuItem.Name = "RemoveBgToolStripMenuItem"
        Me.RemoveBgToolStripMenuItem.Size = New System.Drawing.Size(177, 22)
        Me.RemoveBgToolStripMenuItem.Text = "remove bg"
        '
        'Main2ToolStripMenuItem
        '
        Me.Main2ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ReplaceCurveWithPolynom1ToolStripMenuItem})
        Me.Main2ToolStripMenuItem.Name = "Main2ToolStripMenuItem"
        Me.Main2ToolStripMenuItem.Size = New System.Drawing.Size(52, 20)
        Me.Main2ToolStripMenuItem.Text = "main2"
        '
        'ReplaceCurveWithPolynom1ToolStripMenuItem
        '
        Me.ReplaceCurveWithPolynom1ToolStripMenuItem.Name = "ReplaceCurveWithPolynom1ToolStripMenuItem"
        Me.ReplaceCurveWithPolynom1ToolStripMenuItem.Size = New System.Drawing.Size(227, 22)
        Me.ReplaceCurveWithPolynom1ToolStripMenuItem.Text = "replace curve with polynom1"
        '
        'txtbox_cur_pixel_ind1
        '
        Me.txtbox_cur_pixel_ind1.Location = New System.Drawing.Point(4, 198)
        Me.txtbox_cur_pixel_ind1.Name = "txtbox_cur_pixel_ind1"
        Me.txtbox_cur_pixel_ind1.Size = New System.Drawing.Size(83, 23)
        Me.txtbox_cur_pixel_ind1.TabIndex = 19
        '
        'lbl_progress1
        '
        Me.lbl_progress1.AutoSize = True
        Me.lbl_progress1.Location = New System.Drawing.Point(752, 25)
        Me.lbl_progress1.Name = "lbl_progress1"
        Me.lbl_progress1.Size = New System.Drawing.Size(41, 15)
        Me.lbl_progress1.TabIndex = 20
        Me.lbl_progress1.Text = "Label1"
        '
        'add_end_x_polynom1
        '
        Me.add_end_x_polynom1.Location = New System.Drawing.Point(12, 227)
        Me.add_end_x_polynom1.Name = "add_end_x_polynom1"
        Me.add_end_x_polynom1.Size = New System.Drawing.Size(75, 23)
        Me.add_end_x_polynom1.TabIndex = 21
        Me.add_end_x_polynom1.Text = "add_end_x_polynom1"
        Me.add_end_x_polynom1.UseVisualStyleBackColor = True
        '
        'dec_end_x_polynom1
        '
        Me.dec_end_x_polynom1.Location = New System.Drawing.Point(12, 256)
        Me.dec_end_x_polynom1.Name = "dec_end_x_polynom1"
        Me.dec_end_x_polynom1.Size = New System.Drawing.Size(75, 23)
        Me.dec_end_x_polynom1.TabIndex = 22
        Me.dec_end_x_polynom1.Text = "dec_end_x_polynom1"
        Me.dec_end_x_polynom1.UseVisualStyleBackColor = True
        '
        'add_start_x_polynom1
        '
        Me.add_start_x_polynom1.Location = New System.Drawing.Point(12, 295)
        Me.add_start_x_polynom1.Name = "add_start_x_polynom1"
        Me.add_start_x_polynom1.Size = New System.Drawing.Size(75, 23)
        Me.add_start_x_polynom1.TabIndex = 23
        Me.add_start_x_polynom1.Text = "add_start_x_polynom1"
        Me.add_start_x_polynom1.UseVisualStyleBackColor = True
        '
        'dec_start_x_polynom1
        '
        Me.dec_start_x_polynom1.Location = New System.Drawing.Point(12, 324)
        Me.dec_start_x_polynom1.Name = "dec_start_x_polynom1"
        Me.dec_start_x_polynom1.Size = New System.Drawing.Size(75, 23)
        Me.dec_start_x_polynom1.TabIndex = 24
        Me.dec_start_x_polynom1.Text = "dec_start_x_polynom1"
        Me.dec_start_x_polynom1.UseVisualStyleBackColor = True
        '
        'txtbox_start_x_polynom1
        '
        Me.txtbox_start_x_polynom1.Location = New System.Drawing.Point(110, 325)
        Me.txtbox_start_x_polynom1.Name = "txtbox_start_x_polynom1"
        Me.txtbox_start_x_polynom1.Size = New System.Drawing.Size(100, 23)
        Me.txtbox_start_x_polynom1.TabIndex = 25
        '
        'txtbox_end_x_polynom1
        '
        Me.txtbox_end_x_polynom1.Location = New System.Drawing.Point(108, 354)
        Me.txtbox_end_x_polynom1.Name = "txtbox_end_x_polynom1"
        Me.txtbox_end_x_polynom1.Size = New System.Drawing.Size(100, 23)
        Me.txtbox_end_x_polynom1.TabIndex = 26
        '
        'txtbox_coef1
        '
        Me.txtbox_coef1.Location = New System.Drawing.Point(109, 394)
        Me.txtbox_coef1.Name = "txtbox_coef1"
        Me.txtbox_coef1.Size = New System.Drawing.Size(100, 23)
        Me.txtbox_coef1.TabIndex = 27
        '
        'textbox_start_derivate1
        '
        Me.textbox_start_derivate1.Location = New System.Drawing.Point(108, 452)
        Me.textbox_start_derivate1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.textbox_start_derivate1.Name = "textbox_start_derivate1"
        Me.textbox_start_derivate1.Size = New System.Drawing.Size(100, 23)
        Me.textbox_start_derivate1.TabIndex = 28
        '
        'textbox_end_derivate1
        '
        Me.textbox_end_derivate1.Location = New System.Drawing.Point(108, 484)
        Me.textbox_end_derivate1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.textbox_end_derivate1.Name = "textbox_end_derivate1"
        Me.textbox_end_derivate1.Size = New System.Drawing.Size(101, 23)
        Me.textbox_end_derivate1.TabIndex = 29
        '
        'txtbox_ave_dist_curve_to_polynom1
        '
        Me.txtbox_ave_dist_curve_to_polynom1.Location = New System.Drawing.Point(108, 509)
        Me.txtbox_ave_dist_curve_to_polynom1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtbox_ave_dist_curve_to_polynom1.Name = "txtbox_ave_dist_curve_to_polynom1"
        Me.txtbox_ave_dist_curve_to_polynom1.Size = New System.Drawing.Size(101, 23)
        Me.txtbox_ave_dist_curve_to_polynom1.TabIndex = 30
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(4, 454)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(75, 15)
        Me.Label1.TabIndex = 31
        Me.Label1.Text = "start derivate"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(8, 487)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(72, 15)
        Me.Label2.TabIndex = 32
        Me.Label2.Text = "end derivate"
        '
        'txtbox_degree_two1
        '
        Me.txtbox_degree_two1.Location = New System.Drawing.Point(107, 424)
        Me.txtbox_degree_two1.Name = "txtbox_degree_two1"
        Me.txtbox_degree_two1.Size = New System.Drawing.Size(100, 23)
        Me.txtbox_degree_two1.TabIndex = 33
        '
        'txtbox_log1
        '
        Me.txtbox_log1.Location = New System.Drawing.Point(888, 46)
        Me.txtbox_log1.Multiline = True
        Me.txtbox_log1.Name = "txtbox_log1"
        Me.txtbox_log1.Size = New System.Drawing.Size(405, 233)
        Me.txtbox_log1.TabIndex = 34
        '
        'txtbox_log2
        '
        Me.txtbox_log2.Location = New System.Drawing.Point(1020, 310)
        Me.txtbox_log2.Multiline = True
        Me.txtbox_log2.Name = "txtbox_log2"
        Me.txtbox_log2.Size = New System.Drawing.Size(273, 116)
        Me.txtbox_log2.TabIndex = 35
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1325, 553)
        Me.Controls.Add(Me.txtbox_log2)
        Me.Controls.Add(Me.txtbox_log1)
        Me.Controls.Add(Me.txtbox_degree_two1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtbox_ave_dist_curve_to_polynom1)
        Me.Controls.Add(Me.textbox_end_derivate1)
        Me.Controls.Add(Me.textbox_start_derivate1)
        Me.Controls.Add(Me.txtbox_coef1)
        Me.Controls.Add(Me.txtbox_end_x_polynom1)
        Me.Controls.Add(Me.txtbox_start_x_polynom1)
        Me.Controls.Add(Me.dec_start_x_polynom1)
        Me.Controls.Add(Me.add_start_x_polynom1)
        Me.Controls.Add(Me.dec_end_x_polynom1)
        Me.Controls.Add(Me.add_end_x_polynom1)
        Me.Controls.Add(Me.lbl_progress1)
        Me.Controls.Add(Me.txtbox_cur_pixel_ind1)
        Me.Controls.Add(Me.find_vertical_center_line1_btn1)
        Me.Controls.Add(Me.lbl_root_path1)
        Me.Controls.Add(Me.txtbox_last_cord1)
        Me.Controls.Add(Me.save_cur_image_btn1)
        Me.Controls.Add(Me.txtbox_sobel_factor1)
        Me.Controls.Add(Me.chkbox_compute_sobel)
        Me.Controls.Add(Me.select_file_btn1)
        Me.Controls.Add(Me.lbl_cur_path1)
        Me.Controls.Add(Me.remove_bg_btn1)
        Me.Controls.Add(Me.find_sobel_btn1)
        Me.Controls.Add(Me.plus_sobel_btn1)
        Me.Controls.Add(Me.minus_sobel_btn1)
        Me.Controls.Add(Me.update_sobel_threshold_btn1)
        Me.Controls.Add(Me.txtbox_curent_sobel_threshold1)
        Me.Controls.Add(Me.start_timer_btn1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.next_edge_pixel_btn1)
        Me.Controls.Add(Me.load_img_btn1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Margin = New System.Windows.Forms.Padding(1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents load_img_btn1 As Button
    Friend WithEvents next_edge_pixel_btn1 As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Timer1 As Timer
    Friend WithEvents start_timer_btn1 As Button
    Friend WithEvents txtbox_curent_sobel_threshold1 As TextBox
    Friend WithEvents update_sobel_threshold_btn1 As Button
    Friend WithEvents minus_sobel_btn1 As Button
    Friend WithEvents plus_sobel_btn1 As Button
    Friend WithEvents find_sobel_btn1 As Button
    Friend WithEvents remove_bg_btn1 As Button
    Friend WithEvents lbl_cur_path1 As Label
    Friend WithEvents select_file_btn1 As Button
    Friend WithEvents chkbox_compute_sobel As CheckBox
    Friend WithEvents txtbox_sobel_factor1 As TextBox
    Friend WithEvents save_cur_image_btn1 As Button
    Friend WithEvents txtbox_last_cord1 As TextBox
    Friend WithEvents lbl_root_path1 As Label
    Friend WithEvents find_vertical_center_line1_btn1 As Button
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents Main1ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LoadSobelArrBySobelIndToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ShownextpixelToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Nextpixel1ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents txtbox_cur_pixel_ind1 As TextBox
    Friend WithEvents Backpixel1ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FindLinesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LoadLinesArrBySobelIndToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Nextline1ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FindMaxLineInGlassToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FindCurveOfHandlesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SobelOnSobelToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Preparedataset1ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SignSobelToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ShowCurvesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Nextcurve1ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SearchForStartPoint1ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ShowPrespetive3dToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AddXDeg3dToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RemoveBgProcToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CreateSobelImgsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FindTheSobelValueToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RemoveBgToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents lbl_progress1 As Label
    Friend WithEvents FindFrameOfGlassesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CutHandlesFromFrameToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FilterCurve1ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TunningCurveToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RemoveHandleAboveTheFrame1ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Polynomfit1ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents add_end_x_polynom1 As Button
    Friend WithEvents dec_end_x_polynom1 As Button
    Friend WithEvents add_start_x_polynom1 As Button
    Friend WithEvents dec_start_x_polynom1 As Button
    Friend WithEvents txtbox_start_x_polynom1 As TextBox
    Friend WithEvents txtbox_end_x_polynom1 As TextBox
    Friend WithEvents txtbox_coef1 As TextBox
    Friend WithEvents textbox_start_derivate1 As TextBox
    Friend WithEvents textbox_end_derivate1 As TextBox
    Friend WithEvents txtbox_ave_dist_curve_to_polynom1 As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents txtbox_degree_two1 As TextBox
    Friend WithEvents Main2ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ReplaceCurveWithPolynom1ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Printpolynoms1ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents txtbox_log1 As TextBox
    Friend WithEvents txtbox_log2 As TextBox
End Class
