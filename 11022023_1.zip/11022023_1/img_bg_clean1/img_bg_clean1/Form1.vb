﻿Imports System.Diagnostics.Eventing.Reader
Imports System.Reflection
Imports System.Runtime.InteropServices


Public Class Form1


    Public inds_orders_arr1 As Integer() = {1, 0, 2, 3, 4, 5, 6, 7, 8}
    Public curve_ind1 As Integer


    Public markingfldimg_obj1 As CMarkingFieldInImage1 = New CMarkingFieldInImage1()
    Public macros_obj1 As CMacros1 = New CMacros1()

    Public file_name1 As String = "980376398\191966151131__A_2"

    Dim dir_arr1 As Integer(,) = {{-1, -1}, {0, -1}, {1, -1}, {1, 0}, {1, 1}, {0, 1}, {-1, 1}, {-1, 0}, {-1, -1}, {0, -1}, {1, -1}, {1, 0}, {1, 1}, {0, 1}, {-1, 1}, {-1, 0}}
    Dim dir_arr2 As Integer(,) = {{-1, -1}, {0, -1}, {1, -1}, {1, 0}, {1, 1}, {0, 1}, {-1, 1}, {-1, 0}}
    Dim cord_ind1 As Integer = 0
    Dim last_cord_ind1 As Integer = 0

    Dim x_start2 As Integer
    Dim y_start2 As Integer

    Dim current_bmp1 As Bitmap

    Dim paint_recursive_deep1 As Integer = 0

    Dim count_set_pixels1 As Integer = 0
    Dim max_count_set_pixels1 As Integer = 2350000

    Dim org_bmp1 As Bitmap
    Private Sub load_img_btn1_Click(sender As Object, e As EventArgs) Handles load_img_btn1.Click

        Dim shell As Object = Nothing

        Dim wshtype As Type = Type.GetTypeFromProgID("WScript.Shell")
        If Not wshtype Is Nothing Then
            shell = Activator.CreateInstance(wshtype)
        End If
        Try


            If Not shell Is Nothing Then
                'shell.Run(Chr(34) & "D:\glass_pics1\del_cache1.bat" & Chr(34), 0)

                Dim str As String = CStr(wshtype.InvokeMember(
            "Run",
            BindingFlags.InvokeMethod,
            Nothing,
            shell,
            {Chr(34) & CGlobals1.global_path1 + "del_cache1.bat" & Chr(34)}
        ))
                'MsgBox(str)

                ' Do something else

                Marshal.ReleaseComObject(shell)
            End If
        Catch ex As Exception

        End Try

        Try
            Dim sobel_pics1_path As String = CGlobals1.global_path1 + "sobel_pics1\"
            If System.IO.Directory.Exists(sobel_pics1_path) = False Then
                System.IO.Directory.CreateDirectory(sobel_pics1_path)
            End If
        Catch ex As Exception

        End Try

        'Dim WshShell = CreateObject("WScript.Shell")
        'WshShell.Run(Chr(34) & "D:\glass_pics1\del_cache1.bat" & Chr(34), 0)

        'file_name1 = "980376420\195768208031__A"
        Dim sobel_bmp1 As Bitmap
        'org_bmp1 = New Bitmap("D:\glass_pics1\" + file_name1 + "_crop1.jpg")
        Dim path_of_cache1 As String = CGlobals1.global_path1 + file_name1 + "_sobel_cache1"
        CGlobals1.path_of_sobel_cache1 = path_of_cache1


        If chkbox_compute_sobel.Checked Then


            Dim bmp1 As Bitmap = New Bitmap(CGlobals1.global_path1 + file_name1 + ".jpg")
            Dim crop_bmp1 As Bitmap = crop_img_by_color(bmp1, Color.FromArgb(255, 255, 255))
            crop_bmp1.Save(CGlobals1.global_path1 + file_name1 + "_crop1.jpg")

            Dim bmp2 As Bitmap = rgb_to_monochrome1(bmp1)
            bmp2.Save(CGlobals1.global_path1 + file_name1 + "_mono1.jpg")


            sobel_bmp1 = do_sobel_oparator1(crop_bmp1)
            sobel_bmp1.Save(CGlobals1.global_path1 + file_name1 + "_s1.jpg")

        End If
        markingfldimg_obj1.form_obj1 = Me
        Dim vec_3d_obj1 As vec_3d1 = New vec_3d1()
        vec_3d_obj1.p2.x1 = 100
        vec_3d_obj1.p2.y1 = 0
        Dim vec_3d_obj2 As vec_3d1 = New vec_3d1()
        vec_3d_obj2.p2.x1 = -100
        vec_3d_obj2.p2.y1 = -1

        Dim angle2 As Double = markingfldimg_obj1.get_angle_between_2_3d_vectors(vec_3d_obj1, vec_3d_obj2)
        markingfldimg_obj1.bmp1 = New Bitmap(CGlobals1.global_path1 + file_name1 + "_crop1.jpg")
        Dim copy_bmp1 As Bitmap = CGlobals1.copy_bitmap1(markingfldimg_obj1.bmp1)
        'markingfldimg_obj1.get_change_color_on_region_by_dir(markingfldimg_obj1.bmp1, 1353, 70, 200, 50)
        'markingfldimg_obj1.get_change_color_on_region_by_dir(copy_bmp1, 1125, 67, 200, 50)
        copy_bmp1.Save(CGlobals1.global_path1 + file_name1 + "_test1.jpg")
        markingfldimg_obj1.read_sobel_values1(CGlobals1.global_path1 + file_name1 + "_sobel_vals1.txt")
        txtbox_curent_sobel_threshold1.Text = markingfldimg_obj1.cur_sobel_ind_val1.ToString()
        sobel_bmp1 = New Bitmap(CGlobals1.global_path1 + file_name1 + "_s1.jpg")
        'sobel_bmp1 = filter_pixels_by_around1(sobel_bmp1, Color.FromArgb(255, 255, 255), Color.FromArgb(0, 0, 0))
        CGlobals1.current_bmp1 = sobel_bmp1



        Dim bmp3a As Bitmap = CGlobals1.create_fill_bitmap(200, 150, Color.FromArgb(255, 0, 0, 0))
        Dim bmp4 As Bitmap = CGlobals1.create_fill_bitmap(150, 100, Color.FromArgb(255, 0, 0, 150))
        Dim bmp5 As Bitmap = CGlobals1.copy_bitmap_2_bitmap1(bmp3a, bmp4, 10, 10)
        bmp5 = CGlobals1.crop_bitmap(sobel_bmp1, 5, 5, 200, 800)
        Dim bmp6 As Bitmap = CGlobals1.create_fill_bitmap(230, 1030, Color.FromArgb(255, 0, 0, 0))
        Dim bmp7 As Bitmap = CGlobals1.copy_bitmap_2_bitmap1(bmp6, bmp5, 5, 5)

        PictureBox1.Image = sobel_bmp1

        PictureBox1.Image = bmp7
        'CGlobals1.current_bmp1 = sobel_bmp1
        x_start2 = 50
        y_start2 = 0
        'x_start2 = 300
        'y_start2 = 300

        '"565,428"
        'x_start2 = 565
        'y_start2 = 428
        markingfldimg_obj1.bmp1 = copy_bitmap1(sobel_bmp1)
        Dim cord1 As Integer() = markingfldimg_obj1.find_start_point1(x_start2, y_start2)
        x_start2 = cord1(0)
        y_start2 = cord1(1)
        If chkbox_compute_sobel.Checked Then

            If System.IO.Directory.Exists(path_of_cache1) = False Then
                System.IO.Directory.CreateDirectory(path_of_cache1)
            End If
            markingfldimg_obj1.create_cache_of_sobel_files(path_of_cache1)
            CGlobals1.dict_mono_colors1.Clear()
        End If
        'markingfldimg_obj1.create_cache_of_sobel_files()
        Return
        'sobel_bmp1.SetPixel(cord1(0), cord1(1), Color.FromArgb(255, 10, 10))
        current_bmp1 = sobel_bmp1
        current_bmp1 = walk_on_bmp_by_color1(cord1(0), cord1(1), sobel_bmp1, Color.FromArgb(255, 255, 255))
        'CGlobals1.current_bmp1 =



        Dim bmp3 As Bitmap = zoom_img1(current_bmp1)


        PictureBox1.Image = bmp3

        txtbox_curent_sobel_threshold1.Text = markingfldimg_obj1.cur_sobel_ind_val1
    End Sub

    Public Function compare_colors1(color1 As Color, color2 As Color)
        If color1.R = color2.R And color1.G = color2.G And color1.B = color2.B Then
            Return 1
        End If

        Return 0
    End Function
    Public Function walk_on_bmp_by_color1(x_start1 As Integer, y_start1 As Integer, bmp1 As Bitmap, color1 As Color)
        Dim dict_cords1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)
        dict_cords1(x_start1.ToString() + "," + y_start1.ToString()) = 1

        cord_ind1 = 0
        Dim color_a As Color = bmp1.GetPixel(x_start1 + dir_arr1(cord_ind1, 0), y_start1 + dir_arr1(cord_ind1, 1))
        Dim color_b As Color = bmp1.GetPixel(x_start1 + dir_arr1(cord_ind1 + 1, 0), y_start1 + dir_arr1(cord_ind1 + 1, 1))
        last_cord_ind1 = cord_ind1
        'color_a is not the edge color
        'color_B is the edge color
        While (compare_colors1(color_a, color1) = 0 And compare_colors1(color_b, color1) = 1) = False
            last_cord_ind1 = cord_ind1
            cord_ind1 += 1

            Dim new_x_start2 As Integer = x_start1 + dir_arr1(cord_ind1 + 1, 0)
            Dim new_y_start2 As Integer = y_start1 + dir_arr1(cord_ind1 + 1, 1)
            color_a = bmp1.GetPixel(x_start1 + dir_arr1(cord_ind1, 0), y_start1 + dir_arr1(cord_ind1, 1))
            color_b = bmp1.GetPixel(x_start1 + dir_arr1(cord_ind1 + 1, 0), y_start1 + dir_arr1(cord_ind1 + 1, 1))
        End While
        'cord_ind1 += 1
        last_cord_ind1 = cord_ind1
        color_a = bmp1.GetPixel(x_start1 + dir_arr1(last_cord_ind1, 0), y_start1 + dir_arr1(last_cord_ind1, 1))

        Dim new_x_start3 As Integer = x_start1 + dir_arr1(last_cord_ind1 + 1, 0)
        Dim new_y_start3 As Integer = y_start1 + dir_arr1(last_cord_ind1 + 1, 1)
        color_b = bmp1.GetPixel(x_start1 + dir_arr1(last_cord_ind1 + 1, 0), y_start1 + dir_arr1(last_cord_ind1 + 1, 1))
        Dim ind1 As Integer = 0
        cord_ind1 = last_cord_ind1

        x_start2 = x_start1 + dir_arr1(last_cord_ind1 + 1, 0)
        y_start2 = y_start1 + dir_arr1(last_cord_ind1 + 1, 1)




        Return bmp1
        For ind1 = 0 To 50

            x_start1 = x_start1 + dir_arr1(last_cord_ind1 + 1, 0)
            y_start1 = y_start1 + dir_arr1(last_cord_ind1 + 1, 1)


            color_a = bmp1.GetPixel(x_start1 + dir_arr1(cord_ind1, 0), y_start1 + dir_arr1(cord_ind1, 1))
            color_b = bmp1.GetPixel(x_start1 + dir_arr1(cord_ind1 + 1, 0), y_start1 + dir_arr1(cord_ind1 + 1, 1))

            cord_ind1 = 0
            last_cord_ind1 = cord_ind1
            'color_a is not the edge color
            'color_B is the edge color

            While (compare_colors1(color_a, color1) = 0 And compare_colors1(color_a, Color.FromArgb(255, 10, 10)) = 0 And compare_colors1(color_b, Color.FromArgb(255, 10, 10)) = 0 And compare_colors1(color_b, color1) = 1) = False
                last_cord_ind1 = cord_ind1
                cord_ind1 += 1
                color_a = bmp1.GetPixel(x_start1 + dir_arr1(cord_ind1, 0), y_start1 + dir_arr1(cord_ind1, 1))
                color_b = bmp1.GetPixel(x_start1 + dir_arr1(cord_ind1 + 1, 0), y_start1 + dir_arr1(cord_ind1 + 1, 1))
            End While

        Next

    End Function

    Public Function next_pixel_edge(bmp1 As Bitmap, color1 As Color)

        bmp1.SetPixel(x_start2, y_start2, Color.FromArgb(255, 120, 100))


        cord_ind1 = 0
        Dim color_a As Color = bmp1.GetPixel(x_start2 + dir_arr1(cord_ind1, 0), y_start2 + dir_arr1(cord_ind1, 1))
        Dim color_b As Color = bmp1.GetPixel(x_start2 + dir_arr1(cord_ind1 + 1, 0), y_start2 + dir_arr1(cord_ind1 + 1, 1))
        last_cord_ind1 = cord_ind1
        While (compare_colors1(color_a, color1) = 0 And compare_colors1(color_b, color1) = 1) = False
            last_cord_ind1 = cord_ind1
            cord_ind1 += 1
            color_a = bmp1.GetPixel(x_start2 + dir_arr1(cord_ind1, 0), y_start2 + dir_arr1(cord_ind1, 1))
            color_b = bmp1.GetPixel(x_start2 + dir_arr1(cord_ind1 + 1, 0), y_start2 + dir_arr1(cord_ind1 + 1, 1))
        End While
        last_cord_ind1 = cord_ind1
        x_start2 = x_start2 + dir_arr1(last_cord_ind1 + 1, 0)
        y_start2 = y_start2 + dir_arr1(last_cord_ind1 + 1, 1)
        Return bmp1

    End Function


    Public Function next_pixels_loop1(bmp1 As Bitmap, color1 As Color)
        Dim to_Stop1 As Integer = 0
        Dim pixels_cords_arr1 As ArrayList = New ArrayList()
        Dim wrong_pixels_dict1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)
        Dim org_x_start2 As Integer = x_start2
        Dim org_y_start2 As Integer = y_start2

        While to_Stop1 = 0
            Dim color_set1 As Color = bmp1.GetPixel(x_start2, y_start2)
            If compare_colors1(color_set1, color1) = 0 Then
                Dim e1 As Integer = 1
            End If



            bmp1.SetPixel(x_start2, y_start2, Color.FromArgb(255, 120, 100))
            pixels_cords_arr1.Add(x_start2.ToString() + "," + y_start2.ToString())
            If org_bmp1 IsNot Nothing Then

                org_bmp1.SetPixel(x_start2, y_start2, Color.FromArgb(255, 0, 0, 0))
            End If
            'color_a is not the edge color
            'color_B is the edge color

            'search for cord_ind that is the previues pixel_point:
            cord_ind1 = 0

            If pixels_cords_arr1.Count > 1 Then
                Dim cord_str1 As String() = pixels_cords_arr1(pixels_cords_arr1.Count - 2).ToString().Split(",")
                Dim x1 As Integer = Integer.Parse(cord_str1(0))
                Dim y1 As Integer = Integer.Parse(cord_str1(1))
                Dim to_stop3 As Integer = 0

                While to_stop3 = 0
                    Dim new_x1 As Integer = x_start2 + dir_arr1(cord_ind1, 0)
                    Dim new_y1 As Integer = y_start2 + dir_arr1(cord_ind1, 1)
                    If new_x1 = x1 And new_y1 = y1 Then
                        to_stop3 = 1
                    Else
                        cord_ind1 += 1

                    End If

                End While

            End If
            '--


            Dim color_a As Color = bmp1.GetPixel(x_start2 + dir_arr1(cord_ind1, 0), y_start2 + dir_arr1(cord_ind1, 1))
            Dim color_b As Color = bmp1.GetPixel(x_start2 + dir_arr1(cord_ind1 + 1, 0), y_start2 + dir_arr1(cord_ind1 + 1, 1))
            last_cord_ind1 = cord_ind1

            Dim to_stop2 As Integer = 0
            While (compare_colors1(color_a, Color.FromArgb(0, 0, 0)) = 1 And compare_colors1(color_b, color1) = 1) = False And to_stop2 = 0
                last_cord_ind1 = cord_ind1

                Try
                    color_a = bmp1.GetPixel(x_start2 + dir_arr1(cord_ind1, 0), y_start2 + dir_arr1(cord_ind1, 1))
                    color_b = bmp1.GetPixel(x_start2 + dir_arr1(cord_ind1 + 1, 0), y_start2 + dir_arr1(cord_ind1 + 1, 1))
                    If (x_start2 + dir_arr1(cord_ind1 + 1, 0)) = org_x_start2 And
                        (y_start2 + dir_arr1(cord_ind1 + 1, 1)) = org_y_start2 Then
                        Return bmp1
                    End If
                Catch ex As Exception
                    to_stop2 = 1
                    wrong_pixels_dict1(x_start2.ToString() + "," + y_start2.ToString()) = 1
                    If wrong_pixels_dict1.Count > 50 Then
                        Return bmp1
                    End If
                    'Return bmp1
                End Try
                cord_ind1 += 1

            End While
            If to_stop2 = 0 Then

                color_b = bmp1.GetPixel(x_start2 + dir_arr1(last_cord_ind1 + 1, 0), y_start2 + dir_arr1(last_cord_ind1 + 1, 1))
                If compare_colors1(color_b, color1) = 0 Then
                    Dim err1 As Integer = 1
                End If

            End If

            If to_stop2 = 1 And False Then
                Dim c1 As Integer = 50
                'bmp1.SetPixel(x_start2, y_start2, Color.FromArgb(10, 255, 10))

                cord_ind1 = 0
                color_a = bmp1.GetPixel(x_start2 + dir_arr1(cord_ind1, 0), y_start2 + dir_arr1(cord_ind1, 1))
                color_b = bmp1.GetPixel(x_start2 + dir_arr1(cord_ind1 + 1, 0), y_start2 + dir_arr1(cord_ind1 + 1, 1))
                last_cord_ind1 = cord_ind1

                Dim loop_ind1 As Integer = 0
                to_stop2 = 0
                While (compare_colors1(color_a, Color.FromArgb(0, 0, 0)) = 1 And compare_colors1(color_b, color1) = 1) = False And to_stop2 = 0
                    last_cord_ind1 = cord_ind1

                    Try
                        color_a = bmp1.GetPixel(x_start2 + dir_arr1(cord_ind1, 0), y_start2 + dir_arr1(cord_ind1, 1))
                        color_b = bmp1.GetPixel(x_start2 + dir_arr1((cord_ind1 + 1), 0), y_start2 + dir_arr1(cord_ind1 + 1, 1))
                        If loop_ind1 < 9 Then
                            'bmp1.SetPixel(x_start2 + dir_arr1(cord_ind1, 0), y_start2 + dir_arr1(cord_ind1, 1), Color.FromArgb(c1, 70, 255))

                        End If
                        loop_ind1 += 1
                        c1 += 30
                    Catch ex As Exception
                        Return bmp1
                    End Try
                    cord_ind1 += 1
                End While

            End If
            If to_stop2 = 1 Then
                'x_start2 = x_start2 + dir_arr1(last_cord_ind1 + 1, 0)
                'y_start2 = y_start2 + dir_arr1(last_cord_ind1 + 1, 1)
                pixels_cords_arr1.RemoveAt(pixels_cords_arr1.Count - 1)
                x_start2 = Integer.Parse(pixels_cords_arr1(pixels_cords_arr1.Count - 1).ToString().Split(",")(0))
                y_start2 = Integer.Parse(pixels_cords_arr1(pixels_cords_arr1.Count - 1).ToString().Split(",")(1))
                pixels_cords_arr1.RemoveAt(pixels_cords_arr1.Count - 1)

            Else
                x_start2 = x_start2 + dir_arr1(last_cord_ind1 + 1, 0)
                y_start2 = y_start2 + dir_arr1(last_cord_ind1 + 1, 1)
            End If
            'last_cord_ind1 = cord_ind1

        End While

    End Function



    Public Function find_start_point1(x_start1 As Integer, y_start1 As Integer, bmp1 As Bitmap, color1 As Color)
        While bmp1.GetPixel(x_start1, y_start1).R <> color1.R Or
                bmp1.GetPixel(x_start1, y_start1).G <> color1.G Or
                bmp1.GetPixel(x_start1, y_start1).B <> color1.B
            y_start1 += 1

        End While

        Return New Integer() {x_start1, y_start1}
    End Function

    Public Function crop_img_by_color(bmp1 As Bitmap, color1 As Color)
        Dim x1 As Integer
        Dim y1 As Integer

        Dim top1 As Integer
        Dim to_stop1 = 0
        top1 = 0

        While to_stop1 = 0

            For x1 = 0 To bmp1.Width - 1
                If bmp1.GetPixel(x1, top1).R <> color1.R Or
                        bmp1.GetPixel(x1, top1).G <> color1.G Or
                        bmp1.GetPixel(x1, top1).B <> color1.B Then
                    to_stop1 = 1


                End If

            Next
            If to_stop1 = 0 Then
                top1 += 1
            End If
        End While

        top1 -= 10

        Dim bottom1 As Integer
        to_stop1 = 0
        bottom1 = bmp1.Height - 1
        While to_stop1 = 0

            For x1 = 0 To bmp1.Width - 1
                If bmp1.GetPixel(x1, bottom1).R <> color1.R Or
                        bmp1.GetPixel(x1, bottom1).G <> color1.G Or
                        bmp1.GetPixel(x1, bottom1).B <> color1.B Then
                    to_stop1 = 1



                End If



            Next
            If to_stop1 = 0 Then
                bottom1 -= 1
            End If
        End While

        bottom1 += 10




        to_stop1 = 0
        Dim left1 As Integer = 0

        While to_stop1 = 0

            For y1 = 0 To bmp1.Height - 1
                If bmp1.GetPixel(left1, y1).R <> color1.R Or
                        bmp1.GetPixel(left1, y1).G <> color1.G Or
                        bmp1.GetPixel(left1, y1).B <> color1.B Then
                    to_stop1 = 1


                End If

            Next
            If to_stop1 = 0 Then
                left1 += 1
            End If
        End While

        left1 -= 10
        If left1 < 0 Then
            left1 = 0
        End If
        to_stop1 = 0
        Dim right1 As Integer = bmp1.Width - 1

        While to_stop1 = 0

            For y1 = 0 To bmp1.Height - 1
                If bmp1.GetPixel(right1, y1).R <> color1.R Or
                        bmp1.GetPixel(right1, y1).G <> color1.G Or
                        bmp1.GetPixel(right1, y1).B <> color1.B Then
                    to_stop1 = 1


                End If

            Next
            If to_stop1 = 0 Then
                right1 -= 1
            End If
        End While

        right1 += 10
        If right1 > bmp1.Width - 1 Then
            right1 = bmp1.Width - 1
        End If
        Dim bmp2 As Bitmap = New Bitmap(right1 - left1 + 1, bottom1 - top1 + 1)
        Dim gr As Graphics = Graphics.FromImage(bmp2)

        ' Get source and destination rectangles.
        Dim fr_rect As New Rectangle(left1, top1, right1 - left1 + 1, bottom1 - top1 + 1)
        Dim to_rect As New Rectangle(0, 0, bmp2.Width, bmp2.Height)

        ' Draw from the source to the destination.
        gr.DrawImage(bmp1, to_rect, fr_rect, GraphicsUnit.Pixel)
        'gr.DrawRectangle(Pens.Red, to_rect)

        Return bmp2
    End Function
    Public Function rgb_to_monochrome1(bmp1 As Bitmap)
        Dim x1 As Integer
        Dim y1 As Integer
        Dim bmp2 As Bitmap = bmp1.Clone()
        For x1 = 0 To bmp1.Width - 1
            For y1 = 0 To bmp1.Height - 1
                Dim color1 As Color = bmp1.GetPixel(x1, y1)
                Dim color2 As Integer = (0.3 * color1.R + 0.59 * color1.G + 0.11 * color1.B)
                bmp2.SetPixel(x1, y1, Color.FromArgb(color2, color2, color2))
            Next

        Next

        Return bmp2
        '(0.3* color.R + 0.59 * color.G + 0.11 * color.B);
    End Function
    Public Function do_sobel_oparator1(bmp1 As Bitmap)


        Dim dict_sobel_val1 As Dictionary(Of Integer, Double) = New Dictionary(Of Integer, Double)
        Dim dict_sobel_val2 As Dictionary(Of Double, Integer) = New Dictionary(Of Double, Integer)
        Dim dict_sobel_val_pixels1 As Dictionary(Of String, Double) = New Dictionary(Of String, Double)
        Dim x1 As Integer
        Dim y1 As Integer
        Dim bmp2 As Bitmap = New Bitmap(bmp1.Width, bmp1.Height)
        Dim sobal_size1 As Integer = 7
        Dim ind1 As Integer = 0
        Dim max_sobel As Double = 0
        Dim sobel_vals_str1 As System.Text.StringBuilder = New System.Text.StringBuilder()

        Dim not_relevant1 As Integer = 1

        For x1 = 0 + sobal_size1 To bmp1.Width - 1 - sobal_size1

            If x1 Mod 10 = 0 Then
                CGlobals1.update_label_progress("step1(sobel compute):" + ((x1 / bmp1.Width * 100.0).ToString() + "      ").Substring(0, 5) + "%")
            End If
            For y1 = 0 + sobal_size1 To bmp1.Height - 1 - sobal_size1


                Dim sobel_val1a As Double = -1
                Dim sobel_val1b As Double = -1
                Dim sobel_val1 As Double = -1
                Dim max_sobel_ind1 = 0
                If True Then
                    Dim sobel_val1_1 As Double = get_sobel_value1(bmp1, x1, y1)
                    Dim sobel_val1_2 As Double = get_sobel_value2(bmp1, x1, y1)
                    Dim sobel_val1_3 As Double = get_sobel_value3(bmp1, x1, y1)
                    Dim sobel_val1_4 As Double = get_sobel_value4(bmp1, x1, y1)

                    If sobel_val1_1 < 0 Then
                        sobel_val1_1 = -sobel_val1_1
                    End If
                    If sobel_val1_2 < 0 Then
                        sobel_val1_2 = -sobel_val1_2
                    End If
                    If sobel_val1_3 < 0 Then
                        sobel_val1_3 = -sobel_val1_3
                    End If
                    If sobel_val1_1 < 0 Then
                        sobel_val1_4 = -sobel_val1_4
                    End If

                    Dim max_sobel_val_1 As Double = sobel_val1_1
                    max_sobel_ind1 = 1
                    If sobel_val1_2 > max_sobel_val_1 Then
                        max_sobel_val_1 = sobel_val1_2
                        max_sobel_ind1 = 2
                    End If

                    If sobel_val1_3 > max_sobel_val_1 Then
                        max_sobel_val_1 = sobel_val1_3
                        max_sobel_ind1 = 3
                    End If

                    If sobel_val1_4 > max_sobel_val_1 Then
                        max_sobel_val_1 = sobel_val1_4
                        max_sobel_ind1 = 4

                    End If
                    sobel_val1 = max_sobel_val_1
                    If max_sobel_ind1 <> 2 Then
                        'sobel_val1 = 0
                    End If
                    If max_sobel_ind1 = 1 Then
                        'sobel_val1 = 0
                    End If
                    'sobel_val1 -= sobel_val1_1
                    'sobel_val1a = Math.Max(Math.Abs(get_sobel_value1(bmp1, x1, y1)), Math.Abs(get_sobel_value2(bmp1, x1, y1)))
                    'sobel_val1b = Math.Max(Math.Abs(get_sobel_value3(bmp1, x1, y1)), Math.Abs(get_sobel_value4(bmp1, x1, y1)))
                    'sobel_val1 = Math.Max(sobel_val1a, sobel_val1b)


                    'sobel_val1 = get_sobel_value1(bmp1, x1, y1)

                    'sobel_val1 = Math.Abs(get_sobel_value1(bmp1, x1, y1))

                End If

                'sobel_val1 = Math.Abs(get_sobel_value1_long(bmp1, x1, y1))
                'sobel_val1 = Math.Max(sobel_val1a, sobel_val1b)

                If max_sobel < sobel_val1 Then
                    max_sobel = sobel_val1
                End If

                If not_relevant1 = 1 Then
                    dict_sobel_val_pixels1(x1.ToString() + "," + y1.ToString()) = sobel_val1
                    dict_sobel_val1(ind1) = Math.Abs(sobel_val1)
                    dict_sobel_val2(Math.Abs(sobel_val1)) = 1

                End If


                Dim pixels_arr1 As ArrayList
                If CGlobals1.dict_sobel_pixels.ContainsKey(Math.Abs(sobel_val1)) Then
                    Dim d4 As Integer = 1
                Else
                    CGlobals1.dict_sobel_pixels(Math.Abs(sobel_val1)) = New ArrayList()
                End If
                pixels_arr1 = CGlobals1.dict_sobel_pixels(Math.Abs(sobel_val1))
                pixels_arr1.Add(x1.ToString() + "," + y1.ToString())

                ind1 += 1
                If Math.Abs(sobel_val1) > 70 Then

                    'bmp2.SetPixel(x1, y1, Color.FromArgb(255, 255, 255))

                Else
                    'bmp2.SetPixel(x1, y1, Color.FromArgb(0, 0, 0))
                End If
                If Math.Abs(sobel_val1) > 0 Then
                    Dim d1 As Integer = 1
                End If
                sobel_vals_str1.Append(x1.ToString() + "," + y1.ToString() + "," + Math.Abs(sobel_val1).ToString() + "#")


            Next
        Next


        If not_relevant1 = 0 Then
            For x1 = 0 + sobal_size1 To bmp1.Width - 1 - sobal_size1

                For y1 = 0 + sobal_size1 To bmp1.Height - 1 - sobal_size1
                    Dim sv1 As Integer = dict_sobel_val_pixels1(x1.ToString() + "," + y1.ToString()) / max_sobel * 255
                    'bmp2.SetPixel(x1, y1, Color.FromArgb(sv1, sv1, sv1))
                Next
            Next

        End If

        Dim path1 As String = CGlobals1.global_path1 + file_name1 + "_sobel_vals1.txt"
        System.IO.File.WriteAllText(path1, sobel_vals_str1.ToString())
        Dim sorted = From pair In dict_sobel_val1
                     Order By pair.Value
        Dim sortedDictionary = sorted.ToDictionary(Function(p) p.Key, Function(p) p.Value)
        Dim s2 As Double = sortedDictionary(sortedDictionary.Keys(CType(sortedDictionary.Keys.Count * 0.99, Integer)))
        s2 = 30
        CGlobals1.current_sobel_threshold = s2
        txtbox_curent_sobel_threshold1.Text = CGlobals1.current_sobel_threshold.ToString()
        Dim sorted2 = From pair In dict_sobel_val2
                      Order By pair.Key
        Dim sortedDictionary2 As Dictionary(Of Double, Integer) = sorted2.ToDictionary(Function(p) p.Key, Function(p) p.Value)

        Dim s1 As Double = sortedDictionary2.Keys(CType(sortedDictionary2.Keys.Count * 0.4, Integer))

        Dim count_sobel_ok_pixels1 As Integer = 0
        For x1 = 0 + sobal_size1 To bmp1.Width - 1 - sobal_size1
            For y1 = 0 + sobal_size1 To bmp1.Height - 1 - sobal_size1
                Dim sobel_val1 As Double = dict_sobel_val_pixels1(x1.ToString() + "," + y1.ToString())
                If sobel_val1 > s2 Then

                    bmp2.SetPixel(x1, y1, Color.FromArgb(255, 255, 255))
                    count_sobel_ok_pixels1 += 1
                Else
                    bmp2.SetPixel(x1, y1, Color.FromArgb(0, 0, 0))
                End If
            Next
        Next
        Dim percent_ok1 As Double = count_sobel_ok_pixels1 / (bmp1.Width * bmp1.Height)




        Return bmp2
    End Function

    Public Function get_sobel_value_by_mat(ByRef bmp1 As Bitmap, x1 As Integer, y1 As Integer)
        Dim mat1b As Double(,) = {{0, 0, 0, 0, 0},
                                 {-1, -1, -1, -1, -1},
                                 {0, 0, 0, 0, 0},
                                 {1, 1, 1, 1, 1},
                                 {0, 0, 0, 0, 0}}

        Dim mat1 As Double(,) = {{0, 0, 0, 0, 0, 0, 0},
                                 {0, 0, 0, 0, 0, 0, 0},
                                 {-1, -1, -1, -1, -1, -1, -1},
                                 {0, 0, 0, 0, 0, 0, 0},
                                 {1, 1, 1, 1, 1, 1, 1},
                                 {0, 0, 0, 0, 0, 0, 0},
                                 {0, 0, 0, 0, 0, 0, 0}}

        Dim mat2 As Double(,) = {{0, 1, 0, -1, 0},
                                 {0, 1, 0, -1, 0},
                                 {0, 1, 0, -1, 0},
                                 {0, 1, 0, -1, 0},
                                 {0, 1, 0, -1, 0}}

        Dim mat3 As Double(,) = {{0, 1, 0, 0, 0},
                                 {-1, 0, 1, 0, 0},
                                 {0, -1, 0, 1, 0},
                                 {0, 0, -1, 0, 1},
                                 {0, 0, 0, -1, 0}}

        Dim mat4 As Double(,) = {{0, 0, 0, 1, 0},
                                 {0, 0, 1, 0, -1},
                                 {0, 1, 0, -1, 0},
                                 {1, 0, -1, 0, 0},
                                 {0, -1, 0, 0, 0}}


        Dim mat5 As Double(,) = {{0, -1, 0, 0, 0, 0, 0},
                                 {0, 0, -1, 0, 0, 0, 0},
                                 {0, 0, -1, 0, 0, 0, 0},
                                 {0, 0, 0, 1, 0, 0, 0},
                                 {0, 0, 0, 0, 1, 0, 0},
                                 {0, 0, 0, 0, 1, 0, 0},
                                 {0, 0, 0, 0, 0, 1, 0}}


        Dim mat6 As Double(,) = {{0, -1, 0, 1, 0},
                                 {0, -1, 0, 1, 0},
                                 {0, -1, 0, 1, 0},
                                 {0, 0, -1, 0, 1},
                                 {0, 0, -1, 0, 1}}


    End Function


    'מציאת קווים מאונכים
    Public Function get_sobel_value1(ByRef bmp1 As Bitmap, x1 As Integer, y1 As Integer)
        'Dim mat1 As Double(,) = {{0, 0, 0, 0, 0}, {-1, -1, -1, -1, -1}, {0, 0, 0, 0, 0}, {1, 1, 1, 1, 1}, {0, 0, 0, 0, 0}}
        Dim mat1 As Double(,) = {{0, 0, 0, 0, 0}, {-1, -2, -4, -2, -1}, {0, 0, 0, 0, 0}, {1, 2, 4, 2, 1}, {0, 0, 0, 0, 0}}
        Dim total_sobel_val1 As Double = 0
        Dim sobel_x1 As Integer
        Dim sobel_y1 As Integer
        sobel_x1 = 0
        For x2 = x1 - 2 To x1 + 2
            sobel_y1 = 0

            For y2 = y1 - 2 To y1 + 2
                Dim sobel_val1 As Double = mat1(sobel_x1, sobel_y1)

                total_sobel_val1 += get_mono_color1(bmp1, x2, y2) * sobel_val1
                sobel_y1 += 1

            Next
            sobel_x1 += 1
        Next

        Return total_sobel_val1
    End Function



    Public Function get_sobel_value1_long(bmp1 As Bitmap, x1 As Integer, y1 As Integer)
        Dim mat1 As Double(,) = {{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}}
        Dim total_sobel_val1 As Double = 0
        Dim sobel_x1 As Integer
        Dim sobel_y1 As Integer
        sobel_x1 = 0
        For x2 = x1 - 1 To x1 + 1
            sobel_y1 = 0

            For y2 = y1 - 6 To y1 + 6
                Dim sobel_val1 As Double = mat1(sobel_x1, sobel_y1)

                total_sobel_val1 += get_mono_color1(bmp1, x2, y2) * sobel_val1
                sobel_y1 += 1

            Next
            sobel_x1 += 1
        Next

        Return total_sobel_val1
    End Function


    'מציאת קווים מאוזנים
    Public Function get_sobel_value2(ByRef bmp1 As Bitmap, x1 As Integer, y1 As Integer)
        'Dim mat1 As Double(,) = {{-1, 0, 1}, {-1, 0, 1}, {-1, 0, 1}}
        'Dim mat1 As Double(,) = {{0, -1, 0, 1, 0}, {0, -1, 0, 1, 0}, {0, -1, 0, 1, 0}, {0, -1, 0, 1, 0}, {0, -1, 0, 1, 0}}
        Dim mat1 As Double(,) = {{0, -1, 0, 1, 0}, {0, -2, 0, 2, 0}, {0, -4, 0, 4, 0}, {0, -2, 0, 2, 0}, {0, -1, 0, 1, 0}}
        Dim total_sobel_val1 As Double = 0
        Dim sobel_x1 As Integer
        Dim sobel_y1 As Integer
        sobel_x1 = 0
        For x2 = x1 - 2 To x1 + 2
            sobel_y1 = 0

            For y2 = y1 - 2 To y1 + 2
                Dim sobel_val1 As Double = mat1(sobel_x1, sobel_y1)

                total_sobel_val1 += get_mono_color1(bmp1, x2, y2) * sobel_val1
                sobel_y1 += 1

            Next
            sobel_x1 += 1
        Next

        Return total_sobel_val1
    End Function

    Public Function get_sobel_value3(bmp1 As Bitmap, x1 As Integer, y1 As Integer)
        'Dim mat1 As Double(,) = {{-1, 0, 1}, {-1, 0, 1}, {-1, 0, 1}}
        'Dim mat2 As Double(,) = {{0, -1, 0, 0, 0}, {1, 0, -1, 0, 0}, {0, 1, 0, -1, 0}, {0, 0, 1, 0, -1}, {0, 0, 0, 1, 0}}
        Dim mat2 As Double(,) = {{0, -1, 0, 0, 0}, {2, 0, -2, 0, 0}, {0, 4, 0, -4, 0}, {0, 0, 2, 0, -2}, {0, 0, 0, 1, 0}}
        '0 -1  0  0  0
        '1  0 -1  0  0
        '0  1  0 -1  0
        '0  0  1  0 -1
        '0  0  0  1  0
        Dim total_sobel_val1 As Double = 0
        Dim sobel_x1 As Integer
        Dim sobel_y1 As Integer
        sobel_x1 = 0
        For x2 = x1 - 2 To x1 + 2
            sobel_y1 = 0

            For y2 = y1 - 2 To y1 + 2
                Dim sobel_val1 As Double = mat2(sobel_x1, sobel_y1)

                total_sobel_val1 += get_mono_color1(bmp1, x2, y2) * sobel_val1
                sobel_y1 += 1

            Next
            sobel_x1 += 1
        Next

        Return total_sobel_val1
    End Function
    Public Function get_sobel_value4(bmp1 As Bitmap, x1 As Integer, y1 As Integer)
        'Dim mat1 As Double(,) = {{-1, 0, 1}, {-1, 0, 1}, {-1, 0, 1}}
        'Dim mat2 As Double(,) = {{0, -1, 0, 0, 0}, {1, 0, -1, 0, 0}, {0, 1, 0, -1, 0}, {0, 0, 1, 0, -1}, {0, 0, 0, 1, 0}}
        '0 -1  0  0  0
        '1  0 -1  0  0
        '0  1  0 -1  0
        '0  0  1  0 -1
        '0  0  0  1  0


        'Dim mat2 As Double(,) = {{0, 0, 0, -1, 0}, {0, 0, -1, 0, 1}, {0, -1, 0, 1, 0}, {-1, 0, 1, 0, 0}, {0, 1, 0, 0, 0}}
        Dim mat2 As Double(,) = {{0, 0, 0, -1, 0}, {0, 0, -2, 0, 2}, {0, -4, 0, 4, 0}, {-2, 0, 2, 0, 0}, {0, 1, 0, 0, 0}}

        '0   0  0 -1  0
        '0   0 -1  0  1
        '0  -1  0  1  0
        '-1  0  1  0  0
        '0   1  0  0  0


        Dim total_sobel_val1 As Double = 0
        Dim sobel_x1 As Integer
        Dim sobel_y1 As Integer
        sobel_x1 = 0
        For x2 = x1 - 2 To x1 + 2
            sobel_y1 = 0

            For y2 = y1 - 2 To y1 + 2
                Dim sobel_val1 As Double = mat2(sobel_x1, sobel_y1)

                total_sobel_val1 += get_mono_color1(bmp1, x2, y2) * sobel_val1
                sobel_y1 += 1

            Next
            sobel_x1 += 1
        Next

        Return total_sobel_val1
    End Function


    Public Function get_mono_color1(ByRef bmp1 As Bitmap, x1 As Integer, y1 As Integer)
        'Dim mono_color1 As Double = (CType(bmp1.GetPixel(x1, y1).R, Double) + CType(bmp1.GetPixel(x1, y1).G, Double) + CType(bmp1.GetPixel(x1, y1).B, Double)) / 3 ' * 0.3333
        'Dim color1 As Color = Color.FromArgb(255, 255, 255) ' bmp1.GetPixel(x1, y1)
        Dim key1 As String = x1.ToString() + "," + y1.ToString()
        If CGlobals1.dict_mono_colors1.ContainsKey(key1) = True Then
            Return CGlobals1.dict_mono_colors1(key1)
        End If
        Dim color1 As Color = bmp1.GetPixel(x1, y1)
        Dim mono_color1 As Integer = (0.3 * color1.R + 0.59 * color1.G + 0.11 * color1.B)
        CGlobals1.dict_mono_colors1(key1) = mono_color1
        Return mono_color1
    End Function
    Public Function to_mono_color(bmp1 As Bitmap)
        Dim bmp2 As Bitmap = bmp1.Clone()

        Dim x1 As Integer
        Dim y1 As Integer

        For x1 = 0 To bmp2.Width - 1
            For y1 = 0 To bmp2.Height - 1

                'bmp2.SetPixel()
            Next
        Next
    End Function

    Private Sub next_edge_pixel_btn1_Click(sender As Object, e As EventArgs) Handles next_edge_pixel_btn1.Click

        Dim bmp1 As Bitmap = markingfldimg_obj1.check_if_sobel_found()
        'PictureBox1.Image = bmp1
        If markingfldimg_obj1.success_status = "arrive_to_start_point" Then
            PictureBox1.Image = bmp1
        End If
        Return
        Dim bmp_copy1 As Bitmap = copy_bitmap1(CGlobals1.current_bmp1)


        Try
            bmp_copy1 = markingfldimg_obj1.next_pixels_loop1()

        Catch ex As Exception

        End Try


        Return
        markingfldimg_obj1.save_3d_points_arr(CGlobals1.global_path1 + "arr_3d_pnts2.txt", markingfldimg_obj1.pixels_3d_cords_arr)

        Dim vec_3d_obj1 As vec_3d1 = New vec_3d1()
        vec_3d_obj1.p1 = New point_3d1(900, 100, 0)
        vec_3d_obj1.p2 = New point_3d1(900, 200, 0)


        markingfldimg_obj1.rotate_3d_points_arr(vec_3d_obj1, 80)

        Dim i1 As Integer

        For i1 = 0 To markingfldimg_obj1.pixels_3d_cords_arr.Count - 1
            Dim point_3d_obj1 As point_3d1 = markingfldimg_obj1.pixels_3d_cords_arr(i1)
            Try
                bmp_copy1.SetPixel(point_3d_obj1.x1, point_3d_obj1.y1, Color.FromArgb(200, 200, 200))

            Catch ex As Exception

            End Try
        Next

        PictureBox1.Image = zoom_img1(bmp_copy1)
        bmp_copy1.Save(CGlobals1.global_path1 + file_name1 + "_red_edge2.jpg")
        Return
        'current_bmp1.Save("D:\glass_pics1\" + file_name1 + "_red_edge2.jpg")

    End Sub
    Public Function paint_recursive1()
        paint_recursive_deep1 = 0
        Dim to_stop1 As Integer = 0

        Dim stack_arr1 As ArrayList = New ArrayList()
        Dim add_stack_dict1 As Dictionary(Of String, Integer) = paint_recursive(5, 5, current_bmp1, markingfldimg_obj1.color_of_region, Color.FromArgb(255, 200, 200))
        'stack_arr1.AddRange(add_stack_arr1)
        'to_stop1 = 1
        Dim loop_c1 As Integer = 0
        While to_stop1 = 0
            loop_c1 += 1
            If count_set_pixels1 > max_count_set_pixels1 Then
                to_stop1 = 1
            End If
            Dim new_xy_dict12 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)
            Dim dict_xy_to_del1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)

            Dim i1 As Integer
            For i1 = 0 To add_stack_dict1.Keys.Count - 1
                Dim str_xy1 As String() = add_stack_dict1.Keys(i1).ToString().Split(",")
                Dim x1 As Integer = str_xy1(0)
                Dim y1 As Integer = str_xy1(1)
                Dim add_stack_dict2 As Dictionary(Of String, Integer) = paint_recursive(x1, y1, current_bmp1, markingfldimg_obj1.color_of_region, Color.FromArgb(255, 200, 200))
                If (add_stack_dict2.Count = 0) Then
                    dict_xy_to_del1(x1.ToString() + "," + y1.ToString()) = 1
                Else
                    Dim i2 As Integer
                    For i2 = 0 To add_stack_dict2.Keys.Count - 1
                        new_xy_dict12(add_stack_dict2.Keys(i2)) = 1
                    Next
                End If


            Next

            For i1 = 0 To dict_xy_to_del1.Keys.Count - 1
                add_stack_dict1.Remove(dict_xy_to_del1.Keys(i1))

            Next

            For i1 = 0 To new_xy_dict12.Keys.Count - 1
                add_stack_dict1(new_xy_dict12.Keys(i1)) = 1

            Next
            If add_stack_dict1.Count = 0 Then
                to_stop1 = 1
            End If
            'stack_arr1.Clear()
        End While


        'current_bmp1 = next_pixel_edge(current_bmp1, Color.FromArgb(255, 255, 255))

        'current_bmp1.Save(CGlobals1.global_path1 + file_name1 + "_red_edge1.jpg")
        org_bmp1 = markingfldimg_obj1.remove_around_object1(org_bmp1, Color.FromArgb(0, 0, 0))
        org_bmp1 = markingfldimg_obj1.remove_around_object1(org_bmp1, Color.FromArgb(0, 0, 0))


        org_bmp1.Save(CGlobals1.global_path1 + file_name1 + "_not_bg1.jpg")
        Dim bmp2 As Bitmap = zoom_img1(current_bmp1)


        PictureBox1.Image = bmp2

    End Function


    Public Function paint_recursive2(bmp1 As Bitmap, start_x1 As Integer, start_y1 As Integer, color_of_region As Color, color_to_set As Color)
        paint_recursive_deep1 = 0
        Dim to_stop1 As Integer = 0

        Dim xa As Integer
        Dim ya As Integer
        For xa = 95 To 1200
            For ya = 30 To 700
                Dim c1 As Color = get_pixel_at1(bmp1, xa, ya)
                If compare_colors1(get_pixel_at1(bmp1, xa, ya), color_of_region) = 1 Then
                    Dim d1 As Integer = 1
                End If
            Next
        Next
        Dim stack_arr1 As ArrayList = New ArrayList()
        Dim add_stack_dict1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)
        'stack_arr1.AddRange(add_stack_arr1)
        'to_stop1 = 1
        Dim count_set_pixels1 As Integer = 0
        Dim loop_c1 As Integer = 0
        While to_stop1 = 0
            If add_stack_dict1.Keys.Count > 0 Then
                Dim str_cord1 As String = add_stack_dict1.Keys(add_stack_dict1.Keys.Count - 1)
                start_x1 = Integer.Parse(str_cord1.Split(",")(0))
                start_y1 = Integer.Parse(str_cord1.Split(",")(1))
            End If
            If compare_colors1(get_pixel_at1(bmp1, start_x1, start_y1), color_of_region) = 1 Then
                Dim d1 As Integer = 1
            End If
            Dim was_pixels_around1 As Integer = 0
            If compare_colors1(get_pixel_at1(bmp1, start_x1, start_y1), color_of_region) = 0 And compare_colors1(get_pixel_at1(bmp1, start_x1, start_y1), color_to_set) = 0 Then
                add_stack_dict1(start_x1.ToString() + "," + start_y1.ToString()) = 1
                bmp1.SetPixel(start_x1, start_y1, color_to_set)
                count_set_pixels1 += 1

                Dim i1 As Integer
                For i1 = 0 To 3
                    Dim dir_x1 As Integer = CGlobals1.dir_arr3(i1, 0)
                    Dim dir_y1 As Integer = CGlobals1.dir_arr3(i1, 1)
                    Dim new_x1 As Integer = start_x1 + CGlobals1.dir_arr3(i1, 0)
                    Dim new_y1 As Integer = start_y1 + CGlobals1.dir_arr3(i1, 1)
                    If new_x1 >= 0 And new_y1 >= 0 And new_x1 <= bmp1.Width - 1 And new_y1 <= bmp1.Height - 1 Then
                        If compare_colors1(get_pixel_at1(bmp1, new_x1, new_y1), color_of_region) = 0 And compare_colors1(get_pixel_at1(bmp1, new_x1, new_y1), color_to_set) = 0 Then


                            add_stack_dict1(new_x1.ToString() + "," + new_y1.ToString()) = 1
                            'bmp1.SetPixel(new_x1, new_y1, color_to_set)
                            was_pixels_around1 = 1
                            count_set_pixels1 += 1
                        Else
                            Dim was_set1 As Integer = 1
                        End If

                    End If
                Next

            End If
            If was_pixels_around1 = 0 Then
                add_stack_dict1.Remove(start_x1.ToString() + "," + start_y1.ToString())
            End If
            If add_stack_dict1.Keys.Count <= 0 Then 'Or count_set_pixels1 > 100000 Then
                to_stop1 = 1
            End If
        End While


        'current_bmp1 = next_pixel_edge(current_bmp1, Color.FromArgb(255, 255, 255))

        'current_bmp1.Save(CGlobals1.global_path1 + file_name1 + "_red_edge1.jpg")
        'org_bmp1 = markingfldimg_obj1.remove_around_object1(org_bmp1, Color.FromArgb(0, 0, 0))
        'org_bmp1 = markingfldimg_obj1.remove_around_object1(org_bmp1, Color.FromArgb(0, 0, 0))


        bmp1.Save(CGlobals1.global_path1 + file_name1 + "_not_bg1.jpg")
        Dim bmp2 As Bitmap = zoom_img1(bmp1)


        PictureBox1.Image = bmp2

    End Function



    Public Function zoom_img1(bmp1 As Bitmap, Optional factor1 As Double = 1.5)
        Dim bmp2 As Bitmap = New Bitmap(CType((bmp1.Width / factor1), Integer), CType((bmp1.Height / factor1), Integer))
        Dim gr As Graphics = Graphics.FromImage(bmp2)

        ' Get source and destination rectangles.
        'Dim fr_rect As New Rectangle(0, 0, 70, 50)
        Dim fr_rect As New Rectangle(0, 0, bmp1.Width, bmp1.Height)
        Dim to_rect As New Rectangle(0, 0, bmp2.Width, bmp2.Height)

        ' Draw from the source to the destination.
        gr.DrawImage(bmp1, to_rect, fr_rect, GraphicsUnit.Pixel)


        Return bmp2
    End Function
    Public Function copy_bitmap1(bmp1 As Bitmap)
        Dim bmp2 As Bitmap = New Bitmap(bmp1.Width, bmp1.Height)
        Dim gr As Graphics = Graphics.FromImage(bmp2)

        ' Get source and destination rectangles.
        'Dim fr_rect As New Rectangle(0, 0, 70, 50)
        Dim fr_rect As New Rectangle(0, 0, bmp1.Width, bmp1.Height)
        Dim to_rect As New Rectangle(0, 0, bmp2.Width, bmp2.Height)

        ' Draw from the source to the destination.
        gr.DrawImage(bmp1, to_rect, fr_rect, GraphicsUnit.Pixel)


        Return bmp2
    End Function
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Timer1.Stop()
        plus_sobel_btn1_Click(Nothing, Nothing)
        Dim bmp1 As Bitmap = markingfldimg_obj1.check_if_sobel_found()

        Dim count_pixels1 As Integer = markingfldimg_obj1.pixels_cords_arr1.Count
        If CGlobals1.max_pixels_arr_length1 < count_pixels1 Then
            CGlobals1.max_pixels_arr_length1 = count_pixels1
        End If
        If count_pixels1 > 4000 Then
            Dim ind_len1 As Integer
            ind_len1 = 3400
            Dim to_stop_w1 As Integer = 1
            While to_stop_w1 = 0
                Dim res1 As Integer = markingfldimg_obj1.find_line_in_pixels_arr(markingfldimg_obj1.pixels_cords_arr1, 120, ind_len1, 5)
                If res1 = 1 Then
                    to_stop_w1 = 1
                Else
                    ind_len1 -= 1
                End If

            End While
            For ind_len1 = 10 To 1500

            Next

        End If
        Dim cord_strs1 As String = markingfldimg_obj1.pixels_cords_arr1(markingfldimg_obj1.pixels_cords_arr1.Count - 1)
        txtbox_last_cord1.Text = cord_strs1
        markingfldimg_obj1.set_pixel_arr_on_bmp1(markingfldimg_obj1.pixels_cords_arr1, bmp1)
        PictureBox1.Image = zoom_img1(bmp1)
        If markingfldimg_obj1.success_status = "arrive_to_start_point" Then
            'markingfldimg_obj1.find_line_in_pixels_arr(markingfldimg_obj1.pixels_cords_arr1, 0, 10, 4)
            PictureBox1.Image = markingfldimg_obj1.bmp1
            Return
        End If

        'next_edge_pixel_btn1_Click(Nothing, Nothing)
        Timer1.Start()
    End Sub

    Private Sub start_timer_btn1_Click(sender As Object, e As EventArgs) Handles start_timer_btn1.Click

        'markingfldimg_obj1.loop_on_sobel_vals2()
        Dim line_to_search_start_sobel_pixels1 As ArrayList = markingfldimg_obj1.create_pixel_arr_line_from_2_2d_points(500, 0, 500, 2000)

        markingfldimg_obj1.loop_on_sobel_vals3(line_to_search_start_sobel_pixels1)
        Return
        Dim bmp1 As Bitmap = CGlobals1.copy_bitmap1(CGlobals1.max_sobel_length_bmp1)
        markingfldimg_obj1.set_pixel_arr_on_bmp1(CGlobals1.current_max_arr_sobel, bmp1)
        markingfldimg_obj1.save_2d_pixels_arr1(CGlobals1.global_path1 + file_name1 + "_2d_pixels1.txt", CGlobals1.current_max_arr_sobel)
        PictureBox1.Image = zoom_img1(bmp1)
        Return
        Timer1.Interval = 10
        Timer1.Start()
    End Sub

    Public Function get_pixel_at1(bmp1 As Bitmap, x1 As Integer, y1 As Integer)
        If x1 >= 0 And y1 >= 0 And x1 <= bmp1.Width - 1 And y1 <= bmp1.Height - 1 Then
            Return bmp1.GetPixel(x1, y1)
        Else
            Return Nothing
        End If
    End Function

    Public Function filter_pixels_by_around1(bmp1 As Bitmap, color_of_pixels As Color, color_of_bg As Color)
        Dim bmp2 As Bitmap = copy_bitmap1(bmp1)
        'Return bmp2
        Dim to_stop1 As Integer = 0
        While to_stop1 = 0

            Dim x1 As Integer
            Dim y1 As Integer
            to_stop1 = 1
            For x1 = 0 To bmp2.Width - 1
                For y1 = 0 To bmp2.Height - 1
                    Dim to_set_pixel1 As Integer = 0
                    Dim color1 As Color = get_pixel_at1(bmp1, x1, y1)
                    If compare_colors1(color1, color_of_pixels) = 1 Then
                        Dim count_pixels_around1 As Integer = markingfldimg_obj1.count_pixel_around(bmp1, x1, y1, color_of_pixels)
                        If count_pixels_around1 > 1 Then
                            to_set_pixel1 = 1
                        Else
                            to_stop1 = 0
                        End If
                        'to_set_pixel1 = 1
                    End If
                    If to_set_pixel1 = 0 Then
                        'to_stop1 = 0
                        bmp2.SetPixel(x1, y1, color_of_bg)
                    Else
                        bmp2.SetPixel(x1, y1, color_of_pixels)
                    End If



                Next

            Next
            If to_stop1 = 0 Then
                bmp1 = copy_bitmap1(bmp2)

            End If
        End While

        Return bmp2
    End Function


    Public Function paint_recursive(start_x1 As Integer, start_y1 As Integer, ByRef bmp1 As Bitmap, ByRef bound_color1 As Color, ByRef color_to_set1 As Color)
        paint_recursive_deep1 += 1
        If paint_recursive_deep1 > 4011 Then
            'Return 1
        End If
        'paint_recursive(start_x1, start_y1, bmp1, bound_color1, color_to_set1)
        'Return 2
        Dim x1 As Integer = start_x1
        Dim x2 As Integer = start_x1
        Dim to_stop1 As Integer = 0
        Dim x_arr1 As ArrayList '= New ArrayList()

        Dim stack_dict1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)
        While compare_colors1(bound_color1, get_pixel_at1(bmp1, x1, start_y1)) = 0 And compare_colors1(color_to_set1, get_pixel_at1(bmp1, x1, start_y1)) = 0 And to_stop1 = 0

            If (x1 >= 0 And start_y1 >= 0 And x1 < bmp1.Width And start_y1 < bmp1.Height) Then
                Dim color3 As Color = bmp1.GetPixel(x1, start_y1)
                If compare_colors1(bound_color1, bmp1.GetPixel(x1, start_y1)) = 0 And compare_colors1(color_to_set1, bmp1.GetPixel(x1, start_y1)) = 0 Then
                    If count_set_pixels1 > 136 Then
                        Dim d1 As Integer = 1
                    End If
                    If (count_set_pixels1 < max_count_set_pixels1) Then
                        If start_y1 = 42 Then
                            Dim d2 As Int16 = 1
                        End If

                        bmp1.SetPixel(x1, start_y1, color_to_set1)
                        org_bmp1.SetPixel(x1, start_y1, Color.FromArgb(255, 0, 0, 0))
                    End If
                    count_set_pixels1 += 1
                Else
                    to_stop1 = 1
                End If

                'x_arr1.Add(x1)
                If x1 = bmp1.Width - 1 Then
                    to_stop1 = 1
                End If
                If start_y1 + 1 < bmp1.Height Then

                    If compare_colors1(bound_color1, bmp1.GetPixel(x1, start_y1 + 1)) = 0 And compare_colors1(color_to_set1, bmp1.GetPixel(x1, start_y1 + 1)) = 0 Then
                        If (x1 = 45 And (start_y1 + 1) = 42) Then
                            Dim d3 As Integer = 1
                        End If
                        stack_dict1(x1.ToString() + "," + (start_y1 + 1).ToString()) = 1

                        'paint_recursive(x1, start_y1 + 1, bmp1, bound_color1, color_to_set1)
                    Else
                        'to_stop1 = 1
                    End If
                End If

                If start_y1 - 1 >= 0 Then

                    If compare_colors1(bound_color1, bmp1.GetPixel(x1, start_y1 - 1)) = 0 And compare_colors1(color_to_set1, bmp1.GetPixel(x1, start_y1 - 1)) = 0 Then
                        If (x1 = 45 And (start_y1 - 1) = 42) Then
                            Dim d3 As Integer = 1
                        End If
                        stack_dict1(x1.ToString() + "," + (start_y1 - 1).ToString()) = 1
                    Else
                        'to_stop1 = 1
                        'paint_recursive(x1, start_y1 - 1, bmp1, bound_color1, color_to_set1)
                    End If
                End If


                x1 += 1
            Else
                to_stop1 = 1
            End If
        End While



        to_stop1 = 0
        'x2 = bmp1.Width - 1

        While compare_colors1(bound_color1, get_pixel_at1(bmp1, x2, start_y1)) = 0 And compare_colors1(color_to_set1, get_pixel_at1(bmp1, x1, start_y1)) = 0 And to_stop1 = 0
            If (x2 >= 0 And start_y1 >= 0 And x2 < bmp1.Width And start_y1 < bmp1.Height) Then
                If compare_colors1(bound_color1, bmp1.GetPixel(x2, start_y1)) = 0 And compare_colors1(color_to_set1, bmp1.GetPixel(x2, start_y1)) = 0 Then
                    If count_set_pixels1 > 136 Then
                        Dim d1 As Integer = 1
                    End If
                    If (count_set_pixels1 < max_count_set_pixels1) Then
                        bmp1.SetPixel(x2, start_y1, color_to_set1)
                        org_bmp1.SetPixel(x2, start_y1, Color.FromArgb(255, 0, 0, 0))

                    End If

                    count_set_pixels1 += 1

                End If

                'x_arr1.Add(x2)
                If x2 = 1 Then
                    to_stop1 = 1
                End If

                If start_y1 + 1 < bmp1.Height Then

                    If compare_colors1(bound_color1, bmp1.GetPixel(x2, start_y1 + 1)) = 0 And compare_colors1(color_to_set1, bmp1.GetPixel(x2, start_y1 + 1)) = 0 Then
                        stack_dict1(x2.ToString() + "," + (start_y1 + 1).ToString()) = 1
                        If (x2 = 45 And (start_y1 + 1) = 42) Then
                            Dim d3 As Integer = 1
                        End If

                        'paint_recursive(x2, start_y1 + 1, bmp1, bound_color1, color_to_set1)
                    Else
                        to_stop1 = 1
                    End If
                End If
                If start_y1 - 1 >= 0 Then

                    If compare_colors1(bound_color1, bmp1.GetPixel(x2, start_y1 - 1)) = 0 And compare_colors1(color_to_set1, bmp1.GetPixel(x2, start_y1 - 1)) = 0 Then
                        stack_dict1(x2.ToString() + "," + (start_y1 - 1).ToString()) = 1
                        If (x2 = 45 And (start_y1 - 1) = 42) Then
                            Dim d3 As Integer = 1
                        End If

                        'paint_recursive(x2, start_y1 + 1, bmp1, bound_color1, color_to_set1)
                    Else
                        to_stop1 = 1
                    End If
                End If

                x2 -= 1
            Else
                to_stop1 = 1
            End If

        End While
        Return stack_dict1
        'x_arr1.Clear()
        Dim x_val1 As Integer
        Dim x_ind_val1 As Integer
        If False Then


            For x_ind_val1 = 0 To x_arr1.Count - 1
                x_val1 = x_arr1(x_ind_val1)
                If start_y1 + 1 < bmp1.Height Then

                    If compare_colors1(bound_color1, bmp1.GetPixel(x_val1, start_y1 + 1)) = 0 And compare_colors1(color_to_set1, bmp1.GetPixel(x_val1, start_y1 + 1)) = 0 Then
                        'paint_recursive(x_val1, start_y1 + 1, bmp1, bound_color1, color_to_set1)
                        'stack_arr1.Add(x_val1.ToString() + "," + (start_y1 + 1).ToString())
                    End If
                End If
                If start_y1 > 0 Then

                    If compare_colors1(bound_color1, bmp1.GetPixel(x_val1, start_y1 - 1)) = 0 And compare_colors1(color_to_set1, bmp1.GetPixel(x_val1, start_y1 - 1)) = 0 Then
                        'paint_recursive(x_val1, start_y1 - 1, bmp1, bound_color1, color_to_set1)
                        'stack_arr1.Add(x_val1.ToString() + "," + (start_y1 - 1).ToString())
                    End If
                End If

            Next
        End If
        For x_val1 = x2 + 1 To x1 - 1
            If start_y1 + 1 < bmp1.Height Then

                If compare_colors1(bound_color1, bmp1.GetPixel(x_val1, start_y1 + 1)) = 0 And compare_colors1(color_to_set1, bmp1.GetPixel(x_val1, start_y1 + 1)) = 0 Then
                    'paint_recursive(x_val1, start_y1 + 1, bmp1, bound_color1, color_to_set1)
                    stack_dict1(x_val1.ToString() + "," + (start_y1 + 1).ToString()) = 1

                End If
            End If
            If start_y1 > 0 Then

                If compare_colors1(bound_color1, bmp1.GetPixel(x_val1, start_y1 - 1)) = 0 And compare_colors1(color_to_set1, bmp1.GetPixel(x_val1, start_y1 - 1)) = 0 Then
                    'paint_recursive(x_val1, start_y1 - 1, bmp1, bound_color1, color_to_set1)
                    stack_dict1(x_val1.ToString() + "," + (start_y1 - 1).ToString()) = 1

                End If
            End If
        Next


        Return stack_dict1
    End Function

    Private Sub update_sobel_threshold_btn1_Click(sender As Object, e As EventArgs) Handles update_sobel_threshold_btn1.Click

        Dim sobel_ind As Integer

        If (CGlobals1.last_sobel_threshold > Integer.Parse(txtbox_curent_sobel_threshold1.Text)) Then
            For sobel_ind = Integer.Parse(txtbox_curent_sobel_threshold1.Text) To CGlobals1.last_sobel_threshold

                Dim pixel_arr1 As ArrayList = CGlobals1.dict_sobel_pixels(sobel_ind)
                Dim i1 As Integer

                For i1 = 0 To pixel_arr1.Count - 1
                    Dim x1 As Integer = Integer.Parse(pixel_arr1(i1).split(",")(0).ToString())
                    Dim y1 As Integer = Integer.Parse(pixel_arr1(i1).split(",")(1).ToString())
                    CGlobals1.current_bmp1.SetPixel(x1, y1, Color.FromArgb(255, 255, 255, 255))

                Next
            Next
        Else
            For sobel_ind = CGlobals1.last_sobel_threshold To Integer.Parse(txtbox_curent_sobel_threshold1.Text)

                Dim pixel_arr1 As ArrayList = CGlobals1.dict_sobel_pixels(sobel_ind)
                Dim i1 As Integer

                For i1 = 0 To pixel_arr1.Count - 1
                    Dim x1 As Integer = Integer.Parse(pixel_arr1(i1).split(",")(0).ToString())
                    Dim y1 As Integer = Integer.Parse(pixel_arr1(i1).split(",")(1).ToString())
                    CGlobals1.current_bmp1.SetPixel(x1, y1, Color.FromArgb(255, 0, 0, 0))

                Next
            Next
        End If

        CGlobals1.last_sobel_threshold = Integer.Parse(txtbox_curent_sobel_threshold1.Text)

        PictureBox1.Image = CGlobals1.current_bmp1
        Me.Refresh()

        Return


        For sobel_ind = 0 To Integer.Parse(txtbox_curent_sobel_threshold1.Text)

            Dim pixel_arr1 As ArrayList = CGlobals1.dict_sobel_pixels(Integer.Parse(txtbox_curent_sobel_threshold1.Text))
            Dim i1 As Integer

            For i1 = 0 To pixel_arr1.Count - 1
                Dim x1 As Integer = Integer.Parse(pixel_arr1(i1).split(",")(0).ToString())
                Dim y1 As Integer = Integer.Parse(pixel_arr1(i1).split(",")(1).ToString())
                CGlobals1.current_bmp1.SetPixel(x1, y1, Color.FromArgb(255, 0, 0, 0))

            Next
        Next

        For sobel_ind = Integer.Parse(txtbox_curent_sobel_threshold1.Text) + 1 To CGlobals1.dict_sobel_pixels.Count - 1

            Dim pixel_arr1 As ArrayList = CGlobals1.dict_sobel_pixels(Integer.Parse(txtbox_curent_sobel_threshold1.Text))
            Dim i1 As Integer

            For i1 = 0 To pixel_arr1.Count - 1
                Dim x1 As Integer = Integer.Parse(pixel_arr1(i1).split(",")(0).ToString())
                Dim y1 As Integer = Integer.Parse(pixel_arr1(i1).split(",")(1).ToString())
                CGlobals1.current_bmp1.SetPixel(x1, y1, Color.FromArgb(255, 0, 0, 0))

            Next
        Next

    End Sub

    Private Sub plus_sobel_btn1_Click(sender As Object, e As EventArgs) Handles plus_sobel_btn1.Click
        markingfldimg_obj1.add_dec_sobel_ind("add1", Integer.Parse(txtbox_sobel_factor1.Text))
        txtbox_curent_sobel_threshold1.Text = (markingfldimg_obj1.cur_sobel_ind_val1).ToString()
        'PictureBox1.Image = markingfldimg_obj1.bmp_current_sobel
        PictureBox1.Image = zoom_img1(markingfldimg_obj1.bmp_current_sobel)
    End Sub


    Private Sub minus_sobel_btn1_Click(sender As Object, e As EventArgs) Handles minus_sobel_btn1.Click

        markingfldimg_obj1.add_dec_sobel_ind("dec1", Integer.Parse(txtbox_sobel_factor1.Text))
        txtbox_curent_sobel_threshold1.Text = (markingfldimg_obj1.cur_sobel_ind_val1).ToString()
        PictureBox1.Image = markingfldimg_obj1.bmp_current_sobel
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Text = "ver_11022023_1"

        macros_obj1.markingfldimg_obj1 = markingfldimg_obj1
        CGlobals1.form_obj1 = Me
        'problematic
        '980114933
        '980115778
        'D:\glass_pics1\980115617
        Dim i1 As Integer
        Dim ind1 As Integer = CGlobals1.dir_arr1.Length / 2 - 1
        For i1 = 0 To CGlobals1.dir_arr1.Length / 2 - 1
            CGlobals1.dir_arr1_rev(ind1, 0) = CGlobals1.dir_arr1(i1, 0)
            CGlobals1.dir_arr1_rev(ind1, 1) = CGlobals1.dir_arr1(i1, 1)
            ind1 -= 1
        Next

        txtbox_curent_sobel_threshold1.Text = "1"
        txtbox_cur_pixel_ind1.Text = -1


        file_name1 = "980376398\191966151131__B"
        file_name1 = "980376398\191966151131__A"
        file_name1 = "980378994\195768365710__A"

        file_name1 = "980376449\195768204293__A"
        file_name1 = "980376449\195768204293__C"
        file_name1 = "980376340\195768205504__B"

        file_name1 = "980376340\195768205504__A"

        file_name1 = "980376445\191966121998__A"

        file_name1 = "980376445\191966121998__c"

        'file_name1 = "980376423\195768208772__b"


        txtbox_sobel_factor1.Text = "1"
        Try
            If System.IO.Directory.Exists("c:\img_bg_clean_config1") = False Then
                System.IO.Directory.CreateDirectory("c:\img_bg_clean_config1")
            End If
        Catch ex As Exception

        End Try
        Try
            CGlobals1.global_path1 = System.IO.File.ReadAllText("C:\img_bg_clean_config1\root_path1.txt")
            file_name1 = System.IO.File.ReadAllText("C:\img_bg_clean_config1\file_path1.txt")

        Catch ex As Exception
            select_file_btn1_Click(Nothing, Nothing)
            Return
        End Try
        If CGlobals1.global_path1.Length <= 0 Or file_name1.Length <= 0 Then
            select_file_btn1_Click(Nothing, Nothing)
            Return
        End If
        lbl_root_path1.Text = CGlobals1.global_path1
        lbl_cur_path1.Text = file_name1
        lbl_cur_path1.Text = file_name1


        Return

        CGlobals1.dict_3d_pnts_arrs1("arr_3d_pnts1") = markingfldimg_obj1.load_3d_points_arr(CGlobals1.global_path1 + "arr_3d_pnts1.txt")
        CGlobals1.dict_3d_pnts_arrs1("arr_3d_pnts2") = markingfldimg_obj1.load_3d_points_arr(CGlobals1.global_path1 + "arr_3d_pnts2.txt")


        Dim vec_3d_obj3 As vec_3d1 = New vec_3d1()
        vec_3d_obj3.p1 = New point_3d1(200, 400, 0)
        vec_3d_obj3.p2 = New point_3d1(900, 400, 0)


        markingfldimg_obj1.rotate_3d_points_arr2(CGlobals1.dict_3d_pnts_arrs1("arr_3d_pnts1"), vec_3d_obj3, -20)




        Dim vec_3d_obj2 As vec_3d1 = New vec_3d1()
        vec_3d_obj2.p1 = New point_3d1(900, 90, 0)
        vec_3d_obj2.p2 = New point_3d1(900, 100, 0)


        markingfldimg_obj1.rotate_3d_points_arr2(CGlobals1.dict_3d_pnts_arrs1("arr_3d_pnts1"), vec_3d_obj2, 43)

        Dim vec_3d_obj1 As vec_3d1 = New vec_3d1()
        vec_3d_obj1.p1 = New point_3d1(900, 100, 10)
        vec_3d_obj1.p2 = New point_3d1(900, 100, 0)


        markingfldimg_obj1.rotate_3d_points_arr2(CGlobals1.dict_3d_pnts_arrs1("arr_3d_pnts1"), vec_3d_obj1, 16)

        markingfldimg_obj1.move_3d_points_arr2(CGlobals1.dict_3d_pnts_arrs1("arr_3d_pnts1"), -280, 30, 0)

        Dim bmp1 As Bitmap = New Bitmap(CGlobals1.global_path1 + "temp1.bmp")
        markingfldimg_obj1.set_3d_arr_pixels_on_bmp1_prespective(CGlobals1.dict_3d_pnts_arrs1("arr_3d_pnts1"), bmp1, Color.FromArgb(255, 255, 255))
        markingfldimg_obj1.set_3d_arr_pixels_on_bmp1_prespective(CGlobals1.dict_3d_pnts_arrs1("arr_3d_pnts2"), bmp1, Color.FromArgb(255, 4, 50))
        PictureBox1.Image = zoom_img1(bmp1)





    End Sub

    Private Sub find_sobel_btn1_Click(sender As Object, e As EventArgs) Handles find_sobel_btn1.Click

        x_start2 = 60
        y_start2 = 0

        markingfldimg_obj1.bmp1 = copy_bitmap1(CGlobals1.current_bmp1)
        Dim cord1 As Integer() = markingfldimg_obj1.find_start_point1(x_start2, y_start2)
        x_start2 = cord1(0)
        y_start2 = cord1(1)

        minus_sobel_btn1_Click(Nothing, Nothing)
        update_sobel_threshold_btn1_Click(Nothing, Nothing)


        Dim bmp_copy1 As Bitmap = copy_bitmap1(CGlobals1.current_bmp1)

        markingfldimg_obj1.bmp1 = bmp_copy1
        Try
            bmp_copy1 = markingfldimg_obj1.next_pixels_loop1()

        Catch ex As Exception

        End Try
        If markingfldimg_obj1.success_status = "arrive_to_start_point" Then
            MessageBox.Show("arrive sobel value")
            current_bmp1 = copy_bitmap1(bmp_copy1)
            org_bmp1 = copy_bitmap1(bmp_copy1)
            paint_recursive1()
        End If
        PictureBox1.Image = bmp_copy1
        Return

    End Sub

    Private Sub remove_bg_btn1_Click(sender As Object, e As EventArgs) Handles remove_bg_btn1.Click

        'file_name1 = "980378994\195768365710__A"
        'file_name1 = "980376449\195768204293__A"
        current_bmp1 = New Bitmap(CGlobals1.global_path1 + file_name1 + "_crop_sobel1.jpg")
        org_bmp1 = New Bitmap(CGlobals1.global_path1 + file_name1 + "_crop1.jpg")
        Dim bmp_without_bg1 As Bitmap = markingfldimg_obj1.paint_recursive2(current_bmp1, 2, 2, markingfldimg_obj1.color_of_region, Color.FromArgb(0, 0, 0, 0))
        bmp_without_bg1 = markingfldimg_obj1.remove_around_object1(bmp_without_bg1, Color.FromArgb(0, 0, 0))
        bmp_without_bg1 = markingfldimg_obj1.remove_around_object1(bmp_without_bg1, Color.FromArgb(0, 0, 0))
        bmp_without_bg1.Save(CGlobals1.global_path1 + file_name1 + "_not_bg1.jpg")
        'paint_recursive1()

    End Sub

    Private Sub select_file_btn1_Click(sender As Object, e As EventArgs) Handles select_file_btn1.Click
        Dim file_dlg1 As OpenFileDialog = New OpenFileDialog()
        'file_dlg1.f = "d:"
        file_dlg1.ShowDialog()
        If file_dlg1.FileName.Length <= 0 Then
            Return
        End If
        Dim ind1 As Integer = file_dlg1.FileName.LastIndexOf("\")
        Dim str1 As String = file_dlg1.FileName.Substring(0, ind1)
        Dim ind2 As Integer = str1.LastIndexOf("\")
        Dim str2 As String = file_dlg1.FileName.Substring(0, ind2 + 1)
        CGlobals1.global_path1 = str2
        Dim str3 As String = file_dlg1.FileName.Substring(ind2 + 1)
        Dim ind3 As Integer = str3.LastIndexOf(".")
        Dim str4 As String = str3.Substring(0, ind3)
        file_name1 = str4
        lbl_root_path1.Text = CGlobals1.global_path1
        lbl_cur_path1.Text = file_name1

        System.IO.File.WriteAllText("C:\img_bg_clean_config1\root_path1.txt", CGlobals1.global_path1)
        System.IO.File.WriteAllText("C:\img_bg_clean_config1\file_path1.txt", file_name1)
        'MessageBox.Show(file_dlg1.FileName)
    End Sub

    Private Sub save_cur_image_btn1_Click(sender As Object, e As EventArgs) Handles save_cur_image_btn1.Click
        Dim bmp1 As Bitmap = PictureBox1.Image

        bmp1.Save(CGlobals1.global_path1 + file_name1 + "_cur1.bmp")
    End Sub

    Private Sub lbl_cur_path1_DoubleClick(sender As Object, e As EventArgs) Handles lbl_cur_path1.DoubleClick
        Process.Start("explorer.exe", String.Format("/n, /e, {0}", CGlobals1.global_path1 + file_name1.Substring(0, file_name1.LastIndexOf("\"))))
    End Sub

    Private Sub lbl_root_path1_DoubleClick(sender As Object, e As EventArgs) Handles lbl_root_path1.DoubleClick

        Process.Start("explorer.exe", String.Format("/n, /e, {0}", CGlobals1.global_path1))
    End Sub

    Private Sub find_vertical_center_line1_btn1_Click(sender As Object, e As EventArgs) Handles find_vertical_center_line1_btn1.Click
        Dim arr_2d_pixels1 As ArrayList = markingfldimg_obj1.load_2d_pixels_arr1(CGlobals1.global_path1 + file_name1 + "_2d_pixels1.txt")
        markingfldimg_obj1.find_simetric_line1(arr_2d_pixels1)
    End Sub

    Private Sub LoadSobelArrBySobelIndToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LoadSobelArrBySobelIndToolStripMenuItem.Click

        'save_2d_pixels_arr1(CGlobals1.global_path1 + form_obj1.file_name1 + "_2d_pixels_sobel_" + (cur_sobel_ind_val1 - 1).ToString() + ".txt", prev_dict_res1("pixels_around_sobel_arr1"))
        Dim sobel_ind1 As Integer = Integer.Parse(txtbox_curent_sobel_threshold1.Text)
        Dim pixels_arr1 As ArrayList '= markingfldimg_obj1.load_2d_pixels_arr1(CGlobals1.global_path1 + file_name1 + "_2d_pixels_sobel_" + sobel_ind1.ToString() + ".txt")
        pixels_arr1 = markingfldimg_obj1.load_2d_pixels_arr1(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_frame4.txt")
        Dim path_of_bmp1 As String = CGlobals1.global_path1 + file_name1 + "_sobel_cache1\" + sobel_ind1.ToString() + ".jpg"
        Dim bmp1 As Bitmap = New Bitmap(path_of_bmp1)

        Dim bmp_sobel1 As Bitmap = CGlobals1.create_fill_bitmap(bmp1.Width, bmp1.Height, Color.FromArgb(255, 255, 255))
        markingfldimg_obj1.set_pixel_arr_on_bmp2(pixels_arr1, bmp_sobel1, Color.FromArgb(255, 50, 100))
        CGlobals1.global_vars_dict1("current_pixels_arr_by_sobel_ind1") = pixels_arr1
        CGlobals1.global_vars_dict1("current_bmp_by_sobel_ind1") = bmp_sobel1 'bmp1
        CGlobals1.global_vars_dict1("current_pixel_ind1") = Integer.Parse(txtbox_cur_pixel_ind1.Text)
    End Sub

    Private Sub ShownextpixelToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ShownextpixelToolStripMenuItem.Click

        show_next_pixel(1)

    End Sub

    Private Sub Nextpixel1ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles Nextpixel1ToolStripMenuItem.Click
        show_next_pixel(1)
    End Sub

    Public Function show_next_pixel(dir1 As Integer)
        CGlobals1.global_vars_dict1("current_pixel_ind1") = Integer.Parse(txtbox_cur_pixel_ind1.Text)


        CGlobals1.global_vars_dict1("current_pixel_ind1") += dir1
        txtbox_cur_pixel_ind1.Text = CGlobals1.global_vars_dict1("current_pixel_ind1").ToString()
        Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(CGlobals1.global_vars_dict1("current_pixels_arr_by_sobel_ind1"), CGlobals1.global_vars_dict1("current_pixel_ind1"))
        Dim copy_bmp1 As Bitmap = CGlobals1.copy_bitmap1(CGlobals1.global_vars_dict1("current_bmp_by_sobel_ind1"))

        Dim x1a As Integer
        Dim y1a As Integer

        For x1a = cord_xy1(0) - 4 To cord_xy1(0) + 4
            For y1a = cord_xy1(1) - 4 To cord_xy1(1) + 4
                copy_bmp1.SetPixel(x1a, y1a, Color.FromArgb(200, 30, 50))

            Next

        Next



        PictureBox1.Image = zoom_img1(copy_bmp1, 2)

    End Function

    Private Sub Backpixel1ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles Backpixel1ToolStripMenuItem.Click
        show_next_pixel(-1)
    End Sub
    'חיפוש של כל הקווים לפי סף עובי
    'באג - צריך לסדר שזה גם יהיה ציקלי וימצא גם קווים שמכילים את ההתחלה והסוף בתוכם
    Private Sub FindLinesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles FindLinesToolStripMenuItem.Click
        Dim sobel_ind1 As Integer = Integer.Parse(txtbox_curent_sobel_threshold1.Text)
        Dim pixels_arr1 As ArrayList = markingfldimg_obj1.load_2d_pixels_arr1(CGlobals1.global_path1 + file_name1 + "_2d_pixels_sobel_" + sobel_ind1.ToString() + ".txt")
        Dim path_of_bmp1 As String = CGlobals1.global_path1 + file_name1 + "_sobel_cache1\" + sobel_ind1.ToString() + ".jpg"
        Dim dict_lines1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)
        Dim max_line_width1 As Integer = 3
        Dim start_ind1 As Integer = 0
        Dim max_len1 As Integer
        For start_ind1 = 0 To pixels_arr1.Count - 1
            max_len1 = 5
            Dim res_width_ok1 As Integer = markingfldimg_obj1.find_line_in_pixels_arr(pixels_arr1, start_ind1, max_len1, max_line_width1)
            While res_width_ok1 = 1
                max_len1 *= 2
                res_width_ok1 = markingfldimg_obj1.find_line_in_pixels_arr(pixels_arr1, start_ind1, max_len1, max_line_width1)
            End While
            max_len1 /= 2

            max_len1 -= 1
            res_width_ok1 = markingfldimg_obj1.find_line_in_pixels_arr(pixels_arr1, start_ind1, max_len1, max_line_width1)
            Dim to_stop1 As Integer = 0

            While to_stop1 = 0
                res_width_ok1 = markingfldimg_obj1.find_line_in_pixels_arr(pixels_arr1, start_ind1, max_len1, max_line_width1)

                If res_width_ok1 = 0 Then


                    to_stop1 = 1
                    Dim is_contain_in_dict_lines1 As String = ""
                    Dim was_remove_key1 As String = ""
                    If dict_lines1.Count > 0 Then

                        Dim key_ind1 As Integer

                        Dim to_stop3 As Integer = 0
                        key_ind1 = 0

                        While to_stop3 = 0

                            Dim start_ind2 As Integer = Integer.Parse(dict_lines1.Keys(key_ind1).Split(",")(0))
                            Dim end_ind2 As Integer = Integer.Parse(dict_lines1.Keys(key_ind1).Split(",")(1))
                            'אם יש אורך שהוא מכיל את האורך החדש
                            If start_ind2 <= start_ind1 And end_ind2 >= (start_ind1 + max_len1) Then
                                to_stop3 = 1
                                is_contain_in_dict_lines1 = "yes"
                            End If

                            'אם האורך החדש מכיל אורך קיים
                            If start_ind1 <= start_ind2 And (start_ind1 + max_len1) >= end_ind2 Then
                                dict_lines1.Remove(dict_lines1.Keys(key_ind1))
                            End If


                            'dict_lines1.Remove(dict_lines1.Keys(key_ind1))
                            'was_remove_key1 = "yes"
                            'End If
                            key_ind1 += 1
                            If dict_lines1.Count <= 0 Or key_ind1 > dict_lines1.Count - 1 Then
                                to_stop3 = 1
                            End If
                        End While
                    End If
                    If is_contain_in_dict_lines1 = "" Then


                    End If
                    If is_contain_in_dict_lines1 = "" Or dict_lines1.Count <= 0 Then
                        dict_lines1(start_ind1.ToString() + "," + (start_ind1 + max_len1).ToString()) = max_len1
                    End If
                    'For key_ind1 = 0 To dict_lines1.Keys.Count - 1

                    'Next
                    'dict_lines1(start_ind1) = max_len1
                Else
                    max_len1 += 1
                End If

            End While
        Next
        'מיון הקווים מהארוך ביותר לקצר ביותר
        Dim sorted1 = From pair In dict_lines1 Order By pair.Value Descending
        Dim sortedDictionary1 = sorted1.ToDictionary(Function(p) p.Key, Function(p) p.Value)
        dict_lines1 = sortedDictionary1

        Dim i1 As Integer
        Dim str_lines1 As String = ""
        For i1 = 0 To dict_lines1.Count - 1
            str_lines1 += dict_lines1.Keys(i1) + "#"

        Next

        System.IO.File.WriteAllText(CGlobals1.global_path1 + file_name1 + "_2d_pixels_sobel_" + sobel_ind1.ToString() + "_w_" + max_line_width1.ToString() + ".txt", str_lines1)
    End Sub

    Private Sub LoadLinesArrBySobelIndToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LoadLinesArrBySobelIndToolStripMenuItem.Click
        Dim sobel_ind1 As Integer = Integer.Parse(txtbox_curent_sobel_threshold1.Text)
        Dim max_line_width1 As Integer = 3
        Dim pixels_arr1 As ArrayList ' = markingfldimg_obj1.load_2d_pixels_arr1(CGlobals1.global_path1 + file_name1 + "_2d_pixels_sobel_" + sobel_ind1.ToString() + ".txt")


        Dim org_curve1 As ArrayList = markingfldimg_obj1.load_2d_pixels_arr1(CGlobals1.global_path1 + "\980376445\org_curve1.txt")
        pixels_arr1 = org_curve1
        Dim lines_arr1 As ArrayList ' = markingfldimg_obj1.load_2d_pixels_arr1(CGlobals1.global_path1 + file_name1 + "_2d_pixels_sobel_" + sobel_ind1.ToString() + "_w_" + max_line_width1.ToString() + ".txt")
        Dim path_of_bmp1 As String = CGlobals1.global_path1 + file_name1 + "_sobel_cache1\" + sobel_ind1.ToString() + ".jpg"
        Dim bmp1 As Bitmap = New Bitmap(path_of_bmp1)

        CGlobals1.global_vars_dict1("current_lines_arr_by_sobel_ind1") = lines_arr1
        CGlobals1.global_vars_dict1("current_pixels_arr_by_sobel_ind1") = pixels_arr1
        CGlobals1.global_vars_dict1("current_bmp_by_sobel_ind1") = bmp1
        CGlobals1.global_vars_dict1("current_line_ind1") = Integer.Parse(txtbox_cur_pixel_ind1.Text)
        'merge_lines(pixels_arr1, lines_arr1, 2, 10)
    End Sub
    'מחפשים קווים שהם חופיים מימין לשמאל - אבל לא בפיקסלים
    'כלומר כל קו שייך לצד אחר של ידית או של ידית אחרת
    Public Function find_line_the_overlap_left_to_right_but_different_pixels(pixels_arr1 As ArrayList, lines_arr1 As ArrayList)

    End Function
    Public Function merge_lines(pixels_arr1 As ArrayList, lines_arr1 As ArrayList, max_diff_angle1 As Double, max_distance1 As Double)
        Dim lines_angles1 As Dictionary(Of String, Double) = New Dictionary(Of String, Double)
        Dim line_ind1 As Integer
        Dim line_ind2 As Integer
        For line_ind1 = 0 To lines_arr1.Count - 2
            Dim line_cords_ind1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(lines_arr1, line_ind1)
            Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, line_cords_ind1(0))
            Dim cord_xy2 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, line_cords_ind1(1))
            Dim angle1 As Double = Math.Atan((cord_xy2(1) - cord_xy1(1)) / (cord_xy2(0) - cord_xy1(0))) * 180 / Math.PI
            Dim d1 As Integer = 1
            lines_angles1(lines_arr1(line_ind1)) = angle1
        Next
        For line_ind1 = 0 To lines_arr1.Count - 2
            Dim min_angle_ind2 As Integer
            Dim min_angle1 As Double = 99
            For line_ind2 = 0 To lines_arr1.Count - 2
                If line_ind1 <> line_ind2 Then
                    Dim line_cords_ind1a As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(lines_arr1, line_ind1)
                    Dim cord_xy1a As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, line_cords_ind1a(0))
                    Dim cord_xy2a As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, line_cords_ind1a(1))

                    Dim line_cords_ind1b As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(lines_arr1, line_ind2)
                    Dim cord_xy1b As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, line_cords_ind1b(0))
                    Dim cord_xy2b As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, line_cords_ind1b(1))

                    Dim x_left_line1 As Integer = 0
                    Dim x_right_line1 As Integer = 0
                    If cord_xy1a(0) < cord_xy2a(0) Then
                        x_left_line1 = cord_xy1a(0)
                        x_right_line1 = cord_xy2a(0)
                    Else
                        x_left_line1 = cord_xy2a(0)
                        x_right_line1 = cord_xy1a(0)
                    End If

                    Dim x_left_line2 As Integer = 0
                    Dim x_right_line2 As Integer = 0
                    If cord_xy1b(0) < cord_xy2b(0) Then
                        x_left_line2 = cord_xy1b(0)
                        x_right_line2 = cord_xy2b(0)
                    Else
                        x_left_line2 = cord_xy2b(0)
                        x_right_line2 = cord_xy1b(0)
                    End If
                    Dim dist_min1 As Double = 9999
                    If x_right_line1 < x_left_line2 Or x_right_line2 < x_left_line1 Then
                        Dim dist1 As Integer = Math.Pow(Math.Pow(cord_xy1a(0) - cord_xy1b(0), 2) + Math.Pow(cord_xy1a(1) - cord_xy1b(1), 2), 0.5)
                        Dim dist2 As Integer = Math.Pow(Math.Pow(cord_xy1a(0) - cord_xy2b(0), 2) + Math.Pow(cord_xy1a(1) - cord_xy2b(1), 2), 0.5)
                        Dim dist3 As Integer = Math.Pow(Math.Pow(cord_xy2a(0) - cord_xy1b(0), 2) + Math.Pow(cord_xy2a(1) - cord_xy1b(1), 2), 0.5)
                        Dim dist4 As Integer = Math.Pow(Math.Pow(cord_xy2a(0) - cord_xy2b(0), 2) + Math.Pow(cord_xy2a(1) - cord_xy2b(1), 2), 0.5)
                        dist_min1 = Math.Min(Math.Min(dist1, dist2), Math.Min(dist3, dist4))
                        Dim d12 As Integer = 1
                    End If
                    Dim angle_diff1 As Double = Math.Abs(lines_angles1(lines_arr1(line_ind1)) - lines_angles1(lines_arr1(line_ind2)))
                    If angle_diff1 < min_angle1 And dist_min1 < 5 Then
                        min_angle1 = angle_diff1
                        min_angle_ind2 = line_ind2

                    End If
                End If
            Next
            If Math.Abs(min_angle1) < 1 Then
                Dim copy_bmp1 As Bitmap = CGlobals1.copy_bitmap1(CGlobals1.global_vars_dict1("current_bmp_by_sobel_ind1"))
                markingfldimg_obj1.set_pixel_arr_on_bmp2(pixels_arr1, copy_bmp1, Color.FromArgb(200, 7, 70))
                Dim line_cords_ind1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(lines_arr1, line_ind1)
                Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, line_cords_ind1(0))
                Dim cord_xy2 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, line_cords_ind1(1))
                Dim pixel_arr1b As ArrayList = markingfldimg_obj1.create_pixel_arr_line_from_2_2d_points(cord_xy1(0), cord_xy1(1), cord_xy2(0), cord_xy2(1))
                markingfldimg_obj1.set_pixel_arr_on_bmp2(pixel_arr1b, copy_bmp1, Color.FromArgb(20, 230, 100))


                Dim line_cords_ind2 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(lines_arr1, min_angle_ind2)
                Dim cord_xy1b As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, line_cords_ind2(0))
                Dim cord_xy2b As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, line_cords_ind2(1))
                Dim pixel_arr2b As ArrayList = markingfldimg_obj1.create_pixel_arr_line_from_2_2d_points(cord_xy1b(0), cord_xy1b(1), cord_xy2b(0), cord_xy2b(1))
                markingfldimg_obj1.set_pixel_arr_on_bmp2(pixel_arr2b, copy_bmp1, Color.FromArgb(20, 250, 90))
                copy_bmp1.Save(CGlobals1.global_path1 + file_name1 + "_2_line_.bmp")
                Dim d1 As Integer = 1
            End If


        Next
    End Function
    Private Sub Nextline1ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles Nextline1ToolStripMenuItem.Click
        CGlobals1.global_vars_dict1("current_line_ind1") += 1
        txtbox_cur_pixel_ind1.Text = CGlobals1.global_vars_dict1("current_line_ind1").ToString()
        Dim line_cord_inds1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(CGlobals1.global_vars_dict1("current_lines_arr_by_sobel_ind1"), CGlobals1.global_vars_dict1("current_line_ind1"))
        Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(CGlobals1.global_vars_dict1("current_pixels_arr_by_sobel_ind1"), line_cord_inds1(0))
        Dim cord_xy2 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(CGlobals1.global_vars_dict1("current_pixels_arr_by_sobel_ind1"), line_cord_inds1(1))
        Dim copy_bmp1 As Bitmap = CGlobals1.copy_bitmap1(CGlobals1.global_vars_dict1("current_bmp_by_sobel_ind1"))

        Dim x1a As Integer
        Dim y1a As Integer

        copy_bmp1 = CGlobals1.draw_sqr_around_pixels(copy_bmp1, cord_xy1(0), cord_xy1(1), 4, Color.FromArgb(200, 30, 30))
        copy_bmp1 = CGlobals1.draw_sqr_around_pixels(copy_bmp1, cord_xy2(0), cord_xy2(1), 4, Color.FromArgb(200, 230, 30))



        PictureBox1.Image = zoom_img1(copy_bmp1)
    End Sub

    Private Sub FindMaxLineInGlassToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles FindMaxLineInGlassToolStripMenuItem.Click
        Dim color_of_sign_bg1 As Color = Color.FromArgb(255, 10, 10)
        Dim sobel_ind1 As Integer = Integer.Parse(txtbox_curent_sobel_threshold1.Text)
        Dim pixels_arr1 As ArrayList = markingfldimg_obj1.load_2d_pixels_arr1(CGlobals1.global_path1 + file_name1 + "_2d_pixels_sobel_" + sobel_ind1.ToString() + ".txt")
        Dim path_of_bmp1 As String = CGlobals1.global_path1 + file_name1 + "_sobel_cache1\" + sobel_ind1.ToString() + ".jpg"
        Dim bmp1 As Bitmap = New Bitmap(path_of_bmp1)
        Dim path_of_signbg1 As String = CGlobals1.global_path1 + file_name1 + "_signbg_sobel_" + sobel_ind1.ToString() + ".bmp"
        Dim bmp_without_bg1 As Bitmap
        If System.IO.File.Exists(path_of_signbg1) = True Then
            bmp_without_bg1 = New Bitmap(path_of_signbg1)
        Else
            markingfldimg_obj1.set_pixel_arr_on_bmp_with_width2(pixels_arr1, bmp1, 5, Color.FromArgb(100, 200, 150))

            bmp1.Save(CGlobals1.global_path1 + file_name1 + "_pixels_sobel_" + sobel_ind1.ToString() + ".bmp")
            'org_bmp1 = New Bitmap(CGlobals1.global_path1 + file_name1 + "_crop1.jpg")
            'Return
            bmp_without_bg1 = markingfldimg_obj1.paint_recursive3(bmp1, 2, 2, Color.FromArgb(100, 200, 150), color_of_sign_bg1)
            bmp_without_bg1.Save(CGlobals1.global_path1 + file_name1 + "_signbg_sobel_" + sobel_ind1.ToString() + ".bmp")

        End If
        'markingfldimg_obj1.set_pixel_arr_on_bmp2(pixels_arr1, bmp1, Color.FromArgb(100, 200, 150))
        PictureBox1.Image = zoom_img1(bmp_without_bg1)

        Dim p_ind1 As Integer
        Dim p_ind2 As Integer
        Dim dict_dists1 As Dictionary(Of String, Double) = New Dictionary(Of String, Double)
        Dim min_angle1 As Double = 3
        Dim max_angle1 As Double = 15
        Dim min_dist1 As Double = 500
        For p_ind1 = 0 To pixels_arr1.Count - 1
            For p_ind2 = 0 To pixels_arr1.Count - 1
                If p_ind1 <> p_ind2 And Math.Abs(p_ind1 - p_ind2) > 2 Then
                    Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, p_ind1)
                    Dim cord_xy2 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, p_ind2)

                    Dim angle1 As Double = Math.Atan((cord_xy2(1) - cord_xy1(1)) / (cord_xy2(0) - cord_xy1(0))) * 180 / Math.PI
                    If Math.Abs(angle1) > min_angle1 And Math.Abs(angle1) < max_angle1 Then
                        Dim dist1 As Double = Math.Pow(Math.Pow(cord_xy1(0) - cord_xy2(0), 2) + Math.Pow(cord_xy1(1) - cord_xy2(1), 2), 0.5)
                        If dist1 > min_dist1 Then
                            dict_dists1(p_ind1.ToString() + "," + p_ind2.ToString()) = dist1

                        End If

                    End If
                End If

            Next

        Next

        Dim sorted = From pair In dict_dists1
                     Order By pair.Value Descending
        Dim sortedDictionary = sorted.ToDictionary(Function(p) p.Key, Function(p) p.Value)
        dict_dists1 = sortedDictionary

        Dim dist_ind1 As Integer

        dist_ind1 = 0
        Dim to_save1 As Integer = 0
        While dist_ind1 < dict_dists1.Count
            Dim cord_inds_str1 As String = dict_dists1.Keys(dist_ind1)
            Dim cord_ind1 As Integer = Integer.Parse(cord_inds_str1.Split(",")(0))
            Dim cord_ind2 As Integer = Integer.Parse(cord_inds_str1.Split(",")(1))
            Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, cord_ind1)
            Dim cord_xy2 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, cord_ind2)
            Dim angle1 As Double = Math.Atan((cord_xy2(1) - cord_xy1(1)) / (cord_xy2(0) - cord_xy1(0))) * 180 / Math.PI
            If Math.Abs(angle1) > min_angle1 And Math.Abs(angle1) < max_angle1 Then

                Dim pixel_line_arr1 As ArrayList = markingfldimg_obj1.create_pixel_arr_line_from_2_2d_points(cord_xy1(0), cord_xy1(1), cord_xy2(0), cord_xy2(1))
                Dim i1 As Integer
                Dim good_line1 As String = "yes"
                i1 = 0
                While good_line1 = "yes" And i1 <= pixel_line_arr1.Count - 1
                    Dim cord_xy_in_line As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixel_line_arr1, i1)
                    Dim color1 As Color = get_pixel_at1(bmp_without_bg1, cord_xy_in_line(0), cord_xy_in_line(1))
                    If compare_colors1(color1, color_of_sign_bg1) = 1 Then
                        good_line1 = "no"
                    End If
                    i1 += 1
                End While
                If to_save1 = 1 Then
                    Dim path2 As String = CGlobals1.global_path1 + file_name1 + "_signbg_line_ind1" + dist_ind1.ToString() + ".bmp"
                    markingfldimg_obj1.set_pixels_arr_and_save2(pixel_line_arr1, CGlobals1.copy_bitmap1(bmp_without_bg1), Color.FromArgb(200, 50, 30), path2)
                End If
                If good_line1 = "yes" Then
                    Dim d1 As Integer = 1
                End If
            End If

            dist_ind1 += 1

        End While

        For p_ind1 = 0 To pixels_arr1.Count - 1
            For p_ind2 = 0 To pixels_arr1.Count - 1
                If p_ind1 <> p_ind2 And Math.Abs(p_ind1 - p_ind2) > 400 Then
                    Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, p_ind1)
                    Dim cord_xy2 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, p_ind2)
                    Dim pixel_line_arr1 As ArrayList = markingfldimg_obj1.create_pixel_arr_line_from_2_2d_points(cord_xy1(0), cord_xy1(1), cord_xy2(0), cord_xy2(1))

                    Dim i1 As Integer
                    Dim good_line1 As String = "yes1"
                    i1 = 0
                    While good_line1 = "yes" And i1 <= pixel_line_arr1.Count - 1
                        Dim cord_xy_in_line As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixel_line_arr1, i1)
                        Dim color1 As Color = get_pixel_at1(bmp_without_bg1, cord_xy_in_line(0), cord_xy_in_line(1))
                        If compare_colors1(color1, color_of_sign_bg1) = 1 Then
                            good_line1 = "no"
                        End If
                        i1 += 1
                    End While

                End If
            Next

        Next
    End Sub

    Private Sub FindCurveOfHandlesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles FindCurveOfHandlesToolStripMenuItem.Click
        CGlobals1.clear_all_caches1()
        chkbox_compute_sobel.Checked = True
        load_img_btn1_Click(Nothing, Nothing)

        Dim line_to_search_start_sobel_pixels1 As ArrayList = markingfldimg_obj1.create_pixel_arr_line_from_2_2d_points(500, 0, 500, 2000)
        markingfldimg_obj1.loop_on_sobel_vals3(line_to_search_start_sobel_pixels1)
        'start_timer_btn1_Click(Nothing, Nothing)
        Dim bmp3 As Bitmap = macros_obj1.find_handles_of_glasses1()
        PictureBox1.Image = zoom_img1(bmp3, 3)

        Return

        'find_curve_of_glass_handles1()
        Dim dict_res1 As Dictionary(Of String, Object) = markingfldimg_obj1.find_curves_of_handles1(-1)
        'האינדקס של הפיקסל שממנו מתחילים את הקו הישר
        Dim start_ind1 As Integer = dict_res1("second_pxl_cord_ind1")
        'האינדקס של הפיקסל השמאלי ביותר ששייך לקו ושייך למשקפיים
        Dim end_ind1 As Integer = dict_res1("start_point1")

        Dim pixel_line_arr1 As ArrayList = dict_res1("pxl_line_arr1")
        Dim pixel_arr1 As ArrayList = dict_res1("pixels_arr1")
        'Return
        Dim dict_res2 As Dictionary(Of String, Object) = markingfldimg_obj1.find_curves_of_handles1(1)

        'האינדקס של הפיקסל שממנו מתחילים את הקו הישר
        Dim start_ind2 As Integer = dict_res2("second_pxl_cord_ind1")
        'האינדקס של הפיקסל השמאלי ביותר ששייך לקו ושייך למשקפיים
        Dim end_ind2 As Integer = dict_res2("start_point1")

        Dim pixel_line_arr2 As ArrayList = dict_res2("pxl_line_arr1")
        Dim pixel_arr2 As ArrayList = dict_res2("pixels_arr1")

        Dim left_pixel_arr1 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(pixel_arr2, Math.Min(end_ind1, end_ind2), Math.Max(end_ind1, end_ind2))

        Dim handle_pixel_arr1 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(pixel_arr2, start_ind2, start_ind1)

        Dim bmp1 As Bitmap = New Bitmap(CGlobals1.global_path1 + file_name1 + "_crop1.jpg")
        Dim bmp2 As Bitmap = CGlobals1.create_fill_bitmap(bmp1.Width, bmp1.Height, Color.FromArgb(255, 255, 255))
        markingfldimg_obj1.set_pixel_arr_on_bmp2(left_pixel_arr1, bmp2, Color.FromArgb(255, 200, 70))
        markingfldimg_obj1.set_pixel_arr_on_bmp2(handle_pixel_arr1, bmp2, Color.FromArgb(255, 200, 70))
        markingfldimg_obj1.set_pixel_arr_on_bmp2(pixel_line_arr1, bmp2, Color.FromArgb(255, 200, 70))
        markingfldimg_obj1.set_pixel_arr_on_bmp2(pixel_line_arr2, bmp2, Color.FromArgb(255, 200, 70))
        bmp2 = markingfldimg_obj1.paint_recursive3(bmp2, 20, 20, Color.FromArgb(255, 200, 70), Color.FromArgb(55, 100, 70))

        Dim x1 As Integer
        Dim y1 As Integer
        For x1 = 0 To bmp1.Width - 1
            For y1 = 0 To bmp1.Height - 1
                If markingfldimg_obj1.compare_colors1(markingfldimg_obj1.get_pixel_at1(bmp2, x1, y1), Color.FromArgb(255, 255, 255)) = 1 Then

                Else
                    bmp1.SetPixel(x1, y1, Color.FromArgb(0, 0, 0, 0))
                End If
            Next

        Next

        bmp1 = markingfldimg_obj1.remove_around_object1(bmp1, Color.FromArgb(0, 0, 0))

        bmp1.Save(CGlobals1.global_path1 + file_name1 + "_handle1.bmp")
        PictureBox1.Image = bmp1
        'find_curve_of_glass_handles2()
    End Sub
    'פונקציה שעובדת על הקו של ידיות ומסמנת נוקדות במרחק נימימלי שהן משתי צידי קווי הידית
    Public Function find_curve_of_glass_handles2()
        Dim sobel_ind1 As Integer = Integer.Parse(txtbox_curent_sobel_threshold1.Text)
        Dim path_of_bmp1 As String = CGlobals1.global_path1 + file_name1 + "_sobel_cache1\" + sobel_ind1.ToString() + ".jpg"
        Dim bmp1 As Bitmap = New Bitmap(path_of_bmp1)

        Dim pixels_arr1 As ArrayList = markingfldimg_obj1.load_2d_pixels_arr1(CGlobals1.global_path1 + file_name1 + "_2d_pixels_sobel_" + sobel_ind1.ToString() + ".txt")

        Dim last_secod_cords1 As ArrayList = New ArrayList()
        Dim last_secod_cords2 As ArrayList = New ArrayList()

        Dim dict_second_cord1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)
        Dim i1 As Integer

        Dim dict_pixel_arr1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)

        For i1 = 0 To pixels_arr1.Count - 1
            dict_pixel_arr1(pixels_arr1(i1)) = i1
        Next

        Dim ver_pixels_arr1 As ArrayList = markingfldimg_obj1.create_pixel_arr_line_from_2_2d_points(bmp1.Width / 2 + 220, 0, bmp1.Width / 2 + 220, bmp1.Height - 1)


        Dim to_stop1 As Integer = 0

        Dim dict_center_curve_pixels1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)


        Dim first_pxl_cord1 As String = ""
        Dim second_pxl_cord1 As String = ""
        Dim first_pxl_cord_ind1 As Integer = 0
        Dim second_pxl_cord_ind1 As Integer = 0
        'עוברים עם קו מאונך למטה באמצע עד למעלה - 2 החיתוכים הראשונים זה של הידית התחתונה שהיא השמאלית והקידמית בתמונה
        For i1 = ver_pixels_arr1.Count - 1 To 0 Step -1
            If dict_pixel_arr1.ContainsKey(ver_pixels_arr1(i1)) Then
                Dim d1 As Integer = 1
                If first_pxl_cord1 = "" Then
                    first_pxl_cord1 = ver_pixels_arr1(i1)
                    first_pxl_cord_ind1 = dict_pixel_arr1(ver_pixels_arr1(i1))
                Else
                    If second_pxl_cord1 = "" Then
                        second_pxl_cord1 = ver_pixels_arr1(i1)
                        second_pxl_cord_ind1 = dict_pixel_arr1(ver_pixels_arr1(i1))

                    End If
                End If
            End If
        Next
        Dim last_x1a As Integer = -1
        Dim last_y1a As Integer = -1
        Dim cord_dir1 As Integer = 1
        Dim x1a As Integer = (Integer.Parse(first_pxl_cord1.Split(",")(0)) + Integer.Parse(second_pxl_cord1.Split(",")(0))) / 2
        Dim y1a As Integer = (Integer.Parse(first_pxl_cord1.Split(",")(1)) + Integer.Parse(second_pxl_cord1.Split(",")(1))) / 2

        CGlobals1.draw_sqr_around_pixels2(bmp1, x1a, y1a, 8, Color.FromArgb(200, 150, 100))
        cord_dir1 = -1
        If cord_dir1 = -1 Then
            x1a = (Integer.Parse(second_pxl_cord1.Split(",")(0)) + Integer.Parse(first_pxl_cord1.Split(",")(0))) / 2
            y1a = (Integer.Parse(second_pxl_cord1.Split(",")(1)) + Integer.Parse(first_pxl_cord1.Split(",")(1))) / 2
            Dim temp1 As Integer = first_pxl_cord_ind1
            first_pxl_cord_ind1 = second_pxl_cord_ind1
            second_pxl_cord_ind1 = temp1

        End If
        'Dim x1a As Integer = (Integer.Parse(second_pxl_cord1.Split(",")(0)) + Integer.Parse(first_pxl_cord1.Split(",")(0))) / 2
        'Dim y1a As Integer = (Integer.Parse(second_pxl_cord1.Split(",")(1)) + Integer.Parse(first_pxl_cord1.Split(",")(1))) / 2
        Dim first_pxl_cord_ind1_arr As ArrayList = New ArrayList()

        Dim b1 As Byte = 0
        Dim count_sign_pxls1 As Integer = 0
        Dim count_last_cord_equals1 As Integer = 0
        Dim max_cord_ind1 As Integer = -1
        Dim count_not_over_max_cord1 As Integer = 0
        While to_stop1 = 0




            Dim min_first_pxl_cord_ind1 As Integer = -1
            Dim min_second_pxl_cord_ind1 As Integer = -1



            Dim x1b As Integer
            Dim y1b As Integer

            Dim min_x1b As Integer = -1
            Dim min_y1b As Integer = -1
            If dict_center_curve_pixels1.Count = 190 Then
                Dim d2 As Integer = 1
            End If

            Dim min_dist1 As Double = 999

            Dim min_dist1_ind1 As Integer = -1
            For i1 = second_pxl_cord_ind1 - 20 To second_pxl_cord_ind1 + 20
                Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, first_pxl_cord_ind1)
                Dim cord_xy2 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, i1)
                Dim dist1 As Double = Math.Pow(Math.Pow(cord_xy1(0) - cord_xy2(0), 2) + Math.Pow(cord_xy1(1) - cord_xy2(1), 2), 0.5)
                If min_dist1 > dist1 Then
                    min_dist1 = dist1
                    min_dist1_ind1 = i1

                End If
            Next
            second_pxl_cord_ind1 = min_dist1_ind1

            If cord_dir1 = 1 Then
                If max_cord_ind1 = -1 Then
                    max_cord_ind1 = second_pxl_cord_ind1
                Else
                    If max_cord_ind1 > second_pxl_cord_ind1 Then
                        max_cord_ind1 = second_pxl_cord_ind1
                        count_not_over_max_cord1 = 0

                    Else
                        count_not_over_max_cord1 += 1
                    End If
                End If
            Else
                If max_cord_ind1 = -1 Then
                    max_cord_ind1 = second_pxl_cord_ind1
                Else
                    If max_cord_ind1 < second_pxl_cord_ind1 Then
                        max_cord_ind1 = second_pxl_cord_ind1
                        count_not_over_max_cord1 = 0
                    Else
                        count_not_over_max_cord1 += 1
                    End If
                End If
            End If

            If count_not_over_max_cord1 > 50 Then
                to_stop1 = 1
            End If
            Dim delta_search_second_cord1 As Integer = 40
            If first_pxl_cord_ind1 >= second_pxl_cord_ind1 - delta_search_second_cord1 And first_pxl_cord_ind1 <= second_pxl_cord_ind1 + delta_search_second_cord1 Then
                to_stop1 = 1
            End If


            Dim cord_xy1b As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, first_pxl_cord_ind1)
            Dim cord_xy2b As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, min_dist1_ind1)

            Dim x_center1 As Integer = (cord_xy1b(0) + cord_xy2b(0)) / 2
            Dim y_center1 As Integer = (cord_xy1b(1) + cord_xy2b(1)) / 2

            'first_pxl_cord_ind1 -= 1
            first_pxl_cord_ind1 += cord_dir1
            CGlobals1.draw_sqr_around_pixels2(bmp1, cord_xy1b(0), cord_xy1b(1), 3, Color.FromArgb(200, 50, 100))
            CGlobals1.draw_sqr_around_pixels2(bmp1, cord_xy2b(0), cord_xy2b(1), 3, Color.FromArgb(1, 50, 100))


            last_secod_cords2.Add(cord_xy1b(0).ToString() + "," + cord_xy1b(1).ToString())

            If cord_dir1 = 1 Then

                last_secod_cords1.Add(cord_xy2b(0).ToString() + "," + cord_xy2b(1).ToString())
                'dict_second_cord1(cord_xy2b(0).ToString() + "," + cord_xy2b(1).ToString()) = 1
            Else
                last_secod_cords1.Add(cord_xy1b(0).ToString() + "," + cord_xy1b(1).ToString())
                'dict_second_cord1(cord_xy1b(0).ToString() + "," + cord_xy1b(1).ToString()) = 1

            End If

            Dim max_last_cords1 As Integer = 40

            If count_sign_pxls1 >= 50 Then

                Dim all_last_cords_equal1 As String = "yes"
                Dim last_secod_cords1_ind1 As Integer
                For last_secod_cords1_ind1 = max_last_cords1 To 0 Step -1
                    If dict_second_cord1.ContainsKey(last_secod_cords1(last_secod_cords1_ind1)) = False Then
                        all_last_cords_equal1 = "no"
                    End If
                Next

                If all_last_cords_equal1 = "yes" Then
                    count_last_cord_equals1 += 1
                    If count_last_cord_equals1 > 10 Then
                        'to_stop1 = 1
                    End If

                End If
            End If


            If cord_dir1 = 1 Then
                'last_secod_cords1.Add(cord_xy2b(0).ToString() + "," + cord_xy2b(1).ToString())
                dict_second_cord1(cord_xy2b(0).ToString() + "," + cord_xy2b(1).ToString()) = 1
            Else
                'last_secod_cords1.Add(cord_xy1b(0).ToString() + "," + cord_xy1b(1).ToString())
                dict_second_cord1(cord_xy1b(0).ToString() + "," + cord_xy1b(1).ToString()) = 1

            End If
            While last_secod_cords1.Count > max_last_cords1 + 1
                last_secod_cords1.RemoveAt(0)
            End While
            'bmp1.SetPixel(x_center1, y_center1, Color.FromArgb(255, 230, 30))
            'bmp1.SetPixel(x_center1, y_center1, Color.FromArgb(255, 30, 230))

            bmp1.SetPixel(x_center1, y_center1, Color.FromArgb(255, 30, 30))
            count_sign_pxls1 += 1
            If count_sign_pxls1 > 1400 Then
                to_stop1 = 1
            End If
        End While

        PictureBox1.Image = zoom_img1(bmp1, 2.7)
    End Function
    Public Function find_curve_of_glass_handles1()
        Dim sobel_ind1 As Integer = Integer.Parse(txtbox_curent_sobel_threshold1.Text)
        Dim path_of_bmp1 As String = CGlobals1.global_path1 + file_name1 + "_sobel_cache1\" + sobel_ind1.ToString() + ".jpg"
        Dim bmp1 As Bitmap = New Bitmap(path_of_bmp1)

        Dim pixels_arr1 As ArrayList = markingfldimg_obj1.load_2d_pixels_arr1(CGlobals1.global_path1 + file_name1 + "_2d_pixels_sobel_" + sobel_ind1.ToString() + ".txt")


        Dim i1 As Integer

        Dim dict_pixel_arr1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)

        For i1 = 0 To pixels_arr1.Count - 1
            dict_pixel_arr1(pixels_arr1(i1)) = i1
        Next

        Dim ver_pixels_arr1 As ArrayList = markingfldimg_obj1.create_pixel_arr_line_from_2_2d_points(bmp1.Width / 2 + 220, 0, bmp1.Width / 2 + 220, bmp1.Height - 1)


        Dim to_stop1 As Integer = 0

        Dim dict_center_curve_pixels1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)


        Dim first_pxl_cord1 As String = ""
        Dim second_pxl_cord1 As String = ""
        Dim first_pxl_cord_ind1 As Integer = 0
        Dim second_pxl_cord_ind1 As Integer = 0

        For i1 = ver_pixels_arr1.Count - 1 To 0 Step -1
            If dict_pixel_arr1.ContainsKey(ver_pixels_arr1(i1)) Then
                Dim d1 As Integer = 1
                If first_pxl_cord1 = "" Then
                    first_pxl_cord1 = ver_pixels_arr1(i1)
                    first_pxl_cord_ind1 = dict_pixel_arr1(ver_pixels_arr1(i1))
                Else
                    If second_pxl_cord1 = "" Then
                        second_pxl_cord1 = ver_pixels_arr1(i1)
                        second_pxl_cord_ind1 = dict_pixel_arr1(ver_pixels_arr1(i1))

                    End If
                End If
            End If
        Next
        Dim last_x1a As Integer = -1
        Dim last_y1a As Integer = -1

        Dim x1a As Integer = (Integer.Parse(first_pxl_cord1.Split(",")(0)) + Integer.Parse(second_pxl_cord1.Split(",")(0))) / 2
        Dim y1a As Integer = (Integer.Parse(first_pxl_cord1.Split(",")(1)) + Integer.Parse(second_pxl_cord1.Split(",")(1))) / 2
        Dim first_pxl_cord_ind1_arr As ArrayList = New ArrayList()

        Dim b1 As Byte = 0
        While to_stop1 = 0


            Dim min_first_pxl_cord_ind1 As Integer = -1
            Dim min_second_pxl_cord_ind1 As Integer = -1



            Dim x1b As Integer
            Dim y1b As Integer

            Dim min_x1b As Integer = -1
            Dim min_y1b As Integer = -1
            If dict_center_curve_pixels1.Count = 190 Then
                Dim d2 As Integer = 1
            End If

            Dim min_dist1 As Double = 999
            For x1b = x1a - 70 To x1a + 70
                For y1b = y1a - 70 To y1a + 70
                    '{[772,118, 1]}
                    '{[772,113, 1]}
                    If x1b = 773 And y1b = 114 And dict_center_curve_pixels1.Count > 14 Or dict_center_curve_pixels1.Count = 15 Then
                        Dim d3 As Integer = 1
                    End If

                    Dim check_this_pixels As String = "no"
                    'If dict_center_curve_pixels1.ContainsKey(x1b.ToString() + "," + y1b.ToString()) = False And Math.Abs(last_x1a - x1b) <= 1 And Math.Abs(last_y1a - y1b) <= 1 Then
                    If dict_center_curve_pixels1.ContainsKey(x1b.ToString() + "," + y1b.ToString()) = False Then
                        If last_x1a <> -1 And last_y1a <> -1 And Math.Abs(last_x1a - x1b) <= 1 And Math.Abs(last_y1a - y1b) <= 1 Then
                            check_this_pixels = "yes"
                        Else
                            If last_x1a = -1 And last_y1a = -1 Then

                                check_this_pixels = "yes"
                            End If
                        End If
                    End If
                    If check_this_pixels = "yes" Then

                        Dim count_pixels_neigboors1 As Integer = 0

                        Dim i3 As Integer
                        For i3 = 0 To 7

                            Dim dir_x1 As Integer = CGlobals1.dir_arr2(i3, 0)
                            Dim dir_y1 As Integer = CGlobals1.dir_arr2(i3, 1)
                            Dim new_x1 As Integer = x1b + CGlobals1.dir_arr2(i3, 0)
                            Dim new_y1 As Integer = y1b + CGlobals1.dir_arr2(i3, 1)
                            If dict_center_curve_pixels1.ContainsKey(new_x1.ToString() + "," + new_y1.ToString()) = True Then
                                count_pixels_neigboors1 += 1
                            End If

                        Next
                        If count_pixels_neigboors1 > 1 Then
                            check_this_pixels = "no"
                        End If
                    End If
                    If dict_center_curve_pixels1.Count > 2 Then

                        Dim vec_3d_obj1 As vec_3d1 = New vec_3d1()
                        Dim cord_x1a As Integer = Integer.Parse(dict_center_curve_pixels1.Keys(dict_center_curve_pixels1.Count - 2).Split(",")(0))
                        Dim cord_y1a As Integer = Integer.Parse(dict_center_curve_pixels1.Keys(dict_center_curve_pixels1.Count - 2).Split(",")(1))

                        Dim cord_x1b As Integer = Integer.Parse(dict_center_curve_pixels1.Keys(dict_center_curve_pixels1.Count - 1).Split(",")(0))
                        Dim cord_y1b As Integer = Integer.Parse(dict_center_curve_pixels1.Keys(dict_center_curve_pixels1.Count - 1).Split(",")(1))

                        vec_3d_obj1.p1.x1 = cord_x1a
                        vec_3d_obj1.p1.y1 = cord_y1a
                        vec_3d_obj1.p2.x1 = cord_x1b
                        vec_3d_obj1.p2.y1 = cord_y1b
                        Dim vec_3d_obj2 As vec_3d1 = New vec_3d1()
                        vec_3d_obj2.p2.x1 = cord_x1b
                        vec_3d_obj2.p2.y1 = cord_y1b
                        vec_3d_obj2.p2.x1 = x1b
                        vec_3d_obj2.p2.y1 = y1b

                        Dim angle1 As Double = markingfldimg_obj1.get_angle_between_2_3d_vectors(vec_3d_obj1, vec_3d_obj2)
                        If angle1 >= 90 Then
                            check_this_pixels = "no"
                        End If

                    End If

                    If check_this_pixels = "yes" Then



                        Dim dict_dist1 As Dictionary(Of Double, Integer) = New Dictionary(Of Double, Integer)
                        Dim dict_dist2 As Dictionary(Of Double, Integer) = New Dictionary(Of Double, Integer)

                        For i1 = first_pxl_cord_ind1 - 10 To first_pxl_cord_ind1 + 10
                            Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, i1)
                            Dim dist1 As Double = Math.Pow(Math.Pow(x1b - cord_xy1(0), 2) + Math.Pow(y1b - cord_xy1(1), 2), 0.5)
                            dict_dist1(dist1) = i1
                        Next

                        For i1 = second_pxl_cord_ind1 - 10 To second_pxl_cord_ind1 + 10
                            Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, i1)
                            Dim dist1 As Double = Math.Pow(Math.Pow(x1b - cord_xy1(0), 2) + Math.Pow(y1b - cord_xy1(1), 2), 0.5)
                            dict_dist2(dist1) = i1
                        Next


                        Dim sorted1 = From pair In dict_dist1
                                      Order By pair.Key Ascending
                        dict_dist1 = sorted1.ToDictionary(Function(p) p.Key, Function(p) p.Value)

                        Dim sorted2 = From pair In dict_dist2
                                      Order By pair.Key Ascending
                        dict_dist2 = sorted2.ToDictionary(Function(p) p.Key, Function(p) p.Value)

                        Dim diff_dist1 As Double = 0.5
                        Dim found_ind1 As Integer = -1
                        Dim found_ind2 As Integer = -1
                        Dim key_ind1 As Integer
                        Dim key_ind2 As Integer

                        Dim min_dist_by_diff1 As Double = 999

                        If dict_center_curve_pixels1.Count = 191 Then
                            Dim d2 As Integer = 1
                        End If

                        For diff_dist1 = 0 To 2 Step 0.5

                            If found_ind1 = -1 Or True Then

                                'min_dist_by_diff1 = 99
                                For key_ind1 = 0 To dict_dist1.Keys.Count - 1
                                    For key_ind2 = 0 To dict_dist2.Keys.Count - 1
                                        If Math.Abs(dict_dist1.Keys(key_ind1) - dict_dist2.Keys(key_ind2)) <= diff_dist1 Then
                                            If min_dist_by_diff1 > Math.Max(dict_dist1.Keys(key_ind1), dict_dist2.Keys(key_ind2)) Then
                                                min_dist_by_diff1 = Math.Max(dict_dist1.Keys(key_ind1), dict_dist2.Keys(key_ind2))
                                                found_ind1 = key_ind1
                                                found_ind2 = key_ind2
                                            End If
                                            'If found_ind1 = -1 Then
                                            'found_ind1 = key_ind1
                                            'found_ind2 = key_ind2
                                            ' End If
                                        End If
                                    Next

                                Next
                            End If

                        Next
                        If found_ind1 <> -1 Then
                            If min_dist1 > dict_dist1.Keys(found_ind1) Then
                                min_dist1 = dict_dist1.Keys(found_ind1)

                                min_x1b = x1b
                                min_y1b = y1b
                                min_first_pxl_cord_ind1 = dict_dist1(dict_dist1.Keys(found_ind1))
                                min_second_pxl_cord_ind1 = dict_dist2(dict_dist2.Keys(found_ind2))
                            End If

                        End If
                        Dim d1 As Integer = 1
                    End If

                Next

            Next

            x1a = min_x1b
            y1a = min_y1b
            first_pxl_cord_ind1 = min_first_pxl_cord_ind1
            second_pxl_cord_ind1 = min_second_pxl_cord_ind1

            first_pxl_cord_ind1_arr.Add(first_pxl_cord_ind1)

            dict_center_curve_pixels1(min_x1b.ToString() + "," + min_y1b.ToString()) = 1

            last_x1a = min_x1b
            last_y1a = min_y1b
            Try
                If dict_center_curve_pixels1.Count = 191 Then
                    Dim d2 As Integer = 1
                End If
                If b1 >= 200 Then
                    b1 = 0
                End If
                b1 += 1

                Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, min_first_pxl_cord_ind1)
                'bmp1.SetPixel(cord_xy1(0), cord_xy1(1), Color.FromArgb(200, 30, b1))
                bmp1 = CGlobals1.draw_sqr_around_pixels(bmp1, cord_xy1(0), cord_xy1(1), 2, Color.FromArgb(200, 20, 1))
                Dim cord_xy2 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, min_second_pxl_cord_ind1)
                'bmp1.SetPixel(cord_xy1(0), cord_xy1(1), Color.FromArgb(200, 30, b1))
                bmp1 = CGlobals1.draw_sqr_around_pixels(bmp1, cord_xy2(0), cord_xy2(1), 2, Color.FromArgb(50, 200, 1))
                bmp1.SetPixel(min_x1b, min_y1b, Color.FromArgb(200, b1, b1))



            Catch ex As Exception
                PictureBox1.Image = zoom_img1(bmp1)
                bmp1.Save(CGlobals1.global_path1 + "sobel_pics1\curve1.jpg")
                Return 1

            End Try
            If dict_center_curve_pixels1.Count > 1700 Then
                PictureBox1.Image = zoom_img1(bmp1)
                bmp1.SetPixel(min_x1b, min_y1b, Color.FromArgb(200, b1, b1))
                Return 1
            End If
        End While


    End Function
    Private Sub SobelOnSobelToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SobelOnSobelToolStripMenuItem.Click
        Dim pixels_arr1a As ArrayList = markingfldimg_obj1.load_2d_pixels_arr1(CGlobals1.global_path1 + file_name1 + "_2d_pixels_sobel_1.txt")
        Dim pixels_arr1b As ArrayList = markingfldimg_obj1.load_2d_pixels_arr1(CGlobals1.global_path1 + file_name1 + "_2d_pixels_sobel_2.txt")
        Dim path_of_bmp1 As String = CGlobals1.global_path1 + file_name1 + "_sobel_cache1\1.jpg"
        Dim bmp1 As Bitmap = New Bitmap(path_of_bmp1)
        Dim bmp2 As Bitmap = New Bitmap(bmp1.Width, bmp1.Height)
        Dim i1 As Integer
        Dim new_pixels_arr1b As ArrayList = New ArrayList()

        For i1 = 0 To pixels_arr1b.Count - 1
            Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1b, i1)
            cord_xy1(0) *= 1.285
            cord_xy1(1) *= 1.285
            cord_xy1(1) += 110
            cord_xy1(0) -= 80
            new_pixels_arr1b.Add(cord_xy1(0).ToString() + "," + cord_xy1(1).ToString())
        Next

        Dim path_of_bmp8 As String = CGlobals1.global_path1 + file_name1 + "_sobel_cache1\8.jpg"
        Dim bmp8 As Bitmap = New Bitmap(path_of_bmp8)

        markingfldimg_obj1.set_pixel_arr_on_bmp2(pixels_arr1b, bmp8, Color.FromArgb(255, 100, 50))
        markingfldimg_obj1.set_pixel_arr_on_bmp2(new_pixels_arr1b, bmp8, Color.FromArgb(255, 50, 50))

        bmp8.Save(CGlobals1.global_path1 + "sobel_pics1\s_on_s1_b.bmp")
        PictureBox1.Image = zoom_img1(bmp8)
    End Sub

    Private Sub Preparedataset1ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles Preparedataset1ToolStripMenuItem.Click
        Dim files1 As String() = System.IO.Directory.GetFiles("E:\memomi_folder1\dataset3\ANGLE\")
        Dim i1 As Integer

        For i1 = 0 To files1.Count - 1

            Dim file1 As String = files1(i1)
            file1 = file1.Substring(file1.LastIndexOf("\") + 1)
            file1 = file1.ToLower()
            file1 = file1.Substring(0, file1.LastIndexOf("_angle"))

            System.IO.Directory.CreateDirectory("E:\memomi_folder1\dataset3b\" + file1)

            Try
                System.IO.File.Copy(files1(i1), "E:\memomi_folder1\dataset3b\" + file1 + "\" + file1 + "_angle.jpg")

            Catch ex As Exception

            End Try
        Next


        files1 = System.IO.Directory.GetFiles("E:\memomi_folder1\dataset3\FRONT\")


        For i1 = 0 To files1.Count - 1

            Dim file1 As String = files1(i1)
            file1 = file1.Substring(file1.LastIndexOf("\") + 1)
            file1 = file1.ToLower()
            Try
                file1 = file1.Substring(0, file1.LastIndexOf("_front"))

            Catch ex As Exception
                file1 = file1.Substring(0, file1.LastIndexOf(" "))

            End Try

            System.IO.Directory.CreateDirectory("E:\memomi_folder1\dataset3b\" + file1)

            Try
                System.IO.File.Copy(files1(i1), "E:\memomi_folder1\dataset3b\" + file1 + "\" + file1 + "_front.jpg")

            Catch ex As Exception

            End Try
        Next


        files1 = System.IO.Directory.GetFiles("E:\memomi_folder1\dataset3\SIDE\")


        For i1 = 0 To files1.Count - 1

            Dim file1 As String = files1(i1)
            file1 = file1.Substring(file1.LastIndexOf("\") + 1)
            file1 = file1.ToLower()
            Try
                file1 = file1.Substring(0, file1.LastIndexOf("_side"))

            Catch ex As Exception
                file1 = file1.Substring(0, file1.LastIndexOf(" "))

            End Try

            System.IO.Directory.CreateDirectory("E:\memomi_folder1\dataset3b\" + file1)

            Try
                System.IO.File.Copy(files1(i1), "E:\memomi_folder1\dataset3b\" + file1 + "\" + file1 + "_side.jpg")

            Catch ex As Exception

            End Try
        Next


    End Sub

    Public Function check_d_x_y1(x1 As Integer, y1 As Integer)
        If x1 >= 268 And x1 <= 270 And y1 >= 515 And y1 <= 518 Then
            Dim d1 As Integer = 1
        End If
    End Function
    Public Function find_curves1()

        Dim curves_pixels_dict1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)
        Dim only_curves_pixels_dict1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)


        Dim sobel_ind1 As Integer = Integer.Parse(txtbox_curent_sobel_threshold1.Text)
        sobel_ind1 = 90
        Dim path_of_bmp1 As String = CGlobals1.global_path1 + file_name1 + "_sobel_cache1\" + sobel_ind1.ToString() + ".jpg"

        'Dim path_of_bmp1 As String = CGlobals1.global_path1 + file_name1 + "\" + sobel_ind1.ToString() + ".jpg"
        'Dim path_of_bmp1 As String = "D:\glass_pics1\980115778\" + sobel_ind1.ToString() + ".jpg"


        Dim bmp1 As Bitmap = New Bitmap(path_of_bmp1)
        '90,140,170,500

        Dim bmp5 As Bitmap = CGlobals1.crop_bitmap(bmp1, 90, 140, 170 - 90, 500 - 140)
        Dim bmp6 As Bitmap = CGlobals1.create_fill_bitmap(400, 1030, Color.FromArgb(255, 0, 0, 0))
        Dim bmp7 As Bitmap = CGlobals1.copy_bitmap_2_bitmap1(bmp6, bmp5, 5, 5)
        bmp1 = bmp7

        markingfldimg_obj1.bmp_current_sobel = bmp1


        Dim copy_bmp1 As Bitmap = New Bitmap(bmp1.Width, bmp1.Height)

        Dim x1 As Integer
        Dim y1 As Integer

        Dim start_search_curves_ind1 As Integer = 0
        Dim start_search_curves_arr1 As ArrayList = New ArrayList()
        Dim all_curves_arr1 As ArrayList = New ArrayList()
        Dim last_pixel_ind1 As Integer = 0

        Dim x_padding1 As Integer = 5
        Dim y_padding1 As Integer = 5
        For x1 = x_padding1 To copy_bmp1.Width - 1 - x_padding1
            For y1 = y_padding1 To copy_bmp1.Height - 1 - y_padding1
                If x1 >= 0 And x1 <= 500 And y1 >= 0 And y1 <= 1500 Then

                    copy_bmp1.SetPixel(x1, y1, Color.FromArgb(255, 0, 0, 0))


                    If x1 = 310 And y1 = 544 Then
                        Dim d1 As Integer = 1
                    End If
                    If x1 = 21 And y1 = 135 Then
                        Dim d1 As Integer = 1
                    End If


                    If CGlobals1.compare_colors1(markingfldimg_obj1.get_pixel_at1(markingfldimg_obj1.bmp_current_sobel, x1, y1), markingfldimg_obj1.color_of_sobel) = 1 And x1 > 5 And x1 < 500 And y1 > 5 And y1 < 900 Then
                        Dim dir_ind1 As Integer = 0
                        Dim new_cord_x1 As Integer = x1 + CGlobals1.dir_arr1(dir_ind1, 0)
                        Dim new_cord_y1 As Integer = y1 + CGlobals1.dir_arr1(dir_ind1, 1)
                        Dim count_not_sobel_around1 As Integer = 0
                        Dim p_ind1 As Integer

                        For dir_ind1 = 0 To CGlobals1.dir_arr1.Length / 2 - 1
                            new_cord_x1 = x1 + CGlobals1.dir_arr1(dir_ind1, 0)
                            new_cord_y1 = y1 + CGlobals1.dir_arr1(dir_ind1, 1)
                            If CGlobals1.compare_colors1(markingfldimg_obj1.get_pixel_at1(markingfldimg_obj1.bmp_current_sobel, new_cord_x1, new_cord_y1), markingfldimg_obj1.color_of_sobel) = 0 Then
                                count_not_sobel_around1 += 1
                            End If
                        Next
                        Dim no_sbel_in_left_or_right1 As Integer = 0

                        If CGlobals1.compare_colors1(markingfldimg_obj1.get_pixel_at1(markingfldimg_obj1.bmp_current_sobel, x1 + 1, y1), markingfldimg_obj1.color_of_sobel) = 0 Or
                                CGlobals1.compare_colors1(markingfldimg_obj1.get_pixel_at1(markingfldimg_obj1.bmp_current_sobel, x1 - 1, y1), markingfldimg_obj1.color_of_sobel) = 0 Then
                            no_sbel_in_left_or_right1 = 1
                        End If

                        If count_not_sobel_around1 >= 3 And no_sbel_in_left_or_right1 = 1 Then ' Or True Then
                            If x1 = 269 And y1 = 516 Then
                                Dim d1 As Integer = 1
                            End If
                            'If last_pixel_ind1 Mod 20 = 0 Then
                            If x1 = 18 And y1 = 8 Then
                                Dim d1 As Integer = 4
                            End If
                            start_search_curves_arr1.Add(New Integer() {x1, y1})

                            'End If
                            copy_bmp1.SetPixel(x1, y1, Color.FromArgb(0, 255, 255, 255))
                            last_pixel_ind1 += 1

                        End If
                        'If CGlobals1.compare_colors1(markingfldimg_obj1.get_pixel_at1(markingfldimg_obj1.bmp_current_sobel, new_cord_x1, new_cord_y1), markingfldimg_obj1.color_of_sobel) = 0 Then
                        'start_search_curves_arr1.Add(New Integer() {x1, y1})
                        'copy_bmp1.SetPixel(x1, y1, Color.FromArgb(255, 255, 255, 255))

                        'End If


                    End If
                End If

            Next

        Next

        copy_bmp1.Save(CGlobals1.global_path1 + "sobel_pics1\curves_1.bmp")

        'start_search_curves_arr1.Clear()
        'start_search_curves_arr1.Add(New Integer() {310, 544})
        'start_search_curves_arr1.Add(New Integer() {33, 116})

        x_start2 = 7
        y_start2 = 50

        Dim dict_res1 As Dictionary(Of String, Object)
        Dim to_save1 As Integer = 0

        Dim i1 As Integer

        CGlobals1.dir_x1_to_sobel = 1
        CGlobals1.dir_m1_to_sobel = 0
        Dim to_stop1 As Integer = 0

        x_start2 = start_search_curves_arr1(start_search_curves_ind1)(0)
        y_start2 = start_search_curves_arr1(start_search_curves_ind1)(1)
        'markingfldimg_obj1.compute_current_start_cord_and_vec1()
        While to_stop1 = 0







            'While (get_pixel_at1(bmp1, x_start2, y_start2).R <> markingfldimg_obj1.color_of_sobel.R Or
            'get_pixel_at1(bmp1, x_start2, y_start2).G <> markingfldimg_obj1.color_of_sobel.G Or
            'get_pixel_at1(bmp1, x_start2, y_start2).B <> markingfldimg_obj1.color_of_sobel.B) And y_start2 < bmp1.Height - 1 And x_start2 < bmp1.Width - 1
            'x_start2 += CGlobals1.dir_x1_to_sobel
            'y_start2 += CGlobals1.dir_m1_to_sobel

            'End While


            If start_search_curves_ind1 <= 199 And start_search_curves_ind1 > 0 Then
                Dim d4 As Integer = 1
            End If

            While curves_pixels_dict1.ContainsKey(x_start2.ToString() + "," + y_start2.ToString()) = True
                check_d_x_y1(x_start2, y_start2)

                If start_search_curves_ind1 = 199 Then
                    Dim d4 As Integer = 1
                End If
                start_search_curves_ind1 += 1

                If start_search_curves_ind1 >= start_search_curves_arr1.Count Then
                    For i3 = 0 To all_curves_arr1.Count - 1
                        markingfldimg_obj1.save_2d_pixels_arr1(CGlobals1.global_path1 + "sobel_pics1\curves_pxls_" + i3.ToString() + ".txt", all_curves_arr1(i3))
                    Next
                    Return 1
                End If
                x_start2 = start_search_curves_arr1(start_search_curves_ind1)(0)
                y_start2 = start_search_curves_arr1(start_search_curves_ind1)(1)
                check_d_x_y1(x_start2, y_start2)
            End While

            Dim last_start_search_curves_ind1 As Integer = start_search_curves_ind1
            If start_search_curves_ind1 = 11 Then
                Dim d4 As Integer = 1
            End If
            If curves_pixels_dict1.ContainsKey(x_start2.ToString() + "," + y_start2.ToString()) = False Then

                dict_res1 = markingfldimg_obj1.find_max_sobel_length2(x_start2, y_start2)



                While dict_res1("pixels_around_sobel_arr1")("max_pixels_arr1").Count <= 0 And dict_res1("pixels_around_sobel_arr1_rev")("max_pixels_arr1").Count <= 0
                    check_d_x_y1(x_start2, y_start2)
                    If start_search_curves_ind1 = 11 Then
                        Dim d4 As Integer = 1
                    End If
                    start_search_curves_ind1 += 1

                    If start_search_curves_ind1 >= start_search_curves_arr1.Count Then
                        For i3 = 0 To all_curves_arr1.Count - 1
                            markingfldimg_obj1.save_2d_pixels_arr1(CGlobals1.global_path1 + "sobel_pics1\curves_pxls_" + i3.ToString() + ".txt", all_curves_arr1(i3))
                        Next
                        Return 1
                    End If

                    x_start2 = start_search_curves_arr1(start_search_curves_ind1)(0)
                    y_start2 = start_search_curves_arr1(start_search_curves_ind1)(1)
                    check_d_x_y1(x_start2, y_start2)
                    If start_search_curves_ind1 = 11 Then
                        Dim d4 As Integer = 1
                    End If
                    While curves_pixels_dict1.ContainsKey(x_start2.ToString() + "," + y_start2.ToString()) = True
                        check_d_x_y1(x_start2, y_start2)
                        If start_search_curves_ind1 = 199 Then
                            Dim d4 As Integer = 1
                        End If
                        start_search_curves_ind1 += 1
                        If start_search_curves_ind1 >= start_search_curves_arr1.Count Then
                            For i3 = 0 To all_curves_arr1.Count - 1
                                markingfldimg_obj1.save_2d_pixels_arr1(CGlobals1.global_path1 + "sobel_pics1\curves_pxls_" + i3.ToString() + ".txt", all_curves_arr1(i3))
                            Next
                            Return 1
                        End If

                        x_start2 = start_search_curves_arr1(start_search_curves_ind1)(0)
                        y_start2 = start_search_curves_arr1(start_search_curves_ind1)(1)
                        check_d_x_y1(x_start2, y_start2)

                    End While
                    If start_search_curves_ind1 = 11 Then
                        Dim d4 As Integer = 1
                    End If
                    If curves_pixels_dict1.ContainsKey(x_start2.ToString() + "," + y_start2.ToString()) = False Then
                        dict_res1 = markingfldimg_obj1.find_max_sobel_length2(x_start2, y_start2)

                    End If




                    'Dim i1 As Integer


                    For i1 = 0 To dict_res1("pixels_around_sobel_arr1")("over_all_pixels_arr1").Count - 1
                        If dict_res1("pixels_around_sobel_arr1")("over_all_pixels_arr1")(i1) = "269,516" Then
                            Dim d1 As Integer = 1
                        End If
                        curves_pixels_dict1(dict_res1("pixels_around_sobel_arr1")("over_all_pixels_arr1")(i1)) = 1
                    Next
                    For i1 = 0 To dict_res1("pixels_around_sobel_arr1_rev")("over_all_pixels_arr1").Count - 1
                        If dict_res1("pixels_around_sobel_arr1_rev")("over_all_pixels_arr1")(i1) = "269,516" Then
                            Dim d1 As Integer = 1
                        End If
                        curves_pixels_dict1(dict_res1("pixels_around_sobel_arr1_rev")("over_all_pixels_arr1")(i1)) = 1
                    Next


                End While

                If start_search_curves_ind1 = 11 Then
                    Dim d4 As Integer = 1
                End If

                'Dim i1 As Integer

                If False Then

                    For i1 = 0 To dict_res1("pixels_around_sobel_arr1")("over_all_pixels_arr1").Count - 1
                        If dict_res1("pixels_around_sobel_arr1")("over_all_pixels_arr1")(i1) = "269,516" Then
                            Dim d1 As Integer = 1
                        End If
                        curves_pixels_dict1(dict_res1("pixels_around_sobel_arr1")("over_all_pixels_arr1")(i1)) = 1
                    Next
                    For i1 = 0 To dict_res1("pixels_around_sobel_arr1_rev")("over_all_pixels_arr1").Count - 1
                        If dict_res1("pixels_around_sobel_arr1_rev")("over_all_pixels_arr1")(i1) = "269,516" Then
                            Dim d1 As Integer = 1
                        End If
                        curves_pixels_dict1(dict_res1("pixels_around_sobel_arr1_rev")("over_all_pixels_arr1")(i1)) = 1
                    Next


                End If


                'Dim curves_arr1 As ArrayList = markingfldimg_obj1.get_curve_from_pixels_arr_by_region(dict_res1("pixels_around_sobel_arr1")("pixels_cords_arr1"), 0, 0, 450, 1070)
                'Dim curves_arr2 As ArrayList = markingfldimg_obj1.get_curve_from_pixels_arr_by_region(dict_res1("pixels_around_sobel_arr1_rev")("pixels_cords_arr1"), 0, 0, 450, 1070)

                'Dim curves_arr1 As ArrayList = markingfldimg_obj1.get_curve_from_pixels_arr_by_region(dict_res1("pixels_around_sobel_arr1")("max_pixels_arr1"), 0, 0, 450, 1070)
                'Dim curves_arr2 As ArrayList = markingfldimg_obj1.get_curve_from_pixels_arr_by_region(dict_res1("pixels_around_sobel_arr1_rev")("max_pixels_arr1"), 0, 0, 450, 1070)

                Dim curves_arr1 As ArrayList = markingfldimg_obj1.get_curve_from_pixels_arr_by_region(dict_res1("pixels_around_sobel_arr1")("max_pixels_arr1"), 0, 0, 450, 1070)
                Dim curves_arr2 As ArrayList = markingfldimg_obj1.get_curve_from_pixels_arr_by_region(dict_res1("pixels_around_sobel_arr1_rev")("max_pixels_arr1"), 0, 0, 450, 1070)


                For i1 = 0 To curves_arr1.Count - 1
                    Dim i2 As Integer

                    For i2 = 0 To curves_arr1(i1).Count - 1
                        Dim cord_xy1a As Integer = Integer.Parse(curves_arr1(i1)(i2).ToString().Split(",")(0).ToString())
                        Dim cord_xy1b As Integer = Integer.Parse(curves_arr1(i1)(i2).ToString().Split(",")(1).ToString())
                        If cord_xy1a = 326 And cord_xy1b = 427 Then
                            Dim d3 As Integer = 1
                        End If
                        copy_bmp1.SetPixel(cord_xy1a, cord_xy1b, Color.FromArgb(255, 160, 50, 90))
                        If curves_pixels_dict1.ContainsKey("19,5") = False And curves_arr1(i1)(i2) = "19,5" Then
                            Dim d1 As Integer = 1
                        End If
                        If curves_pixels_dict1.ContainsKey(curves_arr1(i1)(i2)) = True Then
                            Dim err1 As Integer = 1
                        End If
                        curves_pixels_dict1(curves_arr1(i1)(i2)) = 1

                        'only_curves_pixels_dict1


                        If only_curves_pixels_dict1.ContainsKey(curves_arr1(i1)(i2)) = True Then
                            Dim err1 As Integer = 1
                        End If
                        only_curves_pixels_dict1(curves_arr1(i1)(i2)) = 1


                    Next
                    all_curves_arr1.Add(curves_arr1(i1).Clone())
                Next
                If dict_res1("pixels_around_sobel_arr1")("close_loop1") = "yes" Then
                Else
                    curves_arr1 = curves_arr2
                    For i1 = 0 To curves_arr1.Count - 1
                        Dim i2 As Integer
                        Dim count_exist_pixels1 As Integer = 0
                        For i2 = 0 To curves_arr1(i1).Count - 1

                            Dim cord_xy1a As Integer = Integer.Parse(curves_arr1(i1)(i2).ToString().Split(",")(0).ToString())
                            Dim cord_xy1b As Integer = Integer.Parse(curves_arr1(i1)(i2).ToString().Split(",")(1).ToString())
                            If cord_xy1a = 326 And cord_xy1b = 427 Then
                                Dim d3 As Integer = 1
                            End If

                            copy_bmp1.SetPixel(cord_xy1a, cord_xy1b, Color.FromArgb(255, 160, 50, 90))

                            If curves_pixels_dict1.ContainsKey(curves_arr1(i1)(i2)) = True Then
                                Dim err1 As Integer = 1
                                count_exist_pixels1 += 1
                            End If
                            curves_pixels_dict1(curves_arr1(i1)(i2)) = 1

                            If only_curves_pixels_dict1.ContainsKey(curves_arr1(i1)(i2)) = True Then
                                Dim err1 As Integer = 1
                            End If
                            only_curves_pixels_dict1(curves_arr1(i1)(i2)) = 1

                        Next
                        If count_exist_pixels1 >= curves_arr1(i1).Count - 1 Then
                        Else
                            all_curves_arr1.Add(curves_arr1(i1).Clone())
                        End If

                    Next

                End If


            End If

            If start_search_curves_ind1 >= start_search_curves_arr1.Count - 500 Then
                to_stop1 = 1
                to_save1 = 1
            End If
            If to_save1 = 1 Then



                copy_bmp1.Save(CGlobals1.global_path1 + "sobel_pics1\curves_" + start_search_curves_ind1.ToString() + ".bmp")

                Dim i3 As Integer


                For i3 = 0 To all_curves_arr1.Count - 1
                    markingfldimg_obj1.save_2d_pixels_arr1(CGlobals1.global_path1 + "sobel_pics1\curves_pxls_" + i3.ToString() + ".txt", all_curves_arr1(i3))
                Next
                Dim count_over_edge1 As Integer = 0

                For i3 = 0 To start_search_curves_arr1.Count - 1
                    Dim x_start3 As Integer = start_search_curves_arr1(i3)(0)
                    Dim y_start3 As Integer = start_search_curves_arr1(i3)(1)
                    If curves_pixels_dict1.ContainsKey(x_start3.ToString() + "," + y_start3.ToString()) = True Then
                        count_over_edge1 += 1
                    End If

                Next


            End If
            start_search_curves_ind1 += 1



        End While
    End Function
    Private Sub SignSobelToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SignSobelToolStripMenuItem.Click

        find_curves1()

        Return
        Dim sobel_ind1 As Integer = Integer.Parse(txtbox_curent_sobel_threshold1.Text)
        sobel_ind1 = 28
        Dim path_of_bmp1 As String = CGlobals1.global_path1 + file_name1 + "_sobel_cache1\" + sobel_ind1.ToString() + ".jpg"



        Dim bmp1 As Bitmap = New Bitmap(path_of_bmp1)
        bmp1.Save(CGlobals1.global_path1 + "sobel_pics1\f1.bmp")
        bmp1 = markingfldimg_obj1.filter_bmp_by_count_pxls_neigboors(bmp1, 8, Color.FromArgb(255, 255, 255))
        bmp1.Save(CGlobals1.global_path1 + "sobel_pics1\f2.bmp")
        'PictureBox1.Image = bmp1 ' zoom_img1(bmp1)
        'Return
        markingfldimg_obj1.bmp_current_sobel = bmp1
        x_start2 = 94
        y_start2 = 367

        'x_start2 = 133
        'y_start2 = 167

        x_start2 = 43
        y_start2 = 264

        'x_start2 = 94
        'y_start2 = 367

        x_start2 = 103
        y_start2 = 587

        x_start2 = 56
        y_start2 = 86


        x_start2 = 165
        y_start2 = 165


        x_start2 = 70
        y_start2 = 170

        Dim dict_res1 As Dictionary(Of String, Object)


        CGlobals1.dir_x1_to_sobel = 1
        CGlobals1.dir_m1_to_sobel = 0

        'markingfldimg_obj1.compute_current_start_cord_and_vec1()


        While (get_pixel_at1(bmp1, x_start2, y_start2).R <> markingfldimg_obj1.color_of_sobel.R Or
                   get_pixel_at1(bmp1, x_start2, y_start2).G <> markingfldimg_obj1.color_of_sobel.G Or
                   get_pixel_at1(bmp1, x_start2, y_start2).B <> markingfldimg_obj1.color_of_sobel.B) And y_start2 < bmp1.Height - 1 And x_start2 < bmp1.Width - 1
            x_start2 += CGlobals1.dir_x1_to_sobel
            y_start2 += CGlobals1.dir_m1_to_sobel

        End While


        dict_res1 = markingfldimg_obj1.find_max_sobel_length2(x_start2, y_start2)

        If dict_res1("pixels_around_sobel_arr1").Count <= 0 Then
            While ((get_pixel_at1(bmp1, x_start2, y_start2).R <> markingfldimg_obj1.color_of_sobel.R Or
                   get_pixel_at1(bmp1, x_start2, y_start2).G <> markingfldimg_obj1.color_of_sobel.G Or
                   get_pixel_at1(bmp1, x_start2, y_start2).B <> markingfldimg_obj1.color_of_sobel.B) And y_start2 < bmp1.Height - 1 And x_start2 < bmp1.Width - 1) = False
                x_start2 += CGlobals1.dir_x1_to_sobel
                y_start2 += CGlobals1.dir_m1_to_sobel

            End While
            While ((get_pixel_at1(bmp1, x_start2, y_start2).R <> markingfldimg_obj1.color_of_sobel.R Or
                   get_pixel_at1(bmp1, x_start2, y_start2).G <> markingfldimg_obj1.color_of_sobel.G Or
                   get_pixel_at1(bmp1, x_start2, y_start2).B <> markingfldimg_obj1.color_of_sobel.B) And y_start2 < bmp1.Height - 1 And x_start2 < bmp1.Width - 1) = True
                x_start2 += CGlobals1.dir_x1_to_sobel
                y_start2 += CGlobals1.dir_m1_to_sobel

            End While
            dict_res1 = markingfldimg_obj1.find_max_sobel_length2(x_start2, y_start2)
        End If

        Dim curves_arr1 As ArrayList = markingfldimg_obj1.get_curve_from_pixels_arr_by_region(dict_res1("pixels_around_sobel_arr1"), 0, 0, 450, 1070)
        markingfldimg_obj1.find_line_in_pixels_arr(curves_arr1(0), 0, 60, 10)
        markingfldimg_obj1.set_pixels_arr_and_save2(curves_arr1(0), markingfldimg_obj1.bmp_current_sobel, Color.FromArgb(200, 40, 20), CGlobals1.global_path1 + "sobel_pics1\sobel_sign1.jpg")

        Dim i1 As Integer
        Dim i2 As Integer

        If False Then

            For i1 = 0 To dict_res1("pixels_around_sobel_arr1").Count - 1
                Dim cord_xy1c As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(dict_res1("pixels_around_sobel_arr1"), i1)
                markingfldimg_obj1.bmp_current_sobel = CGlobals1.draw_sqr_around_pixels(markingfldimg_obj1.bmp_current_sobel, cord_xy1c(0), cord_xy1c(1), 10, Color.FromArgb(50, 220, 40))

            Next

            PictureBox1.Image = zoom_img1(markingfldimg_obj1.bmp_current_sobel, 1.5)
            Return
        End If

        Dim max_dist_pixel As ArrayList = markingfldimg_obj1.find_max_distance_pixels(dict_res1("pixels_around_sobel_arr1"))

        Dim pxl_ind1 As Integer = Integer.Parse(max_dist_pixel(0).ToString().Split(",")(0))
        Dim cord_xy1a As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(dict_res1("pixels_around_sobel_arr1"), pxl_ind1)
        markingfldimg_obj1.bmp_current_sobel = CGlobals1.draw_sqr_around_pixels(markingfldimg_obj1.bmp_current_sobel, cord_xy1a(0), cord_xy1a(1), 10, Color.FromArgb(200, 20, 40))

        Dim pxl_ind2 As Integer = Integer.Parse(max_dist_pixel(0).ToString().Split(",")(1))
        Dim cord_xy1b As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(dict_res1("pixels_around_sobel_arr1"), pxl_ind2)
        markingfldimg_obj1.bmp_current_sobel = CGlobals1.draw_sqr_around_pixels(markingfldimg_obj1.bmp_current_sobel, cord_xy1b(0), cord_xy1b(1), 10, Color.FromArgb(200, 20, 40))

        Dim new_pxls_arr1 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(dict_res1("pixels_around_sobel_arr1"), pxl_ind2, pxl_ind1)
        Dim new_pxls_arr2 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(dict_res1("pixels_around_sobel_arr1"), pxl_ind1, pxl_ind2)


        Dim dict_min_dist1 As Dictionary(Of Integer, Double) = New Dictionary(Of Integer, Double)
        Dim start_ok_angle_ind1 As Integer = -1
        Dim cords_dist_dict1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)


        Dim last_ok_angle_ind1 As Integer = -1

        Dim start_ind2 As Integer = 6
        Dim end_ind2 As Integer = new_pxls_arr2.Count - 6
        Dim last_ok_angle_ind2 As Integer = -1
        For i1 = 6 To new_pxls_arr1.Count - 6
            Dim cord_xy1c As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(new_pxls_arr1, i1)

            Dim min_dist1 As Double = 99
            Dim min_angle1 As Double = 99
            Dim max_angle1 As Double = -99

            Dim angles_arr1 As ArrayList = New ArrayList()


            Dim cord_xy1e_1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(new_pxls_arr1, i1 - 5)
            Dim cord_xy1e_2 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(new_pxls_arr1, i1 + 5)
            Dim ver_3d_obj3 As vec_3d1 = New vec_3d1()
            ver_3d_obj3.p1.x1 = cord_xy1e_1(0)
            ver_3d_obj3.p1.y1 = cord_xy1e_1(1)
            ver_3d_obj3.p2.x1 = cord_xy1e_2(0)
            ver_3d_obj3.p2.y1 = cord_xy1e_2(1)

            For i2 = start_ind2 To end_ind2
                Dim cord_xy1d As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(new_pxls_arr2, i2)

                Dim ver_3d_obj1 As vec_3d1 = New vec_3d1()
                ver_3d_obj1.p1.x1 = cord_xy1c(0)
                ver_3d_obj1.p1.y1 = cord_xy1c(1)
                ver_3d_obj1.p2.x1 = cord_xy1d(0)
                ver_3d_obj1.p2.y1 = cord_xy1d(1)



                Dim cord_xy1d_1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(new_pxls_arr2, i2 - 5)
                Dim cord_xy1d_2 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(new_pxls_arr2, i2 + 5)
                Dim ver_3d_obj2 As vec_3d1 = New vec_3d1()
                ver_3d_obj2.p1.x1 = cord_xy1d_1(0)
                ver_3d_obj2.p1.y1 = cord_xy1d_1(1)
                ver_3d_obj2.p2.x1 = cord_xy1d_2(0)
                ver_3d_obj2.p2.y1 = cord_xy1d_2(1)




                Dim angle1 As Double = markingfldimg_obj1.get_angle_between_2_3d_vectors(ver_3d_obj1, ver_3d_obj2)
                angles_arr1.Add(angle1)

                Dim angle2 As Double = markingfldimg_obj1.get_angle_between_2_3d_vectors(ver_3d_obj1, ver_3d_obj3)
                angles_arr1.Add(angle1)

                If min_angle1 > angle1 Then
                    min_angle1 = angle1
                End If
                If max_angle1 < angle1 Then
                    max_angle1 = angle1
                End If
                If angle1 >= 85 And angle1 <= 105 Then
                Else

                End If
                If angle1 >= 85 And angle1 <= 95 And angle2 >= 85 And angle2 <= 95 Then
                    If start_ok_angle_ind1 = -1 Then
                        start_ok_angle_ind1 = i1
                        cords_dist_dict1(cord_xy1c(0).ToString() + "," + cord_xy1c(1).ToString() + "," + cord_xy1d(0).ToString() + "," + cord_xy1d(1).ToString()) = 1
                    End If

                    If start_ok_angle_ind1 <> -1 Then
                        'If last_ok_angle_ind1 = -1 Then
                        last_ok_angle_ind1 = i1
                        last_ok_angle_ind2 = i2

                        'End If

                    End If

                    Dim dist1 As Double = Math.Pow(Math.Pow(cord_xy1c(0) - cord_xy1d(0), 2) + Math.Pow(cord_xy1c(1) - cord_xy1d(1), 2), 0.5)
                    If min_dist1 > dist1 Then
                        min_dist1 = dist1
                    End If

                End If

            Next

            'start_ind2 = Math.Max(6, last_ok_angle_ind2 - 5)
            'end_ind2 = last_ok_angle_ind2 + 15

            If min_angle1 < 90 And max_angle1 > 100 Then
            ElseIf i1 > 30 Then

                If start_ok_angle_ind1 <> -1 Then
                    If last_ok_angle_ind1 = -1 Then
                        'last_ok_angle_ind1 = i1
                    End If

                End If

            End If
            dict_min_dist1(i1) = min_dist1
            Dim d1 As Integer = 8
        Next



        Dim new_pxls_arr3 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(new_pxls_arr1, start_ok_angle_ind1, last_ok_angle_ind1)
        'Dim new_pxls_arr3 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(new_pxls_arr1, 0, 59)

        For i1 = 0 To new_pxls_arr3.Count - 1
            Dim cord_xy1c As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(new_pxls_arr3, i1)
            markingfldimg_obj1.bmp_current_sobel = CGlobals1.draw_sqr_around_pixels(markingfldimg_obj1.bmp_current_sobel, cord_xy1c(0), cord_xy1c(1), 10, Color.FromArgb(50, 220, 40))

        Next

        PictureBox1.Image = zoom_img1(markingfldimg_obj1.bmp_current_sobel, 1.5)
        Dim angle_arr1 As ArrayList = markingfldimg_obj1.get_angle_of_pixels_arr1(dict_res1("pixels_around_sobel_arr1"), 10)
    End Sub

    Private Sub ShowCurvesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ShowCurvesToolStripMenuItem.Click
        If CGlobals1.global_vars_dict1.ContainsKey("curve_ind1") = False Then
            CGlobals1.global_vars_dict1("curve_ind1") = 0
        Else
            CGlobals1.global_vars_dict1("curve_ind1") += 1

        End If

        Dim pixels_arr1 As ArrayList = markingfldimg_obj1.load_2d_pixels_arr1("D:\glass_pics1\curves1\curves_pxls_" + CGlobals1.global_vars_dict1("curve_ind1").ToString() + ".txt")
        Dim path_of_bmp1 As String = CGlobals1.global_path1 + file_name1 + "_sobel_cache1\28.jpg"
        Dim bmp1 As Bitmap = New Bitmap(path_of_bmp1)
        markingfldimg_obj1.set_pixel_arr_on_bmp2(pixels_arr1, bmp1, Color.FromArgb(100, 40, 130))
        PictureBox1.Image = zoom_img1(bmp1, 2)
    End Sub

    Private Sub Nextcurve1ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles Nextcurve1ToolStripMenuItem.Click

        Dim pixels_arr1 As ArrayList

        If CGlobals1.global_vars_dict1.ContainsKey("curve_ind1") = False Then
            CGlobals1.global_vars_dict1("dict_curves_len1") = New Dictionary(Of Integer, Integer)
            CGlobals1.global_vars_dict1("curve_ind1") = 0

            pixels_arr1 = markingfldimg_obj1.load_2d_pixels_arr1("D:\glass_pics1\curves1\curves_pxls_" + CGlobals1.global_vars_dict1("curve_ind1").ToString() + ".txt")
            CType(CGlobals1.global_vars_dict1("dict_curves_len1"), Dictionary(Of Integer, Integer))(pixels_arr1.Count) = 1

        Else
            CGlobals1.global_vars_dict1("curve_ind1") += 1
            Dim to_stop1 As Integer = 0

            While to_stop1 = 0
                pixels_arr1 = markingfldimg_obj1.load_2d_pixels_arr1("D:\glass_pics1\curves1\curves_pxls_" + CGlobals1.global_vars_dict1("curve_ind1").ToString() + ".txt")
                If CType(CGlobals1.global_vars_dict1("dict_curves_len1"), Dictionary(Of Integer, Integer)).ContainsKey(pixels_arr1.Count) = False Then
                    CType(CGlobals1.global_vars_dict1("dict_curves_len1"), Dictionary(Of Integer, Integer))(pixels_arr1.Count) = 1
                    to_stop1 = 1
                Else
                    CGlobals1.global_vars_dict1("curve_ind1") += 1
                End If
            End While
        End If


        txtbox_cur_pixel_ind1.Text = CGlobals1.global_vars_dict1("curve_ind1").ToString()
        Dim path_of_bmp1 As String = CGlobals1.global_path1 + file_name1 + "_sobel_cache1\28.jpg"
        Dim bmp1 As Bitmap = New Bitmap(path_of_bmp1)
        Dim copy_bmp1 As Bitmap = New Bitmap(bmp1.Width, bmp1.Height)


        If CGlobals1.global_vars_dict1.ContainsKey("cur_bmp1") = False Then
            CGlobals1.global_vars_dict1("cur_bmp1") = copy_bmp1

        Else
            copy_bmp1 = CGlobals1.global_vars_dict1("cur_bmp1")
        End If


        If False Then
            markingfldimg_obj1.set_pixel_arr_on_bmp2(pixels_arr1, copy_bmp1, Color.FromArgb(100, 40, 130))

            PictureBox1.Image = zoom_img1(copy_bmp1, 2)


            Return
        End If


        Dim dict_res_smothness1 As Dictionary(Of String, Object) = markingfldimg_obj1.measure_pixels_arr_smoothess(pixels_arr1, 4)
        Dim dict_right_to_left_smothnress1 As Dictionary(Of Integer, Double) = dict_res_smothness1("dict_max_left_and_right_len1")
        Dim dict_smoothness1 As Dictionary(Of Integer, Double) = dict_res_smothness1("dict_max_len1")
        markingfldimg_obj1.set_pixel_arr_on_bmp2(pixels_arr1, copy_bmp1, Color.FromArgb(100, 40, 255))

        If dict_right_to_left_smothnress1.Count <= 0 Then
        Else
            Dim ind3 As Integer = 0

            Dim last_ok_ind3 As Integer = -1
            For ind3 = 0 To dict_right_to_left_smothnress1.Keys.Count
                If dict_right_to_left_smothnress1(dict_right_to_left_smothnress1.Keys(ind3)) < 10 Then
                    If last_ok_ind3 <> -1 Then
                        If Math.Abs(ind3 - last_ok_ind3) > 20 Then
                            Dim ind5 As Integer
                            For ind5 = last_ok_ind3 To ind3
                                Dim ind4 As Integer = dict_smoothness1.Keys(ind5)
                                Dim cord_xy3 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, ind4)
                                If copy_bmp1.GetPixel(cord_xy3(0), cord_xy3(1)).R = 255 Or copy_bmp1.GetPixel(cord_xy3(0), cord_xy3(1)).R = 100 Then
                                    Dim err1 As Integer = 1
                                End If
                                copy_bmp1.SetPixel(cord_xy3(0), cord_xy3(1), Color.FromArgb(50, 255, 100))
                                'copy_bmp1 = CGlobals1.draw_sqr_around_pixels(copy_bmp1, cord_xy3(0), cord_xy3(1), 2, Color.FromArgb(255, 50, 100))
                            Next
                        End If
                    End If
                    last_ok_ind3 = ind3
                Else


                End If
            Next


        End If


        'While pixels_arr1.Count > 20000
        '        pixels_arr1.RemoveAt(pixels_arr1.Count - 1)
        'End While

        PictureBox1.Image = zoom_img1(copy_bmp1, 1)

    End Sub

    Private Sub SearchForStartPoint1ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SearchForStartPoint1ToolStripMenuItem.Click
        Dim sobel_ind1 As Integer = Integer.Parse(txtbox_curent_sobel_threshold1.Text)
        sobel_ind1 = 3
        Dim pixels_arr1 As ArrayList = markingfldimg_obj1.load_2d_pixels_arr1(CGlobals1.global_path1 + file_name1 + "_2d_pixels_sobel_" + sobel_ind1.ToString() + ".txt")
        Dim path_of_bmp1 As String = CGlobals1.global_path1 + file_name1 + "_sobel_cache1\" + sobel_ind1.ToString() + ".jpg"
        Dim bmp1 As Bitmap = New Bitmap(path_of_bmp1)

        Dim i1 As Integer
        Dim min_x1 As Integer = 9999
        Dim min_x_ind1 As Integer = -1
        For i1 = 0 To pixels_arr1.Count - 1
            Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, i1)
            If min_x1 > cord_xy1(0) Then
                min_x1 = cord_xy1(0)
                min_x_ind1 = i1
            End If
        Next


        Dim max_y1 As Integer = -9999
        Dim max_y_ind1 As Integer = -1

        For i1 = 0 To pixels_arr1.Count - 1
            Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, i1)
            If Math.Abs(cord_xy1(0) - min_x1) <= 200 Then
                If max_y1 < cord_xy1(1) Then
                    max_y1 = cord_xy1(1)
                    max_y_ind1 = i1
                End If

            End If
        Next



        Dim copy_bmp1 As Bitmap = CGlobals1.copy_bitmap1(bmp1)

        Dim cord_xy2 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, max_y_ind1)
        copy_bmp1 = CGlobals1.draw_sqr_around_pixels(copy_bmp1, cord_xy2(0), cord_xy2(1), 3, Color.FromArgb(255, 100, 100))


        Dim i2 As Integer

        PictureBox1.Image = zoom_img1(copy_bmp1)


        For i1 = max_y_ind1 To max_y_ind1 - 300 Step -1
            For i2 = max_y_ind1 - 300 To i1 Step 1

                Dim cord_xy1a As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, i1)
                Dim cord_xy2a As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, i2)

                Dim dist1 As Double = Math.Pow(Math.Pow(cord_xy1a(0) - cord_xy2a(0), 2) + Math.Pow(cord_xy1a(1) - cord_xy2a(1), 2), 0.5)
                If dist1 > 30 Then

                    Dim angle1 As Double = Math.Atan((cord_xy2a(1) - cord_xy1a(1)) / (cord_xy2a(0) - cord_xy1a(0))) / Math.PI * 180.0
                    Dim pxl_arr2 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(pixels_arr1, max_y_ind1 - 300, max_y_ind1)
                    Dim vec_3d_obj1 As vec_3d1 = New vec_3d1()
                    vec_3d_obj1.p1 = New point_3d1()
                    vec_3d_obj1.p1.x1 = cord_xy1a(0)
                    vec_3d_obj1.p1.y1 = cord_xy1a(1)


                    vec_3d_obj1.p2 = New point_3d1()
                    vec_3d_obj1.p2.x1 = cord_xy1a(0)
                    vec_3d_obj1.p2.y1 = cord_xy1a(1)
                    vec_3d_obj1.p2.z1 = -10

                    Dim rot_pxl_arr1 As ArrayList = markingfldimg_obj1.rotate_2d_pixels_arr(pxl_arr2, vec_3d_obj1, -angle1)
                    'Dim pxl_line1 As ArrayList = markingfldimg_obj1.create_pixel_arr_line_from_2_2d_points(cord_xy1a(0), cord_xy1a(1), cord_xy2a(0), cord_xy2a(1))
                    Dim i3 As Integer
                    Dim not_good_line1 As Integer = 0
                    For i3 = 0 To rot_pxl_arr1.Count - 1

                        If Double.Parse(rot_pxl_arr1(i3).ToString().Split(",")(1)) > cord_xy1a(1) Then
                            not_good_line1 = 1
                        End If
                        'If CGlobals1.get_cord_xy_in_pixels_arr1(rot_pxl_arr1, i3)(1) > cord_xy1a(1) Then
                        'not_good_line1 = 1

                        'End If


                    Next
                    Dim found_point1_ind1 As Integer = -1
                    If not_good_line1 = 0 Then
                        Dim bmp3 As Bitmap = CGlobals1.create_fill_bitmap(1000, 1000, Color.FromArgb(255, 0, 0, 0))
                        Dim cord_xy3a As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(rot_pxl_arr1, i2 - (max_y_ind1 - 300))
                        bmp3 = CGlobals1.draw_sqr_around_pixels(bmp3, cord_xy1a(0), cord_xy1a(1), 3, Color.FromArgb(255, 70, 90))
                        bmp3 = CGlobals1.draw_sqr_around_pixels(bmp3, cord_xy3a(0), cord_xy3a(1), 3, Color.FromArgb(255, 70, 90))
                        markingfldimg_obj1.set_pixels_arr_and_save1(rot_pxl_arr1, bmp3, CGlobals1.global_path1 + "sobel_pics1\" + i1.ToString() + "_" + i2.ToString() + ".jpg")
                        Dim d2 As Integer = 3

                        Dim top_ind1 As Integer
                        Dim min_y3 As Double = 9999
                        For i3 = i2 - (max_y_ind1 - 300) To i1 - (max_y_ind1 - 300)
                            Dim cord_xy4a As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(rot_pxl_arr1, i3)
                            If min_y3 > cord_xy4a(1) Then
                                min_y3 = cord_xy4a(1)
                                top_ind1 = i3
                                found_point1_ind1 = i3 + (max_y_ind1 - 300)
                            End If
                        Next
                    End If

                    If found_point1_ind1 <> -1 Then
                        Dim copy_bmp2 As Bitmap = CGlobals1.copy_bitmap1(bmp1)
                        copy_bmp2 = New Bitmap(CGlobals1.global_path1 + file_name1 + "_crop1.jpg")
                        Dim cord_xy2d As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, found_point1_ind1)
                        copy_bmp2 = CGlobals1.draw_sqr_around_pixels(copy_bmp2, cord_xy2d(0), cord_xy2d(1), 3, Color.FromArgb(255, 100, 100))


                        Dim cord_xy2e As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, found_point1_ind1 - 400)
                        copy_bmp2 = CGlobals1.draw_sqr_around_pixels(copy_bmp2, cord_xy2e(0), cord_xy2e(1), 3, Color.FromArgb(255, 100, 100))

                        Dim cord_xy2f As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, found_point1_ind1 + 55)
                        copy_bmp2 = CGlobals1.draw_sqr_around_pixels(copy_bmp2, cord_xy2f(0), cord_xy2f(1), 3, Color.FromArgb(255, 100, 100))

                        Dim arr3 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(pixels_arr1, found_point1_ind1 - 400, found_point1_ind1)
                        Dim i4 As Integer
                        Dim cord_xy1g As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(arr3, 0)
                        Dim d_x1 As Integer = cord_xy2d(0) - cord_xy2f(0)
                        Dim d_y1 As Integer = cord_xy2d(1) - cord_xy2f(1)
                        For i4 = 0 To arr3.Count - 1
                            Dim cord_xy1h As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(arr3, i4)
                            'copy_bmp2.SetPixel(cord_xy1h(0) - (cord_xy2f(0) - cord_xy1g(0)), cord_xy1h(1) - (cord_xy2f(1) - cord_xy1g(1)), Color.FromArgb(255, 50, 150, 200))
                            copy_bmp2.SetPixel(cord_xy1h(0) - d_x1, cord_xy1h(1) - d_y1, Color.FromArgb(255, 50, 150, 200))
                        Next
                        PictureBox1.Image = zoom_img1(copy_bmp2)

                        Return
                    End If


                    Dim d1 As Integer = 1
                End If

            Next
        Next

        CGlobals1.global_vars_dict1("current_pixels_arr_by_sobel_ind1") = pixels_arr1
        CGlobals1.global_vars_dict1("current_bmp_by_sobel_ind1") = bmp1
        CGlobals1.global_vars_dict1("current_pixel_ind1") = Integer.Parse(txtbox_cur_pixel_ind1.Text)
    End Sub
    Public Function show_3d_prespective1()
        Dim angle_file_name1 As String = "980115617\980115617_angle"
        Dim front_file_name1 As String = "980115617\980115617_front"
        Dim sobel_ind1 As Integer = 3 'Integer.Parse(txtbox_curent_sobel_threshold1.Text)
        Dim pixels_arr1 As ArrayList = markingfldimg_obj1.load_2d_pixels_arr1(CGlobals1.global_path1 + front_file_name1 + "_2d_pixels_sobel_" + sobel_ind1.ToString() + ".txt")
        Dim pxl_arr1a As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(pixels_arr1, 1200, 1700)
        Dim pxl_arr1b As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(pixels_arr1, 2800, 3600)
        pixels_arr1 = markingfldimg_obj1.load_2d_pixels_arr1(CGlobals1.global_path1 + angle_file_name1 + "_2d_pixels_sobel_" + sobel_ind1.ToString() + ".txt")
        Dim pxl_arr2a As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(pixels_arr1, 600, 1800)
        Dim pixels_3d_arr2a = CGlobals1.convert_2darr_to_3d_arr(pxl_arr2a)

        Dim pixels_3d_arr1a = CGlobals1.convert_2darr_to_3d_arr(pxl_arr1a)
        Dim pixels_3d_arr1b = CGlobals1.convert_2darr_to_3d_arr(pxl_arr1b)

        Dim rot_vec_3d_obj1 As vec_3d1 = New vec_3d1()
        rot_vec_3d_obj1.p1.x1 = 600
        rot_vec_3d_obj1.p1.y1 = 0
        rot_vec_3d_obj1.p1.z1 = 0

        rot_vec_3d_obj1.p2.x1 = 600
        rot_vec_3d_obj1.p2.y1 = 1500
        rot_vec_3d_obj1.p2.z1 = 0

        markingfldimg_obj1.rotate_3d_points_arr2(pixels_3d_arr1a, rot_vec_3d_obj1, CGlobals1.global_vars_dict1("x_deg_rot1"))
        markingfldimg_obj1.rotate_3d_points_arr2(pixels_3d_arr1b, rot_vec_3d_obj1, CGlobals1.global_vars_dict1("x_deg_rot1"))


        Dim rot_vec_3d_obj2 As vec_3d1 = New vec_3d1()
        rot_vec_3d_obj2.p1.x1 = 600
        rot_vec_3d_obj2.p1.y1 = 600
        rot_vec_3d_obj2.p1.z1 = 0

        rot_vec_3d_obj2.p2.x1 = 600
        rot_vec_3d_obj1.p2.y1 = 600
        rot_vec_3d_obj2.p2.z1 = 40

        'markingfldimg_obj1.rotate_3d_points_arr2(pixels_3d_arr1a, rot_vec_3d_obj2, -50)
        'markingfldimg_obj1.rotate_3d_points_arr2(pixels_3d_arr1b, rot_vec_3d_obj2, -50)

        Dim bmp1 As Bitmap = CGlobals1.create_fill_bitmap(3000, 3000, Color.FromArgb(255, 0, 0, 0))

        markingfldimg_obj1.set_3d_arr_pixels_on_bmp1_prespective(pixels_3d_arr2a, bmp1, Color.FromArgb(255, 255, 200, 100))
        markingfldimg_obj1.set_3d_arr_pixels_on_bmp1_prespective(pixels_3d_arr1a, bmp1, Color.FromArgb(255, 255, 50, 255))
        markingfldimg_obj1.set_3d_arr_pixels_on_bmp1_prespective(pixels_3d_arr1b, bmp1, Color.FromArgb(255, 255, 255, 255))
        PictureBox1.Image = zoom_img1(bmp1, 5)
    End Function
    Private Sub ShowPrespetive3dToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ShowPrespetive3dToolStripMenuItem.Click
        CGlobals1.global_vars_dict1("x_deg_rot1") = -10
        show_3d_prespective1()
    End Sub

    Private Sub AddXDeg3dToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AddXDeg3dToolStripMenuItem.Click
        CGlobals1.global_vars_dict1("x_deg_rot1") -= 1
        show_3d_prespective1()
    End Sub

    Private Sub FindFrameOfGlassesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles FindFrameOfGlassesToolStripMenuItem.Click
        Dim cut_frame_only1 As String = "yes"
        CGlobals1.clear_all_caches1()
        chkbox_compute_sobel.Checked = False
        CGlobals1.global_suffix_file_name1 = "_frame1"

        Dim path_of_cache1 As String = CGlobals1.global_path1 + file_name1 + "_sobel_cache1"
        CGlobals1.path_of_sobel_cache1 = path_of_cache1

        Dim sobel_ind1 As Integer = -1 'Integer.Parse(form_obj1.txtbox_curent_sobel_threshold1.Text)

        Dim path_sign_sobel_ind1 As String = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_sign_sobel_ind1" + CGlobals1.global_suffix_file_name1 + ".txt"
        Dim old_chkbox_val1 As Boolean = chkbox_compute_sobel.Checked
        If True Then
            If System.IO.File.Exists(path_sign_sobel_ind1) = False Then
                chkbox_compute_sobel.Checked = True
                load_img_btn1_Click(Nothing, Nothing)

                Dim line_to_search_start_sobel_pixels1 As ArrayList = markingfldimg_obj1.create_pixel_arr_line_from_2_2d_points(500, 0, 500, 2000)

                markingfldimg_obj1.loop_on_sobel_vals3(line_to_search_start_sobel_pixels1)

            End If


            'start_timer_btn1_Click(Nothing, Nothing)
        End If

        chkbox_compute_sobel.Checked = old_chkbox_val1


        sobel_ind1 = Integer.Parse(System.IO.File.ReadAllText(path_sign_sobel_ind1))

        Dim path_of_bmp1 As String = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_sobel_cache1\" + sobel_ind1.ToString() + ".jpg"
        Dim bmp1 As Bitmap = New Bitmap(path_of_bmp1)

        Dim pixels_arr1 As ArrayList = markingfldimg_obj1.load_2d_pixels_arr1(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_2d_pixels_sobel_" + sobel_ind1.ToString() + CGlobals1.global_suffix_file_name1 + ".txt")
        System.IO.File.Copy(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_2d_pixels_sobel_" + sobel_ind1.ToString() + CGlobals1.global_suffix_file_name1 + ".txt", CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_frame4.txt", True)
        markingfldimg_obj1.set_pixel_arr_on_bmp2(pixels_arr1, bmp1, Color.FromArgb(200, 60, 90))

        Dim bmp2 As Bitmap = New Bitmap(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_crop1.jpg")
        Dim bmp3 As Bitmap = CGlobals1.create_fill_bitmap(bmp2.Width, bmp2.Height, Color.FromArgb(255, 255, 255))
        markingfldimg_obj1.set_pixel_arr_on_bmp2(pixels_arr1, bmp3, Color.FromArgb(200, 60, 90))


        bmp3 = markingfldimg_obj1.paint_recursive3(bmp3, 20, 20, Color.FromArgb(200, 60, 90), Color.FromArgb(55, 100, 70))
        Dim org_bmp1 As Bitmap = New Bitmap(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_crop1.jpg")

        org_bmp1 = markingfldimg_obj1.set_pixels_by_mask1(bmp3, Color.FromArgb(255, 255, 255), org_bmp1)
        PictureBox1.Image = zoom_img1(org_bmp1, 3)
        org_bmp1.Save(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_frame2.bmp")
        If cut_frame_only1 = "yes" Then
            Return
        End If
        'Return
        Dim i1 As Integer

        Dim dict_rect1 As Dictionary(Of String, Object) = macros_obj1.find_rect_of_pixels_arr(pixels_arr1)
        Dim min_x1 As Integer = dict_rect1("min_x1")
        Dim max_x1 As Integer = dict_rect1("max_x1")
        Dim max_y1 As Integer = dict_rect1("max_y1")

        Dim dict_pixels1 As Dictionary(Of String, Integer) = CGlobals1.add_to_dict1(pixels_arr1)

        Dim center_x1 As Integer = (min_x1 + max_x1) / 2
        Dim y1 As Integer = 0
        While dict_pixels1.ContainsKey(center_x1.ToString() + "," + y1.ToString()) = False
            y1 += 1
        End While

        Dim center_y1 As Integer = (y1 + max_y1) / 2
        'right glass

        Dim max_pixel_x2 As Integer = center_x1
        Dim min_pixel_x2 As Integer = center_x1
        Dim key_ind1 As Integer

        For key_ind1 = 0 To dict_pixels1.Keys.Count - 1
            If dict_pixels1.Keys(key_ind1).Split(",")(1) = center_y1.ToString() Then
                If CGlobals1.max_pixel_x1 < Integer.Parse(dict_pixels1.Keys(key_ind1).Split(",")(0)) Then
                    CGlobals1.max_pixel_x1 = Integer.Parse(dict_pixels1.Keys(key_ind1).Split(",")(0))
                End If

                If CGlobals1.min_pixel_x1 > Integer.Parse(dict_pixels1.Keys(key_ind1).Split(",")(0)) Then
                    CGlobals1.min_pixel_x1 = Integer.Parse(dict_pixels1.Keys(key_ind1).Split(",")(0))
                End If

            End If
        Next
        'While dict_pixels1.ContainsKey(CGlobals1.max_pixel_x1.ToString() + "," + center_y1.ToString()) = False
        'CGlobals1.max_pixel_x1 += 1
        'End While
        max_pixel_x2 -= Math.Abs(center_x1 - CGlobals1.max_pixel_x1) * 0.25

        Dim right_x1 As Integer = (center_x1 + max_x1) / 2


        CGlobals1.global_suffix_file_name1 = "_right_glass1"

        load_img_btn1_Click(Nothing, Nothing)
        Dim line_to_search_start_sobel_of_right_frame_pixels1 As ArrayList = markingfldimg_obj1.create_pixel_arr_line_from_2_2d_points(right_x1, center_y1, max_x1, center_y1)
        markingfldimg_obj1.bmp1 = New Bitmap(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_crop1.jpg")

        CGlobals1.max_dist_between_sobel_line1 = 1.5
        CGlobals1.max_pixel_x1 = max_pixel_x2

        markingfldimg_obj1.loop_on_sobel_vals3(line_to_search_start_sobel_of_right_frame_pixels1)
        CGlobals1.max_pixel_x1 = -1
        path_sign_sobel_ind1 = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_sign_sobel_ind1" + CGlobals1.global_suffix_file_name1 + ".txt"


        sobel_ind1 = Integer.Parse(System.IO.File.ReadAllText(path_sign_sobel_ind1))


        path_of_bmp1 = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_sobel_cache1\" + sobel_ind1.ToString() + ".jpg"
        bmp1 = New Bitmap(path_of_bmp1)

        Dim pixels_arr_right_glass1 As ArrayList = markingfldimg_obj1.load_2d_pixels_arr1(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_2d_pixels_sobel_" + sobel_ind1.ToString() + CGlobals1.global_suffix_file_name1 + ".txt")


        'left glass


        Dim left_x1 As Integer = (center_x1 + left_x1) / 2
        CGlobals1.global_suffix_file_name1 = "_left_glass1"

        load_img_btn1_Click(Nothing, Nothing)
        Dim line_to_search_start_sobel_of_left_frame_pixels1 As ArrayList = markingfldimg_obj1.create_pixel_arr_line_from_2_2d_points(left_x1, center_y1, min_x1, center_y1)
        markingfldimg_obj1.bmp1 = New Bitmap(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_crop1.jpg")

        CGlobals1.max_dist_between_sobel_line1 = 1.5
        CGlobals1.min_pixel_x1 = min_pixel_x2

        markingfldimg_obj1.loop_on_sobel_vals3(line_to_search_start_sobel_of_left_frame_pixels1)
        CGlobals1.min_pixel_x1 = -1

        path_sign_sobel_ind1 = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_sign_sobel_ind1" + CGlobals1.global_suffix_file_name1 + ".txt"


        sobel_ind1 = Integer.Parse(System.IO.File.ReadAllText(path_sign_sobel_ind1))


        path_of_bmp1 = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_sobel_cache1\" + sobel_ind1.ToString() + ".jpg"
        bmp1 = New Bitmap(path_of_bmp1)

        Dim pixels_arr_left_glass1 As ArrayList = markingfldimg_obj1.load_2d_pixels_arr1(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_2d_pixels_sobel_" + sobel_ind1.ToString() + CGlobals1.global_suffix_file_name1 + ".txt")
        Dim color_of_mask1 As Color = Color.FromArgb(55, 100, 70)
        markingfldimg_obj1.set_pixel_arr_on_bmp2(pixels_arr_left_glass1, bmp1, Color.FromArgb(200, 60, 90))
        bmp1 = markingfldimg_obj1.paint_recursive3(bmp1, left_x1, center_y1, Color.FromArgb(200, 60, 90), color_of_mask1)


        markingfldimg_obj1.set_pixel_arr_on_bmp2(pixels_arr_right_glass1, bmp1, Color.FromArgb(200, 60, 90))
        'bmp1.Save(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_frame1.bmp")

        bmp1 = markingfldimg_obj1.paint_recursive3(bmp1, right_x1, center_y1, Color.FromArgb(200, 60, 90), color_of_mask1)

        'PictureBox1.Image = zoom_img1(bmp1, 1)

        'Return


        org_bmp1 = markingfldimg_obj1.set_pixels_by_mask2(bmp1, color_of_mask1, org_bmp1, Color.FromArgb(0, 0, 0, 0), "set_on_mask1")

        org_bmp1 = markingfldimg_obj1.remove_around_object1(org_bmp1, Color.FromArgb(0, 0, 0, 0))
        org_bmp1 = markingfldimg_obj1.remove_around_object1(org_bmp1, Color.FromArgb(0, 0, 0, 0))


        org_bmp1.Save(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_frame1.bmp")

        PictureBox1.Image = zoom_img1(org_bmp1, 1)

    End Sub

    Private Sub CToolStripMenuItem_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub CutHandlesFromFrameToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CutHandlesFromFrameToolStripMenuItem.Click
        'CGlobals1.clear_all_caches1()
        load_img_btn1_Click(Nothing, Nothing)
        chkbox_compute_sobel.Checked = False
        CGlobals1.global_suffix_file_name1 = "_frame1"

        Dim path_of_cache1 As String = CGlobals1.global_path1 + file_name1 + "_sobel_cache1"
        CGlobals1.path_of_sobel_cache1 = path_of_cache1

        Dim sobel_ind1 As Integer = -1 'Integer.Parse(form_obj1.txtbox_curent_sobel_threshold1.Text)

        Dim path_sign_sobel_ind1 As String = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_sign_sobel_ind1" + CGlobals1.global_suffix_file_name1 + ".txt"


        sobel_ind1 = Integer.Parse(System.IO.File.ReadAllText(path_sign_sobel_ind1))

        Dim path_of_bmp1 As String = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_sobel_cache1\" + sobel_ind1.ToString() + ".jpg"
        Dim bmp1 As Bitmap = New Bitmap(path_of_bmp1)
        Dim bmp1b As Bitmap = New Bitmap(path_of_bmp1)
        Dim pixels_arr1 As ArrayList = markingfldimg_obj1.load_2d_pixels_arr1(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_2d_pixels_sobel_" + sobel_ind1.ToString() + CGlobals1.global_suffix_file_name1 + ".txt")

        markingfldimg_obj1.set_pixels_arr_and_save2(pixels_arr1, bmp1b, Color.FromArgb(200, 30, 100), CGlobals1.global_path1 + "sobel_pics1\p1_" + sobel_ind1.ToString() + ".jpg")
        Dim dict_rect1 As Dictionary(Of String, Object) = macros_obj1.find_rect_of_pixels_arr(pixels_arr1)
        Dim min_x1 As Integer = dict_rect1("min_x1")
        Dim max_x1 As Integer = dict_rect1("max_x1")
        Dim max_y1 As Integer = dict_rect1("max_y1")

        Dim dict_pixels1 As Dictionary(Of String, Integer) = CGlobals1.add_to_dict1(pixels_arr1)

        Dim center_x1 As Integer = (min_x1 + max_x1) / 2
        Dim y1 As Integer = 0
        While dict_pixels1.ContainsKey(center_x1.ToString() + "," + y1.ToString()) = False
            y1 += 1
        End While

        Dim center_top_pixel_ind1 As Integer = dict_pixels1(center_x1.ToString() + "," + y1.ToString())

        Dim dict_res_cord1 As Dictionary(Of String, Object) = macros_obj1.search_for_start_pixels_between_frame_and_handles_above2(pixels_arr1)
        '--
        Dim cord_start_pixels1 As Integer() = dict_res_cord1("cord_xy_res1")

        Dim cord_start_pixels_prev_10_pxls1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, dict_res_cord1("ind_in_pixels1") - 10)

        'Dim dist1 As Double = Math.Pow(Math.Pow(cord_xy1a(0) - cord_xy2a(0), 2) + Math.Pow(cord_xy1a(1) - cord_xy2a(1), 2), 0.5)


        'Dim start_pixel_ind1 As Integer = center_top_pixel_ind1
        'Dim next_pixel_ind2 As Integer = start_pixel_ind1 + 100

        'Dim pixel_line1 As ArrayList = markingfldimg_obj1.create_pixel_arr_line_from_2_2d_points2(CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, start_pixel_ind1), CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, next_pixel_ind2))

        Dim crop_bmp2 As Bitmap = New Bitmap(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_crop1.jpg")
        CGlobals1.global_vars_dict1("crop_bmp2_path1") = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_crop1.jpg"
        Dim bmp3 As Bitmap = CGlobals1.create_fill_bitmap(crop_bmp2.Width, crop_bmp2.Height, Color.FromArgb(255, 255, 255))
        'bmp3 = bmp2
        markingfldimg_obj1.set_pixel_arr_on_bmp2(pixels_arr1, bmp3, Color.FromArgb(200, 60, 90))
        'markingfldimg_obj1.set_pixel_arr_on_bmp2(pixel_line1, bmp3, Color.FromArgb(0, 0, 0))
        CGlobals1.draw_sqr_around_pixels2(bmp3, cord_start_pixels1(0), cord_start_pixels1(1), 4, Color.FromArgb(2, 250, 100))

        PictureBox1.Image = zoom_img1(crop_bmp2, 4)

        'Return


        CGlobals1.draw_sqr_around_pixels2(bmp3, cord_start_pixels_prev_10_pxls1(0), cord_start_pixels_prev_10_pxls1(1), 4, Color.FromArgb(200, 50, 30))

        Dim m1 As Double = (cord_start_pixels1(1) - cord_start_pixels_prev_10_pxls1(1)) / (cord_start_pixels1(0) - cord_start_pixels_prev_10_pxls1(0))
        Dim new_cord_xy1(2) As Integer
        new_cord_xy1(0) = cord_start_pixels1(0) + 50
        new_cord_xy1(1) = cord_start_pixels1(1) + 50 * m1

        Dim new_cord_xy2(2) As Integer
        new_cord_xy2(0) = cord_start_pixels1(0) + 2500
        new_cord_xy2(1) = cord_start_pixels1(1) + 2500 * m1


        CGlobals1.draw_sqr_around_pixels2(bmp3, new_cord_xy1(0), new_cord_xy1(1), 4, Color.FromArgb(200, 50, 30))
        PictureBox1.Image = zoom_img1(bmp3, 4)

        'Return
        Dim pixel_line_find_curve1 As ArrayList = markingfldimg_obj1.create_pixel_arr_line_from_2_2d_points2(cord_start_pixels1, new_cord_xy1)
        Dim pixel_line_top1 As ArrayList = markingfldimg_obj1.create_pixel_arr_line_from_2_2d_points2(cord_start_pixels1, new_cord_xy2)

        Dim dec_delta_y1 As Integer = 4
        Dim dec_delta_x1 As Integer = -10
        Dim sobel_ind1b As Integer
        Dim curves_arr1 As ArrayList
        Dim last_curve1 As ArrayList
        Dim dict_all_sobel_curves_res1 As Dictionary(Of Integer, Object) = New Dictionary(Of Integer, Object)
        Dim max_x1_of_curve1 As Integer = -1
        Dim last_ok_curve_by_sobel1 As Integer = -1
        Dim start_sobel_ind1 As Integer = 5
        Dim end_sobel_ind1 As Integer = 300
        CGlobals1.read_int_if_exist("last_ok_curve_by_sobel1", last_ok_curve_by_sobel1)
        If last_ok_curve_by_sobel1 <> -1 Then
            start_sobel_ind1 = last_ok_curve_by_sobel1
            end_sobel_ind1 = last_ok_curve_by_sobel1 + 10
        End If
        'System.IO.File.WriteAllText(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_last_ok_curve_by_sobel1.txt", last_ok_curve_by_sobel1.ToString())


        For sobel_ind1b = start_sobel_ind1 To end_sobel_ind1 Step 5
            lbl_progress1.Text = sobel_ind1b.ToString()
            Application.DoEvents()
            Dim path_of_bmp1b As String = CGlobals1.global_path1 + "980376445_2\191966121998__A_sobel_cache1_h_dir2\" + sobel_ind1b.ToString() + ".jpg"
            'path_of_bmp1b = "E:\memomi_folder1\glass_pics_8\980378996\195768365741__A_sobel_cache1_h_dir2\" + sobel_ind1b.ToString() + ".jpg"
            'path_of_bmp1b = "E:\memomi_folder1\glass_pics_8\980378996\195768365741__A_sobel_cache1\" + sobel_ind1b.ToString() + ".jpg"
            'path_of_bmp1b = "E:\memomi_folder1\glass_pics_8\980376445\191966121998__A_sobel_cache1_h_dir2\" + sobel_ind1b.ToString() + ".jpg"
            path_of_bmp1b = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "__A_sobel_cache1\" + sobel_ind1b.ToString() + ".jpg" '"E:\memomi_folder1\glass_pics_8\980376445\191966121998__A_sobel_cache1\" + sobel_ind1b.ToString() + ".jpg"
            path_of_bmp1b = path_of_cache1 + "\" + sobel_ind1b.ToString() + ".jpg"
            Dim bmp_sobel1 As Bitmap = New Bitmap(path_of_bmp1b)
            curves_arr1 = markingfldimg_obj1.find_curves1(cord_start_pixels1(0) + dec_delta_x1, cord_start_pixels1(1) - dec_delta_y1, bmp_sobel1)

            Dim x_offset1 As Integer = cord_start_pixels1(0) + dec_delta_x1 - 5
            Dim y_offset1 As Integer = cord_start_pixels1(1) - dec_delta_y1 - 5
            Dim cord_xy3(2) As Integer
            cord_xy3(0) = cord_start_pixels1(0) - x_offset1
            cord_xy3(1) = cord_start_pixels1(1) - y_offset1

            Dim curve_ind2 As Integer
            Dim curves_arr3 As ArrayList = New ArrayList()
            For curve_ind2 = 0 To curves_arr1.Count - 1
                Dim dict_rect_res1 As Dictionary(Of String, Object) = macros_obj1.find_rect_of_pixels_arr(curves_arr1(curve_ind2))
                Dim curves_arr2 As ArrayList = markingfldimg_obj1.get_curve_from_pixels_arr_by_region(curves_arr1(curve_ind2), 10, 0, dict_rect_res1("max_x1") - 1, 1070)
                Dim d1 As Integer = 1
                Dim curve_ind3 As Integer

                For curve_ind3 = 0 To curves_arr2.Count - 1
                    curves_arr3.Add(curves_arr2(curve_ind3))
                Next
            Next



            'מחפשים את העקומה שהכי קרובה לנקודה שממנה הידית מתחילה לבלוט מעל המסגרת
            'Dim curve_ind1b As Integer = markingfldimg_obj1.find_curve_nearset_to_cord_xy1(curves_arr1, cord_xy3)
            Dim curve_ind1b As Integer = markingfldimg_obj1.find_curve_nearset_to_cord_xy1(curves_arr3, cord_xy3)
            'curve_ind1b = 8


            Dim curve_pxls_arr2 As ArrayList = CGlobals1.add_val_to_pxls_arr1(curves_arr3(curve_ind1b), x_offset1, y_offset1)
            Dim bmp_sobel2 As Bitmap = New Bitmap(path_of_bmp1b)
            markingfldimg_obj1.set_pixels_arr_and_save2(curve_pxls_arr2, bmp_sobel2, Color.FromArgb(255, 20, 20), CGlobals1.global_path1 + "sobel_pics1\bmp_sobel2_" + sobel_ind1b.ToString() + ".jpg")

            Dim curve_dict1 As Dictionary(Of String, Integer) = CGlobals1.add_to_dict1(curve_pxls_arr2)
            If curve_dict1.ContainsKey(cord_start_pixels1(0).ToString() + "," + cord_start_pixels1(1).ToString()) Then
                Dim d1 As Integer = 1
            End If

            Dim x3 As Integer
            Dim y3 As Integer
            Dim curve_contain_start_pixel1 As String = ""
            For x3 = cord_start_pixels1(0) - 1 To cord_start_pixels1(0) + 1
                For y3 = cord_start_pixels1(1) - 1 To cord_start_pixels1(1) + 1
                    If curve_dict1.ContainsKey(x3.ToString() + "," + y3.ToString()) Then
                        curve_contain_start_pixel1 = "yes"
                    End If

                Next
            Next

            If curve_dict1.ContainsKey(cord_start_pixels1(0).ToString() + "," + cord_start_pixels1(1).ToString()) Or curve_contain_start_pixel1 = "yes" Then

                Dim dict_rect_curve1 As Dictionary(Of String, Object) = macros_obj1.find_rect_of_pixels_arr(curve_pxls_arr2)
                If max_x1_of_curve1 = -1 Then
                    max_x1_of_curve1 = dict_rect_curve1("max_x1") - 10

                End If
                If max_x1_of_curve1 <= dict_rect_curve1("max_x1") Then
                    max_x1_of_curve1 = dict_rect_curve1("max_x1") - 10
                    last_ok_curve_by_sobel1 = sobel_ind1b
                End If
            End If
            'curve_pxls_arr2 = CGlobals1.get_arr_from_ind_to_ind1(curve_pxls_arr2, 0, 1000)
            Dim pixel_arr2 As ArrayList = CGlobals1.dict_keys_to_arr1(dict_pixels1)

            'markingfldimg_obj1.set_pixel_arr_on_bmp2(pixel_arr2, bmp_sobel1, Color.FromArgb(230, 50, 100))

            markingfldimg_obj1.set_pixel_arr_on_bmp2(curve_pxls_arr2, bmp_sobel1, Color.FromArgb(100, 50, 200))
            bmp_sobel1.Save(CGlobals1.global_path1 + "sobel_pics1\bmp_sobel1_" + sobel_ind1b.ToString() + ".jpg")
            Dim filtered_curve1 As ArrayList = New ArrayList()
            Dim i5 As Integer
            Dim count_min_dist_to_line1 As Integer = 0
            Dim first_ind_curve_min_dist_line1 As Integer = -1
            Dim last_ind_curve_min_dist_line1 As Integer = -1
            Dim ind_ok_curve_arr1 As ArrayList = New ArrayList()
            Dim dict_inds1 As Dictionary(Of Integer, Integer) = New Dictionary(Of Integer, Integer)

            For i5 = 0 To pixel_line_find_curve1.Count - 1

                Dim dict_res1 As Dictionary(Of String, Object) = markingfldimg_obj1.check_min_dist_to_curve1(curve_pxls_arr2, CGlobals1.get_cord_xy_in_pixels_arr1(pixel_line_find_curve1, i5), 20)

                'Dim dict_res1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
                Dim min_dist2 As Integer = dict_res1("min_dist1")

                'dict_res1("min_dist_ind1") = min_dist_ind1

                If min_dist2 < 3 Then
                    count_min_dist_to_line1 += 1
                    If first_ind_curve_min_dist_line1 = -1 Then
                        first_ind_curve_min_dist_line1 = dict_res1("min_dist_ind1")
                    End If
                    last_ind_curve_min_dist_line1 = dict_res1("min_dist_ind1")
                    If dict_inds1.ContainsKey(dict_res1("min_dist_ind1")) = False Then

                        ind_ok_curve_arr1.Add(dict_res1("min_dist_ind1"))
                        dict_inds1(dict_res1("min_dist_ind1")) = 1
                    End If
                    'filtered_curve1.Add(curve_pxls_arr2(i5))
                End If
            Next
            Dim dict_curve_res1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
            dict_curve_res1("curve_pxls_arr2") = curve_pxls_arr2
            dict_curve_res1("count_min_dist_to_line1") = count_min_dist_to_line1
            dict_curve_res1("first_ind_curve_min_dist_line1") = first_ind_curve_min_dist_line1
            dict_curve_res1("last_ind_curve_min_dist_line1") = last_ind_curve_min_dist_line1
            dict_curve_res1("ind_ok_curve_arr1") = ind_ok_curve_arr1
            'CGlobals1.get_arr_from_ind_to_ind1()
            dict_all_sobel_curves_res1(sobel_ind1b) = dict_curve_res1
            For i5 = 0 To curve_pxls_arr2.Count - 1

                Dim dict_res1 As Dictionary(Of String, Object) = markingfldimg_obj1.check_min_dist_to_curve1(pixels_arr1, CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr2, i5), 20)
                Dim min_dist1 As Integer = dict_res1("min_dist1")
                If min_dist1 < 4 Then
                    Dim d3 As Integer = 1

                Else
                    'filtered_curve1.Add(curve_pxls_arr2(i5))
                End If
                If dict_pixels1.ContainsKey(curve_pxls_arr2(i5)) = True Then
                    Dim d1 As Integer = 1
                End If


            Next
            'curve_pxls_arr2 = filtered_curve1
            Dim bmp4 As Bitmap = CGlobals1.create_fill_bitmap(8000, 1500, Color.FromArgb(255, 255, 255))
            'markingfldimg_obj1.set_pixel_arr_on_bmp2(curve_pxls_arr2, bmp4, Color.FromArgb(100, 50, 200))
            markingfldimg_obj1.set_pixel_arr_on_bmp2_with_zoom1(curve_pxls_arr2, bmp4, Color.FromArgb(100, 50, 200), 4)
            'bmp4 = crop_img_by_color(bmp4, Color.FromArgb(255, 255, 255))
            'bmp4.Save("E:\memomi_folder1\glass_pics_8\sobel_pics1\img_" + sobel_ind1b.ToString() + ".jpg")

            If last_curve1 Is Nothing Then

            Else
                'Dim dict_res1 As Dictionary(Of String, String) = markingfldimg_obj1.check_if_pixels_arr_contain_other_pixels_arr_by_sqr_distance(last_curve1, curve_pxls_arr2, 4)
            End If

            last_curve1 = curve_pxls_arr2
        Next
        Dim key_ind1 As Integer
        Dim max_count_min_dist_to_line1 As Integer = -1
        For key_ind1 = 0 To dict_all_sobel_curves_res1.Keys.Count - 1
            Dim count_min_dist_to_line1 As Integer = dict_all_sobel_curves_res1(dict_all_sobel_curves_res1.Keys(key_ind1))("count_min_dist_to_line1")
            If max_count_min_dist_to_line1 < count_min_dist_to_line1 Then
                max_count_min_dist_to_line1 = count_min_dist_to_line1
            End If
        Next
        Dim max_width_rect1 As Integer = -1
        Dim max_width_rect_ind1 As Integer = -1
        Dim max_len_curve_pxls_arr2 As Integer = -1
        Dim max_len_curve_pxls_arr2_ind1 As Integer = -1
        For key_ind1 = 0 To dict_all_sobel_curves_res1.Keys.Count - 1
            Dim count_min_dist_to_line1 As Integer = dict_all_sobel_curves_res1(dict_all_sobel_curves_res1.Keys(key_ind1))("count_min_dist_to_line1")
            If max_count_min_dist_to_line1 / 3 <= count_min_dist_to_line1 Then
                Dim curve_pxls_arr2 As ArrayList = dict_all_sobel_curves_res1(dict_all_sobel_curves_res1.Keys(key_ind1))("curve_pxls_arr2")
                Dim dict_rect1a As Dictionary(Of String, Object) = macros_obj1.find_rect_of_pixels_arr(curve_pxls_arr2)

                Dim w1 As Integer = Math.Abs(dict_rect1a("min_x1") - dict_rect1a("max_x1"))
                If max_width_rect1 <= w1 Then
                    max_width_rect1 = w1
                    max_width_rect_ind1 = key_ind1
                End If



                If curve_pxls_arr2.Count > max_len_curve_pxls_arr2 Then
                    max_len_curve_pxls_arr2 = curve_pxls_arr2.Count
                    max_len_curve_pxls_arr2_ind1 = key_ind1
                End If
            End If
        Next
        CGlobals1.read_int_if_exist("max_width_rect_ind1", max_width_rect_ind1)
        max_len_curve_pxls_arr2_ind1 = 10
        CGlobals1.write_int1("max_width_rect_ind1", max_width_rect_ind1)
        CGlobals1.write_int1("last_ok_curve_by_sobel1", last_ok_curve_by_sobel1)

        Dim ok_start_curve_inds1 As ArrayList '= dict_all_sobel_curves_res1(dict_all_sobel_curves_res1.Keys(max_len_curve_pxls_arr2_ind1))("ind_ok_curve_arr1")
        Dim org_curve1 As ArrayList ' = dict_all_sobel_curves_res1(dict_all_sobel_curves_res1.Keys(max_len_curve_pxls_arr2_ind1))("curve_pxls_arr2")

        'max_width_rect_ind1 += 3
        'ok_start_curve_inds1 = dict_all_sobel_curves_res1(dict_all_sobel_curves_res1.Keys(last_ok_curve_by_sobel1))("ind_ok_curve_arr1")
        'org_curve1 = dict_all_sobel_curves_res1(dict_all_sobel_curves_res1.Keys(last_ok_curve_by_sobel1))("curve_pxls_arr2")
        ok_start_curve_inds1 = dict_all_sobel_curves_res1(last_ok_curve_by_sobel1)("ind_ok_curve_arr1")
        org_curve1 = dict_all_sobel_curves_res1(last_ok_curve_by_sobel1)("curve_pxls_arr2")

        Dim path_of_last_ok_curve_by_sobel1 As String = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_sobel_cache1\" + last_ok_curve_by_sobel1.ToString() + ".jpg"
        Dim bmp_last_ok_curve_by_sobel1 As Bitmap = New Bitmap(path_of_last_ok_curve_by_sobel1)


        Dim new_ok_start_curve1 As ArrayList = New ArrayList()
        For i1 = 0 To ok_start_curve_inds1.Count - 1
            new_ok_start_curve1.Add(org_curve1(ok_start_curve_inds1(i1)))
        Next


        'Dim org_curve1 As ArrayList = markingfldimg_obj1.load_2d_pixels_arr1("E:\memomi_folder1\glass_pics_8\980376445\org_curve1.txt")
        'Dim new_ok_start_curve1 As ArrayList = markingfldimg_obj1.load_2d_pixels_arr1("E:\memomi_folder1\glass_pics_8\980376445\new_ok_start_curve1.txt")

        Dim first_ind1 As Integer = 0
        Dim last_ind1 As Integer = 0
        While org_curve1(first_ind1) <> new_ok_start_curve1(0)
            first_ind1 += 1
            last_ind1 += 1
        End While
        For i1 = 0 To dict_all_sobel_curves_res1.Count - 1
            If dict_all_sobel_curves_res1.Keys(i1) = last_ok_curve_by_sobel1 Then
                max_width_rect_ind1 = i1
            End If
        Next

        Dim path_of_cache2 As String = CGlobals1.global_path1 + file_name1 + "_sobel_cache1\" + dict_all_sobel_curves_res1.Keys(max_width_rect_ind1).ToString() + ".jpg"
        bmp3 = New Bitmap(path_of_cache2)
        markingfldimg_obj1.set_pixel_arr_on_bmp2(org_curve1, bmp3, Color.FromArgb(100, 100, 220))
        bmp3.Save(CGlobals1.global_path1 + "sobel_pics1\org_curve1.bmp")

        Dim start_pixel_str1 As String = cord_start_pixels1(0).ToString() + "," + cord_start_pixels1(1).ToString()
        Dim org_crve_clone1b As ArrayList = org_curve1.Clone()
        org_curve1.Insert(0, start_pixel_str1)
        Dim org_crve_clone1 As ArrayList = org_curve1.Clone()
        Dim false_positive_cords_arr1 As ArrayList = New ArrayList()
        Dim filtered_curde_res3 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
        Dim override_curve_by_New_complete_curve1 As String = "מם"
        CGlobals1.global_vars_dict1("cuvature3_loop1") = 0

        filtered_curde_res3 = markingfldimg_obj1.filter_curve_by_curvature3(org_curve1, CGlobals1.get_cord_xy_in_pixels_arr1(org_curve1, first_ind1), pixel_line_top1, false_positive_cords_arr1, dict_pixels1)
        While filtered_curde_res3.ContainsKey("false_positive_cords_arr1") = True
            Dim new_false_positive_cords_arr1 As ArrayList = filtered_curde_res3("false_positive_cords_arr1")
            Dim i3 As Integer

            For i3 = 0 To new_false_positive_cords_arr1.Count - 1
                false_positive_cords_arr1.Add(new_false_positive_cords_arr1(i3))
            Next
            new_false_positive_cords_arr1 = filtered_curde_res3("false_positive_cords_from_sub_curves1")
            For i3 = 0 To new_false_positive_cords_arr1.Count - 1
                false_positive_cords_arr1.Add(new_false_positive_cords_arr1(i3))
            Next


            If override_curve_by_New_complete_curve1 = "yes" Then
                org_curve1 = filtered_curde_res3("new_complete_curve1")
            End If
            filtered_curde_res3 = markingfldimg_obj1.filter_curve_by_curvature3(org_curve1, CGlobals1.get_cord_xy_in_pixels_arr1(org_curve1, first_ind1), pixel_line_top1, false_positive_cords_arr1, dict_pixels1)

        End While
        Dim filtered_curde3 As ArrayList = filtered_curde_res3("new_complete_curve1")

        Dim bmp_curves1 As Bitmap = New Bitmap(CGlobals1.global_vars_dict1("crop_bmp2_path1").ToString())
        markingfldimg_obj1.save_2d_pixels_arr1(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_curve_between_frame_and_handle1.txt", filtered_curde3)


        markingfldimg_obj1.set_pixels_arr_and_save2(filtered_curde3, bmp_curves1, Color.FromArgb(255, 20, 100), CGlobals1.global_path1 + "sobel_pics1\sub_curves_f1.bmp")
        markingfldimg_obj1.set_pixel_arr_on_bmp2(filtered_curde3, bmp_last_ok_curve_by_sobel1, Color.FromArgb(55, 250, 100))

        markingfldimg_obj1.save_2d_pixels_arr1(CGlobals1.global_path1 + "sobel_pics1\sub_curves_f1.txt", filtered_curde3)
        Dim dict_false_positive_cords As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)

        'בדיקת עקמוניות מונותונית
        Dim false_positive_cords1 As ArrayList = New ArrayList()
        Dim c_ind1 As Integer
        For c_ind1 = 0 To filtered_curde3.Count - 2
            Dim dict_res1 As Dictionary(Of String, Object) = markingfldimg_obj1.find_the_tangent_to_curve_from_cord_ind(filtered_curde3, c_ind1)
            Dim curve_arr1 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(dict_res1("rot_curve_pixels"), dict_res1("cord_ind1"), dict_res1("last_cord_ind1"))
            Dim good_curve1 As String = "yes"
            'Dim false_positive_cords_arr1 As ArrayList = New ArrayList()
            Dim i2 As Integer
            Dim cord_xy3a As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_arr1, 0)
            For i2 = 0 To curve_arr1.Count - 1
                Dim cord_xy3b As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_arr1, i2)
                If cord_xy3b(0) < cord_xy3a(0) - 1 Then
                    good_curve1 = "no"
                    If dict_false_positive_cords.ContainsKey(filtered_curde3(dict_res1("cord_ind1") + i2)) = False Then
                        false_positive_cords_arr1.Add(filtered_curde3(dict_res1("cord_ind1") + i2))
                        dict_false_positive_cords(filtered_curde3(dict_res1("cord_ind1") + i2)) = 1

                    End If
                End If
            Next

            If good_curve1 = "no" Then


                false_positive_cords1.Add(c_ind1)
            End If
        Next




        markingfldimg_obj1.save_2d_pixels_arr1(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_filtered_curde3.txt", filtered_curde3)
        'markingfldimg_obj1.save_2d_pixels_arr1("E:\memomi_folder1\glass_pics_8\980376445\org_curve1.txt", org_curve1)
        'markingfldimg_obj1.save_2d_pixels_arr1("E:\memomi_folder1\glass_pics_8\980376445\new_ok_start_curve1.txt", new_ok_start_curve1)
        PictureBox1.Image = zoom_img1(bmp_last_ok_curve_by_sobel1, 1)
        Return
        Dim curve_ind1 As Integer
        Dim curve_inds_cut_with_line1 As ArrayList = New ArrayList()
        Dim min_dist_by_curve1 As Dictionary(Of Integer, Double) = New Dictionary(Of Integer, Double)
        Dim min_dist_ind_by_curve1 As Dictionary(Of Integer, Integer) = New Dictionary(Of Integer, Integer)
        '1360,15
        For curve_ind1 = 0 To curves_arr1.Count - 1
            Dim curve_pxls1 As ArrayList = curves_arr1(curve_ind1)
            'Dim curve_pxls2 As ArrayList = CGlobals1.add_val_to_pxls_arr1(curve_pxls1, cord_start_pixels1(0) + 5 + dec_delta_x1, cord_start_pixels1(1) + 5 - dec_delta_y1)
            Dim curve_pxls2 As ArrayList = CGlobals1.add_val_to_pxls_arr1(curve_pxls1, cord_start_pixels1(0) - (5 - dec_delta_x1), cord_start_pixels1(1) - (5 + dec_delta_y1))
            Dim dict_curve_pxls1 As Dictionary(Of String, Integer) = CGlobals1.add_to_dict1(curve_pxls2)

            Dim line_pxl_ind1 As Integer
            Dim cut_with_line1 As String = ""
            For line_pxl_ind1 = 0 To pixel_line_find_curve1.Count - 1
                If dict_curve_pxls1.ContainsKey(pixel_line_find_curve1(line_pxl_ind1)) = True Then
                    Dim d1 As Integer = 1

                    Dim cord_xy2 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixel_line_find_curve1, line_pxl_ind1)
                    'CGlobals1.draw_sqr_around_pixels2(bmp3, cord_xy2(0), cord_xy2(1), 4, Color.FromArgb(200, 50, 30))
                    Dim dist1 As Double = Math.Pow(Math.Pow(cord_xy2(0) - cord_start_pixels1(0), 2) + Math.Pow(cord_xy2(1) - cord_start_pixels1(1), 2), 0.5)
                    If dist1 > 5 Then

                        If min_dist_by_curve1.ContainsKey(curve_ind1) = False Then
                            min_dist_by_curve1(curve_ind1) = dist1
                            min_dist_ind_by_curve1(curve_ind1) = dict_curve_pxls1(pixel_line_find_curve1(line_pxl_ind1))
                        Else
                            If min_dist_by_curve1(curve_ind1) > dist1 Then
                                min_dist_by_curve1(curve_ind1) = dist1
                                min_dist_ind_by_curve1(curve_ind1) = dict_curve_pxls1(pixel_line_find_curve1(line_pxl_ind1))

                            End If
                        End If

                    End If
                    cut_with_line1 = "yes"
                End If
            Next
            If cut_with_line1 = "yes" Then
                curve_inds_cut_with_line1.Add(curve_ind1)
            End If
        Next
        PictureBox1.Image = zoom_img1(crop_bmp2)
        Return
        bmp3 = crop_bmp2

        CGlobals1.draw_sqr_around_pixels2(bmp3, new_cord_xy1(0), new_cord_xy1(1), 4, Color.FromArgb(200, 50, 30))
        CGlobals1.draw_sqr_around_pixels2(bmp3, cord_start_pixels1(0), cord_start_pixels1(1), 4, Color.FromArgb(200, 50, 100))


        Dim curve_pxls3 As ArrayList = CGlobals1.add_val_to_pxls_arr1(curves_arr1(min_dist_ind_by_curve1.Keys(0)), cord_start_pixels1(0) - 5 + dec_delta_x1, cord_start_pixels1(1) - 5 - dec_delta_y1)


        Dim cord_min_dist1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls3, min_dist_ind_by_curve1(min_dist_ind_by_curve1.Keys(0)) + 0)
        CGlobals1.draw_sqr_around_pixels2(bmp3, cord_min_dist1(0), cord_min_dist1(1), 5, Color.FromArgb(0, 200, 0))

        Dim sub_curve1 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(curve_pxls3, min_dist_ind_by_curve1(min_dist_ind_by_curve1.Keys(0)) - 10, min_dist_ind_by_curve1(min_dist_ind_by_curve1.Keys(0)) + 50)
        'Dim sub_curve1 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(curve_pxls3, min_dist_ind_by_curve1(min_dist_ind_by_curve1.Keys(0)), 30)

        'Dim curve_pxls3 As ArrayList = CGlobals1.add_val_to_pxls_arr1(sub_curve1, cord_start_pixels1(0) - 5, cord_start_pixels1(1) - 5 - dec_delta_y1)


        'markingfldimg_obj1.set_pixel_arr_on_bmp2(curve_pxls3, bmp3, Color.FromArgb(100, 50, 200))
        markingfldimg_obj1.set_pixel_arr_on_bmp2(sub_curve1, bmp3, Color.FromArgb(100, 50, 200))
        Dim cord_xy4 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(sub_curve1, 3)
        CGlobals1.draw_sqr_around_pixels2(bmp3, cord_xy4(0), cord_xy4(1), 8, Color.FromArgb(0, 20, 220))

        'markingfldimg_obj1.find_first_change_curveture1(sub_curve1)
        PictureBox1.Image = zoom_img1(crop_bmp2, 2)

        '1360,15->1560,121

    End Sub

    Private Sub FilterCurve1ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles FilterCurve1ToolStripMenuItem.Click
        Dim org_curve1 As ArrayList = markingfldimg_obj1.load_2d_pixels_arr1(CGlobals1.global_path1 + "980376445\org_curve1.txt")
        Dim new_ok_start_curve1 As ArrayList = markingfldimg_obj1.load_2d_pixels_arr1(CGlobals1.global_path1 + "980376445\new_ok_start_curve1.txt")

        Dim first_ind1 As Integer = 0
        Dim last_ind1 As Integer = 0
        While org_curve1(first_ind1) <> new_ok_start_curve1(0)
            first_ind1 += 1
            last_ind1 += 1
        End While

        While org_curve1(last_ind1) <> new_ok_start_curve1(new_ok_start_curve1.Count - 1)
            last_ind1 += 1
        End While

        Dim org_curve2 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(org_curve1, first_ind1, 4000)
        Dim filtered_curde3 As ArrayList '= markingfldimg_obj1.filter_curve_by_curvature3(org_curve1, CGlobals1.get_cord_xy_in_pixels_arr1(org_curve1, first_ind1))
        Dim bmp1 As Bitmap = CGlobals1.create_fill_bitmap(3000, 2000, Color.FromArgb(255, 255, 255))
        markingfldimg_obj1.set_pixels_arr_and_save2(filtered_curde3, bmp1, Color.FromArgb(0, 0, 0), CGlobals1.global_path1 + "sobel_pics1\fc1.bmp")
        'markingfldimg_obj1.save_2d_pixels_arr1("E:\memomi_folder1\glass_pics_8\980376445\org_curve1.txt", org_curve1)
        'markingfldimg_obj1.save_2d_pixels_arr1("E:\memomi_folder1\glass_pics_8\980376445\new_ok_start_curve1.txt", new_ok_start_curve1)

    End Sub

    Private Sub TunningCurveToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TunningCurveToolStripMenuItem.Click
        Dim sub_curve1 As ArrayList = markingfldimg_obj1.load_2d_pixels_arr1(CGlobals1.global_path1 + "980376340_2\right_curves1\sub_curve_6.txt")
        sub_curve1 = markingfldimg_obj1.load_2d_pixels_arr1(CGlobals1.global_path1 + "980376340\right_curves1\sub_curve_4.txt")
        sub_curve1 = markingfldimg_obj1.load_2d_pixels_arr1(CGlobals1.global_path1 + "sobel_pics1\sub_curves_f1.txt")

        'Dim i1 As Integer
        Dim false_positive_cords_arr1 As ArrayList = New ArrayList()
        Dim c_ind1 As Integer
        Dim res_str1 As String = ""
        For c_ind1 = 0 To sub_curve1.Count - 2
            If CGlobals1.get_cord_xy_in_pixels_arr1(sub_curve1, c_ind1)(0) > 0 Then

                Dim dict_res1 As Dictionary(Of String, Object) = markingfldimg_obj1.find_the_tangent_to_curve_from_cord_ind(sub_curve1, c_ind1)
                Dim curve_arr1 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(dict_res1("rot_curve_pixels"), dict_res1("cord_ind1"), dict_res1("last_cord_ind1"))
                Dim dict_cords1 As Dictionary(Of Integer, Integer()) = CGlobals1.conv_2d_arr_to_2d_cords_dict1(curve_arr1)
                Dim good_curve1 As String = "yes"
                'Dim false_positive_cords_arr1 As ArrayList = New ArrayList()
                Dim i2 As Integer
                Dim cord_xy3a As Integer() = dict_cords1(0) ' CGlobals1.get_cord_xy_in_pixels_arr1(curve_arr1, 0)
                For i2 = 0 To curve_arr1.Count - 1
                    Dim cord_xy3b As Integer() = dict_cords1(i2) ' CGlobals1.get_cord_xy_in_pixels_arr1(curve_arr1, i2)
                    If cord_xy3b(0) < cord_xy3a(0) - 1 Then
                        good_curve1 = "no"
                        false_positive_cords_arr1.Add(curve_arr1(i2))
                    End If
                Next

                res_str1 += c_ind1.ToString() + "," + dict_res1("cord_ind1").ToString() + "," + dict_res1("last_cord_ind1").ToString() + "," + good_curve1 + "," + sub_curve1(Integer.Parse(dict_res1("cord_ind1").ToString())) + "," + sub_curve1(Integer.Parse(dict_res1("last_cord_ind1").ToString())) + "#"
                System.IO.File.WriteAllText(CGlobals1.global_path1 + "sobel_pics1\sub_curves_res_f1.txt", res_str1)
                If good_curve1 = "no" Then
                    'false_positive_cords1.Add(c_ind1)
                End If
            End If

        Next
        markingfldimg_obj1.save_2d_pixels_arr1(CGlobals1.global_path1 + "sobel_pics1\sub_curves_false_positive1.txt", false_positive_cords_arr1)


        'Dim sub_curve1 As ArrayList = markingfldimg_obj1.load_2d_pixels_arr1("E:\memomi_folder1\glass_pics_8\980376340_2\right_curves1\sub_curve_3.txt")
        Dim bmp1t As Bitmap = CGlobals1.create_fill_bitmap(3000, 2500, Color.FromArgb(0, 0, 0))
        'markingfldimg_obj1.set_pixels_arr_and_save2(sub_curve1, bmp1t, Color.FromArgb(255, 255, 250), CGlobals1.global_path1 + "sobel_pics1\c1.bmp")
        'Dim dict_res1 As Dictionary(Of String, Object) = markingfldimg_obj1.find_the_tangent_to_curve_from_cord_ind(sub_curve1, 0)
        markingfldimg_obj1.find_max_tangent_len_on_curve1(sub_curve1)
        'sub_curve1.RemoveAt(0)
        'sub_curve1.RemoveAt(0)
        Dim start_ind1 As Integer = 0
        Dim end_ind1 As Integer = sub_curve1.Count - 1
        Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(sub_curve1, start_ind1)
        Dim angle1 As Double = 90
        Dim line_len1 As Integer = 200
        Dim to_stop1 As Integer = 0

        Dim ind1 As Integer = 0
        While to_stop1 = 0

            Dim sin1 As Double = Math.Sin(angle1 * Math.PI / 180)
            Dim cos1 As Double = Math.Cos(angle1 * Math.PI / 180)
            Dim cord_xy2(1) As Integer
            cord_xy2(0) = cord_xy1(0) + line_len1 * sin1
            cord_xy2(1) = cord_xy1(1) + line_len1 * cos1

            Dim pxl_line_arr1 As ArrayList = markingfldimg_obj1.create_pixel_arr_line_from_2_2d_points2(cord_xy1, cord_xy2)

            'Dim bmp2 As Bitmap = CGlobals1.create_fill_bitmap(2500, 1300, Color.FromArgb(255, 255, 255))
            'markingfldimg_obj1.set_pixel_arr_on_bmp2(pxl_line_arr1, bmp2, Color.FromArgb(200, 50, 100))
            'bmp2.Save(CGlobals1.global_path1 + "sobel_pics1\angle_" + ind1.ToString() + ".bmp")

            Dim pxl_line_dict1 As Dictionary(Of String, Integer) = CGlobals1.add_to_dict1(pxl_line_arr1)

            Dim new_sub_curve1 As ArrayList = CGlobals1.add_val_to_pxls_arr1(sub_curve1, 0, 0)


            Dim i1 As Integer
            Dim not_on_line1 As String = ""
            For i1 = start_ind1 To end_ind1
                Dim cord_xy3 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(new_sub_curve1, i1)
                If pxl_line_dict1.ContainsKey(cord_xy3(0).ToString() + "," + cord_xy3(1).ToString()) = False Then
                    not_on_line1 = "yes"
                End If
            Next
            Dim i2 As Integer
            Dim last_ok_i2 As Integer = -1
            For i2 = 0 To 10
                If not_on_line1 = "yes" Then
                    not_on_line1 = ""
                    Dim add_x1 As Integer = CGlobals1.get_cord_xy_in_pixels_arr1(pxl_line_arr1, i2 + 1)(0) - CGlobals1.get_cord_xy_in_pixels_arr1(pxl_line_arr1, 0)(0)
                    Dim add_y1 As Integer = CGlobals1.get_cord_xy_in_pixels_arr1(pxl_line_arr1, i2 + 1)(1) - CGlobals1.get_cord_xy_in_pixels_arr1(pxl_line_arr1, 0)(1)
                    new_sub_curve1 = CGlobals1.add_val_to_pxls_arr1(sub_curve1, add_x1, add_y1)

                    For i1 = start_ind1 To end_ind1
                        Dim cord_xy3 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(new_sub_curve1, i1)
                        If pxl_line_dict1.ContainsKey(cord_xy3(0).ToString() + "," + cord_xy3(1).ToString()) = False Then
                            not_on_line1 = "yes"
                        End If
                    Next
                    If not_on_line1 = "" Then
                        last_ok_i2 = i2
                    End If
                End If

            Next

            If not_on_line1 = "" Then

                Dim bmp2 As Bitmap = CGlobals1.create_fill_bitmap(2500, 1300, Color.FromArgb(255, 255, 255))
                'markingfldimg_obj1.set_pixel_arr_on_bmp2(pxl_line_arr1, bmp2, Color.FromArgb(200, 50, 100))
                'markingfldimg_obj1.set_pixel_arr_on_bmp2(new_sub_curve1, bmp2, Color.FromArgb(20, 250, 100))

                'bmp2.Save(CGlobals1.global_path1 + "sobel_pics1\angle_" + ind1.ToString() + ".bmp")

                ind1 += 1

                For i1 = start_ind1 To end_ind1
                    Dim cord_xy3 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(sub_curve1, i1)
                    If pxl_line_dict1.ContainsKey(cord_xy3(0).ToString() + "," + cord_xy3(1).ToString()) = False Then
                        not_on_line1 = "yes"
                    End If
                Next


                Dim vec_3d_obj1 As vec_3d1 = New vec_3d1()
                vec_3d_obj1.p1 = New point_3d1(cord_xy1(0), cord_xy1(1), 0)
                vec_3d_obj1.p2 = New point_3d1(cord_xy1(0), cord_xy1(1), 10)


                Dim pxl_line_arr1_r1 As ArrayList = markingfldimg_obj1.rotate_2d_pixels_arr(pxl_line_arr1, vec_3d_obj1, angle1)
                Dim new_sub_curve1_r1 As ArrayList = markingfldimg_obj1.rotate_2d_pixels_arr(new_sub_curve1, vec_3d_obj1, angle1)
                'markingfldimg_obj1.set_pixel_arr_on_bmp2(pxl_line_arr1_r1, bmp2, Color.FromArgb(200, 50, 100))
                'markingfldimg_obj1.set_pixel_arr_on_bmp2(new_sub_curve1_r1, bmp2, Color.FromArgb(20, 250, 100))
                Dim cord_xy5 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(new_sub_curve1_r1, 0)
                Dim ok_start_ind_curve1 As String = ""
                For i2 = 0 To new_sub_curve1_r1.Count - 1
                    Dim cord_xy4 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(new_sub_curve1_r1, i2)
                    If cord_xy4(0) > cord_xy5(0) Then
                        ok_start_ind_curve1 = "no"
                    End If
                Next
                If ok_start_ind_curve1 = "no" Then
                    to_stop1 = 0
                    sub_curve1.RemoveAt(0)
                    'sub_curve1.RemoveAt(0)
                    start_ind1 = 0
                    end_ind1 = sub_curve1.Count - 1
                    cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(sub_curve1, start_ind1)
                    angle1 = 90
                Else
                    markingfldimg_obj1.set_pixel_arr_on_bmp2(sub_curve1, bmp2, Color.FromArgb(200, 50, 100))
                    bmp2.Save(CGlobals1.global_path1 + "sobel_pics1\angle_" + ind1.ToString() + ".bmp")


                    to_stop1 = 1
                End If

            Else
                angle1 -= 0.5
                If angle1 = 0 Then
                    angle1 = 90
                    end_ind1 -= 1
                End If
            End If
        End While


        Dim cord_xy2b As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(sub_curve1, end_ind1)



        Dim in_line1 As Integer = 1
        While in_line1 = 1
            'Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(sub_curve1, start_ind1)
            'Dim cord_xy2 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(sub_curve1, end_ind1)
        End While
        Dim bmp1 As Bitmap = CGlobals1.create_fill_bitmap(2500, 1300, Color.FromArgb(255, 255, 255))
        Dim pixel_line1 As ArrayList = markingfldimg_obj1.create_pixel_line_by_m1(1.01, 100)
        markingfldimg_obj1.set_pixel_arr_on_bmp2(sub_curve1, bmp1, Color.FromArgb(200, 50, 100))
        markingfldimg_obj1.set_pixel_arr_on_bmp2(pixel_line1, bmp1, Color.FromArgb(200, 50, 100))

        PictureBox1.Image = zoom_img1(bmp1, 1)
    End Sub

    Private Sub RemoveHandleAboveTheFrame1ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RemoveHandleAboveTheFrame1ToolStripMenuItem.Click
        load_img_btn1_Click(Nothing, Nothing)
        chkbox_compute_sobel.Checked = False
        CGlobals1.global_suffix_file_name1 = "_frame1"

        Dim path_of_cache1 As String = CGlobals1.global_path1 + file_name1 + "_sobel_cache1"
        CGlobals1.path_of_sobel_cache1 = path_of_cache1

        Dim sobel_ind1 As Integer = -1 'Integer.Parse(form_obj1.txtbox_curent_sobel_threshold1.Text)

        Dim path_sign_sobel_ind1 As String = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_sign_sobel_ind1" + CGlobals1.global_suffix_file_name1 + ".txt"


        sobel_ind1 = Integer.Parse(System.IO.File.ReadAllText(path_sign_sobel_ind1))

        Dim path_of_bmp1 As String = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_sobel_cache1\" + sobel_ind1.ToString() + ".jpg"
        Dim bmp1 As Bitmap = New Bitmap(path_of_bmp1)
        Dim bmp1b As Bitmap = New Bitmap(path_of_bmp1)
        Dim pixels_arr1 As ArrayList = markingfldimg_obj1.load_2d_pixels_arr1(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_2d_pixels_sobel_" + sobel_ind1.ToString() + CGlobals1.global_suffix_file_name1 + ".txt")

        Dim curve_pixels2 As ArrayList = markingfldimg_obj1.load_2d_pixels_arr1(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_filtered_curde3.txt")

        'CGlobals1.global_path1 +CGlobals1.form_obj1.file_name1 + "_curve_between_frame_and_handle1.txt"
        Dim rev_pixels_arr1 As ArrayList = pixels_arr1.Clone()
        rev_pixels_arr1.Reverse()

        Dim dict_res1a As Dictionary(Of String, Object) = macros_obj1.combine_new_curve_in_frame_pixels_arr1(curve_pixels2, pixels_arr1)

        Dim first_cord1a As String = pixels_arr1(dict_res1a("first_cord_ind1"))
        Dim first_cord1_on_new_curve As String = dict_res1a("last_min_dist_x1").ToString() + "," + dict_res1a("last_min_dist_y1").ToString()

        Dim dict_res1b As Dictionary(Of String, Object) = macros_obj1.combine_new_curve_in_frame_pixels_arr1(curve_pixels2, rev_pixels_arr1)

        Dim second_cord1a As String = pixels_arr1(rev_pixels_arr1.Count - dict_res1b("first_cord_ind1"))
        Dim second_cord1_on_new_curve As String = dict_res1b("last_min_dist_x1").ToString() + "," + dict_res1b("last_min_dist_y1").ToString()


        Dim new_frame_curve1 As ArrayList = New ArrayList()
        Dim i1 As Integer
        For i1 = 0 To dict_res1a("first_cord_ind1")
            new_frame_curve1.Add(pixels_arr1(i1))
        Next

        Dim first_ind_curve1 As Integer = 0
        While curve_pixels2(first_ind_curve1) <> first_cord1_on_new_curve
            first_ind_curve1 += 1
        End While

        Dim last_ind_curve1 As Integer = first_ind_curve1
        While curve_pixels2(last_ind_curve1) <> second_cord1_on_new_curve
            last_ind_curve1 += 1
        End While

        For i1 = first_ind_curve1 To last_ind_curve1
            new_frame_curve1.Add(curve_pixels2(i1))
        Next


        For i1 = rev_pixels_arr1.Count - dict_res1b("first_cord_ind1") To pixels_arr1.Count - 1
            new_frame_curve1.Add(pixels_arr1(i1))
        Next



        markingfldimg_obj1.save_2d_pixels_arr1(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_frame4.txt", new_frame_curve1)
        markingfldimg_obj1.set_pixel_arr_on_bmp2(new_frame_curve1, bmp1, Color.FromArgb(200, 60, 90))

        Dim bmp2 As Bitmap = New Bitmap(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_crop1.jpg")
        Dim bmp3 As Bitmap = CGlobals1.create_fill_bitmap(bmp2.Width, bmp2.Height, Color.FromArgb(255, 255, 255))
        markingfldimg_obj1.set_pixel_arr_on_bmp2(new_frame_curve1, bmp3, Color.FromArgb(200, 60, 90))


        bmp3 = markingfldimg_obj1.paint_recursive3(bmp3, 20, 20, Color.FromArgb(200, 60, 90), Color.FromArgb(55, 100, 70))
        Dim org_bmp1 As Bitmap = New Bitmap(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_crop1.jpg")

        org_bmp1 = markingfldimg_obj1.set_pixels_by_mask1(bmp3, Color.FromArgb(255, 255, 255), org_bmp1)
        org_bmp1 = markingfldimg_obj1.remove_around_object1(org_bmp1, Color.FromArgb(0, 0, 0, 0))
        PictureBox1.Image = zoom_img1(org_bmp1, 1)



    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        Dim bmp1 As Bitmap = New Bitmap(CGlobals1.global_path1 + file_name1 + ".jpg")
        PictureBox1.Image = zoom_img1(bmp1, 3)
    End Sub




    Public Function polynom_fit_to_curve_by_start_derivate2(dict_prms1 As Dictionary(Of String, Object))

        If txtbox_degree_two1.Text = "" Then
            txtbox_degree_two1.Text = "1.1" ' "1.35"
        End If
        If txtbox_coef1.Text = "" Then
            txtbox_coef1.Text = "0.1"
        End If
        'derivate=0.55 , 0.1 , 1.3458 , 570, 680
        Dim start_derivate1 As Double = dict_prms1("start_derivate1")
        Dim curve_arr1 As ArrayList = dict_prms1("curve_arr1")

        Dim curve_rect1 As Dictionary(Of String, Object) = macros_obj1.find_rect_of_pixels_arr(curve_arr1)
        Dim curve_arr2 As ArrayList = curve_arr1.Clone()
        curve_arr2.RemoveAt(curve_arr2.Count - 1)
        curve_arr2.RemoveAt(curve_arr2.Count - 1)
        curve_arr2.RemoveAt(curve_arr2.Count - 1)
        curve_arr2.RemoveAt(curve_arr2.Count - 1)
        curve_arr2.RemoveAt(curve_arr2.Count - 1)
        Dim curve_rect2 As Dictionary(Of String, Object) = macros_obj1.find_rect_of_pixels_arr(curve_arr2)
        Dim i1 As Integer
        Dim height_of_bmp1 As Integer = 2000
        Dim new_curve_arr1 As ArrayList = New ArrayList()
        Dim first_cord_curve_xy1 As Integer()
        For i1 = 0 To curve_arr1.Count - 1
            Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_arr1, i1)
            If (i1 = 0) Then
                first_cord_curve_xy1 = cord_xy1
            End If
            Dim x_val1 As Integer = (cord_xy1(0) - Integer.Parse(curve_rect1("min_x1").ToString()))
            Dim y_val1 As Integer = (cord_xy1(1) - Integer.Parse(curve_rect1("min_y1").ToString()))
            new_curve_arr1.Add(x_val1.ToString() + "," + y_val1.ToString())
        Next



        For i1 = 0 To curve_arr1.Count - 1
            Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_arr1, i1)
            'curve_arr1(i1) = cord_xy1(0).ToString(0) + "," + (height_of_bmp1 - cord_xy1(1)).ToString()
        Next

        'bmp1.Save(CGlobals1.global_path1 + "sobel_pics1\curve_2.bmp")

        'Return 2

        Dim height_of_curve1 As Double = Math.Abs(curve_rect1("min_y1") - curve_rect1("max_y1"))
        Dim width_of_curve1 As Double = Math.Abs(curve_rect1("min_x1") - curve_rect1("max_x1")) + 1
        Dim height_of_curve2 As Double = Math.Abs(curve_rect2("min_y1") - curve_rect2("max_y1"))
        Dim polynom_start_x_value1 As Double = -10
        Dim polynom_end_x_value1 As Double = -1

        Dim coef_a1 As Double = Double.Parse(txtbox_coef1.Text) ' 0.1299
        Dim two_degree_val1 As Double = 1.01 ' Double.Parse(txtbox_degree_two1.Text)
        Dim polynom_obj1 As CPolynom1 = New CPolynom1()
        polynom_obj1.coef_arr1.Add(coef_a1)
        polynom_obj1.coef_arr1.Add(0)
        polynom_obj1.two_degree1 = two_degree_val1
        Dim to_stop1 As Integer = 0

        Dim dir_add_coef As Double = 1
        Dim add_coef As Double = 0.1


        Dim dir_add_two_degree As Double = 1
        Dim add_two_degree As Double = 0.1


        Dim to_stop_add_two_degree1 As Integer = 0
        Dim min_avs_dist1 As Double = 0.3
        Dim curve_ind1 As Integer = 1
        Dim last_dist_ave1 As Double = -1

        Dim last_polynom_two_degree1 As Double = -1
        Dim last_polynom_coef_a1 As Double = -1
        Dim last_start_x_val1 As Double = -1
        Dim last_end_x_val1 As Double = -1
        Dim last_step_x_val1 As Double = -1
        Dim last_start_y_val1 As Double = -1
        Dim last_end_derivate1 As Double = -1


        Dim min_last_polynom_two_degree1 As Double = -1
        Dim min_last_polynom_coef_a1 As Double = -1
        Dim min_last_start_x_val1 As Double = -1
        Dim min_last_end_x_val1 As Double = -1
        Dim min_last_step_x_val1 As Double = -1
        Dim min_last_start_y_val1 As Double = -1
        Dim min_last_end_derivate1 As Double = -1


        Dim min_ave_dist1 As Double = -1
        Dim polynoms_arr1 As ArrayList = New ArrayList()
        While to_stop_add_two_degree1 = 0

            coef_a1 = Double.Parse(txtbox_coef1.Text)

            Dim bmp1 As Bitmap = CGlobals1.create_fill_bitmap(3000, 2000, Color.FromArgb(255, 255, 255))
            markingfldimg_obj1.set_pixel_arr_on_bmp2(curve_arr1, bmp1, Color.FromArgb(255, 40, 100))

            dir_add_coef = 1
            add_coef = 0.1
            to_stop1 = 0
            Dim last_start_y_val2 As Double = -1
            Dim min_diff_start_y_height1 As Double = -999
            'Dim last_start_y_val2_arr1 As ArrayList=New ArrayList()
            While to_stop1 = 0
                polynom_obj1.coef_arr1.Clear()
                polynom_obj1.coef_arr1.Add(coef_a1)
                polynom_obj1.coef_arr1.Add(0)
                polynom_obj1.two_degree1 = two_degree_val1
                last_polynom_two_degree1 = two_degree_val1
                last_polynom_coef_a1 = coef_a1

                polynoms_arr1.Add(polynom_obj1.clone1())
                Dim polynom_curve_arr1 As ArrayList = New ArrayList()

                polynom_start_x_value1 = -polynom_obj1.get_x_val_by_derivate1(start_derivate1)
                Dim derivate_res1 As Double = polynom_obj1.get_polynom_derivate_value1(Math.Abs(polynom_start_x_value1))

                Dim i5 As Integer
                Dim last_add_to_start_x1 As Double = 9999
                If derivate_res1 <> start_derivate1 And Math.Abs(polynom_start_x_value1) < 200 Then

                    Dim derivate_diff_arr1 As ArrayList = New ArrayList()
                    For i5 = -100 To 100
                        Dim add_to_start_x1 As Double = i5 / Math.Pow(10, 16)
                        Dim new_start_x1 As Double = Math.Abs(polynom_start_x_value1 + add_to_start_x1)
                        Dim derivate_res2 As Double = polynom_obj1.get_polynom_derivate_value1(new_start_x1)

                        If derivate_res2 <> start_derivate1 Then
                            Dim err2 As Integer = 4
                        Else
                            Dim ok1 As Integer = 4
                            If last_add_to_start_x1 = 9999 Then
                                last_add_to_start_x1 = add_to_start_x1
                            End If
                        End If
                        Dim diff_derivate1 As Double = start_derivate1 - derivate_res2
                        derivate_diff_arr1.Add(new_start_x1.ToString() + "," + diff_derivate1.ToString())
                        Dim d1 As Integer = 1
                    Next

                End If

                If last_add_to_start_x1 <> 9999 Then
                    polynom_start_x_value1 = Math.Abs(polynom_start_x_value1 + last_add_to_start_x1)

                End If
                'הנקודה הראשונה צריכה להתחיל באותו גובה של הנקודה האחרונה בעקומה הקודמת
                Dim start_y_val1 As Double = polynom_obj1.get_y_polynom_value1(Math.Abs(polynom_start_x_value1))
                last_start_y_val2 = start_y_val1
                If min_diff_start_y_height1 = -999 Then
                    min_diff_start_y_height1 = Math.Abs(start_y_val1 - height_of_curve1)
                Else
                    If min_diff_start_y_height1 > Math.Abs(start_y_val1 - height_of_curve1) Then
                        min_diff_start_y_height1 = Math.Abs(start_y_val1 - height_of_curve1)

                    End If
                End If
                If start_y_val1 <= height_of_curve1 Then
                    coef_a1 -= dir_add_coef * add_coef
                    add_coef /= 2
                Else
                    If add_coef <= Math.Pow(10, -10) Then
                        to_stop1 = 1
                    End If
                    If to_stop1 = 0 Then
                        Dim before_coef_a1 As Double = coef_a1
                        coef_a1 += dir_add_coef * add_coef
                        If before_coef_a1 = coef_a1 Then
                            add_coef *= 2
                            coef_a1 += dir_add_coef * add_coef
                        End If
                    End If
                End If


            End While

            to_stop1 = 0
            'בשיל שתהיה עקמומיות - צריך להעלות את הדרגה
            'אבל מצד שני בשביל שיהיה גובה - צריך להוריד את המקדם
            'כי ככה הנגזרת הקטנה מקבלת x יותר גדול
            'וש x יותר גדול - אז גם הגובה עולה
            While to_stop1 = 0
                Dim polynom_curve_arr1 As ArrayList = New ArrayList()

                polynom_start_x_value1 = -polynom_obj1.get_x_val_by_derivate1(start_derivate1)
                last_start_x_val1 = polynom_start_x_value1
                'הנקודה הראשונה צריכה להתחיל באותו גובה של הנקודה האחרונה בעקומה הקודמת
                Dim start_y_val1 As Double = polynom_obj1.get_y_polynom_value1(Math.Abs(polynom_start_x_value1))
                last_start_y_val1 = start_y_val1
                Dim dict_x_val1 As Dictionary(Of String, Object) = polynom_obj1.get_x_polynom_degree_2_value_by_y1(start_y_val1 - height_of_curve1)
                'dict_x_val1 = polynom_obj1.get_x_polynom_degree_2_value_by_y1(start_y_val1 - height_of_curve2)
                Dim end_x_val1 As Double = dict_x_val1("x_val2")
                Dim end_derivate1 As Double = polynom_obj1.get_polynom_derivate_value1(Math.Abs(end_x_val1))
                last_end_derivate1 = end_derivate1
                Dim end_y_val1 As Double = polynom_obj1.get_y_polynom_value1(Math.Abs(end_x_val1))

                CGlobals1.global_vars_dict1("end_derivate1") = end_derivate1
                CGlobals1.global_vars_dict1("end_y_val1") = end_y_val1 - height_of_curve1
                Dim end_derivate5_before1 As Double = polynom_obj1.get_polynom_derivate_value1(Math.Abs(end_x_val1))
                Dim i2 As Integer
                Dim to_stop2 As Integer = 0
                Dim x_val1 As Double = polynom_start_x_value1
                Dim x_ind1 As Integer = 0

                last_step_x_val1 = (end_x_val1 - polynom_start_x_value1) / (width_of_curve1 - 1)
                While to_stop2 = 0
                    Dim y_val1 As Double = polynom_obj1.get_y_polynom_value1(Math.Abs(x_val1))
                    Dim new_y_val1 As Double = y_val1 'height_of_bmp1 - y_val1

                    polynom_curve_arr1.Add(x_ind1.ToString() + "," + new_y_val1.ToString())
                    x_ind1 += 1
                    x_val1 += (end_x_val1 - polynom_start_x_value1) / (width_of_curve1 - 1)

                    'x_val1 += (end_x_val1 - polynom_start_x_value1) / (curve_arr2.Count)
                    If x_val1 >= end_x_val1 Then
                        'to_stop2 = 1
                    End If
                    If x_ind1 = width_of_curve1 - 6 Then
                        end_derivate5_before1 = polynom_obj1.get_polynom_derivate_value1(Math.Abs(x_val1))
                    End If
                    If x_ind1 > width_of_curve1 - 1 Then
                        to_stop2 = 1
                    Else
                        last_end_x_val1 = x_val1
                    End If
                End While
                Dim polynom_rect1 As Dictionary(Of String, Object) = macros_obj1.find_rect_of_pixels_arr(polynom_curve_arr1)


                Dim cord_xy2 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(polynom_curve_arr1, 0)
                Dim x_val3 As Double = (cord_xy2(0) - Integer.Parse(polynom_rect1("min_x1").ToString()))
                Dim y_val3 As Double = (cord_xy2(1) - Integer.Parse(polynom_rect1("min_y1").ToString()))
                Dim delta_x1 As Double = first_cord_curve_xy1(0) - x_val3
                Dim delta_y1 As Double = first_cord_curve_xy1(1) - y_val3

                Dim delta_y_show1 As Integer = -5
                Dim new_polynom_curve_arr1 As ArrayList = New ArrayList()
                For i1 = 0 To polynom_curve_arr1.Count - 1
                    Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(polynom_curve_arr1, i1)
                    Dim x_val2 As Double = (cord_xy1(0) - Integer.Parse(polynom_rect1("min_x1").ToString()) + delta_x1)
                    Dim y_val2 As Double = (cord_xy1(1) - Integer.Parse(polynom_rect1("min_y1").ToString()) + delta_y1 + delta_y_show1)
                    new_polynom_curve_arr1.Add(x_val2.ToString() + "," + y_val2.ToString())
                Next



                to_stop1 = 1
                markingfldimg_obj1.set_pixel_arr_on_bmp2(new_polynom_curve_arr1, bmp1, Color.FromArgb(25, 0, 100))
                Dim bmp2 As Bitmap = CGlobals1.crop_bitmap(bmp1, 1030, 36, 400, 300)
                bmp2.Save(CGlobals1.global_path1 + "sobel_pics1\curve_" + dict_prms1("curve_ind1").ToString() + "_" + curve_ind1.ToString() + ".bmp")
                curve_ind1 += 1
                PictureBox1.Image = zoom_img1(bmp1, 2)
                Dim ave_dist1 As Double = 0
                For i1 = 0 To new_polynom_curve_arr1.Count - 1
                    Dim cord_xy1c As Double() = CGlobals1.get_double_cord_xy_in_pixels_arr2(curve_arr1, i1)
                    Dim i3 As Integer
                    Dim did_ave1 As Integer = 0
                    For i3 = i1 - 5 To i1 + 5
                        If i3 >= 0 And i3 <= new_polynom_curve_arr1.Count - 1 Then
                            Dim cord_xy1p As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(new_polynom_curve_arr1, i3)
                            If cord_xy1p(0) = cord_xy1c(0) And did_ave1 = 0 Then
                                ave_dist1 += Math.Abs((cord_xy1p(1) - delta_y_show1) - cord_xy1c(1))
                                did_ave1 = 1
                            End If

                        End If
                    Next




                Next
                ave_dist1 /= curve_arr1.Count
                If min_ave_dist1 <> -1 Then
                    If min_ave_dist1 > ave_dist1 Then
                        min_ave_dist1 = ave_dist1
                        min_last_polynom_two_degree1 = last_polynom_two_degree1
                        min_last_polynom_coef_a1 = last_polynom_coef_a1
                        min_last_end_derivate1 = last_end_derivate1
                        min_last_step_x_val1 = last_step_x_val1
                        min_last_start_x_val1 = last_start_x_val1
                        min_last_end_x_val1 = last_end_x_val1
                        min_last_start_y_val1 = last_start_y_val1
                    End If

                Else
                    min_ave_dist1 = ave_dist1

                    min_last_polynom_two_degree1 = last_polynom_two_degree1
                    min_last_polynom_coef_a1 = last_polynom_coef_a1
                    min_last_end_derivate1 = last_end_derivate1
                    min_last_step_x_val1 = last_step_x_val1
                    min_last_start_x_val1 = last_start_x_val1
                    min_last_end_x_val1 = last_end_x_val1
                    min_last_start_y_val1 = last_start_y_val1

                End If
                txtbox_ave_dist_curve_to_polynom1.Text = ave_dist1.ToString()
                If ave_dist1 <= min_avs_dist1 Or add_two_degree < 0.00001 Then
                    to_stop_add_two_degree1 = 1

                    Dim dict_return_res1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
                    Dim temp_polynom_obj1 As CPolynom1 = New CPolynom1()
                    temp_polynom_obj1.coef_arr1.Add(min_last_polynom_coef_a1)
                    temp_polynom_obj1.coef_arr1.Add(0)
                    temp_polynom_obj1.two_degree1 = min_last_polynom_two_degree1
                    'temp_polynom_obj1 = polynoms_arr1(polynoms_arr1.Count - 2)
                    Dim x_start_temp1 As Double = -temp_polynom_obj1.get_x_val_by_derivate1(start_derivate1)
                    Dim x_end_temp1 As Double = -temp_polynom_obj1.get_x_val_by_derivate1(end_derivate1)


                    Dim start_derivate_temp1 As Double = -temp_polynom_obj1.get_polynom_derivate_value1(Math.Abs(min_last_start_x_val1))


                    dict_return_res1("end_derivate1") = min_last_end_derivate1
                    dict_return_res1("last_polynom_two_degree1") = min_last_polynom_two_degree1
                    dict_return_res1("last_polynom_coef_a1") = min_last_polynom_coef_a1
                    dict_return_res1("last_step_x_val1") = min_last_step_x_val1
                    dict_return_res1("last_start_x_val1") = min_last_start_x_val1
                    dict_return_res1("last_end_x_val1") = min_last_end_x_val1
                    dict_return_res1("last_start_y_val1") = min_last_start_y_val1
                    dict_return_res1("x_end_temp1") = x_end_temp1

                    Dim i5 As Integer
                    For i5 = 0 To polynoms_arr1.Count - 1
                        temp_polynom_obj1 = polynoms_arr1(i5)
                        Dim x_end_temp2 As Double = -temp_polynom_obj1.get_x_val_by_derivate1(end_derivate1)
                        If x_end_temp2 <> min_last_end_x_val1 Then
                            Dim d1 As Integer = 1
                        Else
                            Dim ok1 As Integer = 1

                        End If
                    Next
                    If x_end_temp1 <> min_last_end_x_val1 Then
                        Dim d1 As Integer = 1
                    End If


                    Return dict_return_res1
                Else



                    If last_dist_ave1 <> -1 Then
                        If last_dist_ave1 < ave_dist1 Then
                            two_degree_val1 -= dir_add_two_degree * add_two_degree
                            add_two_degree /= 2
                        Else
                            two_degree_val1 += dir_add_two_degree * add_two_degree
                        End If


                    End If
                    last_dist_ave1 = ave_dist1

                End If
            End While
        End While

    End Function


    Public Function polynom_fit_to_curve_by_start_derivate1(dict_prms1 As Dictionary(Of String, Object))

        If txtbox_degree_two1.Text = "" Then
            txtbox_degree_two1.Text = "1.1" ' "1.35"
        End If
        If txtbox_coef1.Text = "" Then
            txtbox_coef1.Text = "0.1"
        End If
        'derivate=0.55 , 0.1 , 1.3458 , 570, 680
        Dim start_derivate1 As Double = dict_prms1("start_derivate1")
        Dim curve_arr1 As ArrayList = dict_prms1("curve_arr1")

        Dim curve_rect1 As Dictionary(Of String, Object) = macros_obj1.find_rect_of_pixels_arr(curve_arr1)
        Dim curve_arr2 As ArrayList = curve_arr1.Clone()
        curve_arr2.RemoveAt(curve_arr2.Count - 1)
        curve_arr2.RemoveAt(curve_arr2.Count - 1)
        curve_arr2.RemoveAt(curve_arr2.Count - 1)
        curve_arr2.RemoveAt(curve_arr2.Count - 1)
        curve_arr2.RemoveAt(curve_arr2.Count - 1)
        Dim curve_rect2 As Dictionary(Of String, Object) = macros_obj1.find_rect_of_pixels_arr(curve_arr2)
        Dim i1 As Integer
        Dim height_of_bmp1 As Integer = 2000
        Dim new_curve_arr1 As ArrayList = New ArrayList()
        Dim first_cord_curve_xy1 As Integer()
        For i1 = 0 To curve_arr1.Count - 1
            Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_arr1, i1)
            If (i1 = 0) Then
                first_cord_curve_xy1 = cord_xy1
            End If
            Dim x_val1 As Integer = (cord_xy1(0) - Integer.Parse(curve_rect1("min_x1").ToString()))
            Dim y_val1 As Integer = (cord_xy1(1) - Integer.Parse(curve_rect1("min_y1").ToString()))
            new_curve_arr1.Add(x_val1.ToString() + "," + y_val1.ToString())
        Next



        For i1 = 0 To curve_arr1.Count - 1
            Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_arr1, i1)
            'curve_arr1(i1) = cord_xy1(0).ToString(0) + "," + (height_of_bmp1 - cord_xy1(1)).ToString()
        Next

        'bmp1.Save(CGlobals1.global_path1 + "sobel_pics1\curve_2.bmp")

        'Return 2

        Dim height_of_curve1 As Double = Math.Abs(curve_rect1("min_y1") - curve_rect1("max_y1"))
        Dim width_of_curve1 As Double = Math.Abs(curve_rect1("min_x1") - curve_rect1("max_x1")) + 1
        Dim height_of_curve2 As Double = Math.Abs(curve_rect2("min_y1") - curve_rect2("max_y1"))
        Dim polynom_start_x_value1 As Double = -10
        Dim polynom_end_x_value1 As Double = -1

        Dim coef_a1 As Double = Double.Parse(txtbox_coef1.Text) ' 0.1299
        Dim two_degree_val1 As Double = 1.0001 ' 1.01 ' Double.Parse(txtbox_degree_two1.Text)
        Dim polynom_obj1 As CPolynom1 = New CPolynom1()
        polynom_obj1.coef_arr1.Add(coef_a1)
        polynom_obj1.coef_arr1.Add(0)
        polynom_obj1.two_degree1 = two_degree_val1
        Dim to_stop1 As Integer = 0

        Dim dir_add_coef As Double = 1
        Dim add_coef As Double = 0.1


        Dim dir_add_two_degree As Double = 1
        Dim add_two_degree As Double = 0.1


        Dim to_stop_add_two_degree1 As Integer = 0
        Dim min_avs_dist1 As Double = 0.3
        Dim curve_ind1 As Integer = 1
        Dim last_dist_ave1 As Double = -1

        Dim last_polynom_two_degree1 As Double = -1
        Dim last_polynom_coef_a1 As Double = -1
        Dim last_start_x_val1 As Double = -1
        Dim last_end_x_val1 As Double = -1
        Dim last_step_x_val1 As Double = -1
        Dim last_start_y_val1 As Double = -1
        Dim last_end_derivate1 As Double = -1


        Dim min_last_polynom_two_degree1 As Double = -1
        Dim min_last_polynom_coef_a1 As Double = -1
        Dim min_last_start_x_val1 As Double = -1
        Dim min_last_end_x_val1 As Double = -1
        Dim min_last_step_x_val1 As Double = -1
        Dim min_last_start_y_val1 As Double = -1
        Dim min_last_end_derivate1 As Double = -1


        Dim min_ave_dist1 As Double = -1
        Dim polynoms_arr1 As ArrayList = New ArrayList()

        Dim last_start_y_val2_arr1 As ArrayList = New ArrayList()
        Dim to_stop_add_two_degree1_ind1 As Integer = 0
        While to_stop_add_two_degree1 = 0
            to_stop_add_two_degree1_ind1 += 1
            coef_a1 = Double.Parse(txtbox_coef1.Text)

            Dim bmp1 As Bitmap = CGlobals1.create_fill_bitmap(3000, 2000, Color.FromArgb(255, 255, 255))
            markingfldimg_obj1.set_pixel_arr_on_bmp2(curve_arr1, bmp1, Color.FromArgb(255, 40, 100))

            dir_add_coef = 1
            add_coef = 0.1
            to_stop1 = 0
            Dim last_start_y_val2 As Double = -1
            While to_stop1 = 0
                polynom_obj1.coef_arr1.Clear()
                polynom_obj1.coef_arr1.Add(coef_a1)
                polynom_obj1.coef_arr1.Add(0)
                polynom_obj1.two_degree1 = two_degree_val1
                last_polynom_two_degree1 = two_degree_val1
                last_polynom_coef_a1 = coef_a1

                polynoms_arr1.Add(polynom_obj1.clone1())
                Dim polynom_curve_arr1 As ArrayList = New ArrayList()

                polynom_start_x_value1 = -polynom_obj1.get_x_val_by_derivate1(start_derivate1)
                Dim derivate_res1 As Double = polynom_obj1.get_polynom_derivate_value1(Math.Abs(polynom_start_x_value1))

                Dim i5 As Integer
                Dim last_add_to_start_x1 As Double = 9999
                If derivate_res1 <> start_derivate1 And Math.Abs(polynom_start_x_value1) < 200 Then

                    Dim derivate_diff_arr1 As ArrayList = New ArrayList()
                    For i5 = -100 To 100
                        Dim add_to_start_x1 As Double = i5 / Math.Pow(10, 16)
                        Dim new_start_x1 As Double = Math.Abs(polynom_start_x_value1 + add_to_start_x1)
                        Dim derivate_res2 As Double = polynom_obj1.get_polynom_derivate_value1(new_start_x1)

                        If derivate_res2 <> start_derivate1 Then
                            Dim err2 As Integer = 4
                        Else
                            Dim ok1 As Integer = 4
                            If last_add_to_start_x1 = 9999 Then
                                last_add_to_start_x1 = add_to_start_x1
                            End If
                        End If
                        Dim diff_derivate1 As Double = start_derivate1 - derivate_res2
                        derivate_diff_arr1.Add(new_start_x1.ToString() + "," + diff_derivate1.ToString())
                        Dim d1 As Integer = 1
                    Next

                End If

                If last_add_to_start_x1 <> 9999 Then
                    polynom_start_x_value1 = Math.Abs(polynom_start_x_value1 + last_add_to_start_x1)

                End If
                'הנקודה הראשונה צריכה להתחיל באותו גובה של הנקודה האחרונה בעקומה הקודמת
                Dim start_y_val1 As Double = polynom_obj1.get_y_polynom_value1(Math.Abs(polynom_start_x_value1))
                last_start_y_val2 = start_y_val1
                If start_y_val1 <= height_of_curve1 Then
                    coef_a1 -= dir_add_coef * add_coef
                    add_coef /= 2
                Else
                    If add_coef <= Math.Pow(10, -5) Then
                        to_stop1 = 1
                    End If
                    If to_stop1 = 0 Then
                        coef_a1 += dir_add_coef * add_coef

                    End If
                End If


            End While
            last_start_y_val2_arr1.Add(last_start_y_val2)
            to_stop1 = 0
            'בשיל שתהיה עקמומיות - צריך להעלות את הדרגה
            'אבל מצד שני בשביל שיהיה גובה - צריך להוריד את המקדם
            'כי ככה הנגזרת הקטנה מקבלת x יותר גדול
            'וש x יותר גדול - אז גם הגובה עולה
            While to_stop1 = 0
                Dim polynom_curve_arr1 As ArrayList = New ArrayList()

                polynom_start_x_value1 = -polynom_obj1.get_x_val_by_derivate1(start_derivate1)
                last_start_x_val1 = polynom_start_x_value1
                'הנקודה הראשונה צריכה להתחיל באותו גובה של הנקודה האחרונה בעקומה הקודמת
                Dim start_y_val1 As Double = polynom_obj1.get_y_polynom_value1(Math.Abs(polynom_start_x_value1))
                last_start_y_val1 = start_y_val1
                Dim dict_x_val1 As Dictionary(Of String, Object) = polynom_obj1.get_x_polynom_degree_2_value_by_y1(start_y_val1 - height_of_curve1)
                'dict_x_val1 = polynom_obj1.get_x_polynom_degree_2_value_by_y1(start_y_val1 - height_of_curve2)
                Dim end_x_val1 As Double = dict_x_val1("x_val2")
                Dim end_derivate1 As Double = polynom_obj1.get_polynom_derivate_value1(Math.Abs(end_x_val1))
                last_end_derivate1 = end_derivate1
                Dim end_y_val1 As Double = polynom_obj1.get_y_polynom_value1(Math.Abs(end_x_val1))

                CGlobals1.global_vars_dict1("end_derivate1") = end_derivate1
                CGlobals1.global_vars_dict1("end_y_val1") = end_y_val1 - height_of_curve1
                Dim end_derivate5_before1 As Double = polynom_obj1.get_polynom_derivate_value1(Math.Abs(end_x_val1))


                'בניית הנקודות של הפולינום כדי להשוות עם העקומה המקורית
                Dim i2 As Integer
                Dim to_stop2 As Integer = 0
                Dim x_val1 As Double = polynom_start_x_value1
                Dim x_ind1 As Integer = 0

                last_step_x_val1 = (end_x_val1 - polynom_start_x_value1) / (width_of_curve1 - 1)
                While to_stop2 = 0
                    Dim y_val1 As Double = polynom_obj1.get_y_polynom_value1(Math.Abs(x_val1))
                    Dim new_y_val1 As Double = y_val1 'height_of_bmp1 - y_val1

                    polynom_curve_arr1.Add(x_ind1.ToString() + "," + new_y_val1.ToString())
                    x_ind1 += 1
                    x_val1 += (end_x_val1 - polynom_start_x_value1) / (width_of_curve1 - 1)

                    'x_val1 += (end_x_val1 - polynom_start_x_value1) / (curve_arr2.Count)
                    If x_val1 >= end_x_val1 Then
                        'to_stop2 = 1
                    End If
                    If x_ind1 = width_of_curve1 - 6 Then
                        end_derivate5_before1 = polynom_obj1.get_polynom_derivate_value1(Math.Abs(x_val1))
                    End If
                    If x_ind1 > width_of_curve1 - 1 Then
                        to_stop2 = 1
                    Else
                        last_end_x_val1 = x_val1
                    End If
                End While
                Dim polynom_rect1 As Dictionary(Of String, Object) = macros_obj1.find_rect_of_pixels_arr(polynom_curve_arr1)


                Dim cord_xy2 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(polynom_curve_arr1, 0)
                Dim x_val3 As Double = (cord_xy2(0) - Integer.Parse(polynom_rect1("min_x1").ToString()))
                Dim y_val3 As Double = (cord_xy2(1) - Integer.Parse(polynom_rect1("min_y1").ToString()))
                Dim delta_x1 As Double = first_cord_curve_xy1(0) - x_val3
                Dim delta_y1 As Double = first_cord_curve_xy1(1) - y_val3

                Dim delta_y_show1 As Integer = -5
                Dim new_polynom_curve_arr1 As ArrayList = New ArrayList()
                For i1 = 0 To polynom_curve_arr1.Count - 1
                    Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(polynom_curve_arr1, i1)
                    Dim x_val2 As Double = (cord_xy1(0) - Integer.Parse(polynom_rect1("min_x1").ToString()) + delta_x1)
                    Dim y_val2 As Double = (cord_xy1(1) - Integer.Parse(polynom_rect1("min_y1").ToString()) + delta_y1 + delta_y_show1)
                    new_polynom_curve_arr1.Add(x_val2.ToString() + "," + y_val2.ToString())
                Next



                to_stop1 = 1
                markingfldimg_obj1.set_pixel_arr_on_bmp2(new_polynom_curve_arr1, bmp1, Color.FromArgb(25, 0, 100))
                Dim bmp2 As Bitmap = CGlobals1.crop_bitmap(bmp1, 1030, 36, 400, 300)
                bmp2.Save(CGlobals1.global_path1 + "sobel_pics1\curve_" + dict_prms1("curve_ind1").ToString() + "_" + curve_ind1.ToString() + ".bmp")
                curve_ind1 += 1
                PictureBox1.Image = zoom_img1(bmp1, 2)
                'השוואת הנקודות של הפוליניום עם העקומה המקורית
                Dim ave_dist1 As Double = 0
                For i1 = 0 To new_polynom_curve_arr1.Count - 1
                    Dim cord_xy1c As Double() = CGlobals1.get_double_cord_xy_in_pixels_arr2(curve_arr1, i1)
                    Dim i3 As Integer
                    Dim did_ave1 As Integer = 0
                    For i3 = i1 - 5 To i1 + 5
                        If i3 >= 0 And i3 <= new_polynom_curve_arr1.Count - 1 Then
                            Dim cord_xy1p As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(new_polynom_curve_arr1, i3)
                            If cord_xy1p(0) = cord_xy1c(0) And did_ave1 = 0 Then
                                ave_dist1 += Math.Abs((cord_xy1p(1) - delta_y_show1) - cord_xy1c(1))
                                did_ave1 = 1
                            End If

                        End If
                    Next




                Next
                ave_dist1 /= curve_arr1.Count
                If min_ave_dist1 <> -1 Then
                    If min_ave_dist1 > ave_dist1 Then
                        min_ave_dist1 = ave_dist1
                        min_last_polynom_two_degree1 = last_polynom_two_degree1
                        min_last_polynom_coef_a1 = last_polynom_coef_a1
                        min_last_end_derivate1 = last_end_derivate1
                        min_last_step_x_val1 = last_step_x_val1
                        min_last_start_x_val1 = last_start_x_val1
                        min_last_end_x_val1 = last_end_x_val1
                        min_last_start_y_val1 = last_start_y_val1
                    End If

                Else
                    min_ave_dist1 = ave_dist1

                    min_last_polynom_two_degree1 = last_polynom_two_degree1
                    min_last_polynom_coef_a1 = last_polynom_coef_a1
                    min_last_end_derivate1 = last_end_derivate1
                    min_last_step_x_val1 = last_step_x_val1
                    min_last_start_x_val1 = last_start_x_val1
                    min_last_end_x_val1 = last_end_x_val1
                    min_last_start_y_val1 = last_start_y_val1

                End If
                txtbox_ave_dist_curve_to_polynom1.Text = ave_dist1.ToString()
                If ave_dist1 <= min_avs_dist1 Or add_two_degree < Math.Pow(10, -5) Then
                    to_stop_add_two_degree1 = 1

                    Dim dict_return_res1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
                    Dim temp_polynom_obj1 As CPolynom1 = New CPolynom1()
                    temp_polynom_obj1.coef_arr1.Add(min_last_polynom_coef_a1)
                    temp_polynom_obj1.coef_arr1.Add(0)
                    temp_polynom_obj1.two_degree1 = min_last_polynom_two_degree1
                    'temp_polynom_obj1 = polynoms_arr1(polynoms_arr1.Count - 2)
                    Dim x_start_temp1 As Double = -temp_polynom_obj1.get_x_val_by_derivate1(start_derivate1)
                    Dim x_end_temp1 As Double = -temp_polynom_obj1.get_x_val_by_derivate1(end_derivate1)


                    Dim start_derivate_temp1 As Double = -temp_polynom_obj1.get_polynom_derivate_value1(Math.Abs(min_last_start_x_val1))


                    dict_return_res1("end_derivate1") = min_last_end_derivate1
                    dict_return_res1("last_polynom_two_degree1") = min_last_polynom_two_degree1
                    dict_return_res1("last_polynom_coef_a1") = min_last_polynom_coef_a1
                    dict_return_res1("last_step_x_val1") = min_last_step_x_val1
                    dict_return_res1("last_start_x_val1") = min_last_start_x_val1
                    dict_return_res1("last_end_x_val1") = min_last_end_x_val1
                    dict_return_res1("last_start_y_val1") = min_last_start_y_val1
                    dict_return_res1("x_end_temp1") = x_end_temp1

                    Dim i5 As Integer
                    For i5 = 0 To polynoms_arr1.Count - 1
                        temp_polynom_obj1 = polynoms_arr1(i5)
                        Dim x_end_temp2 As Double = -temp_polynom_obj1.get_x_val_by_derivate1(end_derivate1)
                        If x_end_temp2 <> min_last_end_x_val1 Then
                            Dim d1 As Integer = 1
                        Else
                            Dim ok1 As Integer = 1

                        End If
                    Next
                    If x_end_temp1 <> min_last_end_x_val1 Then
                        Dim d1 As Integer = 1
                    End If


                    Return dict_return_res1
                Else



                    If last_dist_ave1 <> -1 Then
                        If last_dist_ave1 < ave_dist1 Then
                            two_degree_val1 -= dir_add_two_degree * add_two_degree
                            add_two_degree /= 2
                        Else
                            two_degree_val1 += dir_add_two_degree * add_two_degree
                        End If


                    End If
                    last_dist_ave1 = ave_dist1

                End If
            End While
        End While

    End Function



    Public Function polynom_fit_to_curve_by_start_derivate1b(dict_prms1 As Dictionary(Of String, Object))

        If txtbox_degree_two1.Text = "" Then
            txtbox_degree_two1.Text = "1.1" ' "1.35"
        End If
        If txtbox_coef1.Text = "" Then
            txtbox_coef1.Text = "0.1"
        End If
        'derivate=0.55 , 0.1 , 1.3458 , 570, 680
        Dim start_derivate1 As Double = dict_prms1("start_derivate1")
        Dim curve_arr1 As ArrayList = dict_prms1("curve_arr1")

        Dim curve_rect1 As Dictionary(Of String, Object) = macros_obj1.find_rect_of_pixels_arr(curve_arr1)
        Dim curve_arr2 As ArrayList = curve_arr1.Clone()
        curve_arr2.RemoveAt(curve_arr2.Count - 1)
        curve_arr2.RemoveAt(curve_arr2.Count - 1)
        curve_arr2.RemoveAt(curve_arr2.Count - 1)
        curve_arr2.RemoveAt(curve_arr2.Count - 1)
        curve_arr2.RemoveAt(curve_arr2.Count - 1)
        Dim curve_rect2 As Dictionary(Of String, Object) = macros_obj1.find_rect_of_pixels_arr(curve_arr2)
        Dim i1 As Integer
        Dim height_of_bmp1 As Integer = 2000
        Dim new_curve_arr1 As ArrayList = New ArrayList()
        Dim first_cord_curve_xy1 As Integer()
        For i1 = 0 To curve_arr1.Count - 1
            Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_arr1, i1)
            If (i1 = 0) Then
                first_cord_curve_xy1 = cord_xy1
            End If
            Dim x_val1 As Integer = (cord_xy1(0) - Integer.Parse(curve_rect1("min_x1").ToString()))
            Dim y_val1 As Integer = (cord_xy1(1) - Integer.Parse(curve_rect1("min_y1").ToString()))
            new_curve_arr1.Add(x_val1.ToString() + "," + y_val1.ToString())
        Next



        For i1 = 0 To curve_arr1.Count - 1
            Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_arr1, i1)
            'curve_arr1(i1) = cord_xy1(0).ToString(0) + "," + (height_of_bmp1 - cord_xy1(1)).ToString()
        Next

        'bmp1.Save(CGlobals1.global_path1 + "sobel_pics1\curve_2.bmp")

        'Return 2

        Dim height_of_curve1 As Double = Math.Abs(curve_rect1("min_y1") - curve_rect1("max_y1")) + 1
        Dim width_of_curve1 As Double = Math.Abs(curve_rect1("min_x1") - curve_rect1("max_x1")) + 1
        Dim height_of_curve2 As Double = Math.Abs(curve_rect2("min_y1") - curve_rect2("max_y1"))
        Dim polynom_start_x_value1 As Double = -10
        Dim polynom_end_x_value1 As Double = -1

        Dim coef_a1 As Double = 1 ' Double.Parse(txtbox_coef1.Text) ' 0.1299
        Dim two_degree_val1 As Double = 1.78001 ' 1.01 ' Double.Parse(txtbox_degree_two1.Text)
        Dim polynom_obj1 As CPolynom1 = New CPolynom1()
        polynom_obj1.coef_arr1.Add(coef_a1)
        polynom_obj1.coef_arr1.Add(0)
        polynom_obj1.two_degree1 = two_degree_val1
        Dim to_stop1 As Integer = 0

        Dim dir_add_coef As Double = 1
        Dim add_coef As Double = 0.1


        Dim dir_add_two_degree As Double = 1
        Dim add_two_degree As Double = 0.1


        Dim to_stop_add_two_degree1 As Integer = 0
        Dim min_avs_dist1 As Double = 0.3
        Dim curve_ind1 As Integer = 1
        Dim last_dist_ave1 As Double = -1

        Dim last_polynom_two_degree1 As Double = -1
        Dim last_polynom_coef_a1 As Double = -1
        Dim last_start_x_val1 As Double = -1
        Dim last_end_x_val1 As Double = -1
        Dim last_step_x_val1 As Double = -1
        Dim last_start_y_val1 As Double = -1
        Dim last_end_derivate1 As Double = -1


        Dim min_last_polynom_two_degree1 As Double = -1
        Dim min_last_polynom_coef_a1 As Double = -1
        Dim min_last_start_x_val1 As Double = -1
        Dim min_last_end_x_val1 As Double = -1
        Dim min_last_step_x_val1 As Double = -1
        Dim min_last_start_y_val1 As Double = -1
        Dim min_last_end_derivate1 As Double = -1


        Dim min_ave_dist1 As Double = -1
        Dim polynoms_arr1 As ArrayList = New ArrayList()

        Dim last_start_y_val2_arr1 As ArrayList = New ArrayList()
        Dim to_stop_add_two_degree1_ind1 As Integer = 0

        Dim min_last_derivate2 As Double = dict_prms1("last_derivate2")
        While to_stop_add_two_degree1 = 0
            to_stop_add_two_degree1_ind1 += 1
            coef_a1 = 1 ' Double.Parse(txtbox_coef1.Text)

            Dim bmp1 As Bitmap = CGlobals1.create_fill_bitmap(3000, 2000, Color.FromArgb(255, 255, 255))
            markingfldimg_obj1.set_pixel_arr_on_bmp2(curve_arr1, bmp1, Color.FromArgb(255, 40, 100))

            dir_add_coef = 1
            add_coef = 0.1
            to_stop1 = 0
            Dim last_start_y_val2 As Double = -1
            Dim delta_start_end_x1 As Double = 100
            Dim width_of_curve1b As Double = width_of_curve1 * 70 / 58
            'width_of_curve1b = 70
            Dim last_ok_end_derivate1 As Double = -999
            While to_stop1 = 0

                Dim stop_search_polynom_vals1 As Integer = 0

                Dim add_factor1 As Double = 0.1
                coef_a1 = 2
                two_degree_val1 = 2
                Dim max_cur_polynom_start_x_value1 As Double = -9999

                Dim last_ok_polynom_obj1 As CPolynom1 = New CPolynom1()
                Dim last_zero_polynom_start_x_value1 As Double = -1
                Dim count_loop1 As Integer = 0
                While stop_search_polynom_vals1 = 0
                    count_loop1 += 1
                    Dim coef_add_ind1 As Double
                    Dim two_degree_and_ind1 As Double
                    Dim polynoms_objs_arr1 As ArrayList = New ArrayList()
                    For coef_add_ind1 = -1 To 1
                        For two_degree_and_ind1 = -1 To 1
                            If coef_add_ind1 <> 0 Or two_degree_and_ind1 <> 0 Then
                                Dim new_coef_val1 As Double = coef_a1 + coef_add_ind1 * add_factor1
                                Dim new_two_degree_val1 As Double = two_degree_val1 + two_degree_and_ind1 * add_factor1
                                Dim polynom_obj2 As CPolynom1 = New CPolynom1()
                                polynom_obj2.coef_arr1.Clear()
                                polynom_obj2.coef_arr1.Add(new_coef_val1)
                                polynom_obj2.coef_arr1.Add(0)
                                polynom_obj2.two_degree1 = new_two_degree_val1
                                polynoms_objs_arr1.Add(polynom_obj2)
                            End If

                        Next

                    Next

                    Dim polynom_obj_ind1 As Integer
                    Dim zero_polynom_obj1 As CPolynom1 = New CPolynom1()
                    zero_polynom_obj1.coef_arr1.Clear()
                    zero_polynom_obj1.coef_arr1.Add(coef_a1)
                    zero_polynom_obj1.coef_arr1.Add(0)
                    zero_polynom_obj1.two_degree1 = two_degree_val1
                    last_ok_polynom_obj1 = zero_polynom_obj1
                    Dim zero_polynom_start_x_value1 = -zero_polynom_obj1.get_x_val_by_derivate1(start_derivate1)
                    last_zero_polynom_start_x_value1 = zero_polynom_start_x_value1
                    Dim polynom_y_start_val2 As Double = zero_polynom_obj1.get_y_polynom_value1(Math.Abs(zero_polynom_start_x_value1))
                    Dim polynom_y_end_val2 As Double = zero_polynom_obj1.get_y_polynom_value1(Math.Abs(zero_polynom_start_x_value1 + width_of_curve1b))
                    Dim end_deriovate_val1 As Double = zero_polynom_obj1.get_polynom_derivate_value1(Math.Abs(zero_polynom_start_x_value1 + width_of_curve1b))
                    Dim zero_diff_height1 As Double = Math.Abs(height_of_curve1 - Math.Abs(polynom_y_start_val2 - polynom_y_end_val2))
                    Dim diff_end_deriovate_val1 As Double = Math.Abs(end_deriovate_val1 - min_last_derivate2)
                    last_ok_end_derivate1 = end_deriovate_val1
                    If zero_diff_height1 < Math.Pow(10, -8) Then
                        stop_search_polynom_vals1 = 1
                    End If
                    If dict_prms1("curve_ind1").ToString() = "3" Then
                        Dim d1 As Integer = 1
                    End If
                    Dim result_dict_arr As ArrayList = New ArrayList()
                    Dim min_diff_height1 As Double = -9999
                    max_cur_polynom_start_x_value1 = -9999
                    Dim min_result_ind1 As Integer = -1
                    For polynom_obj_ind1 = 0 To polynoms_objs_arr1.Count - 1
                        Dim polynom_obj2 As CPolynom1 = polynoms_objs_arr1(polynom_obj_ind1)
                        Dim cur_polynom_start_x_value1 As Double = -polynom_obj2.get_x_val_by_derivate1(start_derivate1)
                        Dim polynom_y_start_val2a As Double = polynom_obj2.get_y_polynom_value1(Math.Abs(cur_polynom_start_x_value1))
                        Dim polynom_y_end_val2a As Double = polynom_obj2.get_y_polynom_value1(Math.Abs(cur_polynom_start_x_value1 + width_of_curve1b))
                        Dim end_deriovate_val1a As Double = polynom_obj2.get_polynom_derivate_value1((Math.Abs(cur_polynom_start_x_value1 + width_of_curve1b)))
                        Dim diff_height1a As Double = Math.Abs(height_of_curve1 - Math.Abs(polynom_y_start_val2a - polynom_y_end_val2a))
                        Dim diff_end_deriovate_val1a As Double = Math.Abs(end_deriovate_val1a - min_last_derivate2)

                        Dim dict_result1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
                        dict_result1("polynom_start_x_value1") = polynom_start_x_value1
                        dict_result1("diff_height1") = diff_height1a

                        'If Math.Abs(polynom_start_x_value1) > delta_start_end_x1 Then

                        If zero_diff_height1 > diff_height1a And Math.Abs(cur_polynom_start_x_value1) < Math.Pow(10, 12) Then
                            If Math.Abs(zero_polynom_start_x_value1) < Math.Abs(cur_polynom_start_x_value1) Or Math.Abs(cur_polynom_start_x_value1) > width_of_curve1b Then
                                If max_cur_polynom_start_x_value1 > Math.Abs(cur_polynom_start_x_value1) Or max_cur_polynom_start_x_value1 = -9999 Or Math.Abs(cur_polynom_start_x_value1) > width_of_curve1b Then
                                    max_cur_polynom_start_x_value1 = Math.Abs(cur_polynom_start_x_value1)
                                    If min_diff_height1 > diff_height1a Or min_diff_height1 = -9999 Then 'And diff_end_deriovate_val1 <= diff_end_deriovate_val1a Then
                                        min_diff_height1 = diff_height1a
                                        min_result_ind1 = polynom_obj_ind1
                                    End If
                                End If
                                'If min_diff_height1 > diff_height1a Or min_diff_height1 = -9999 Then
                                'min_diff_height1 = diff_height1a
                                'min_result_ind1 = polynom_obj_ind1

                                'End If
                            End If

                        End If

                        'End If

                    Next
                    If count_loop1 > 300 Then
                        Dim dict_return_res2 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
                        dict_return_res2("error1") = "yes"
                        Return dict_return_res2

                    End If
                    If min_result_ind1 <> -1 Then
                        Dim polynom_obj2 As CPolynom1 = polynoms_objs_arr1(min_result_ind1)
                        coef_a1 = polynom_obj2.coef_arr1(0)
                        two_degree_val1 = polynom_obj2.two_degree1
                    Else
                        add_factor1 /= 2
                        If add_factor1 <= Math.Pow(10, -15) Then
                            Dim dict_return_res2 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
                            dict_return_res2("error1") = "yes"
                            Return dict_return_res2
                        End If
                    End If


                End While
                Dim bmp_polynom_obj1 As Bitmap = CGlobals1.create_fill_bitmap(1000, 1000, Color.FromArgb(255, 255, 255))
                Dim polyno_curve_arr1 As ArrayList = New ArrayList()
                Dim x_val2 As Double = last_zero_polynom_start_x_value1
                Dim curve_arr_ind1 As Integer = 0
                Dim last_cur_x_cord1 = -1
                For i1 = 0 To width_of_curve1

                    Dim curve_cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_arr1, curve_arr_ind1)
                    Dim cur_x_cord1 As Integer = curve_cord_xy1(0) - curve_rect1("min_x1")
                    Dim start_y_val1 As Double = last_ok_polynom_obj1.get_y_polynom_value1(Math.Abs(last_zero_polynom_start_x_value1))
                    While cur_x_cord1 = last_cur_x_cord1 And curve_arr_ind1 < curve_arr1.Count - 1
                        curve_arr_ind1 += 1
                        curve_cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(curve_arr1, curve_arr_ind1)
                        cur_x_cord1 = curve_cord_xy1(0) - curve_rect1("min_x1")
                    End While
                    last_cur_x_cord1 = cur_x_cord1
                    Dim y_val1 As Double = last_ok_polynom_obj1.get_y_polynom_value1(Math.Abs(x_val2))
                    x_val2 += width_of_curve1b / width_of_curve1
                    polyno_curve_arr1.Add(i1.ToString() + "," + y_val1.ToString())
                    bmp_polynom_obj1.SetPixel(i1, CType(y_val1, Integer) + 400 - start_y_val1, Color.FromArgb(255, 30, 100))
                    bmp_polynom_obj1.SetPixel(cur_x_cord1, CType(curve_cord_xy1(1) - curve_rect1("min_y1"), Integer) + 50, Color.FromArgb(55, 30, 100))

                Next

                bmp_polynom_obj1.Save(CGlobals1.global_path1 + "sobel_pics1\poly_curve_" + dict_prms1("curve_ind1").ToString() + ".bmp")
                Dim dict_return_res1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)

                dict_return_res1("polynom_obj1") = last_ok_polynom_obj1
                dict_return_res1("polynom_start_x_value1") = last_zero_polynom_start_x_value1
                dict_return_res1("end_derivate1") = last_ok_end_derivate1

                Return dict_return_res1

                last_polynom_coef_a1 = coef_a1
                Dim end_derivate1 As Double = polynom_obj1.get_polynom_derivate_value1(Math.Abs(polynom_start_x_value1 + delta_start_end_x1))
                Dim derivate_res1 As Double = polynom_obj1.get_polynom_derivate_value1(Math.Abs(polynom_start_x_value1))
                to_stop1 = 1
                If to_stop1 = 0 Then

                    Dim i5 As Integer
                    Dim last_add_to_start_x1 As Double = 9999
                    If derivate_res1 <> start_derivate1 And Math.Abs(polynom_start_x_value1) < 200 Then

                        Dim derivate_diff_arr1 As ArrayList = New ArrayList()
                        For i5 = -100 To 100
                            Dim add_to_start_x1 As Double = i5 / Math.Pow(10, 16)
                            Dim new_start_x1 As Double = Math.Abs(polynom_start_x_value1 + add_to_start_x1)
                            Dim derivate_res2 As Double = polynom_obj1.get_polynom_derivate_value1(new_start_x1)

                            If derivate_res2 <> start_derivate1 Then
                                Dim err2 As Integer = 4
                            Else
                                Dim ok1 As Integer = 4
                                If last_add_to_start_x1 = 9999 Then
                                    last_add_to_start_x1 = add_to_start_x1
                                End If
                            End If
                            Dim diff_derivate1 As Double = start_derivate1 - derivate_res2
                            derivate_diff_arr1.Add(new_start_x1.ToString() + "," + diff_derivate1.ToString())
                            Dim d1 As Integer = 1
                        Next

                    End If

                    If last_add_to_start_x1 <> 9999 Then
                        polynom_start_x_value1 = Math.Abs(polynom_start_x_value1 + last_add_to_start_x1)

                    End If
                    'הנקודה הראשונה צריכה להתחיל באותו גובה של הנקודה האחרונה בעקומה הקודמת
                    Dim end_y_val1 As Double = polynom_obj1.get_y_polynom_value1(Math.Abs(polynom_start_x_value1) + delta_start_end_x1)
                    Dim start_y_val1 As Double = polynom_obj1.get_y_polynom_value1(Math.Abs(polynom_start_x_value1))
                    last_start_y_val2 = start_y_val1
                    If start_y_val1 <= height_of_curve1 Then
                        coef_a1 -= dir_add_coef * add_coef
                        add_coef /= 2
                    Else
                        If add_coef <= Math.Pow(10, -5) Then
                            to_stop1 = 1
                        End If
                        If to_stop1 = 0 Then
                            coef_a1 += dir_add_coef * add_coef

                        End If
                    End If

                End If

            End While
        'last_start_y_val2_arr1.Add(last_start_y_val2)
        to_stop1 = 0
            'בשיל שתהיה עקמומיות - צריך להעלות את הדרגה
            'אבל מצד שני בשביל שיהיה גובה - צריך להוריד את המקדם
            'כי ככה הנגזרת הקטנה מקבלת x יותר גדול
            'וש x יותר גדול - אז גם הגובה עולה
            While to_stop1 = 0
                Dim polynom_curve_arr1 As ArrayList = New ArrayList()

                polynom_start_x_value1 = -polynom_obj1.get_x_val_by_derivate1(start_derivate1)
                last_start_x_val1 = polynom_start_x_value1
                'הנקודה הראשונה צריכה להתחיל באותו גובה של הנקודה האחרונה בעקומה הקודמת
                Dim start_y_val1 As Double = polynom_obj1.get_y_polynom_value1(Math.Abs(polynom_start_x_value1))
                last_start_y_val1 = start_y_val1
                Dim dict_x_val1 As Dictionary(Of String, Object) = polynom_obj1.get_x_polynom_degree_2_value_by_y1(start_y_val1 - height_of_curve1)
                'dict_x_val1 = polynom_obj1.get_x_polynom_degree_2_value_by_y1(start_y_val1 - height_of_curve2)
                Dim end_x_val1 As Double = dict_x_val1("x_val2")
                Dim end_derivate1 As Double = polynom_obj1.get_polynom_derivate_value1(Math.Abs(end_x_val1))
                last_end_derivate1 = end_derivate1
                Dim end_y_val1 As Double = polynom_obj1.get_y_polynom_value1(Math.Abs(end_x_val1))

                CGlobals1.global_vars_dict1("end_derivate1") = end_derivate1
                CGlobals1.global_vars_dict1("end_y_val1") = end_y_val1 - height_of_curve1
                Dim end_derivate5_before1 As Double = polynom_obj1.get_polynom_derivate_value1(Math.Abs(end_x_val1))


                'בניית הנקודות של הפולינום כדי להשוות עם העקומה המקורית
                Dim i2 As Integer
                Dim to_stop2 As Integer = 0
                Dim x_val1 As Double = polynom_start_x_value1
                Dim x_ind1 As Integer = 0

                last_step_x_val1 = (end_x_val1 - polynom_start_x_value1) / (width_of_curve1 - 1)
                While to_stop2 = 0
                    Dim y_val1 As Double = polynom_obj1.get_y_polynom_value1(Math.Abs(x_val1))
                    Dim new_y_val1 As Double = y_val1 'height_of_bmp1 - y_val1

                    polynom_curve_arr1.Add(x_ind1.ToString() + "," + new_y_val1.ToString())
                    x_ind1 += 1
                    x_val1 += (end_x_val1 - polynom_start_x_value1) / (width_of_curve1 - 1)

                    'x_val1 += (end_x_val1 - polynom_start_x_value1) / (curve_arr2.Count)
                    If x_val1 >= end_x_val1 Then
                        'to_stop2 = 1
                    End If
                    If x_ind1 = width_of_curve1 - 6 Then
                        end_derivate5_before1 = polynom_obj1.get_polynom_derivate_value1(Math.Abs(x_val1))
                    End If
                    If x_ind1 > width_of_curve1 - 1 Then
                        to_stop2 = 1
                    Else
                        last_end_x_val1 = x_val1
                    End If
                End While
                Dim polynom_rect1 As Dictionary(Of String, Object) = macros_obj1.find_rect_of_pixels_arr(polynom_curve_arr1)


                Dim cord_xy2 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(polynom_curve_arr1, 0)
                Dim x_val3 As Double = (cord_xy2(0) - Integer.Parse(polynom_rect1("min_x1").ToString()))
                Dim y_val3 As Double = (cord_xy2(1) - Integer.Parse(polynom_rect1("min_y1").ToString()))
                Dim delta_x1 As Double = first_cord_curve_xy1(0) - x_val3
                Dim delta_y1 As Double = first_cord_curve_xy1(1) - y_val3

                Dim delta_y_show1 As Integer = -5
                Dim new_polynom_curve_arr1 As ArrayList = New ArrayList()
                For i1 = 0 To polynom_curve_arr1.Count - 1
                    Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(polynom_curve_arr1, i1)
                    Dim x_val2 As Double = (cord_xy1(0) - Integer.Parse(polynom_rect1("min_x1").ToString()) + delta_x1)
                    Dim y_val2 As Double = (cord_xy1(1) - Integer.Parse(polynom_rect1("min_y1").ToString()) + delta_y1 + delta_y_show1)
                    new_polynom_curve_arr1.Add(x_val2.ToString() + "," + y_val2.ToString())
                Next



                to_stop1 = 1
                markingfldimg_obj1.set_pixel_arr_on_bmp2(new_polynom_curve_arr1, bmp1, Color.FromArgb(25, 0, 100))
                Dim bmp2 As Bitmap = CGlobals1.crop_bitmap(bmp1, 1030, 36, 400, 300)
                bmp2.Save(CGlobals1.global_path1 + "sobel_pics1\curve_" + dict_prms1("curve_ind1").ToString() + "_" + curve_ind1.ToString() + ".bmp")
                curve_ind1 += 1
                PictureBox1.Image = zoom_img1(bmp1, 2)
                'השוואת הנקודות של הפוליניום עם העקומה המקורית
                Dim ave_dist1 As Double = 0
                For i1 = 0 To new_polynom_curve_arr1.Count - 1
                    Dim cord_xy1c As Double() = CGlobals1.get_double_cord_xy_in_pixels_arr2(curve_arr1, i1)
                    Dim i3 As Integer
                    Dim did_ave1 As Integer = 0
                    For i3 = i1 - 5 To i1 + 5
                        If i3 >= 0 And i3 <= new_polynom_curve_arr1.Count - 1 Then
                            Dim cord_xy1p As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(new_polynom_curve_arr1, i3)
                            If cord_xy1p(0) = cord_xy1c(0) And did_ave1 = 0 Then
                                ave_dist1 += Math.Abs((cord_xy1p(1) - delta_y_show1) - cord_xy1c(1))
                                did_ave1 = 1
                            End If

                        End If
                    Next




                Next
                ave_dist1 /= curve_arr1.Count
                If min_ave_dist1 <> -1 Then
                    If min_ave_dist1 > ave_dist1 Then
                        min_ave_dist1 = ave_dist1
                        min_last_polynom_two_degree1 = last_polynom_two_degree1
                        min_last_polynom_coef_a1 = last_polynom_coef_a1
                        min_last_end_derivate1 = last_end_derivate1
                        min_last_step_x_val1 = last_step_x_val1
                        min_last_start_x_val1 = last_start_x_val1
                        min_last_end_x_val1 = last_end_x_val1
                        min_last_start_y_val1 = last_start_y_val1
                    End If

                Else
                    min_ave_dist1 = ave_dist1

                    min_last_polynom_two_degree1 = last_polynom_two_degree1
                    min_last_polynom_coef_a1 = last_polynom_coef_a1
                    min_last_end_derivate1 = last_end_derivate1
                    min_last_step_x_val1 = last_step_x_val1
                    min_last_start_x_val1 = last_start_x_val1
                    min_last_end_x_val1 = last_end_x_val1
                    min_last_start_y_val1 = last_start_y_val1

                End If
                txtbox_ave_dist_curve_to_polynom1.Text = ave_dist1.ToString()
                If ave_dist1 <= min_avs_dist1 Or add_two_degree < Math.Pow(10, -5) Then
                    to_stop_add_two_degree1 = 1

                    Dim dict_return_res1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
                    Dim temp_polynom_obj1 As CPolynom1 = New CPolynom1()
                    temp_polynom_obj1.coef_arr1.Add(min_last_polynom_coef_a1)
                    temp_polynom_obj1.coef_arr1.Add(0)
                    temp_polynom_obj1.two_degree1 = min_last_polynom_two_degree1
                    'temp_polynom_obj1 = polynoms_arr1(polynoms_arr1.Count - 2)
                    Dim x_start_temp1 As Double = -temp_polynom_obj1.get_x_val_by_derivate1(start_derivate1)
                    Dim x_end_temp1 As Double = -temp_polynom_obj1.get_x_val_by_derivate1(end_derivate1)


                    Dim start_derivate_temp1 As Double = -temp_polynom_obj1.get_polynom_derivate_value1(Math.Abs(min_last_start_x_val1))


                    dict_return_res1("end_derivate1") = min_last_end_derivate1
                    dict_return_res1("last_polynom_two_degree1") = min_last_polynom_two_degree1
                    dict_return_res1("last_polynom_coef_a1") = min_last_polynom_coef_a1
                    dict_return_res1("last_step_x_val1") = min_last_step_x_val1
                    dict_return_res1("last_start_x_val1") = min_last_start_x_val1
                    dict_return_res1("last_end_x_val1") = min_last_end_x_val1
                    dict_return_res1("last_start_y_val1") = min_last_start_y_val1
                    dict_return_res1("x_end_temp1") = x_end_temp1

                    Dim i5 As Integer
                    For i5 = 0 To polynoms_arr1.Count - 1
                        temp_polynom_obj1 = polynoms_arr1(i5)
                        Dim x_end_temp2 As Double = -temp_polynom_obj1.get_x_val_by_derivate1(end_derivate1)
                        If x_end_temp2 <> min_last_end_x_val1 Then
                            Dim d1 As Integer = 1
                        Else
                            Dim ok1 As Integer = 1

                        End If
                    Next
                    If x_end_temp1 <> min_last_end_x_val1 Then
                        Dim d1 As Integer = 1
                    End If


                    Return dict_return_res1
                Else



                    If last_dist_ave1 <> -1 Then
                        If last_dist_ave1 < ave_dist1 Then
                            two_degree_val1 -= dir_add_two_degree * add_two_degree
                            add_two_degree /= 2
                        Else
                            two_degree_val1 += dir_add_two_degree * add_two_degree
                        End If


                    End If
                    last_dist_ave1 = ave_dist1

                End If
            End While
        End While

    End Function
    Public Function get_curve_dist1(curve_start_ind1 As Integer, curve_end_ind1 As Integer, start_derivate1 As Double, coef_a1 As Double)
        Dim frame_pixels_arr1 As ArrayList = markingfldimg_obj1.load_2d_pixels_arr1(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_frame4.txt")
        Dim curve1 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, curve_start_ind1, curve_end_ind1)

        Dim i1 As Integer
        Dim mul_factor1 As Double = 1
        For i1 = 0 To curve1.Count - 1
            Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve1, i1)
            'curve1(i1) = (cord_xy1(0) * mul_factor1).ToString() + "," + (cord_xy1(1) * mul_factor1).ToString()
        Next



        Dim do_search1 As String = "1"
        If start_derivate1 = 9999 Then
            do_search1 = "2"
        End If
        Dim dict_rect1 As Dictionary(Of String, Object) = macros_obj1.find_rect_of_pixels_arr(curve1)
        'dict_rect1("min_x1") = min_x1
        'dict_rect1("max_x1") = max_x1
        'dict_rect1("min_y1") = min_y1
        'dict_rect1("max_y1") = max_y1

        'dict_rect1("min_x_ind1") = min_x_ind1
        'dict_rect1("max_x_ind1") = max_x_ind1
        'dict_rect1("min_y_ind1") = min_y_ind1
        'dict_rect1("max_y_ind1") = max_y_ind1

        Dim img_height1 As Integer = 2000
        Dim img_width1 As Integer = 3000
        Dim bmp1 As Bitmap = CGlobals1.create_fill_bitmap(img_width1, img_height1, Color.FromArgb(255, 255, 255))

        Dim padding2 As Integer = 5

        Dim cord_xy1a As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve1, 0)

        Dim cord_y_pos1a As Integer = (cord_xy1a(1) - dict_rect1("min_y1"))
        Dim delta_y1 As Integer = 1999 - cord_y_pos1a
        Dim max_x_pos1 As Integer = -1
        Dim first_xy_cord_curve1 As Integer() = New Integer() {0, 0}
        Dim last_xy_cord_curve1 As Integer() = New Integer() {0, 0}
        Dim curve_pos_arr1 As ArrayList = New ArrayList()

        For i1 = 0 To curve1.Count - 1
            Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve1, i1)
            Dim cord_x_pos1 As Integer = (cord_xy1(0) - dict_rect1("min_x1"))
            Dim cord_y_pos1 As Integer = (cord_xy1(1) - dict_rect1("min_y1")) + delta_y1

            If i1 = 0 Then
                first_xy_cord_curve1 = New Integer() {cord_x_pos1, cord_y_pos1}
            End If
            If i1 = curve1.Count - 1 Then
                last_xy_cord_curve1 = New Integer() {cord_x_pos1, cord_y_pos1}
            End If
            If cord_x_pos1 > 0 + padding2 And cord_x_pos1 < bmp1.Width - 1 - padding2 And cord_y_pos1 > 0 + padding2 And cord_y_pos1 < bmp1.Height - 1 - padding2 Then
                'CGlobals1.draw_sqr_around_pixels2(bmp1, cord_x_pos1, cord_y_pos1, 2, Color.FromArgb(0, 0, 0))
                CGlobals1.draw_sqr_around_pixels2(bmp1, cord_x_pos1, cord_y_pos1, 2, Color.FromArgb(0, 0, 0))

            End If
            curve_pos_arr1.Add(cord_x_pos1.ToString() + "," + cord_y_pos1.ToString())
            If max_x_pos1 < cord_x_pos1 Then
                max_x_pos1 = cord_x_pos1
            End If

        Next
        If CGlobals1.global_vars_dict1.ContainsKey("end_x_polynom1") = False Then
            CGlobals1.global_vars_dict1("end_x_polynom1") = -5
        End If
        If CGlobals1.global_vars_dict1.ContainsKey("start_x_polynom1") = False Then
            CGlobals1.global_vars_dict1("start_x_polynom1") = -30
        End If
        Dim start_x1 As Double = CGlobals1.global_vars_dict1("start_x_polynom1")
        Dim end_x1 As Double = CGlobals1.global_vars_dict1("end_x_polynom1")
        If end_x1 <= start_x1 Then
            end_x1 = start_x1 + 1

            CGlobals1.global_vars_dict1("start_x_polynom1") = start_x1
            CGlobals1.global_vars_dict1("end_x_polynom1") = end_x1
        End If
        Dim x1 As Double
        Dim y1 As Integer
        Dim curve_obj1 As CCurve1 = New CCurve1()


        Dim polynon_curve_pxl_arr1 As ArrayList
        Dim first_xy_cord_polynom1 As Integer()
        Dim last_xy_cord_polynom1 As Integer()
        Dim coef1 As Double = -3
        Dim dir_coef_add1 As Double = -1
        Dim dir_coef_add_factor1 As Double = 1
        Dim to_stop_tunning_polynom1 As Integer = 0
        Dim last_diff_x1 As Double = 9999
        Dim last_diff_y1 As Double = 9999

        Dim polynom_obj1 As CPolynom1 = New CPolynom1()

        'Dim coef_a1 As Double = 0.1
        Dim add_coef_a1 As Double = 0.1
        Dim dir_add_coef_a1 As Double = 1
        Dim last_delta_height_poly_and_curve1 = -1


        While to_stop_tunning_polynom1 = 0 And do_search1 = "1"


            polynom_obj1.coef_arr1 = New ArrayList()


            polynom_obj1.polynom_name1 = "1"
            polynom_obj1.coef_arr1.Add(-coef_a1)
            polynom_obj1.coef_arr1.Add(0)
            If start_derivate1 <> 9999 Then
                start_x1 = polynom_obj1.get_x_val_by_derivate1(start_derivate1)
            End If
            Dim polynom_first_y_val1 As Double = polynom_obj1.get_y_polynom_value1(start_x1)
            Dim polynom_last_y_val1 As Double = polynom_obj1.get_y_polynom_value1(end_x1)
            Dim delta_height_poly_and_curve1 As Double = Math.Abs(Math.Abs(polynom_first_y_val1 - polynom_last_y_val1) - Math.Abs(first_xy_cord_curve1(1) - last_xy_cord_curve1(1)))
            If delta_height_poly_and_curve1 > 1 Then

                If last_delta_height_poly_and_curve1 = -1 Then
                    end_x1 += add_coef_a1 * dir_add_coef_a1
                Else
                    If last_delta_height_poly_and_curve1 > delta_height_poly_and_curve1 Then

                    Else
                        dir_add_coef_a1 = -dir_add_coef_a1
                        add_coef_a1 /= 2
                    End If
                    end_x1 += add_coef_a1 * dir_add_coef_a1
                End If
            Else
                to_stop_tunning_polynom1 = 1
            End If

            last_delta_height_poly_and_curve1 = delta_height_poly_and_curve1

        End While


        While to_stop_tunning_polynom1 = 0 And do_search1 = "2"


            polynom_obj1.coef_arr1 = New ArrayList()


            polynom_obj1.polynom_name1 = "1"
            polynom_obj1.coef_arr1.Add(-coef_a1)
            polynom_obj1.coef_arr1.Add(0)
            Dim polynom_first_y_val1 As Double = polynom_obj1.get_y_polynom_value1(start_x1)
            Dim polynom_last_y_val1 As Double = polynom_obj1.get_y_polynom_value1(end_x1)
            Dim delta_height_poly_and_curve1 As Double = Math.Abs(Math.Abs(polynom_first_y_val1 - polynom_last_y_val1) - Math.Abs(first_xy_cord_curve1(1) - last_xy_cord_curve1(1)))
            If delta_height_poly_and_curve1 > 1 Then

                If last_delta_height_poly_and_curve1 = -1 Then
                    coef_a1 += add_coef_a1 * dir_add_coef_a1
                Else
                    If last_delta_height_poly_and_curve1 > delta_height_poly_and_curve1 Then

                    Else
                        dir_add_coef_a1 = -dir_add_coef_a1
                        add_coef_a1 /= 2
                    End If
                    coef_a1 += add_coef_a1 * dir_add_coef_a1
                End If
            Else
                to_stop_tunning_polynom1 = 1
            End If

            last_delta_height_poly_and_curve1 = delta_height_poly_and_curve1

        End While

        'polynon_curve_pxl_arr1 = curve_obj1.create_polynom_curve_pxl_arr2(start_x1, end_x1, img_width1, curve1.Count, -coef_a1)
        'polynon_curve_pxl_arr1 = curve_obj1.create_polynom_curve_pxl_arr2(start_x1, end_x1, img_width1, max_x_pos1, -coef_a1)
        polynon_curve_pxl_arr1 = curve_obj1.create_polynom_curve_pxl_arr2(start_x1, end_x1, img_width1, max_x_pos1, -coef_a1)

        Dim dict_res1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
        dict_res1("start_derivate1") = polynom_obj1.get_polynom_derivate_value1(start_x1)
        dict_res1("end_derivate1") = polynom_obj1.get_polynom_derivate_value1(end_x1)
        textbox_start_derivate1.Text = polynom_obj1.get_polynom_derivate_value1(start_x1)
        textbox_end_derivate1.Text = polynom_obj1.get_polynom_derivate_value1(end_x1)
        While to_stop_tunning_polynom1 = 1 And False
            polynon_curve_pxl_arr1 = curve_obj1.create_polynom_curve_pxl_arr2(start_x1, end_x1, img_width1, curve1.Count, coef1)
            first_xy_cord_polynom1 = CGlobals1.get_cord_xy_in_pixels_arr1(polynon_curve_pxl_arr1, 0)
            last_xy_cord_polynom1 = CGlobals1.get_cord_xy_in_pixels_arr1(polynon_curve_pxl_arr1, polynon_curve_pxl_arr1.Count - 1)
            Dim cur_diff_x1 As Double = Math.Abs(last_xy_cord_polynom1(0) - last_xy_cord_curve1(0))
            Dim cur_diff_y1 As Double = Math.Abs(last_xy_cord_polynom1(1) - (img_height1 - last_xy_cord_curve1(1))) + Math.Abs(first_xy_cord_polynom1(1) - (img_height1 - first_xy_cord_curve1(1)))
            If last_diff_y1 < cur_diff_y1 Then
                dir_coef_add1 *= -1
                dir_coef_add_factor1 /= 2
            End If
            last_diff_y1 = cur_diff_y1
            If cur_diff_x1 > 1 Or cur_diff_y1 > 1 Then
                coef1 -= dir_coef_add1 * dir_coef_add_factor1

            Else
                to_stop_tunning_polynom1 = 1
            End If

        End While
        txtbox_coef1.Text = coef_a1.ToString()
        'MessageBox.Show(coef1.ToString())
        'Dim polynon_curve_pxl_arr1 As ArrayList = curve_obj1.create_polynom_curve_pxl_arr1(start_x1, end_x1, img_width1, max_x_pos1)
        Dim max_y1 As Double = -99999
        Dim min_y1 As Double = 99999
        Dim y_vals_arr1 As ArrayList = New ArrayList()
        Dim x_vals_arr1 As ArrayList = New ArrayList()

        Dim x_ind1 As Integer = 0

        'PictureBox1.Image = zoom_img1(bmp1, 4)

        'Return
        Dim average_dist1 As Double = 0
        Dim polynom_pos_arr1 As ArrayList = New ArrayList()
        For ind_x1 = 0 To polynon_curve_pxl_arr1.Count - 2 ' img_width1 - 1

            'Next
            Dim cord_xy1 As Double() = CGlobals1.get_double_cord_xy_in_pixels_arr2(polynon_curve_pxl_arr1, ind_x1)
            Dim y_pos_pixel1 As Double = (img_height1 - cord_xy1(1))
            Dim x_val1 As Integer = cord_xy1(0)
            Dim padding1 As Integer = 5
            'If x_val1 >= 0 + padding1 And x_val1 <= bmp1.Width - 1 - padding1 And y_pos_pixel1 >= 0 + padding1 And y_pos_pixel1 <= bmp1.Height - 1 - padding1 Then
            'CGlobals1.draw_sqr_around_pixels2(bmp1, cord_xy1(0), y_pos_pixel1, 1, Color.FromArgb(255, 50, 0))

            'End If

            If ind_x1 >= 0 + padding1 And ind_x1 <= bmp1.Width - 1 - padding1 And y_pos_pixel1 >= 0 + padding1 And y_pos_pixel1 <= bmp1.Height - 1 - padding1 Then
                CGlobals1.draw_sqr_around_pixels2(bmp1, ind_x1, y_pos_pixel1, 1, Color.FromArgb(255, 50, 0))

                Dim cord_xy_curve1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pos_arr1, ind_x1)
                average_dist1 += Math.Abs(y_pos_pixel1 - cord_xy_curve1(1))
            End If
            polynom_pos_arr1.Add(ind_x1.ToString() + "," + y_pos_pixel1.ToString())


            'x1 += (end_x1 - start_x1) / img_width1

        Next

        bmp1.Save(CGlobals1.global_path1 + "sobel_pics1\curve_fit1.bmp")

        Dim rect_dict1 As Dictionary(Of String, Object) = macros_obj1.find_rect_of_pixels_arr(curve_pos_arr1)
        Dim rect_dict2 As Dictionary(Of String, Object) = macros_obj1.find_rect_of_pixels_arr(polynom_pos_arr1)

        average_dist1 /= polynon_curve_pxl_arr1.Count

        dict_res1("average_dist1") = average_dist1
        Return dict_res1
    End Function


    Public Function aproximation_curve_to_multi_polynoms()
        Dim frame_pixels_arr1 As ArrayList = markingfldimg_obj1.load_2d_pixels_arr1(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_frame4.txt")

        Dim start_ind_slice1 As Integer = 450
        Dim end_ind_slice1 As Integer = 750
        start_ind_slice1 = 350
        end_ind_slice1 = 695 ' 900

        Dim detlta_curve_polynom1 As Integer = 0



        Dim org_curve1 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, start_ind_slice1, end_ind_slice1)

        Dim curve_ind4 As Integer

        For curve_ind4 = 0 To org_curve1.Count - 1
            Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(org_curve1, curve_ind4)
        Next

        Dim curve_rect1 As Dictionary(Of String, Object) = macros_obj1.find_rect_of_pixels_arr(org_curve1)

        Dim min_y1 As Integer = curve_rect1("min_y1")

        Dim min_y1_cords_arr1 As ArrayList = New ArrayList()

        Dim curve_ind2 As Integer
        Dim start_ind_y_min1 As Integer = -1
        For curve_ind2 = 0 To org_curve1.Count - 1
            Dim cord_xy1b As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(org_curve1, curve_ind2)
            If cord_xy1b(1) = min_y1 Then
                If start_ind_y_min1 = -1 Then
                    start_ind_y_min1 = curve_ind2
                End If
                min_y1_cords_arr1.Add(cord_xy1b(0).ToString() + "," + cord_xy1b(1).ToString())
            End If
        Next
        Dim zero_derivate_cord_ind1 As Integer = start_ind_slice1 + start_ind_y_min1 + min_y1_cords_arr1.Count / 2
        'Dim cord_xy1d As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(org_curve1, zero_derivate_cord_ind1)

        Dim div_curve1 As Integer = 6

        Dim slice_len1 As Integer = (end_ind_slice1 - start_ind_slice1) / div_curve1
        Dim slice_curve_ind1 As ArrayList = New ArrayList()
        Dim i4 As Integer

        While start_ind_slice1 + slice_len1 <= end_ind_slice1
            slice_curve_ind1.Add(start_ind_slice1)
            start_ind_slice1 += slice_len1
        End While

        slice_curve_ind1.Add(zero_derivate_cord_ind1)
        'slice_curve_ind1.Add(end_ind_slice1)

        Dim slice_ind_insert1 As Integer = 0
        Dim to_stop2 As Integer = 0
        If False Then

            While to_stop2 = 0
                If slice_curve_ind1(slice_ind_insert1) < zero_derivate_cord_ind1 And slice_curve_ind1(slice_ind_insert1 + 1) > zero_derivate_cord_ind1 Then
                    to_stop2 = 1
                Else
                    slice_ind_insert1 += 1
                End If
            End While

            slice_curve_ind1.Insert(slice_ind_insert1 + 1, zero_derivate_cord_ind1)
        End If

        If False Then
            slice_curve_ind1.Add(500)
            slice_curve_ind1.Add(620)
            slice_curve_ind1.Add(750)
            slice_curve_ind1.Add(840)
            slice_curve_ind1.Clear()


            slice_curve_ind1.Add(400)
            slice_curve_ind1.Add(400)
            slice_curve_ind1.Add(600)
            slice_curve_ind1.Add(700)
            slice_curve_ind1.Add(800)

        End If
        'slice_curve_ind1.Add(820)
        'Dim curve1 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, 570, 750)
        Dim curve1 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, 550, 700)
        'curve1 = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, 700, 930)
        'Dim curve1 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, 700, 750)
        'Dim curve1 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, 680, 750)
        Dim i3 As Integer
        Dim factor_zoom1 As Double = 1 ' 2.8 '1.9 '2.43

        'Dim factor_zoom2 As Double = 2
        For i3 = 0 To org_curve1.Count - 1
            Dim cord_org_curve_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(org_curve1, i3)
            org_curve1(i3) = (cord_org_curve_xy1(0) * factor_zoom1).ToString() + "," + (cord_org_curve_xy1(1) * factor_zoom1 + detlta_curve_polynom1).ToString()
        Next
        txtbox_degree_two1.Text = "1.182" '"1.565" '"1.157" '"1.565" ' "1.35

        Dim start_x_val1 As Double
        Dim end_x_val1 As Double
        Dim coef_a_val1 As Double
        Dim ave_dist_arr1 As ArrayList = New ArrayList()
        Dim to_stop1 As Integer = 0
        start_x_val1 = -100
        end_x_val1 = -100
        coef_a_val1 = 1
        Dim dict_prm1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
        Dim cord_xy_1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve1, 0)
        Dim cord_xy_2 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve1, 10)
        Dim m1 As Double = -(cord_xy_1(1) - cord_xy_2(1)) / (cord_xy_1(0) - cord_xy_2(0))
        dict_prm1("start_derivate1") = m1 '0.033155596767410436 'm1 '0.10235627616057077 'm1 ' 0.35 ' 0.28978711825879855 ' 0.55 '0.9 ' 1.4640625

        dict_prm1("curve_arr1") = curve1


        If False Then
            dict_prm1("start_derivate1") = 0.00078006514734999194 '0.00078006514734999194
            dict_prm1("x_ind_zero_derivate1") = 100
            Dim dict_res1a As Dictionary(Of String, Object) = polynom_fit_to_curve_by_start_derivate2(dict_prm1)

        End If


        Dim polynoms_arr1 As ArrayList = New ArrayList()

        Dim curve_ind1 As Integer
        Dim last_derivate1 As Double = -1
        Dim start_derivate1 As Double = -1




        Dim last_m1 As Double = 9999
        For curve_ind1 = 0 To 3 'slice_curve_ind1.Count - 2
            Dim start_curve_ind1 As Integer = slice_curve_ind1(curve_ind1)
            Dim end_curve_ind1 As Integer = slice_curve_ind1(curve_ind1 + 1)

            curve1 = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, start_curve_ind1, end_curve_ind1)

            cord_xy_1 = CGlobals1.get_cord_xy_in_pixels_arr1(curve1, 0)
            cord_xy_2 = CGlobals1.get_cord_xy_in_pixels_arr1(curve1, 30)

            If curve_ind1 = 0 Then
                m1 = -(cord_xy_1(1) - cord_xy_2(1)) / (cord_xy_1(0) - cord_xy_2(0))
                'm1 = 0.4
            End If

            Dim start_curve_ind2 As Integer = slice_curve_ind1(curve_ind1 + 1)
            Dim end_curve_ind2 As Integer = slice_curve_ind1(curve_ind1 + 2)

            Dim curve2 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, start_curve_ind2, end_curve_ind2)

            cord_xy_1 = CGlobals1.get_cord_xy_in_pixels_arr1(curve2, 0)
            cord_xy_2 = CGlobals1.get_cord_xy_in_pixels_arr1(curve2, curve2.Count - 1)


            Dim last_derivate2 As Double = -(cord_xy_1(1) - cord_xy_2(1)) / (cord_xy_1(0) - cord_xy_2(0))

            If curve_ind1 = 1 Then
                'm1 = 0.38020806962814818
            End If

            If curve_ind1 = 2 Then
                Dim d1 As Integer = 1
                'm1 = 0.30305451133801686
            End If
            dict_prm1("start_derivate1") = m1 '0.033155596767410436 'm1 '0.10235627616057077 'm1 ' 0.35 ' 0.28978711825879855 ' 0.55 '0.9 ' 1.4640625
            dict_prm1("curve_arr1") = curve1
            dict_prm1("curve_ind1") = curve_ind1
            dict_prm1("last_derivate2") = last_derivate2
            Dim dict_res1 As Dictionary(Of String, Object)
            If end_curve_ind1 = zero_derivate_cord_ind1 Then
                dict_prm1("zero_derivate_at_last_ind1") = "yes"
                dict_res1 = polynom_fit_to_curve_by_start_derivate2(dict_prm1)
            Else
                dict_res1 = polynom_fit_to_curve_by_start_derivate1b(dict_prm1)
                Dim new_end_curve_ind1 As Integer = end_curve_ind1 - 20
                While dict_res1.ContainsKey("error1")
                    new_end_curve_ind1 += 1
                    slice_curve_ind1(curve_ind1 + 1) = new_end_curve_ind1
                    curve1 = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, start_curve_ind1, new_end_curve_ind1)
                    dict_prm1("curve_arr1") = curve1
                    cord_xy_1 = CGlobals1.get_cord_xy_in_pixels_arr1(curve1, 0)
                    cord_xy_2 = CGlobals1.get_cord_xy_in_pixels_arr1(curve1, 6)
                    dict_res1 = polynom_fit_to_curve_by_start_derivate1b(dict_prm1)
                End While
            End If

            'dict_return_res1("polynom_obj1") = last_ok_polynom_obj1
            'dict_return_res1("polynom_start_x_value1") = last_zero_polynom_start_x_value1
            'dict_return_res1("end_derivate1") = last_ok_end_derivate1
            'dict_res1 = polynom_fit_to_curve_by_start_derivate1(dict_prm1)
            Dim polynom_obj2 As CPolynom1 = dict_res1("polynom_obj1")
            'dict_return_res1("last_start_x_val1") = last_start_x_val1
            If False Then

                Dim polynom_curve_arr2 As ArrayList = New ArrayList()
                Dim x_start2 As Double = dict_res1("last_start_x_val1")
                Dim derivate_arr1 As ArrayList = New ArrayList()
                While x_start2 <= dict_res1("last_end_x_val1")


                    Dim temp_polynon2_obj1 As CPolynom1 = New CPolynom1()
                    temp_polynon2_obj1.coef_arr1.Add(dict_res1("last_polynom_coef_a1") * factor_zoom1)
                    temp_polynon2_obj1.coef_arr1.Add(0)
                    temp_polynon2_obj1.two_degree1 = dict_res1("last_polynom_two_degree1")
                    derivate_arr1.Add(temp_polynon2_obj1.get_polynom_derivate_value1(Math.Abs(x_start2)))
                    Dim y_val2 As Double = temp_polynon2_obj1.get_y_polynom_value1(Math.Abs(x_start2))
                    x_start2 += dict_res1("last_step_x_val1")
                    polynom_curve_arr2.Add(CType(1000 + x_start2 * factor_zoom1, Integer).ToString() + "," + CType(1000 + y_val2, Integer).ToString())
                End While
                Dim bmp_polynom_curve2 As Bitmap = CGlobals1.create_fill_bitmap(5000, 5000, Color.FromArgb(255, 255, 255))
                markingfldimg_obj1.set_pixel_arr_on_bmp2(polynom_curve_arr2, bmp_polynom_curve2, Color.FromArgb(100, 60, 120))
                'markingfldimg_obj1.set_color_with_sqr_size_from_arr1(bmp_polynom_curve2, polynom_curve_arr2)
                bmp_polynom_curve2.Save(CGlobals1.global_path1 + "sobel_pics1\curve_polynom_" + curve_ind1.ToString() + ".bmp")
                'dict_polynom_data1("polynom_obj2") = polynom_obj2
                'polynoms_arr1.Add(dict_polynom_data1)
                Dim start_derivate2a As Double = polynom_obj2.get_polynom_derivate_value1(Math.Abs(dict_res1("last_start_x_val1")))

            End If

            m1 = dict_res1("end_derivate1")
            'If last_m1 <> start_derivate2a Then
            Dim err2 As Integer = 2
            'End If
            last_m1 = m1
        Next

        Dim polynom_ind1 As Integer
        Dim bmp1r As Bitmap = CGlobals1.create_fill_bitmap(4000, 3000, Color.FromArgb(255, 255, 255))
        Dim last_y_val1 As Double = -1
        Dim last_true_derivate1 As Double = -1

        For polynom_ind1 = 0 To polynoms_arr1.Count - 1
            Dim dict_polynom_data1 As Dictionary(Of String, Object) = polynoms_arr1(polynom_ind1)
            Dim cur_polynom_obj1 As CPolynom1 = dict_polynom_data1("polynom_obj2")
            cur_polynom_obj1.coef_arr1(0) = cur_polynom_obj1.coef_arr1(0) * factor_zoom1
            Dim start_cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1, slice_curve_ind1(polynom_ind1))
            Dim end_cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1, slice_curve_ind1(polynom_ind1 + 1))
            Dim last_start_x_val1 As Double = dict_polynom_data1("last_start_x_val1")
            Dim last_end_x_val1 As Double = dict_polynom_data1("last_end_x_val1")

            Dim last_start_y_val1 As Double = dict_polynom_data1("last_start_y_val1")
            Dim last_step_x_val1 As Double = dict_polynom_data1("last_step_x_val1")
            CGlobals1.draw_sqr_around_pixels2(bmp1r, start_cord_xy1(0), start_cord_xy1(1) - 10, 3, Color.FromArgb(200, 60, 100))
            Dim x_ind2 As Integer
            Dim x_val_polynom1 As Double = last_start_x_val1
            Dim len1 As Integer = end_cord_xy1(0) - start_cord_xy1(0)
            Dim len2 As Integer = (end_cord_xy1(0) - start_cord_xy1(0)) * factor_zoom1
            'len2 = 0
            Dim step_x_val2 As Double = (last_end_x_val1 - last_start_x_val1) / (len2 + 1)
            Dim x_1 As Double = last_start_x_val1
            Dim x_2 As Double = x_1 + step_x_val2 * CType((len2 + 1), Double)
            start_derivate1 = cur_polynom_obj1.get_polynom_derivate_value1(Math.Abs(x_val_polynom1))
            If last_true_derivate1 <> -1 Then
                If last_true_derivate1 <> start_derivate1 Then
                    Dim diff_derivate1 As Double = last_true_derivate1 - start_derivate1
                    Dim err1 As Integer = 2
                End If
            End If
            If last_derivate1 <> start_derivate1 * 2 Then
                Dim err1 As Integer = 2
            End If
            Dim derivate_arr1 As ArrayList = New ArrayList()
            Dim start_cord_x1 As Integer = start_cord_xy1(0) * factor_zoom1
            Dim start_cord_y1 As Integer = start_cord_xy1(1) * factor_zoom1
            For x_ind2 = 0 To len2 '(len1) * factor_zoom1
                Dim y_val_polynom1 As Double = cur_polynom_obj1.get_y_polynom_value1(Math.Abs(x_val_polynom1))
                x_val_polynom1 += step_x_val2 ' last_step_x_val1 / factor_zoom1
                bmp1r.SetPixel(start_cord_x1 + x_ind2, start_cord_y1 + y_val_polynom1 - last_start_y_val1 * factor_zoom1, Color.FromArgb(255, 20, 20))
                last_y_val1 = start_cord_xy1(1) + y_val_polynom1
                'bmp1r.SetPixel(start_cord_xy1(0) + x_ind2, start_cord_xy1(1) + y_val_polynom1, Color.FromArgb(255, 20, 20))
                'last_derivate1 = cur_polynom_obj1.get_polynom_derivate_value1(Math.Abs(x_val_polynom1))
                derivate_arr1.Add(cur_polynom_obj1.get_polynom_derivate_value1(Math.Abs(x_val_polynom1)))
            Next

            last_true_derivate1 = cur_polynom_obj1.get_polynom_derivate_value1(Math.Abs(last_end_x_val1))
            'last_true_derivate1 = cur_polynom_obj1.get_polynom_derivate_value1(Math.Abs(x_val_polynom1))
            Dim delte_end1 As Double = x_val_polynom1 - last_end_x_val1

            Dim cur_last_derivate1 As Double = cur_polynom_obj1.get_polynom_derivate_value1(Math.Abs(x_val_polynom1))
            If last_derivate1 <> cur_last_derivate1 Then
                Dim err1 As Integer = 1
            End If

            last_derivate1 = cur_last_derivate1

            Dim d1 As Integer = 1
        Next
        markingfldimg_obj1.set_pixel_arr_on_bmp2(org_curve1, bmp1r, Color.FromArgb(10, 40, 200))

        bmp1r.Save(CGlobals1.global_path1 + "sobel_pics1\res_curve1.bmp")

        'סוף קירוב עקומה
        Return 1

    End Function




    Public Function analize_polynom1()



        Dim polynom_curve_obj1 As CPolynom_curve1 = New CPolynom_curve1()


        'polynom_curve_obj1.find_turn_pixels_points()
        'polynom_curve_obj1.find_first_turn_pixel_point1(1)
        'polynom_curve_obj1.find_first_turn_pixel_point1(2)
        'Return 1




        'Public suffix_path_arr1 As String() = {"_front_top_0_frame1", "_front_top_1_frame1", "_front_top_2_frame1", "_front_right_1_frame1", "_front_right_2_frame1", "_front_bottom_1_frame1", "_front_bottom_2_frame1", "_front_bottom_3_frame1", "_front_bottom_4_frame1"}



        'For curve_ind1 = 7 To 8
        For curve_ind1 = 8 To 8


            polynom_curve_obj1 = New CPolynom_curve1()
            'polynom_curve_obj1.analize_polynom2()
            lbl_progress1.Text = "polynom_num=" + curve_ind1.ToString()
            Application.DoEvents()
            polynom_curve_obj1.suffix_path1 = polynom_curve_obj1.suffix_path_arr1(inds_orders_arr1(curve_ind1))

            polynom_curve_obj1.create_polynom_from_curve1()

        Next


        Return 1
        'polynom_curve_obj1.analize_polynom1_right_corner()
        'polynom_curve_obj1.analize_polynom1()
        'polynom_curve_obj1.analize_polynom2()
        Return 1
        Dim init_poynom_obj1 As CPolynom2 = New CPolynom2()
        init_poynom_obj1.coef_arr1.Add(0)
        init_poynom_obj1.coef_arr1.Add(0)
        'init_poynom_obj1.coef_arr1.Add(0.000001)
        'init_poynom_obj1.coef_arr1.Add(0.000001)
        init_poynom_obj1.coef_arr1.Add(0.001)
        init_poynom_obj1.coef_arr1.Add(0.001)
        init_poynom_obj1.create_derivative1()
        Dim curve_pxls_arr1 As ArrayList = New ArrayList()
        Dim frame_pixels_arr1 As ArrayList = markingfldimg_obj1.load_2d_pixels_arr1(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_frame4.txt")
        Dim last_ind1 As Integer = 500
        curve_pxls_arr1 = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, 400, last_ind1)
        'curve_pxls_arr1 = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, 600, 700)
        'curve_pxls_arr1 = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, 700, 750)
        Dim cord_xy_start1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, curve_pxls_arr1.Count - 10)
        Dim cord_xy_end1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, curve_pxls_arr1.Count - 1)

        Dim m1 As Double = -(cord_xy_start1(1) - cord_xy_end1(1)) / (cord_xy_start1(0) - cord_xy_end1(0))
        'm1 = 0.3
        Dim dict_res1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
        dict_res1("error1") = "yes"
        Dim minus_m1 As Double = 0.01
        While dict_res1.ContainsKey("error1")

            'last_ind1 -= 1
            curve_pxls_arr1 = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, 400, last_ind1)
            'curve_pxls_arr1 = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, 600, 700)
            'curve_pxls_arr1 = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, 700, 750)
            cord_xy_start1 = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, curve_pxls_arr1.Count - 10)
            cord_xy_end1 = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, curve_pxls_arr1.Count - 1)

            cord_xy_start1 = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, 0)
            cord_xy_end1 = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, 40)

            m1 = -(cord_xy_start1(1) - cord_xy_end1(1)) / (cord_xy_start1(0) - cord_xy_end1(0))
            'm1 -= 0.09

            m1 -= minus_m1
            minus_m1 += 0.001
            dict_res1 = polynom_curve_obj1.find_polynom_coefs1(init_poynom_obj1, m1, 99, curve_pxls_arr1, "find_start_x_val_more_then_width1", Nothing)
            init_poynom_obj1 = dict_res1("polynom_obj1")


            cord_xy_start1 = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, curve_pxls_arr1.Count - 10)
            cord_xy_end1 = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, curve_pxls_arr1.Count - 1)
            Dim m1_end As Double = -(cord_xy_start1(1) - cord_xy_end1(1)) / (cord_xy_start1(0) - cord_xy_end1(0))

            dict_res1 = polynom_curve_obj1.find_polynom_coefs1(init_poynom_obj1, m1, 99, curve_pxls_arr1, "only_start_derivate1", Nothing)

        End While




        'polynom_curve_obj1.find_polynom_coefs1(init_poynom_obj1, 0.21052631578947367, 99, curve_pxls_arr1, "only_start_derivate1")
        '
        polynom_curve_obj1.find_polynom_coefs1(init_poynom_obj1, 0.061900946837172108, 99, curve_pxls_arr1, "only_start_derivate1", Nothing)

        polynom_curve_obj1.init_polynom_by_min_x1(80, 0.4)

        Dim polynom_obj1 As CPolynom2 = New CPolynom2()
        polynom_obj1.coef_arr1.Add(0)
        polynom_obj1.coef_arr1.Add(0)
        polynom_obj1.coef_arr1.Add(0.0001)
        polynom_obj1.coef_arr1.Add(0.0005)

        polynom_obj1.create_derivative1()
        Dim start_x_val1 As Double = polynom_obj1.find_x_by_derivative_val(0.5)
        Dim y_val1 As Double = polynom_obj1.get_y_val1(start_x_val1)
        Dim y_val2 As Double = polynom_obj1.get_y_val1(start_x_val1 - 7)
        Dim delta_y1 As Double = y_val1 - y_val2

        polynom_obj1.coef_arr1.Clear()
        polynom_obj1.coef_arr1.Add(0)
        polynom_obj1.coef_arr1.Add(0)
        polynom_obj1.coef_arr1.Add(0.00033)
        polynom_obj1.coef_arr1.Add(0.00021)
        polynom_obj1.create_derivative1()


        Dim start_x_val1b As Double = polynom_obj1.find_x_by_derivative_val(0.5)
        Dim y_val1b As Double = polynom_obj1.get_y_val1(start_x_val1b)
        Dim y_val2b As Double = polynom_obj1.get_y_val1(start_x_val1b - 7)
        Dim delta_y1b As Double = y_val1b - y_val2b



    End Function
    Private Sub Polynomfit1ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles Polynomfit1ToolStripMenuItem.Click
        'analize_polynom2()
        analize_polynom1()
        Return
        aproximation_curve_to_multi_polynoms()
        Return
        Dim frame_pixels_arr1 As ArrayList = markingfldimg_obj1.load_2d_pixels_arr1(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_frame4.txt")
        Dim slice_curve_ind1 As ArrayList = New ArrayList()
        slice_curve_ind1.Add(500)
        slice_curve_ind1.Add(620)
        slice_curve_ind1.Add(750)
        slice_curve_ind1.Add(840)

        'Dim curve1 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, 570, 750)
        Dim curve1 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, 550, 800)
        'Dim curve1 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, 700, 750)
        'Dim curve1 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, 680, 750)
        Dim org_curve1 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, 500, 840)
        Dim i3 As Integer
        Dim factor_zoom1 As Double = 2.43

        'Dim factor_zoom2 As Double = 2
        For i3 = 0 To org_curve1.Count - 1
            Dim cord_org_curve_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(org_curve1, i3)
            org_curve1(i3) = (cord_org_curve_xy1(0) * factor_zoom1).ToString() + "," + (cord_org_curve_xy1(1) * factor_zoom1 + 3).ToString()
        Next
        txtbox_degree_two1.Text = "1.182" '"1.565" '"1.157" '"1.565" ' "1.35

        Dim start_x_val1 As Double
        Dim end_x_val1 As Double
        Dim coef_a_val1 As Double
        Dim ave_dist_arr1 As ArrayList = New ArrayList()
        Dim to_stop1 As Integer = 0
        start_x_val1 = -100
        end_x_val1 = -100
        coef_a_val1 = 1
        Dim dict_prm1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
        Dim cord_xy_1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve1, 0)
        Dim cord_xy_2 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve1, 10)
        Dim m1 As Double = -(cord_xy_1(1) - cord_xy_2(1)) / (cord_xy_1(0) - cord_xy_2(0))
        dict_prm1("start_derivate1") = m1 '0.033155596767410436 'm1 '0.10235627616057077 'm1 ' 0.35 ' 0.28978711825879855 ' 0.55 '0.9 ' 1.4640625
        dict_prm1("curve_arr1") = curve1
        Dim polynoms_arr1 As ArrayList = New ArrayList()

        Dim curve_ind1 As Integer
        For curve_ind1 = 0 To slice_curve_ind1.Count - 2
            Dim start_curve_ind1 As Integer = slice_curve_ind1(curve_ind1)
            Dim end_curve_ind1 As Integer = slice_curve_ind1(curve_ind1 + 1)
            curve1 = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, start_curve_ind1, end_curve_ind1)

            cord_xy_1 = CGlobals1.get_cord_xy_in_pixels_arr1(curve1, 0)
            cord_xy_2 = CGlobals1.get_cord_xy_in_pixels_arr1(curve1, 10)
            If curve_ind1 = 0 Then
                m1 = -(cord_xy_1(1) - cord_xy_2(1)) / (cord_xy_1(0) - cord_xy_2(0))

            End If
            dict_prm1("start_derivate1") = m1 '0.033155596767410436 'm1 '0.10235627616057077 'm1 ' 0.35 ' 0.28978711825879855 ' 0.55 '0.9 ' 1.4640625
            dict_prm1("curve_arr1") = curve1
            Dim dict_res1 As Dictionary(Of String, Object) = polynom_fit_to_curve_by_start_derivate1(dict_prm1)
            Dim polynom_obj2 As CPolynom1 = New CPolynom1()
            polynom_obj2.coef_arr1.Add(dict_res1("last_polynom_coef_a1"))
            polynom_obj2.coef_arr1.Add(0)
            polynom_obj2.two_degree1 = dict_res1("last_polynom_two_degree1")
            'dict_return_res1("last_step_x_val1") = last_step_x_val1
            'dict_return_res1("last_start_x_val1") = last_start_x_val1
            Dim dict_polynom_data1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
            dict_polynom_data1("last_step_x_val1") = dict_res1("last_step_x_val1")
            dict_polynom_data1("last_start_x_val1") = dict_res1("last_start_x_val1")
            dict_polynom_data1("last_start_y_val1") = dict_res1("last_start_y_val1")

            dict_polynom_data1("polynom_obj2") = polynom_obj2
            polynoms_arr1.Add(dict_polynom_data1)


            m1 = dict_res1("end_derivate1")
        Next

        Dim polynom_ind1 As Integer
        Dim bmp1r As Bitmap = CGlobals1.create_fill_bitmap(4000, 3000, Color.FromArgb(255, 255, 255))
        Dim last_y_val1 As Double = -1
        For polynom_ind1 = 0 To polynoms_arr1.Count - 1
            Dim dict_polynom_data1 As Dictionary(Of String, Object) = polynoms_arr1(polynom_ind1)
            Dim cur_polynom_obj1 As CPolynom1 = dict_polynom_data1("polynom_obj2")
            cur_polynom_obj1.coef_arr1(0) = cur_polynom_obj1.coef_arr1(0) * factor_zoom1
            Dim start_cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1, slice_curve_ind1(polynom_ind1))
            Dim end_cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1, slice_curve_ind1(polynom_ind1 + 1))
            Dim last_start_x_val1 As Double = dict_polynom_data1("last_start_x_val1")
            Dim last_start_y_val1 As Double = dict_polynom_data1("last_start_y_val1")
            Dim last_step_x_val1 As Double = dict_polynom_data1("last_step_x_val1")

            Dim x_ind2 As Integer
            Dim x_val_polynom1 As Double = last_start_x_val1
            Dim len1 As Integer = end_cord_xy1(0) - start_cord_xy1(0)
            For x_ind2 = 0 To len1 * factor_zoom1
                Dim y_val_polynom1 As Double = cur_polynom_obj1.get_y_polynom_value1(Math.Abs(x_val_polynom1))
                x_val_polynom1 += last_step_x_val1 / factor_zoom1
                bmp1r.SetPixel(start_cord_xy1(0) * factor_zoom1 + x_ind2, start_cord_xy1(1) * factor_zoom1 + y_val_polynom1 - last_start_y_val1 * factor_zoom1, Color.FromArgb(255, 20, 20))
                last_y_val1 = start_cord_xy1(1) + y_val_polynom1
                'bmp1r.SetPixel(start_cord_xy1(0) + x_ind2, start_cord_xy1(1) + y_val_polynom1, Color.FromArgb(255, 20, 20))
            Next

            Dim d1 As Integer = 1
        Next
        markingfldimg_obj1.set_pixel_arr_on_bmp2(org_curve1, bmp1r, Color.FromArgb(10, 40, 200))

        bmp1r.Save(CGlobals1.global_path1 + "sobel_pics1\curve_res1.bmp")

        'סוף קירוב עקומה
        Return
        '0.28978711825879855
        Dim err1 As Integer = 1
        Dim dir_coef1 As Double = 1
        Dim mul_coef1 As Double = 0.01
        Dim to_stop1_search_polynom As Integer = 0
        Dim last_err1 As Integer = 1
        While to_stop1_search_polynom = 0
            err1 = 0
            Try

                polynom_fit_to_curve_by_start_derivate1(dict_prm1)
                last_err1 = 0
            Catch ex As Exception
                'MessageBox.Show("err")

                err1 = 1
                txtbox_coef1.Text = (Double.Parse(txtbox_coef1.Text) - dir_coef1 * mul_coef1).ToString()
                'mul_coef1 /= 2
                If last_err1 = 0 Then
                    mul_coef1 /= 2
                End If
                last_err1 = 1

            End Try
            If err1 = 0 Then
                If txtbox_coef1.Text <> "" Then
                    txtbox_coef1.Text = (Double.Parse(txtbox_coef1.Text) + dir_coef1 * mul_coef1).ToString()
                End If

            End If
            If err1 = 0 Then
                'to_stop1_search_polynom = 1
            End If
            Try
                If Double.Parse(txtbox_ave_dist_curve_to_polynom1.Text) < 0.95 Then
                    to_stop1_search_polynom = 1
                End If

            Catch ex As Exception

            End Try
        End While

        Return
        While to_stop1 = 0
            start_x_val1 += 1

            If start_x_val1 >= -20 Then
                start_x_val1 = -50
                coef_a_val1 += 0.1
            End If
            CGlobals1.global_vars_dict1("start_x_polynom1") = start_x_val1
            CGlobals1.global_vars_dict1("end_x_polynom1") = end_x_val1
            Dim dict_res1 As Dictionary(Of String, Object) = get_curve_dist1(600, 700, 0.46406250000000071, coef_a_val1)
            ave_dist_arr1.Add(dict_res1("average_dist1"))
            If Math.Abs(dict_res1("average_dist1")) <= 1 Then
                Dim end_derivare1 As Double = dict_res1("end_derivate1")
                to_stop1 = 1
            End If

        End While

        While to_stop1 = 0
            end_x_val1 += 1

            If end_x_val1 >= -1 Then
                end_x_val1 = -100
                start_x_val1 += 1
            End If
            CGlobals1.global_vars_dict1("start_x_polynom1") = start_x_val1
            CGlobals1.global_vars_dict1("end_x_polynom1") = end_x_val1
            Dim dict_res1 As Dictionary(Of String, Object) = get_curve_dist1(600, 700, 0.46406250000000071, 1)
            ave_dist_arr1.Add(dict_res1("average_dist1"))
            If Math.Abs(dict_res1("average_dist1")) <= 1 Then
                Dim end_derivare1 As Double = dict_res1("end_derivate1")
                to_stop1 = 1
            End If

        End While





        Dim i1 As Integer
        Dim mul_factor1 As Double = 1
        For i1 = 0 To curve1.Count - 1
            Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve1, i1)
            'curve1(i1) = (cord_xy1(0) * mul_factor1).ToString() + "," + (cord_xy1(1) * mul_factor1).ToString()
        Next




        Dim dict_rect1 As Dictionary(Of String, Object) = macros_obj1.find_rect_of_pixels_arr(curve1)
        'dict_rect1("min_x1") = min_x1
        'dict_rect1("max_x1") = max_x1
        'dict_rect1("min_y1") = min_y1
        'dict_rect1("max_y1") = max_y1

        'dict_rect1("min_x_ind1") = min_x_ind1
        'dict_rect1("max_x_ind1") = max_x_ind1
        'dict_rect1("min_y_ind1") = min_y_ind1
        'dict_rect1("max_y_ind1") = max_y_ind1

        Dim img_height1 As Integer = 2000
        Dim img_width1 As Integer = 3000
        Dim bmp1 As Bitmap = CGlobals1.create_fill_bitmap(img_width1, img_height1, Color.FromArgb(255, 255, 255))

        Dim padding2 As Integer = 5

        Dim cord_xy1a As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve1, 0)

        Dim cord_y_pos1a As Integer = (cord_xy1a(1) - dict_rect1("min_y1"))
        Dim delta_y1 As Integer = 1999 - cord_y_pos1a
        Dim max_x_pos1 As Integer = -1
        Dim first_xy_cord_curve1 As Integer() = New Integer() {0, 0}
        Dim last_xy_cord_curve1 As Integer() = New Integer() {0, 0}
        Dim curve_pos_arr1 As ArrayList = New ArrayList()

        For i1 = 0 To curve1.Count - 1
            Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve1, i1)
            Dim cord_x_pos1 As Integer = (cord_xy1(0) - dict_rect1("min_x1"))
            Dim cord_y_pos1 As Integer = (cord_xy1(1) - dict_rect1("min_y1")) + delta_y1

            If i1 = 0 Then
                first_xy_cord_curve1 = New Integer() {cord_x_pos1, cord_y_pos1}
            End If
            If i1 = curve1.Count - 1 Then
                last_xy_cord_curve1 = New Integer() {cord_x_pos1, cord_y_pos1}
            End If
            If cord_x_pos1 > 0 + padding2 And cord_x_pos1 < bmp1.Width - 1 - padding2 And cord_y_pos1 > 0 + padding2 And cord_y_pos1 < bmp1.Height - 1 - padding2 Then
                'CGlobals1.draw_sqr_around_pixels2(bmp1, cord_x_pos1, cord_y_pos1, 2, Color.FromArgb(0, 0, 0))
                CGlobals1.draw_sqr_around_pixels2(bmp1, cord_x_pos1, cord_y_pos1, 2, Color.FromArgb(0, 0, 0))

            End If
            curve_pos_arr1.Add(cord_x_pos1.ToString() + "," + cord_y_pos1.ToString())
            If max_x_pos1 < cord_x_pos1 Then
                max_x_pos1 = cord_x_pos1
            End If

        Next
        If CGlobals1.global_vars_dict1.ContainsKey("end_x_polynom1") = False Then
            CGlobals1.global_vars_dict1("end_x_polynom1") = -5
        End If
        If CGlobals1.global_vars_dict1.ContainsKey("start_x_polynom1") = False Then
            CGlobals1.global_vars_dict1("start_x_polynom1") = -30
        End If
        Dim start_x1 As Double = CGlobals1.global_vars_dict1("start_x_polynom1")
        Dim end_x1 As Double = CGlobals1.global_vars_dict1("end_x_polynom1")
        If end_x1 <= start_x1 Then
            end_x1 = start_x1 + 1

            CGlobals1.global_vars_dict1("start_x_polynom1") = start_x1
            CGlobals1.global_vars_dict1("end_x_polynom1") = end_x1
        End If
        Dim x1 As Double
        Dim y1 As Integer
        Dim curve_obj1 As CCurve1 = New CCurve1()


        Dim polynon_curve_pxl_arr1 As ArrayList
        Dim first_xy_cord_polynom1 As Integer()
        Dim last_xy_cord_polynom1 As Integer()
        Dim coef1 As Double = -3
        Dim dir_coef_add1 As Double = -1
        Dim dir_coef_add_factor1 As Double = 1
        Dim to_stop_tunning_polynom1 As Integer = 0
        Dim last_diff_x1 As Double = 9999
        Dim last_diff_y1 As Double = 9999

        Dim polynom_obj1 As CPolynom1 = New CPolynom1()

        Dim coef_a1 As Double = 0.1
        Dim add_coef_a1 As Double = 0.1
        Dim dir_add_coef_a1 As Double = 1
        Dim last_delta_height_poly_and_curve1 = -1

        While to_stop_tunning_polynom1 = 0


            polynom_obj1.coef_arr1 = New ArrayList()


            polynom_obj1.polynom_name1 = "1"
            polynom_obj1.coef_arr1.Add(-coef_a1)
            polynom_obj1.coef_arr1.Add(0)
            Dim polynom_first_y_val1 As Double = polynom_obj1.get_y_polynom_value1(start_x1)
            Dim polynom_last_y_val1 As Double = polynom_obj1.get_y_polynom_value1(end_x1)
            Dim delta_height_poly_and_curve1 As Double = Math.Abs(Math.Abs(polynom_first_y_val1 - polynom_last_y_val1) - Math.Abs(first_xy_cord_curve1(1) - last_xy_cord_curve1(1)))
            If delta_height_poly_and_curve1 > 1 Then

                If last_delta_height_poly_and_curve1 = -1 Then
                    coef_a1 += add_coef_a1 * dir_add_coef_a1
                Else
                    If last_delta_height_poly_and_curve1 > delta_height_poly_and_curve1 Then

                    Else
                        dir_add_coef_a1 = -dir_add_coef_a1
                        add_coef_a1 /= 2
                    End If
                    coef_a1 += add_coef_a1 * dir_add_coef_a1
                End If
            Else
                to_stop_tunning_polynom1 = 1
            End If

            last_delta_height_poly_and_curve1 = delta_height_poly_and_curve1

        End While

        'polynon_curve_pxl_arr1 = curve_obj1.create_polynom_curve_pxl_arr2(start_x1, end_x1, img_width1, curve1.Count, -coef_a1)
        'polynon_curve_pxl_arr1 = curve_obj1.create_polynom_curve_pxl_arr2(start_x1, end_x1, img_width1, max_x_pos1, -coef_a1)
        polynon_curve_pxl_arr1 = curve_obj1.create_polynom_curve_pxl_arr2(start_x1, end_x1, img_width1, max_x_pos1, -coef_a1)

        textbox_start_derivate1.Text = polynom_obj1.get_polynom_derivate_value1(start_x1)
        textbox_end_derivate1.Text = polynom_obj1.get_polynom_derivate_value1(end_x1)
        While to_stop_tunning_polynom1 = 1 And False
            polynon_curve_pxl_arr1 = curve_obj1.create_polynom_curve_pxl_arr2(start_x1, end_x1, img_width1, curve1.Count, coef1)
            first_xy_cord_polynom1 = CGlobals1.get_cord_xy_in_pixels_arr1(polynon_curve_pxl_arr1, 0)
            last_xy_cord_polynom1 = CGlobals1.get_cord_xy_in_pixels_arr1(polynon_curve_pxl_arr1, polynon_curve_pxl_arr1.Count - 1)
            Dim cur_diff_x1 As Double = Math.Abs(last_xy_cord_polynom1(0) - last_xy_cord_curve1(0))
            Dim cur_diff_y1 As Double = Math.Abs(last_xy_cord_polynom1(1) - (img_height1 - last_xy_cord_curve1(1))) + Math.Abs(first_xy_cord_polynom1(1) - (img_height1 - first_xy_cord_curve1(1)))
            If last_diff_y1 < cur_diff_y1 Then
                dir_coef_add1 *= -1
                dir_coef_add_factor1 /= 2
            End If
            last_diff_y1 = cur_diff_y1
            If cur_diff_x1 > 1 Or cur_diff_y1 > 1 Then
                coef1 -= dir_coef_add1 * dir_coef_add_factor1

            Else
                to_stop_tunning_polynom1 = 1
            End If

        End While
        txtbox_coef1.Text = coef_a1.ToString()
        'MessageBox.Show(coef1.ToString())
        'Dim polynon_curve_pxl_arr1 As ArrayList = curve_obj1.create_polynom_curve_pxl_arr1(start_x1, end_x1, img_width1, max_x_pos1)
        Dim max_y1 As Double = -99999
        Dim min_y1 As Double = 99999
        Dim y_vals_arr1 As ArrayList = New ArrayList()
        Dim x_vals_arr1 As ArrayList = New ArrayList()

        Dim x_ind1 As Integer = 0

        'PictureBox1.Image = zoom_img1(bmp1, 4)

        'Return
        Dim average_dist1 As Double = 0
        Dim polynom_pos_arr1 As ArrayList = New ArrayList()
        For ind_x1 = 0 To polynon_curve_pxl_arr1.Count - 2 ' img_width1 - 1

            'Next
            Dim cord_xy1 As Double() = CGlobals1.get_double_cord_xy_in_pixels_arr2(polynon_curve_pxl_arr1, ind_x1)
            Dim y_pos_pixel1 As Double = (img_height1 - cord_xy1(1))
            Dim x_val1 As Integer = cord_xy1(0)
            Dim padding1 As Integer = 5
            'If x_val1 >= 0 + padding1 And x_val1 <= bmp1.Width - 1 - padding1 And y_pos_pixel1 >= 0 + padding1 And y_pos_pixel1 <= bmp1.Height - 1 - padding1 Then
            'CGlobals1.draw_sqr_around_pixels2(bmp1, cord_xy1(0), y_pos_pixel1, 1, Color.FromArgb(255, 50, 0))

            'End If

            If ind_x1 >= 0 + padding1 And ind_x1 <= bmp1.Width - 1 - padding1 And y_pos_pixel1 >= 0 + padding1 And y_pos_pixel1 <= bmp1.Height - 1 - padding1 Then
                CGlobals1.draw_sqr_around_pixels2(bmp1, ind_x1, y_pos_pixel1, 1, Color.FromArgb(255, 50, 0))

                Dim cord_xy_curve1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pos_arr1, ind_x1)
                average_dist1 += (y_pos_pixel1 - cord_xy_curve1(1))
            End If
            polynom_pos_arr1.Add(ind_x1.ToString() + "," + y_pos_pixel1.ToString())


            'x1 += (end_x1 - start_x1) / img_width1

        Next

        Dim rect_dict1 As Dictionary(Of String, Object) = macros_obj1.find_rect_of_pixels_arr(curve_pos_arr1)
        Dim rect_dict2 As Dictionary(Of String, Object) = macros_obj1.find_rect_of_pixels_arr(polynom_pos_arr1)

        average_dist1 /= polynon_curve_pxl_arr1.Count
        txtbox_ave_dist_curve_to_polynom1.Text = average_dist1.ToString()
        'For x1 = start_x1 To end_x1
        PictureBox1.Image = zoom_img1(bmp1, 4)
    End Sub

    Private Sub add_end_x_polynom1_Click(sender As Object, e As EventArgs) Handles add_end_x_polynom1.Click
        CGlobals1.global_vars_dict1("end_x_polynom1") += CGlobals1.poly_dec_add_range_factor1
        Polynomfit1ToolStripMenuItem_Click(Nothing, Nothing)
        txtbox_end_x_polynom1.Text = CGlobals1.global_vars_dict1("end_x_polynom1").ToString()
        txtbox_start_x_polynom1.Text = CGlobals1.global_vars_dict1("start_x_polynom1").ToString()
    End Sub

    Private Sub dec_end_x_polynom1_Click(sender As Object, e As EventArgs) Handles dec_end_x_polynom1.Click
        CGlobals1.global_vars_dict1("end_x_polynom1") -= CGlobals1.poly_dec_add_range_factor1
        Polynomfit1ToolStripMenuItem_Click(Nothing, Nothing)
        txtbox_end_x_polynom1.Text = CGlobals1.global_vars_dict1("end_x_polynom1").ToString()
        txtbox_start_x_polynom1.Text = CGlobals1.global_vars_dict1("start_x_polynom1").ToString()

    End Sub

    Private Sub add_start_x_polynom1_Click(sender As Object, e As EventArgs) Handles add_start_x_polynom1.Click
        CGlobals1.global_vars_dict1("start_x_polynom1") += CGlobals1.poly_dec_add_range_factor1
        Polynomfit1ToolStripMenuItem_Click(Nothing, Nothing)
        txtbox_end_x_polynom1.Text = CGlobals1.global_vars_dict1("end_x_polynom1").ToString()
        txtbox_start_x_polynom1.Text = CGlobals1.global_vars_dict1("start_x_polynom1").ToString()
    End Sub

    Private Sub dec_start_x_polynom1_Click(sender As Object, e As EventArgs) Handles dec_start_x_polynom1.Click
        CGlobals1.global_vars_dict1("start_x_polynom1") -= CGlobals1.poly_dec_add_range_factor1
        Polynomfit1ToolStripMenuItem_Click(Nothing, Nothing)
        txtbox_end_x_polynom1.Text = CGlobals1.global_vars_dict1("end_x_polynom1").ToString()
        txtbox_start_x_polynom1.Text = CGlobals1.global_vars_dict1("start_x_polynom1").ToString()

    End Sub

    Private Sub ReplaceCurveWithPolynom1ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ReplaceCurveWithPolynom1ToolStripMenuItem.Click

        Dim frame_pixels_arr1 As ArrayList = CGlobals1.form_obj1.markingfldimg_obj1.load_2d_pixels_arr1(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_frame4.txt")

        Dim polynom_curve1 As ArrayList = CGlobals1.form_obj1.markingfldimg_obj1.load_double_2d_pixels_arr1(CGlobals1.global_path1 + "980376340\polynom_curve_16112022_1\polynom_curve1.txt")

        Dim curve_start_ind1 As Integer = Integer.Parse(System.IO.File.ReadAllText(CGlobals1.global_path1 + "980376340\polynom_curve_16112022_1\curve_start_ind1.txt").ToString())
        Dim curve_last_ind1 As Integer = Integer.Parse(System.IO.File.ReadAllText(CGlobals1.global_path1 + "980376340\polynom_curve_16112022_1\curve_last_ind1.txt").ToString())

        Dim polynom_curve_obj1 As CPolynom_curve1 = New CPolynom_curve1()
        Dim dict_res1 As Dictionary(Of String, Object)
        polynom_curve_obj1.replace_slice_of_curve_with_polynom_curve1(frame_pixels_arr1, curve_start_ind1, curve_last_ind1, polynom_curve1)
    End Sub

    Private Sub Printpolynoms1ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles Printpolynoms1ToolStripMenuItem.Click




        Dim polynom_curve_obj1 As CPolynom_curve1 = New CPolynom_curve1()
        'polynom_curve_obj1.analize_polynom2()

        polynom_curve_obj1.draw_polynoms1()
    End Sub
End Class
