﻿Public Class CSobel1

    Public dict_mono_colors2 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)

    Public Function do_sobel_oparator1(bmp1 As Bitmap, path_of_sobel_res1 As String)


        Dim dict_sobel_val1 As Dictionary(Of Integer, Double) = New Dictionary(Of Integer, Double)
        Dim dict_sobel_val2 As Dictionary(Of Double, Integer) = New Dictionary(Of Double, Integer)
        Dim dict_sobel_val_pixels1 As Dictionary(Of String, Double) = New Dictionary(Of String, Double)
        Dim x1 As Integer
        Dim y1 As Integer
        Dim bmp2 As Bitmap = New Bitmap(bmp1.Width, bmp1.Height)
        Dim sobal_size1 As Integer = 7
        Dim ind1 As Integer = 0
        Dim max_sobel As Double = 0
        Dim sobel_vals_str1 As System.Text.StringBuilder = New System.Text.StringBuilder()

        Dim not_relevant1 As Integer = 1

        For x1 = 0 + sobal_size1 To bmp1.Width - 1 - sobal_size1

            If x1 Mod 10 = 0 Then
                CGlobals1.update_label_progress("step1(sobel compute):" + ((x1 / bmp1.Width * 100.0).ToString() + "      ").Substring(0, 5) + "%")
            End If
            For y1 = 0 + sobal_size1 To bmp1.Height - 1 - sobal_size1


                Dim sobel_val1a As Double = -1
                Dim sobel_val1b As Double = -1
                Dim sobel_val1 As Double = -1

                If True Then
                    Dim sobel_val1_1 As Double = get_sobel_value1(bmp1, x1, y1)
                    Dim sobel_val1_2 As Double = get_sobel_value2(bmp1, x1, y1)
                    Dim sobel_val1_3 As Double = get_sobel_value3(bmp1, x1, y1)
                    Dim sobel_val1_4 As Double = get_sobel_value4(bmp1, x1, y1)

                    If sobel_val1_1 < 0 Then
                        sobel_val1_1 = -sobel_val1_1
                    End If
                    If sobel_val1_2 < 0 Then
                        sobel_val1_2 = -sobel_val1_2
                    End If
                    If sobel_val1_3 < 0 Then
                        sobel_val1_3 = -sobel_val1_3
                    End If
                    If sobel_val1_1 < 0 Then
                        sobel_val1_4 = -sobel_val1_4
                    End If

                    Dim max_sobel_val_1 As Double = sobel_val1_2
                    If sobel_val1_2 > max_sobel_val_1 Then
                        max_sobel_val_1 = sobel_val1_2
                    End If

                    If sobel_val1_3 > max_sobel_val_1 Then
                        'max_sobel_val_1 = sobel_val1_3
                    End If

                    If sobel_val1_4 > max_sobel_val_1 Then
                        'max_sobel_val_1 = sobel_val1_4
                    End If
                    sobel_val1 = max_sobel_val_1
                    'sobel_val1 -= sobel_val1_1
                    'sobel_val1a = Math.Max(Math.Abs(get_sobel_value1(bmp1, x1, y1)), Math.Abs(get_sobel_value2(bmp1, x1, y1)))
                    'sobel_val1b = Math.Max(Math.Abs(get_sobel_value3(bmp1, x1, y1)), Math.Abs(get_sobel_value4(bmp1, x1, y1)))
                    'sobel_val1 = Math.Max(sobel_val1a, sobel_val1b)


                    'sobel_val1 = get_sobel_value1(bmp1, x1, y1)

                    'sobel_val1 = Math.Abs(get_sobel_value1(bmp1, x1, y1))

                End If

                'sobel_val1 = Math.Abs(get_sobel_value1_long(bmp1, x1, y1))
                'sobel_val1 = Math.Max(sobel_val1a, sobel_val1b)

                If max_sobel < sobel_val1 Then
                    max_sobel = sobel_val1
                End If

                If not_relevant1 = 1 Then
                    dict_sobel_val_pixels1(x1.ToString() + "," + y1.ToString()) = sobel_val1
                    dict_sobel_val1(ind1) = Math.Abs(sobel_val1)
                    dict_sobel_val2(Math.Abs(sobel_val1)) = 1

                End If


                Dim pixels_arr1 As ArrayList
                If CGlobals1.dict_sobel_pixels.ContainsKey(Math.Abs(sobel_val1)) Then
                    Dim d4 As Integer = 1
                Else
                    CGlobals1.dict_sobel_pixels(Math.Abs(sobel_val1)) = New ArrayList()
                End If
                pixels_arr1 = CGlobals1.dict_sobel_pixels(Math.Abs(sobel_val1))
                pixels_arr1.Add(x1.ToString() + "," + y1.ToString())

                ind1 += 1
                If Math.Abs(sobel_val1) > 70 Then

                    'bmp2.SetPixel(x1, y1, Color.FromArgb(255, 255, 255))

                Else
                    'bmp2.SetPixel(x1, y1, Color.FromArgb(0, 0, 0))
                End If
                If Math.Abs(sobel_val1) > 0 Then
                    Dim d1 As Integer = 1
                End If
                sobel_vals_str1.Append(x1.ToString() + "," + y1.ToString() + "," + Math.Abs(sobel_val1).ToString() + "#")


            Next
        Next


        If not_relevant1 = 0 Then
            For x1 = 0 + sobal_size1 To bmp1.Width - 1 - sobal_size1

                For y1 = 0 + sobal_size1 To bmp1.Height - 1 - sobal_size1
                    Dim sv1 As Integer = dict_sobel_val_pixels1(x1.ToString() + "," + y1.ToString()) / max_sobel * 255
                    'bmp2.SetPixel(x1, y1, Color.FromArgb(sv1, sv1, sv1))
                Next
            Next

        End If

        'Dim path1 As String = CGlobals1.global_path1 + file_name1 + "_sobel_vals1.txt"
        System.IO.File.WriteAllText(path_of_sobel_res1, sobel_vals_str1.ToString())
        Dim sorted = From pair In dict_sobel_val1
                     Order By pair.Value
        Dim sortedDictionary = sorted.ToDictionary(Function(p) p.Key, Function(p) p.Value)
        Dim s2 As Double = sortedDictionary(sortedDictionary.Keys(CType(sortedDictionary.Keys.Count * 0.99, Integer)))
        s2 = 30
        CGlobals1.current_sobel_threshold = s2
        'txtbox_curent_sobel_threshold1.Text = CGlobals1.current_sobel_threshold.ToString()
        Dim sorted2 = From pair In dict_sobel_val2
                      Order By pair.Key
        Dim sortedDictionary2 As Dictionary(Of Double, Integer) = sorted2.ToDictionary(Function(p) p.Key, Function(p) p.Value)

        Dim s1 As Double = sortedDictionary2.Keys(CType(sortedDictionary2.Keys.Count * 0.4, Integer))

        Dim count_sobel_ok_pixels1 As Integer = 0
        For x1 = 0 + sobal_size1 To bmp1.Width - 1 - sobal_size1
            For y1 = 0 + sobal_size1 To bmp1.Height - 1 - sobal_size1
                Dim sobel_val1 As Double = dict_sobel_val_pixels1(x1.ToString() + "," + y1.ToString())
                If sobel_val1 > s2 Then

                    bmp2.SetPixel(x1, y1, Color.FromArgb(255, 255, 255))
                    count_sobel_ok_pixels1 += 1
                Else
                    bmp2.SetPixel(x1, y1, Color.FromArgb(0, 0, 0))
                End If
            Next
        Next
        Dim percent_ok1 As Double = count_sobel_ok_pixels1 / (bmp1.Width * bmp1.Height)




        Return bmp2
    End Function
    Public Function sobel_matrix1()
        Dim mat1 As Double(,) = {
        {0, 1, 0, -1, 0, 0, 0},
        {0, 2, 0, -2, 0, 0, 0},
        {0, 0, 4, 0, -4, 0, 0},
        {0, 0, 8, 0, -8, 0, 0},
        {0, 0, 4, 0, -4, 0, 0},
        {0, 0, 0, 2, 0, 2, 0},
        {0, 0, 0, 1, 0, 1, 0}}


        Dim mat2 As Double(,) = {
        {0, 1, 0, 0, 0, 0, 0},
        {0, 0, 2, 0, 0, 2, 1},
        {0, 0, 0, 4, 4, 0, 0},
        {0, 0, 0, 0, 8, 0, 0},
        {0, 0, -4, -8, 0, 0, 0},
        {-1, -2, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0}}


    End Function

    'מציאת קווים מאונכים
    Public Function get_sobel_value1(ByRef bmp1 As Bitmap, x1 As Integer, y1 As Integer)
        Dim mat1 As Double(,) = {{0, 0, 0, 0, 0}, {-1, -1, -1, -1, -1}, {0, 0, 0, 0, 0}, {1, 1, 1, 1, 1}, {0, 0, 0, 0, 0}}
        Dim total_sobel_val1 As Double = 0
        Dim sobel_x1 As Integer
        Dim sobel_y1 As Integer
        sobel_x1 = 0
        For x2 = x1 - 2 To x1 + 2
            sobel_y1 = 0

            For y2 = y1 - 2 To y1 + 2
                Dim sobel_val1 As Double = mat1(sobel_x1, sobel_y1)

                total_sobel_val1 += get_mono_color1(bmp1, x2, y2) * sobel_val1
                sobel_y1 += 1

            Next
            sobel_x1 += 1
        Next

        Return total_sobel_val1
    End Function



    Public Function get_sobel_value1_long(bmp1 As Bitmap, x1 As Integer, y1 As Integer)
        Dim mat1 As Double(,) = {{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}}
        Dim total_sobel_val1 As Double = 0
        Dim sobel_x1 As Integer
        Dim sobel_y1 As Integer
        sobel_x1 = 0
        For x2 = x1 - 1 To x1 + 1
            sobel_y1 = 0

            For y2 = y1 - 6 To y1 + 6
                Dim sobel_val1 As Double = mat1(sobel_x1, sobel_y1)

                total_sobel_val1 += get_mono_color1(bmp1, x2, y2) * sobel_val1
                sobel_y1 += 1

            Next
            sobel_x1 += 1
        Next

        Return total_sobel_val1
    End Function


    'מציאת קווים מאוזנים
    Public Function get_sobel_value2(ByRef bmp1 As Bitmap, x1 As Integer, y1 As Integer)
        'Dim mat1 As Double(,) = {{-1, 0, 1}, {-1, 0, 1}, {-1, 0, 1}}
        Dim mat1 As Double(,) = {{0, -1, 0, 1, 0}, {0, -1, 0, 1, 0}, {0, -1, 0, 1, 0}, {0, -1, 0, 1, 0}, {0, -1, 0, 1, 0}}
        Dim total_sobel_val1 As Double = 0
        Dim sobel_x1 As Integer
        Dim sobel_y1 As Integer
        sobel_x1 = 0
        For x2 = x1 - 2 To x1 + 2
            sobel_y1 = 0

            For y2 = y1 - 2 To y1 + 2
                Dim sobel_val1 As Double = mat1(sobel_x1, sobel_y1)

                total_sobel_val1 += get_mono_color1(bmp1, x2, y2) * sobel_val1
                sobel_y1 += 1

            Next
            sobel_x1 += 1
        Next

        Return total_sobel_val1
    End Function

    Public Function get_sobel_value3(bmp1 As Bitmap, x1 As Integer, y1 As Integer)
        'Dim mat1 As Double(,) = {{-1, 0, 1}, {-1, 0, 1}, {-1, 0, 1}}
        Dim mat2 As Double(,) = {{0, -1, 0, 0, 0}, {1, 0, -1, 0, 0}, {0, 1, 0, -1, 0}, {0, 0, 1, 0, -1}, {0, 0, 0, 1, 0}}
        '0 -1  0  0  0
        '1  0 -1  0  0
        '0  1  0 -1  0
        '0  0  1  0 -1
        '0  0  0  1  0
        Dim total_sobel_val1 As Double = 0
        Dim sobel_x1 As Integer
        Dim sobel_y1 As Integer
        sobel_x1 = 0
        For x2 = x1 - 2 To x1 + 2
            sobel_y1 = 0

            For y2 = y1 - 2 To y1 + 2
                Dim sobel_val1 As Double = mat2(sobel_x1, sobel_y1)

                total_sobel_val1 += get_mono_color1(bmp1, x2, y2) * sobel_val1
                sobel_y1 += 1

            Next
            sobel_x1 += 1
        Next

        Return total_sobel_val1
    End Function
    Public Function get_sobel_value4(bmp1 As Bitmap, x1 As Integer, y1 As Integer)
        'Dim mat1 As Double(,) = {{-1, 0, 1}, {-1, 0, 1}, {-1, 0, 1}}
        'Dim mat2 As Double(,) = {{0, -1, 0, 0, 0}, {1, 0, -1, 0, 0}, {0, 1, 0, -1, 0}, {0, 0, 1, 0, -1}, {0, 0, 0, 1, 0}}
        '0 -1  0  0  0
        '1  0 -1  0  0
        '0  1  0 -1  0
        '0  0  1  0 -1
        '0  0  0  1  0


        Dim mat2 As Double(,) = {{0, 0, 0, -1, 0}, {0, 0, -1, 0, 1}, {0, -1, 0, 1, 0}, {-1, 0, 1, 0, 0}, {0, 1, 0, 0, 0}}

        '0   0  0 -1  0
        '0   0 -1  0  1
        '0  -1  0  1  0
        '-1  0  1  0  0
        '0   1  0  0  0


        Dim total_sobel_val1 As Double = 0
        Dim sobel_x1 As Integer
        Dim sobel_y1 As Integer
        sobel_x1 = 0
        For x2 = x1 - 2 To x1 + 2
            sobel_y1 = 0

            For y2 = y1 - 2 To y1 + 2
                Dim sobel_val1 As Double = mat2(sobel_x1, sobel_y1)

                total_sobel_val1 += get_mono_color1(bmp1, x2, y2) * sobel_val1
                sobel_y1 += 1

            Next
            sobel_x1 += 1
        Next

        Return total_sobel_val1
    End Function
    Public Function get_mono_color1(ByRef bmp1 As Bitmap, x1 As Integer, y1 As Integer)
        'Dim mono_color1 As Double = (CType(bmp1.GetPixel(x1, y1).R, Double) + CType(bmp1.GetPixel(x1, y1).G, Double) + CType(bmp1.GetPixel(x1, y1).B, Double)) / 3 ' * 0.3333
        'Dim color1 As Color = Color.FromArgb(255, 255, 255) ' bmp1.GetPixel(x1, y1)
        Dim key1 As String = x1.ToString() + "," + y1.ToString()
        If dict_mono_colors2.ContainsKey(key1) = True Then
            Return dict_mono_colors2(key1)
        End If
        Dim color1 As Color = bmp1.GetPixel(x1, y1)
        Dim mono_color1 As Integer = (0.3 * color1.R + 0.59 * color1.G + 0.11 * color1.B)
        dict_mono_colors2(key1) = mono_color1
        Return mono_color1
    End Function

End Class
