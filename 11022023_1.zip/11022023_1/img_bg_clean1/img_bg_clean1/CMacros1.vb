﻿Public Class CMacros1
    Public markingfldimg_obj1 As CMarkingFieldInImage1


    Public Function find_rect_of_pixels_arr(pixels_arr1 As ArrayList)
        Dim i1 As Integer
        Dim min_x1 As Integer = 9999
        Dim max_x1 As Integer = 9999
        Dim min_y1 As Integer = 9999
        Dim max_y1 As Integer = 9999


        Dim min_x_ind1 As Integer = 9999
        Dim max_x_ind1 As Integer = 9999
        Dim min_y_ind1 As Integer = 9999
        Dim max_y_ind1 As Integer = 9999

        For i1 = 0 To pixels_arr1.Count - 1
            Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, i1)
            If i1 = 0 Then
                min_x1 = cord_xy1(0)
                max_x1 = cord_xy1(0)
                min_y1 = cord_xy1(1)
                max_y1 = cord_xy1(1)


                min_x_ind1 = i1
                max_x_ind1 = i1
                min_y_ind1 = i1
                max_y_ind1 = i1

            Else
                If min_x1 > cord_xy1(0) Then
                    min_x1 = cord_xy1(0)
                    min_x_ind1 = i1
                End If
                If max_x1 < cord_xy1(0) Then
                    max_x1 = cord_xy1(0)
                    max_x_ind1 = i1
                End If
                If min_y1 > cord_xy1(1) Then
                    min_y1 = cord_xy1(1)
                    min_y_ind1 = i1
                End If
                If max_y1 < cord_xy1(1) Then
                    max_y1 = cord_xy1(1)
                    max_y_ind1 = i1
                End If
            End If
        Next
        Dim dict_rect1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
        dict_rect1("min_x1") = min_x1
        dict_rect1("max_x1") = max_x1
        dict_rect1("min_y1") = min_y1
        dict_rect1("max_y1") = max_y1

        dict_rect1("min_x_ind1") = min_x_ind1
        dict_rect1("max_x_ind1") = max_x_ind1
        dict_rect1("min_y_ind1") = min_y_ind1
        dict_rect1("max_y_ind1") = max_y_ind1


        Return dict_rect1
    End Function


    Public Function find_double_rect_of_pixels_arr(pixels_arr1 As ArrayList)
        Dim i1 As Integer
        Dim min_x1 As Double = 9999
        Dim max_x1 As Double = 9999
        Dim min_y1 As Double = 9999
        Dim max_y1 As Double = 9999


        Dim min_x_ind1 As Integer = 9999
        Dim max_x_ind1 As Integer = 9999
        Dim min_y_ind1 As Integer = 9999
        Dim max_y_ind1 As Integer = 9999

        For i1 = 0 To pixels_arr1.Count - 1
            Dim cord_xy1 As Double() = CGlobals1.get_double_cord_xy_in_pixels_arr2(pixels_arr1, i1)
            If i1 = 0 Then
                min_x1 = cord_xy1(0)
                max_x1 = cord_xy1(0)
                min_y1 = cord_xy1(1)
                max_y1 = cord_xy1(1)


                min_x_ind1 = i1
                max_x_ind1 = i1
                min_y_ind1 = i1
                max_y_ind1 = i1

            Else
                If min_x1 > cord_xy1(0) Then
                    min_x1 = cord_xy1(0)
                    min_x_ind1 = i1
                End If
                If max_x1 < cord_xy1(0) Then
                    max_x1 = cord_xy1(0)
                    max_x_ind1 = i1
                End If
                If min_y1 > cord_xy1(1) Then
                    min_y1 = cord_xy1(1)
                    min_y_ind1 = i1
                End If
                If max_y1 < cord_xy1(1) Then
                    max_y1 = cord_xy1(1)
                    max_y_ind1 = i1
                End If
            End If
        Next
        Dim dict_rect1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
        dict_rect1("min_x1") = min_x1
        dict_rect1("max_x1") = max_x1
        dict_rect1("min_y1") = min_y1
        dict_rect1("max_y1") = max_y1

        dict_rect1("min_x_ind1") = min_x_ind1
        dict_rect1("max_x_ind1") = max_x_ind1
        dict_rect1("min_y_ind1") = min_y_ind1
        dict_rect1("max_y_ind1") = max_y_ind1


        Return dict_rect1
    End Function


    Public Function find_handles_of_glasses1()
        'find_curve_of_glass_handles1()
        Dim dict_res1 As Dictionary(Of String, Object) = markingfldimg_obj1.find_curves_of_handles1(-1)
        'האינדקס של הפיקסל שממנו מתחילים את הקו הישר
        Dim start_ind1 As Integer = dict_res1("second_pxl_cord_ind1")
        'האינדקס של הפיקסל השמאלי ביותר ששייך לקו ושייך למשקפיים
        Dim end_ind1 As Integer = dict_res1("start_point1")

        Dim pixel_line_arr1 As ArrayList = dict_res1("pxl_line_arr1")
        Dim pixel_arr1 As ArrayList = dict_res1("pixels_arr1")
        'Return
        Dim dict_res2 As Dictionary(Of String, Object) = markingfldimg_obj1.find_curves_of_handles1(1)

        'האינדקס של הפיקסל שממנו מתחילים את הקו הישר
        Dim start_ind2 As Integer = dict_res2("second_pxl_cord_ind1")
        'האינדקס של הפיקסל השמאלי ביותר ששייך לקו ושייך למשקפיים
        Dim end_ind2 As Integer = dict_res2("start_point1")

        Dim pixel_line_arr2 As ArrayList = dict_res2("pxl_line_arr1")
        Dim pixel_arr2 As ArrayList = dict_res2("pixels_arr1")

        Dim left_pixel_arr1 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(pixel_arr2, Math.Min(end_ind1, end_ind2), Math.Max(end_ind1, end_ind2))

        Dim handle_pixel_arr1 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(pixel_arr2, start_ind2, start_ind1)

        Dim bmp1 As Bitmap = New Bitmap(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_crop1.jpg")
        Dim bmp2 As Bitmap = CGlobals1.create_fill_bitmap(bmp1.Width, bmp1.Height, Color.FromArgb(255, 255, 255))
        markingfldimg_obj1.set_pixel_arr_on_bmp2(left_pixel_arr1, bmp2, Color.FromArgb(255, 200, 70))
        markingfldimg_obj1.set_pixel_arr_on_bmp2(handle_pixel_arr1, bmp2, Color.FromArgb(255, 200, 70))
        markingfldimg_obj1.set_pixel_arr_on_bmp2(pixel_line_arr1, bmp2, Color.FromArgb(255, 200, 70))
        markingfldimg_obj1.set_pixel_arr_on_bmp2(pixel_line_arr2, bmp2, Color.FromArgb(255, 200, 70))
        bmp2 = markingfldimg_obj1.paint_recursive3(bmp2, 20, 20, Color.FromArgb(255, 200, 70), Color.FromArgb(55, 100, 70))

        Dim x1 As Integer
        Dim y1 As Integer
        For x1 = 0 To bmp1.Width - 1
            For y1 = 0 To bmp1.Height - 1
                If markingfldimg_obj1.compare_colors1(markingfldimg_obj1.get_pixel_at1(bmp2, x1, y1), Color.FromArgb(255, 255, 255)) = 1 Then

                Else
                    bmp1.SetPixel(x1, y1, Color.FromArgb(0, 0, 0, 0))
                End If
            Next

        Next

        bmp1 = markingfldimg_obj1.remove_around_object1(bmp1, Color.FromArgb(0, 0, 0, 0))
        bmp1 = markingfldimg_obj1.remove_around_object1(bmp1, Color.FromArgb(0, 0, 0, 0))
        bmp1.Save(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_handle1.bmp")
        Return bmp1
    End Function


    Public Function search_for_start_pixels_between_frame_and_handles_above1(curve_pxls1 As ArrayList)

        Dim debug_mode1 As Integer = 1
        Dim start_ind1 As Integer
        Dim curve_pxls_dict1 As Dictionary(Of String, Integer) = CGlobals1.add_to_dict1(curve_pxls1)

        Dim to_stop1 As Integer = 0
        Dim dict_rect1 As Dictionary(Of String, Object) = find_rect_of_pixels_arr(curve_pxls1)


        Dim center_x1 As Integer = (dict_rect1("min_x1") + dict_rect1("max_x1")) / 2
        Dim start_x1 As Integer = center_x1 + (dict_rect1("max_x1") - center_x1) * 0.3
        Dim y1 As Integer = 0
        While curve_pxls_dict1.ContainsKey(start_x1.ToString() + "," + y1.ToString()) = False
            y1 += 1
        End While

        start_ind1 = curve_pxls_dict1(start_x1.ToString() + "," + y1.ToString())


        Dim m1_arr1 As ArrayList = New ArrayList()
        Dim ind3 As Integer = 0
        While to_stop1 = 0
            If ind3 = 49 Then
                Dim d1 As Integer = 1
            End If
            Dim bmp1 As Bitmap = CGlobals1.create_fill_bitmap(dict_rect1("max_x1") + 5, dict_rect1("max_y1") + 5, Color.FromArgb(255, 255, 255))
            Dim bmp2 As Bitmap = CGlobals1.create_fill_bitmap(dict_rect1("max_x1") + 5, dict_rect1("max_y1") + 5, Color.FromArgb(255, 255, 255))
            markingfldimg_obj1.set_pixel_arr_on_bmp2(curve_pxls1, bmp1, Color.FromArgb(255, 50, 100))

            ind3 += 1
            Dim end_ind1 As Integer
            Dim dict_res1 As Dictionary(Of String, Object) = markingfldimg_obj1.find_max_line_len_on_curve1(curve_pxls1, start_ind1, start_ind1 + 1, 1)
            end_ind1 = dict_res1("end_ind1")

            Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls1, start_ind1)
            Dim cord_xy2 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls1, end_ind1)

            Dim m1 As Double = (cord_xy2(1) - cord_xy1(1)) / (cord_xy2(0) - cord_xy1(0))
            m1_arr1.Add(m1)
            Dim add_x1 As Integer = dict_rect1("max_x1") - cord_xy2(0)
            Dim cord_xy3(2) As Integer
            cord_xy3(0) = cord_xy2(0) + add_x1
            cord_xy3(1) = cord_xy2(1) + add_x1 * m1
            Dim pxls_line1 As ArrayList = markingfldimg_obj1.create_pixel_arr_line_from_2_2d_points2(cord_xy3, cord_xy2)
            Dim pxl_ind1 As Integer = 0
            Dim last_ind_sub_curve2 As Integer = -1
            While curve_pxls_dict1.ContainsKey(pxls_line1(pxl_ind1)) = False
                pxl_ind1 += 1
            End While
            last_ind_sub_curve2 = curve_pxls_dict1(pxls_line1(pxl_ind1))
            Dim x1 As Integer = Integer.Parse(pxls_line1(pxl_ind1 - 1).ToString().Split(",")(0))
            Dim max_x_ind1 As Integer = dict_rect1("max_x_ind1")
            Dim sub_curve1 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(curve_pxls1, start_ind1, max_x_ind1)

            Dim pxl_ind2 As Integer = pxls_line1.Count - 1


            Dim dict_res2 As Dictionary(Of String, Object) = markingfldimg_obj1.check_min_dist_to_curve1(sub_curve1, CGlobals1.get_cord_xy_in_pixels_arr1(pxls_line1, pxl_ind2), 5)
            While dict_res2("min_dist1") <= 2
                dict_res2 = markingfldimg_obj1.check_min_dist_to_curve1(sub_curve1, CGlobals1.get_cord_xy_in_pixels_arr1(pxls_line1, pxl_ind2), 5)
                pxl_ind2 -= 1
            End While

            Dim cord_xy4 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pxls_line1, pxl_ind2)
            Dim cord_xy_res1 As Integer() ' = CGlobals1.get_cord_xy_in_pixels_arr1(sub_curve2, max_dist_ind1)

            'bug צריך לתקן שלא נשווה את m1
            If cord_xy1(0) <= x1 And x1 <= cord_xy4(0) Then 'And m1 >= 0 Then
            Else
                Dim sub_curve2 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(curve_pxls1, end_ind1, last_ind_sub_curve2)

                If debug_mode1 = 1 Then

                    markingfldimg_obj1.set_pixel_arr_on_bmp2(sub_curve2, bmp2, Color.FromArgb(255, 50, 100))
                    markingfldimg_obj1.set_pixel_arr_on_bmp2(pxls_line1, bmp2, Color.FromArgb(55, 150, 100))

                    bmp2.Save(CGlobals1.global_path1 + "sobel_pics1\check_" + ind3.ToString() + ".jpg")
                End If

                Dim i2 As Integer
                Dim max_dist1 As Double = -1
                Dim max_dist_ind1 As Double = -1
                For i2 = 0 To sub_curve2.Count - 1
                    dict_res2 = markingfldimg_obj1.check_min_dist_to_curve1(pxls_line1, CGlobals1.get_cord_xy_in_pixels_arr1(sub_curve2, i2), 145)
                    If max_dist1 <= dict_res2("min_dist1") And dict_res2("min_dist_ind1") <> -1 Then
                        max_dist1 = dict_res2("min_dist1")
                        max_dist_ind1 = i2
                    End If
                Next
                cord_xy_res1 = CGlobals1.get_cord_xy_in_pixels_arr1(sub_curve2, max_dist_ind1)
                Dim dict_res_cord1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
                dict_res_cord1("cord_xy_res1") = cord_xy_res1
                dict_res_cord1("max_dist_ind1") = max_dist_ind1
                dict_res_cord1("ind_in_pixels1") = curve_pxls_dict1(cord_xy_res1(0).ToString() + "," + cord_xy_res1(1).ToString())
                Return dict_res_cord1
                to_stop1 = 1
            End If
            If to_stop1 = 1 Then
                CGlobals1.draw_sqr_around_pixels2(bmp1, cord_xy_res1(0), cord_xy_res1(1), 4, Color.FromArgb(100, 30, 200))

            End If
            If debug_mode1 = 1 Then

                markingfldimg_obj1.set_pixel_arr_on_bmp2(pxls_line1, bmp1, Color.FromArgb(20, 250, 100))
                bmp1.Save(CGlobals1.global_path1 + "sobel_pics1\" + ind3.ToString() + ".jpg")
            End If

            If (start_ind1 + 2) >= end_ind1 Then
                to_stop1 = 1
            End If
            start_ind1 += 1


        End While

    End Function
    Public Function move_pixel_line_above_until_not_overlap_curve1(curve_pxls1 As ArrayList, pxls_line1 As ArrayList)
        Dim debug_mode1 As Integer = 1
        CGlobals1.global_vars_dict1("loop_overlap1") += 1
        Dim curve_pxls_dict1 As Dictionary(Of String, Integer) = CGlobals1.add_to_dict1(curve_pxls1)

        Dim to_stop_move_line1 As String = ""
        Dim line_touch_curve_above_arr1 As ArrayList = New ArrayList()
        Dim dict_res1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
        While to_stop_move_line1 = ""
            Dim i1 As Integer
            Dim line_exist_on_curve1 As String = ""
            Dim is_overlap1 As Integer = CGlobals1.is_pixels_arr_overlap_pixels_dict1(pxls_line1, curve_pxls_dict1)
            Dim dict_xy1 As Dictionary(Of Integer, Integer) = CGlobals1.arr_xy_to_dict2(curve_pxls1)
            For i1 = 0 To pxls_line1.Count - 1
                Dim cord_xy1a As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pxls_line1, i1)
                If dict_xy1.ContainsKey(cord_xy1a(0)) = True Then
                    If cord_xy1a(1) >= dict_xy1(cord_xy1a(0)) Then
                        is_overlap1 = 1
                    End If
                End If
            Next
            If is_overlap1 = 1 Then
                pxls_line1 = CGlobals1.add_val_to_pxls_arr1(pxls_line1, 0, -1)
            Else
                Dim first_touch_ind1 As Integer = -1
                Dim last_touch_ind1 As Integer = -1
                Dim first_curve_ind1 As Integer = -1
                Dim last_curve_ind1 As Integer = -1
                For i1 = 0 To pxls_line1.Count - 1
                    Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pxls_line1, i1)
                    If curve_pxls_dict1.ContainsKey(cord_xy1(0).ToString() + "," + (cord_xy1(1) + 1).ToString()) = True Then
                        If first_touch_ind1 = -1 Then
                            first_touch_ind1 = i1
                            first_curve_ind1 = curve_pxls_dict1(cord_xy1(0).ToString() + "," + (cord_xy1(1) + 1).ToString())
                        End If
                        last_touch_ind1 = i1
                        line_touch_curve_above_arr1.Add(i1)
                        last_curve_ind1 = curve_pxls_dict1(cord_xy1(0).ToString() + "," + (cord_xy1(1) + 1).ToString())
                    End If
                Next
                dict_res1("first_touch_ind1") = first_touch_ind1
                dict_res1("last_touch_ind1") = last_touch_ind1
                dict_res1("first_curve_ind1") = first_curve_ind1
                dict_res1("last_curve_ind1") = last_curve_ind1
                dict_res1("line_touch_curve_above_arr1") = line_touch_curve_above_arr1
                dict_res1("pxls_line1") = pxls_line1
                If debug_mode1 = 1 Then
                    Dim bmp1 As Bitmap = CGlobals1.create_fill_bitmap(4000, 3000, Color.FromArgb(255, 255, 255))
                    markingfldimg_obj1.set_pixel_arr_on_bmp2(curve_pxls1, bmp1, Color.FromArgb(255, 100, 100))
                    markingfldimg_obj1.set_pixel_arr_on_bmp2(pxls_line1, bmp1, Color.FromArgb(55, 200, 100))
                    bmp1.Save(CGlobals1.global_path1 + "sobel_pics1\overlap1_" + CGlobals1.global_vars_dict1("loop_overlap1").ToString() + ".bmp")

                End If
                to_stop_move_line1 = 1
            End If


        End While

        Return dict_res1
    End Function

    Public Function check_if_have_first_touch_session(curve_pxls1 As ArrayList, pxls_line1 As ArrayList)
        Dim curve_pxls1_xy_dict1 As Dictionary(Of Integer, Integer) = CGlobals1.arr_xy_to_dict2(curve_pxls1)
        Dim pxls_line1_xy_dict1 As Dictionary(Of Integer, Integer) = CGlobals1.arr_xy_to_dict2(pxls_line1)

        Dim i1 As Integer = 0
        Dim to_stop1 As Integer = 0
        Dim dict_res1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
        While to_stop1 = 0
            Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pxls_line1, i1)

            If curve_pxls1_xy_dict1(cord_xy1(0)) - 1 = cord_xy1(1) Then
                to_stop1 = 1

            End If
            If curve_pxls1_xy_dict1(cord_xy1(0)) = cord_xy1(1) Then
                to_stop1 = 1
                dict_res1("res1") = "overlap_failed1"

                Return dict_res1
            End If
            i1 += 1

        End While
        to_stop1 = 0
        While to_stop1 = 0
            Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pxls_line1, i1)

            If curve_pxls1_xy_dict1(cord_xy1(0)) - 1 < cord_xy1(1) Then
                to_stop1 = 1

            End If
            If curve_pxls1_xy_dict1(cord_xy1(0)) = cord_xy1(1) Then
                to_stop1 = 1
                dict_res1("res1") = "overlap_failed1"

                Return dict_res1
            End If
            i1 += 1

        End While

    End Function

    Public Function move_pixel_line_above_until_not_overlap_curve2(curve_pxls1 As ArrayList, pxls_line1 As ArrayList)
        CGlobals1.global_vars_dict1("loop_overlap1") += 1
        Dim curve_pxls_dict1 As Dictionary(Of String, Integer) = CGlobals1.add_to_dict1(curve_pxls1)

        Dim to_stop_move_line1 As String = ""
        Dim line_touch_curve_above_arr1 As ArrayList = New ArrayList()
        Dim dict_res1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
        While to_stop_move_line1 = ""
            Dim i1 As Integer
            Dim line_exist_on_curve1 As String = ""

            'Dim dict_res1 As Dictionary(Of String, Object) = check_if_have_first_touch_session(curve_pxls1, pxls_line1)
            'If dict_res1("res1") = "overlap_failed1" Then
            'pxls_line1 = CGlobals1.add_val_to_pxls_arr1(pxls_line1, 0, -1)

            Dim is_overlap1 As Integer = CGlobals1.is_pixels_arr_overlap_pixels_dict1(pxls_line1, curve_pxls_dict1)
                If is_overlap1 = 1 Then
                    pxls_line1 = CGlobals1.add_val_to_pxls_arr1(pxls_line1, 0, -1)
                Else
                    Dim first_touch_ind1 As Integer = -1
                Dim last_touch_ind1 As Integer = -1
                For i1 = 0 To pxls_line1.Count - 1
                    Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pxls_line1, i1)
                    If curve_pxls_dict1.ContainsKey(cord_xy1(0).ToString() + "," + (cord_xy1(1) + 1).ToString()) = True Then
                        If first_touch_ind1 = -1 Then
                            first_touch_ind1 = i1

                        End If
                        last_touch_ind1 = i1
                        line_touch_curve_above_arr1.Add(i1)
                    End If
                Next
                dict_res1("first_touch_ind1") = first_touch_ind1
                dict_res1("last_touch_ind1") = last_touch_ind1
                dict_res1("line_touch_curve_above_arr1") = line_touch_curve_above_arr1
                dict_res1("pxls_line1") = pxls_line1

                Dim bmp1 As Bitmap = CGlobals1.create_fill_bitmap(4000, 3000, Color.FromArgb(255, 255, 255))
                markingfldimg_obj1.set_pixel_arr_on_bmp2(curve_pxls1, bmp1, Color.FromArgb(255, 100, 100))
                markingfldimg_obj1.set_pixel_arr_on_bmp2(pxls_line1, bmp1, Color.FromArgb(55, 200, 100))
                bmp1.Save(CGlobals1.global_path1 + "sobel_pics1\overlap1_" + CGlobals1.global_vars_dict1("loop_overlap1").ToString() + ".bmp")
                to_stop_move_line1 = 1
            End If


        End While

        Return dict_res1
    End Function



    Public Function search_for_start_pixels_between_frame_and_handles_above2(curve_pxls1 As ArrayList)

        Dim debug_mode1 As Integer = 1
        Dim start_ind1 As Integer
        Dim curve_pxls_dict1 As Dictionary(Of String, Integer) = CGlobals1.add_to_dict1(curve_pxls1)

        Dim to_stop1 As Integer = 0
        Dim dict_rect1 As Dictionary(Of String, Object) = find_rect_of_pixels_arr(curve_pxls1)


        Dim center_x1 As Integer = (dict_rect1("min_x1") + dict_rect1("max_x1")) / 2
        Dim start_x1 As Integer = center_x1 + (dict_rect1("max_x1") - center_x1) * 0.1
        Dim y1 As Integer = 0
        While curve_pxls_dict1.ContainsKey(start_x1.ToString() + "," + y1.ToString()) = False
            y1 += 1
        End While

        start_ind1 = curve_pxls_dict1(start_x1.ToString() + "," + y1.ToString())


        Dim bmp1 As Bitmap = CGlobals1.create_fill_bitmap(dict_rect1("max_x1") + 5, dict_rect1("max_y1") + 5, Color.FromArgb(255, 255, 255))
        Dim bmp2 As Bitmap = CGlobals1.create_fill_bitmap(dict_rect1("max_x1") + 5, dict_rect1("max_y1") + 5, Color.FromArgb(255, 255, 255))
        markingfldimg_obj1.set_pixel_arr_on_bmp2(curve_pxls1, bmp1, Color.FromArgb(255, 50, 100))
        Dim ind3 As Integer = 0

        ind3 += 1
        Dim end_ind1 As Integer
        Dim dict_res1 As Dictionary(Of String, Object) = markingfldimg_obj1.find_max_line_len_on_curve1(curve_pxls1, start_ind1, start_ind1 + 1, 1)
        end_ind1 = dict_res1("end_ind1")

        Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls1, start_ind1)
        Dim cord_xy2 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls1, end_ind1)

        Dim m1 As Double = (cord_xy2(1) - cord_xy1(1)) / (cord_xy2(0) - cord_xy1(0))

        Dim add_x1 As Integer = dict_rect1("max_x1") - cord_xy2(0)
        Dim cord_xy3(2) As Integer
        cord_xy3(0) = cord_xy2(0) + add_x1
        cord_xy3(1) = cord_xy2(1) + add_x1 * m1
        Dim pxls_line1 As ArrayList = markingfldimg_obj1.create_pixel_arr_line_from_2_2d_points2(cord_xy2, cord_xy3)




        Dim m1_arr1 As ArrayList = New ArrayList()
        CGlobals1.global_vars_dict1("loop_overlap1") = 0
        Dim last_cord_xy1(1) As Integer

        Dim last_last_x1 As Integer = -1

        Dim add_m1 As Double = 0.01
        Dim max_len1 As Double = -1
        Dim max_len_m1 As Double = -1

        Dim max_x1 As Double = -1
        Dim delta_max_x_arr1 As Dictionary(Of Double, Double) = New Dictionary(Of Double, Double)
        Dim max_delta_max_x1 As Double = -1
        Dim max_delta_max_x1_m1 As Double = -1
        Dim res_arr1 As ArrayList = New ArrayList()
        Dim max_delta_max_x1_is_first_to_last1 As String = ""
        Dim max_len1_arr1 As ArrayList = New ArrayList()
        Dim ok_m1 As Double = -1
        Dim max_m1_to_search1 As Double = 0.1
        While to_stop1 = 0
            If CGlobals1.global_vars_dict1("loop_overlap1") = 36 Then
                Dim d1 As Integer = 1
            End If
            m1 += add_m1
            cord_xy3(0) = cord_xy2(0) + add_x1
            cord_xy3(1) = cord_xy2(1) + add_x1 * m1
            pxls_line1 = markingfldimg_obj1.create_pixel_arr_line_from_2_2d_points2(cord_xy2, cord_xy3)
            Dim dict_res2 As Dictionary(Of String, Object) = move_pixel_line_above_until_not_overlap_curve1(curve_pxls1, pxls_line1)

            Dim line_touch_curve_above_arr1 As ArrayList = dict_res2("line_touch_curve_above_arr1")
            pxls_line1 = dict_res2("pxls_line1")

            last_cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(pxls_line1, line_touch_curve_above_arr1(line_touch_curve_above_arr1.Count - 1))
            Dim last_cord_xy2 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pxls_line1, dict_res2("last_touch_ind1"))
            Dim first_cord_xy2 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pxls_line1, dict_res2("first_touch_ind1"))
            Dim len1 As Double = Math.Abs(last_cord_xy2(0) - first_cord_xy2(0))
            If first_cord_xy2(0) > max_x1 And max_x1 <> -1 Then
                Dim d1 As Integer = 1
                'add_m1 = add_m1 / -2
                Dim cur_len1 As Double = Math.Abs(max_x1 - first_cord_xy2(0))
                If max_len1 = -1 Then
                    max_len1 = cur_len1
                    max_len_m1 = m1
                Else
                    If max_len1 < cur_len1 Then
                        max_len1 = cur_len1

                    End If

                End If
                max_len1_arr1.Add(cur_len1.ToString() + "," + first_cord_xy2(0).ToString() + "," + max_x1.ToString())
            End If
            max_len1_arr1.Add(len1)
            If max_x1 < last_cord_xy2(0) Then
                If max_x1 <> -1 Then
                    delta_max_x_arr1(m1) = last_cord_xy2(0) - max_x1
                    If max_delta_max_x1 < (last_cord_xy2(0) - max_x1) Then
                        max_delta_max_x1 = (last_cord_xy2(0) - max_x1)
                        max_delta_max_x1_m1 = m1
                        dict_res2("max_delta_max_x1_m1") = max_delta_max_x1_m1
                    End If
                End If
                max_x1 = last_cord_xy2(0)
            End If
            dict_res2("m1") = m1
            res_arr1.Add(dict_res2)

            last_last_x1 = last_cord_xy2(0)
            If m1 >= max_m1_to_search1 Then

                Dim i2 As Integer
                Dim max_delta_max_x1_m1_ind1 As Integer = -1
                For i2 = 0 To res_arr1.Count - 1
                    Dim dict_res3 As Dictionary(Of String, Object) = res_arr1(i2)
                    If dict_res3.ContainsKey("max_delta_max_x1_m1") = True Then
                        max_delta_max_x1_m1_ind1 = i2
                    End If
                Next
                Dim last_touch_ind1_last1 As Integer = CType(res_arr1(max_delta_max_x1_m1_ind1), Dictionary(Of String, Object))("last_touch_ind1")
                Dim first_touch_ind1_last1 As Integer = CType(res_arr1(max_delta_max_x1_m1_ind1), Dictionary(Of String, Object))("first_touch_ind1")

                Dim last_touch_ind1_before1 As Integer = CType(res_arr1(max_delta_max_x1_m1_ind1 - 1), Dictionary(Of String, Object))("last_touch_ind1")
                Dim first_touch_ind1_after1 As Integer = CType(res_arr1(max_delta_max_x1_m1_ind1 + 1), Dictionary(Of String, Object))("first_touch_ind1")

                If first_touch_ind1_last1 <= last_touch_ind1_before1 And last_touch_ind1_last1 >= first_touch_ind1_after1 Then
                    Dim d1 As Integer = 1
                    to_stop1 = 1
                    ok_m1 = m1
                    Dim pxls_line1_res As ArrayList = CType(res_arr1(max_delta_max_x1_m1_ind1), Dictionary(Of String, Object))("pxls_line1")
                    Dim bmp1a As Bitmap = CGlobals1.create_fill_bitmap(4000, 3000, Color.FromArgb(255, 255, 255))
                    markingfldimg_obj1.set_pixel_arr_on_bmp2(pxls_line1_res, bmp1a, Color.FromArgb(55, 200, 100))


                    Dim first_curve_ind1 As Integer = CType(res_arr1(max_delta_max_x1_m1_ind1), Dictionary(Of String, Object))("first_curve_ind1")
                    Dim last_curve_ind1 As Integer = CType(res_arr1(max_delta_max_x1_m1_ind1), Dictionary(Of String, Object))("last_curve_ind1")

                    Dim sub_curve1 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(curve_pxls1, first_curve_ind1, last_curve_ind1)
                    markingfldimg_obj1.set_pixel_arr_on_bmp2(sub_curve1, bmp1a, Color.FromArgb(255, 100, 100))
                    bmp1a.Save(CGlobals1.global_path1 + "sobel_pics1\overlap1_1res.bmp")

                    Dim i3 As Integer
                    Dim max_dist1 As Double = -1
                    Dim max_dist1_ind1 As Integer = -1
                    For i3 = 0 To sub_curve1.Count - 1
                        Dim dict_res3 As Dictionary(Of String, Object) = markingfldimg_obj1.check_min_dist_to_curve1(pxls_line1_res, CGlobals1.get_cord_xy_in_pixels_arr1(sub_curve1, i3), 150)
                        'If max_dist1 < dict_res3("min_dist1") Then
                        '                        max_dist1 = dict_res3("min_dist1")
                        'max_dist1_ind1 = i3
                        'End If

                        If max_dist1 <= dict_res3("min_dist1") And dict_res3("min_dist_ind1") <> -1 Then
                            max_dist1 = dict_res3("min_dist1")
                            max_dist1_ind1 = i3
                        End If
                    Next

                    CGlobals1.draw_sqr_around_pixels2(bmp1a, CGlobals1.get_cord_xy_in_pixels_arr1(sub_curve1, max_dist1_ind1)(0), CGlobals1.get_cord_xy_in_pixels_arr1(sub_curve1, max_dist1_ind1)(1), 3, Color.FromArgb(255, 50, 120))
                    bmp1a.Save(CGlobals1.global_path1 + "sobel_pics1\overlap1_1res2.bmp")
                    Dim d4 As Integer = 1

                    Dim dict_return_res1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
                    dict_return_res1("cord_xy_res1") = CGlobals1.get_cord_xy_in_pixels_arr1(sub_curve1, max_dist1_ind1)
                    dict_return_res1("ind_in_pixels1") = curve_pxls_dict1(sub_curve1(max_dist1_ind1))
                    '

                    Return dict_return_res1

                End If


                m1 = max_delta_max_x1_m1 - add_m1 * 2
                max_m1_to_search1 = CType(res_arr1(max_delta_max_x1_m1_ind1 + 1), Dictionary(Of String, Object))("m1") + add_m1
                max_delta_max_x1_m1 = -1
                max_delta_max_x1 = -1
                max_x1 = -1
                add_m1 /= 2
                res_arr1.Clear()
                'to_stop1 = 1
            End If
        End While

        While to_stop1 = 0
            If ind3 = 49 Then
                Dim d1 As Integer = 1
            End If

            m1_arr1.Add(m1)
            add_x1 = dict_rect1("max_x1") - cord_xy2(0)
            'Dim cord_xy3(2) As Integer
            cord_xy3(0) = cord_xy2(0) + add_x1
            cord_xy3(1) = cord_xy2(1) + add_x1 * m1
            pxls_line1 = markingfldimg_obj1.create_pixel_arr_line_from_2_2d_points2(cord_xy3, cord_xy2)
            Dim pxl_ind1 As Integer = 0
            Dim last_ind_sub_curve2 As Integer = -1
            While curve_pxls_dict1.ContainsKey(pxls_line1(pxl_ind1)) = False
                pxl_ind1 += 1
            End While
            last_ind_sub_curve2 = curve_pxls_dict1(pxls_line1(pxl_ind1))
            Dim x1 As Integer = Integer.Parse(pxls_line1(pxl_ind1 - 1).ToString().Split(",")(0))
            Dim max_x_ind1 As Integer = dict_rect1("max_x_ind1")
            Dim sub_curve1 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(curve_pxls1, start_ind1, max_x_ind1)

            Dim pxl_ind2 As Integer = pxls_line1.Count - 1


            Dim dict_res2 As Dictionary(Of String, Object) = markingfldimg_obj1.check_min_dist_to_curve1(sub_curve1, CGlobals1.get_cord_xy_in_pixels_arr1(pxls_line1, pxl_ind2), 5)
            While dict_res2("min_dist1") <= 2
                dict_res2 = markingfldimg_obj1.check_min_dist_to_curve1(sub_curve1, CGlobals1.get_cord_xy_in_pixels_arr1(pxls_line1, pxl_ind2), 5)
                pxl_ind2 -= 1
            End While

            Dim cord_xy4 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pxls_line1, pxl_ind2)
            Dim cord_xy_res1 As Integer() ' = CGlobals1.get_cord_xy_in_pixels_arr1(sub_curve2, max_dist_ind1)

            'bug צריך לתקן שלא נשווה את m1
            If cord_xy1(0) <= x1 And x1 <= cord_xy4(0) Then 'And m1 >= 0 Then
            Else
                Dim sub_curve2 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(curve_pxls1, end_ind1, last_ind_sub_curve2)

                If debug_mode1 = 1 Then

                    markingfldimg_obj1.set_pixel_arr_on_bmp2(sub_curve2, bmp2, Color.FromArgb(255, 50, 100))
                    markingfldimg_obj1.set_pixel_arr_on_bmp2(pxls_line1, bmp2, Color.FromArgb(55, 150, 100))

                    bmp2.Save(CGlobals1.global_path1 + "sobel_pics1\check_" + ind3.ToString() + ".jpg")
                End If

                Dim i2 As Integer
                Dim max_dist1 As Double = -1
                Dim max_dist_ind1 As Double = -1
                For i2 = 0 To sub_curve2.Count - 1
                    dict_res2 = markingfldimg_obj1.check_min_dist_to_curve1(pxls_line1, CGlobals1.get_cord_xy_in_pixels_arr1(sub_curve2, i2), 145)
                    If max_dist1 <= dict_res2("min_dist1") And dict_res2("min_dist_ind1") <> -1 Then
                        max_dist1 = dict_res2("min_dist1")
                        max_dist_ind1 = i2
                    End If
                Next
                cord_xy_res1 = CGlobals1.get_cord_xy_in_pixels_arr1(sub_curve2, max_dist_ind1)
                Dim dict_res_cord1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
                dict_res_cord1("cord_xy_res1") = cord_xy_res1
                dict_res_cord1("max_dist_ind1") = max_dist_ind1
                dict_res_cord1("ind_in_pixels1") = curve_pxls_dict1(cord_xy_res1(0).ToString() + "," + cord_xy_res1(1).ToString())
                Return dict_res_cord1
                to_stop1 = 1
            End If
            If to_stop1 = 1 Then
                CGlobals1.draw_sqr_around_pixels2(bmp1, cord_xy_res1(0), cord_xy_res1(1), 4, Color.FromArgb(100, 30, 200))

            End If
            If debug_mode1 = 1 Then

                markingfldimg_obj1.set_pixel_arr_on_bmp2(pxls_line1, bmp1, Color.FromArgb(20, 250, 100))
                bmp1.Save(CGlobals1.global_path1 + "sobel_pics1\" + ind3.ToString() + ".jpg")
            End If

            If (start_ind1 + 2) >= end_ind1 Then
                to_stop1 = 1
            End If
            start_ind1 += 1


        End While

    End Function



    Public Function combine_new_curve_in_frame_pixels_arr1(new_curve1 As ArrayList, frame_pixel_arr1 As ArrayList)
        Dim i1 As Integer
        Dim dict_new_curve1 As Dictionary(Of String, Integer) = CGlobals1.add_to_dict1(new_curve1)
        Dim min_dist_arr1 As ArrayList = New ArrayList()

        Dim first_cord_ind1 As Integer = -1
        Dim first_min_dist1 As Double = 99
        Dim lock_first_min_dist1 As Integer = 0


        Dim second_cord_ind1 As Integer = -1
        Dim second_min_dist1 As Double = 99
        Dim lock_second_min_dist1 As Integer = 0

        Dim last_min_dist_x1 As Integer = -1
        Dim last_min_dist_y1 As Integer = -1


        For i1 = 0 To frame_pixel_arr1.Count - 1
            Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixel_arr1, i1)
            Dim x1 As Integer
            Dim y1 As Integer
            Dim min_dist_x1 As Integer = -1
            Dim min_dist_y1 As Integer = -1
            Dim min_dist1 As Double = 99
            Dim delta_xy1 As Integer = 5
            For x1 = cord_xy1(0) - delta_xy1 To cord_xy1(0) + delta_xy1
                For y1 = cord_xy1(1) - delta_xy1 To cord_xy1(1) + delta_xy1
                    If dict_new_curve1.ContainsKey(x1.ToString() + "," + y1.ToString()) = True Then
                        Dim dist1 As Double = markingfldimg_obj1.get_dist_between_2_cords_xy1(New Integer() {x1, y1}, cord_xy1)
                        If dist1 < min_dist1 Then
                            min_dist1 = dist1
                            min_dist_x1 = x1
                            min_dist_y1 = y1
                        End If
                    End If
                Next

            Next

            If first_min_dist1 < min_dist1 And lock_first_min_dist1 = 0 Then
                lock_first_min_dist1 = 1

            End If

            If first_min_dist1 > min_dist1 And lock_first_min_dist1 = 0 Then
                first_min_dist1 = min_dist1
                first_cord_ind1 = i1
                last_min_dist_x1 = min_dist_x1
                last_min_dist_y1 = min_dist_y1
            End If



            If min_dist1 < 6 Then
                min_dist_arr1.Add(i1.ToString() + "," + min_dist1.ToString() + "#" + min_dist_x1.ToString() + "," + min_dist_y1.ToString() + "#" + frame_pixel_arr1(i1))
            End If

        Next
        Dim dict_res1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
        dict_res1("first_cord_ind1") = first_cord_ind1
        dict_res1("last_min_dist_x1") = last_min_dist_x1
        dict_res1("last_min_dist_y1") = last_min_dist_y1

        Return dict_res1

    End Function
End Class
