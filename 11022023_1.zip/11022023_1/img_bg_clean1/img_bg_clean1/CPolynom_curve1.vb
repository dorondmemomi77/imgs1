﻿Imports System.IO
Imports System.Reflection
Imports System.Runtime.Intrinsics.X86
Imports System.Security.Cryptography
Imports System.Xml

Public Class CPolynom_curve1

    Dim best_polynom_3 As CPolynom2 = Nothing
    Dim best_polynom_4 As CPolynom2 = Nothing


    Dim last_add_height_prm1 As Double = 0
    Dim mode_fix_last_pixel1 As String = ""
    Dim is_last_sub_curve1 As String = ""
    Dim cur_last_derivative_of_curve1 As Double = 0
    Dim start_coef1 As Double = Math.Pow(10, -5)
    Dim factor_div_prop1 As Double = 0.9

    Dim search_by_zero_last_derivate1 As String = ""
    Dim factor_div1 As Double = 2
    Dim count_div_step_factor_fix_last_pixel1 As Integer = 0
    Dim max_loop_count1 As Integer = 500 ' 200

    Dim min_min_diff_h1 As Double = Math.Pow(10, -10)

    Dim min_min_value5 As Double = 9999

    Dim dir_arr1 As Double() = {0, 0, -1, -1, 0, -1, 1, -1, -1, 0, 1, 0, -1, 1, 0, 1, 1, 1}
    Dim dir_arr_cur_ind1 As Integer = 0

    Dim polynom_result_dir_arr_ind_dicts1 As Dictionary(Of Integer, Object) = New Dictionary(Of Integer, Object)

    Dim go_back_last_ind1 As Integer = 0
    Dim last_go_back_ind1 As Integer = -1
    Dim last_go_back_ind1_start_ind1 As Integer = -1
    Dim last_go_back_ind1_last_derivative1 As Double = -1

    Dim min_diff_h_and_deriv1 As Double = 9999
    Dim cur_min_diff_h1_val1 As Double = 9999
    Dim cur_end_deriv_val1 As Double = 9999

    Dim was_error_in_fix_last_pxl1 As String = ""
    Dim mode_fix_last_pxl1 As String = ""

    Dim count_remove_start_pxls1 As Integer = 10
    Dim curve_zoom1 As Double = 1 '1.97 ' 2.467 '1 ' 2.8

    Dim max_delta_inds_for_hole1 As Integer = 2

    Dim first_top_ind1 As Integer = 240
    Dim delta_add_last_ind_min_m1 As Integer = 100
    Dim curve_start_ind1 As Integer = 0

    Dim max_add_curve_height1 As Double = 1.2

    Dim max_diff_start_last As Integer = 5
    Dim min_dist_last_derivative1 As Double = 0.07
    Dim min_dist_down_last_derivative1 As Double = 0.01 '0.06
    Dim min_dist_up_last_derivative1 As Double = 0.1
    Dim min_diff_last_derivative1 As Double = 0.15
    Dim dict_min_derivative As Dictionary(Of Integer, Double)

    Dim last_ind1 As Integer = 0
    Dim delta_add_last_ind1 As Integer = 30
    Dim start_ind1 As Integer = 0
    Dim m1b As Double
    Dim last_derivate1 As Double
    Dim min_last_derivative1 As Double = -1
    Dim curve_last_ind1 As Integer
    Dim last_delta_height1 As Double = 0
    Dim last_add_height1 As Double = 0

    Dim init_poynom_obj1 As CPolynom2 = New CPolynom2()
    Dim curve_pxls_arr1 As ArrayList

    Dim dict_prms1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)

    Dim mode1 As String = ""

    Dim polynom_result_arr1 As ArrayList = New ArrayList()
    Dim do_force1 As String = ""

    Public suffix_path1 As String = "_find_turn_pixel1"

    'Dim suffix_path1 As String = "_front_top_1_frame1"
    'Public suffix_path1 As String = "_front_top_2_frame1"
    'Dim suffix_path1 As String = "_front_right_1_frame1"
    'Dim suffix_path1 As String = "_front_right_2_frame1"
    'Dim suffix_path1 As String = "_front_bottom_1_frame1"
    'Dim suffix_path1 As String = "_front_bottom_2_frame1"

    Public suffix_path_arr1 As String() = {"_front_top_0_frame1", "_front_top_1_frame1", "_front_top_2_frame1", "_front_right_1_frame1", "_front_right_2_frame1", "_front_bottom_1_frame1", "_front_bottom_2_frame1", "_front_bottom_3_frame1", "_front_bottom_4_frame1"}


    Dim path_arr1(8) As String
    Dim path_ind1 As Integer
    Dim cur_path_ind1 As Integer = -1

    Public Function create_curve_from_polynom1(polynom_obj1 As CPolynom2, start_x1 As Double, end_x1 As Double, len_of_pixels1 As Integer)
        Dim curve_pixels_arr1 As ArrayList = New ArrayList()
        Dim x_val1 As Double = start_x1

        Dim add_to_x_val1 As Double = Math.Floor(x_val1 + 1) - x_val1
        add_to_x_val1 = 0
        Dim step_x_val1 As Double = (end_x1 - start_x1) / len_of_pixels1
        Dim x_ind1 As Integer = 0
        While x_ind1 <= len_of_pixels1

            Dim y_val1 As Double = polynom_obj1.get_y_val1(x_val1)
            curve_pixels_arr1.Add(CType((x_val1 + add_to_x_val1), Double).ToString() + "," + CType(y_val1, Double).ToString())
            x_val1 += step_x_val1
            x_ind1 += 1
        End While

        Return curve_pixels_arr1

    End Function
    Public Function init_polynom_by_min_x1(x_val1 As Double, derivative_val1 As Double)
        Dim polynom_obj1 As CPolynom2 = New CPolynom2()

        polynom_obj1.coef_arr1.Clear()
        polynom_obj1.coef_arr1.Add(0)
        polynom_obj1.coef_arr1.Add(0)
        polynom_obj1.coef_arr1.Add(0.00001)
        polynom_obj1.coef_arr1.Add(0.00005)
        polynom_obj1.coef_arr1.Add(0.000001)

        polynom_obj1.create_derivative1()
        Dim start_x_val1 As Double = polynom_obj1.find_x_by_derivative_val(derivative_val1)


        Dim start_y_val1 As Double = polynom_obj1.find_x_by_derivative_val(start_x_val1)
        Dim end_y_val1 As Double = polynom_obj1.find_x_by_derivative_val(start_x_val1 - 30)

        Dim curve1 As ArrayList = create_curve_from_polynom1(polynom_obj1, start_x_val1, start_x_val1 - 30, 100)
        Dim bmp1 As Bitmap = CGlobals1.create_fill_bitmap(1000, 1000, Color.FromArgb(255, 255, 255))
        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(curve1, bmp1, Color.FromArgb(200, 30, 70))
        bmp1.Save(CGlobals1.global_path1 + "sobel_pics1\c1.bmp")
        Dim diff1 As Double = start_y_val1 - end_y_val1
        Dim to_stop1 As Integer = 0

        While to_stop1 = 0

            polynom_obj1.create_derivative1()
            start_x_val1 = polynom_obj1.find_x_by_derivative_val(derivative_val1)
            Dim start_y_val1b As Double = polynom_obj1.find_x_by_derivative_val(start_x_val1)
            Dim end_y_val1b As Double = polynom_obj1.find_x_by_derivative_val(start_x_val1 - 30)
            Dim diff1b As Double = start_y_val1b - end_y_val1b

            If start_x_val1 < x_val1 Then
                Dim i1 As Integer

                For i1 = 0 To polynom_obj1.coef_arr1.Count - 1
                    polynom_obj1.coef_arr1(i1) *= 0.1
                Next
            Else
                to_stop1 = 1
            End If
        End While
        Dim curve2 As ArrayList = create_curve_from_polynom1(polynom_obj1, start_x_val1, start_x_val1 - 30, 100)
        Dim bmp2 As Bitmap = CGlobals1.create_fill_bitmap(1000, 1000, Color.FromArgb(255, 255, 255))
        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(curve2, bmp2, Color.FromArgb(200, 30, 70))
        bmp2.Save(CGlobals1.global_path1 + "sobel_pics1\c2.bmp")


        Dim add_coef1 As Double = 0.000001

        Dim i2 As Integer
        Dim diff_arr1 As ArrayList = New ArrayList()
        For i2 = -200 To 200
            Dim diff_height1 As Double = polynom_obj1.change_polynom_coef_and_no_change_x(120, 2, add_coef1, 3)
            Dim diff_height2 As Double = polynom_obj1.change_polynom_coef_and_no_change_x(120, 3, add_coef1, 4)
            Dim diff_height3 As Double = polynom_obj1.change_polynom_coef_and_no_change_x(120, 4, add_coef1, 3)
            If Math.Abs(diff_height3) > 50 And diff_height3 <> -9999 Then
                diff_height3 = polynom_obj1.change_polynom_coef_and_no_change_x(100, 4, add_coef1, 3)
            End If
            Dim d1 As Integer = 1
            add_coef1 = 0.00000001 * i2
            diff_arr1.Add(diff_height1)
            diff_arr1.Add(diff_height2)
            diff_arr1.Add(diff_height3)
        Next
    End Function


    Public Function find_polynom_coefs1(init_polynom1 As CPolynom2, start_derivative1 As Double, end_derivative1 As Double, curve_pxls_arr1 As ArrayList, search_mode1 As String, dict_prms1 As Dictionary(Of String, Object))



        Dim min_add_coef_factor1 As Double = Math.Pow(10, -15)



        If dict_prms1.ContainsKey("max_loop_count1") = True Then
            max_loop_count1 = dict_prms1("max_loop_count1")
        End If
        'max_loop_count1 = 600

        If mode_fix_last_pxl1 = "yes" Then
            If max_loop_count1 < 2000 Then
                'max_loop_count1 = 2000

            End If
        End If

        Dim mode_exp1 As String = "mode1"


        If mode_exp1 = "mode1" Then

            If mode_fix_last_pxl1 = "yes" Then

                min_add_coef_factor1 = Math.Pow(10, -15)
                min_min_diff_h1 = Math.Pow(10, -12)


                If dict_prms1.ContainsKey("max_loop_count1") = True Then
                    If max_loop_count1 < dict_prms1("max_loop_count1") Then
                        'max_loop_count1 = dict_prms1("max_loop_count1")

                    End If
                End If

                If max_loop_count1 < 3000 Then
                    'max_loop_count1 = 3000

                End If


                If max_loop_count1 < 1000 Then
                    'max_loop_count1 = 1000

                End If

            End If
        End If
        'max_loop_count1 = 3000
        Dim i1 As Integer
        'Dim search_mode1 As String = "only_end_derivate1"
        Dim dict_rect1 As Dictionary(Of String, Object) = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(curve_pxls_arr1)
        'Dim dict_rect1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)

        Dim width_of_curve1 As Double = Math.Abs(dict_rect1("max_x1") - dict_rect1("min_x1"))

        Dim height_of_curve1 As Double = Math.Abs(dict_rect1("max_y1") - dict_rect1("min_y1"))


        height_of_curve1 -= dict_prms1("last_delta_height1")
        height_of_curve1 -= dict_prms1("last_add_height1")
        If dict_prms1.ContainsKey("add_height_to_curve1") Then
            height_of_curve1 += dict_prms1("add_height_to_curve1")
        End If

        If dict_prms1.ContainsKey("add_curve_height1") Then
            height_of_curve1 += dict_prms1("add_curve_height1")

        End If


        If dict_prms1.ContainsKey("add_curve_width1") Then
            width_of_curve1 += dict_prms1("add_curve_width1")

        End If

        init_polynom1.coef_arr1(1) = height_of_curve1 / width_of_curve1 * factor_div_prop1

        init_polynom1.coef_arr1(2) = start_coef1
        init_polynom1.coef_arr1(3) = start_coef1

        If False Then

            If polynom_result_arr1.Count = 2 Then
                If best_polynom_3 IsNot Nothing Then
                    init_polynom1 = best_polynom_3.clone1()

                End If
            End If
            If polynom_result_arr1.Count = 3 Then
                If best_polynom_4 IsNot Nothing Then
                    init_polynom1 = best_polynom_4.clone1()

                End If


            End If

        End If

        'best_polynom_3 = CType(polynom_result_arr1(polynom_result_arr1.Count - 2)("polynom_obj1"), CPolynom2).clone1()
        'best_polynom_4 = CType(polynom_result_arr1(polynom_result_arr1.Count - 1)("polynom_obj1"), CPolynom2).clone1()


        'height_of_curve1 += dict_prms1("last_delta_height1")
        'width_of_curve1 = 50
        Dim add_coef_factor1 As Double = 0.1

        Dim coef_ind1 As Integer
        Dim coef_ind2 As Integer
        Dim coef_ind3 As Integer
        Dim coef_ind4 As Integer


        Dim last_dict_return_res1 As Dictionary(Of String, Object)

        Dim polynoms_res_arr1 As ArrayList = New ArrayList()

        Dim coef_add_arr1 As Integer() = {0, 0, 0, 0}
        Dim min_dist_height1 As Double = 9999999
        Dim min_dist_height2 As Double = 9999999

        Dim min_dist_height_ind1 As Integer = -1
        Dim min_dist_from_curve1 As Double = 999999
        Dim polynom_ind1 As Integer = 0
        Dim to_stop1 As Integer = 0
        Dim loop_ind1 As Integer = 0

        Dim last_end_x_polynom1 As Double = 99

        Dim max_end_x_val1 As Double = -1
        Dim status1 As String = ""
        Dim min_dist_diff_height1 As Double = 999
        Dim min_diff_start_x_val1 As Double = 999
        Dim padd_start_x_val1 As Double = 5
        Dim last_min_diff_h1 As Double = -1
        Dim last_delta_min_diff_h1 As Double = -1

        Dim min_last_diff_h1_and_last_deriv1 As Double = 9999

        Dim min_last_derivative1 As Double = 9999

        polynoms_res_arr1 = New ArrayList()

        Dim poly_ind1 As Integer

        Dim polynoms_arr1 As ArrayList = New ArrayList()
        For poly_ind1 = 0 To 81
            polynoms_arr1.Add(init_polynom1.clone1())
            'dict_polynom_res1
        Next
        Dim create_polynom_objs_count1 As Integer = 0

        CGlobals1.add_to_txt_log1("start_find_polynom_coeafs1")
        Dim last_end_x_val1 As Double = 0
        While to_stop1 = 0
            polynoms_res_arr1 = New ArrayList()
            min_dist_height_ind1 = -1
            polynom_ind1 = 0
            loop_ind1 += 1

            If loop_ind1 = 187 Then
                If dict_prms1("curve_ind1") = 2 Then
                    Dim d5 As Integer = 2

                End If
            End If
            For coef_ind1 = -1 To 1
                For coef_ind2 = -1 To 1
                    For coef_ind3 = -1 To 1
                        For coef_ind4 = -1 To 1
                            'Dim polynom_obj1 As CPolynom2 = init_polynom1.clone1()

                            Dim polynom_obj1 As CPolynom2

                            polynom_obj1 = init_polynom1.clone1()
                            create_polynom_objs_count1 += 1
                            If False Then
                                Try
                                    polynom_obj1 = polynoms_arr1(polynom_ind1)
                                Catch ex As Exception
                                    Dim d123 As Integer = 1
                                End Try

                            End If




                            Dim coef_i1 As Integer
                            coef_add_arr1(0) = 0 ' coef_ind1
                            coef_add_arr1(1) = coef_ind2
                            coef_add_arr1(2) = coef_ind3
                            coef_add_arr1(3) = coef_ind4
                            Dim min_coef_val1 As Double = Math.Pow(10, -15)
                            Dim is_ok_coefs1 As Integer = 1
                            For coef_i1 = 0 To 3
                                polynom_obj1.coef_arr1(coef_i1) = init_polynom1.coef_arr1(coef_i1)
                            Next

                            For coef_i1 = 0 To 3
                                polynom_obj1.coef_arr1(coef_i1) += add_coef_factor1 * coef_add_arr1(coef_i1)
                                If polynom_obj1.coef_arr1(coef_i1) < min_coef_val1 And coef_i1 >= 1 Then
                                    is_ok_coefs1 = 0
                                End If
                            Next
                            If mode_fix_last_pxl1 = "yes" Then
                                'coef_add_arr1(1) = 0
                                'coef_add_arr1(3) = 0
                            End If
                            If coef_ind2 = 0 And coef_ind3 = 0 And coef_ind4 = 0 Then
                                Dim d1 As Integer = 1
                            End If
                            If is_ok_coefs1 = 1 Then
                                Dim max_dist_from_curve1 As Double = -1
                                If polynom_obj1.is_all_coef_zero_as_least1() = 0 Then
                                    Dim d5 As Integer = 1
                                End If

                                polynom_obj1.create_derivative1()
                                Dim height1 As Double
                                Dim start_x_val1 As Double
                                Dim end_x_val1 As Double

                                Dim end_y1 As Double
                                Dim start_y1 As Double

                                If search_mode1 = "search_by_min_end_derivate1" Then
                                    polynom_obj1.get_derivative1(end_derivative1)
                                End If
                                If search_mode1 = "only_end_derivate1" Then
                                    end_x_val1 = polynom_obj1.find_x_by_derivative_val(end_derivative1)
                                    end_y1 = polynom_obj1.get_y_val1(end_x_val1)
                                    start_y1 = polynom_obj1.get_y_val1(end_x_val1 + width_of_curve1)
                                    height1 = Math.Abs(end_y1 - start_y1)

                                End If
                                If search_mode1 = "only_start_derivate1" Then
                                    Dim temp_end_x_val1 As Double = end_x_val1
                                    Dim end_x_val1a As Double = polynom_obj1.find_x_by_derivative_val2(start_derivative1, last_end_x_val1)
                                    end_x_val1 = end_x_val1a
                                    'end_x_val1 = polynom_obj1.find_x_by_derivative_val(start_derivative1)
                                    If Math.Abs(end_x_val1a - end_x_val1) > Math.Pow(10, -8) Then
                                        Dim err1 As Integer = 112


                                        'Dim end_x_val1b As Double = polynom_obj1.find_x_by_derivative_val2(start_derivative1, temp_end_x_val1)
                                        Dim end_x_val1c As Double = polynom_obj1.find_x_by_derivative_val(start_derivative1)
                                    End If
                                    end_x_val1 = end_x_val1a
                                    If end_x_val1 <> CPolynom2.max_end_x_val1 Then
                                        last_end_x_val1 = end_x_val1
                                    End If
                                    If end_x_val1 <= width_of_curve1 Then
                                        Dim err1 As Integer = 1
                                    End If
                                    start_y1 = polynom_obj1.get_y_val1(end_x_val1)
                                    end_y1 = polynom_obj1.get_y_val1(end_x_val1 - width_of_curve1)
                                    height1 = Math.Abs(end_y1 - start_y1)

                                    If max_end_x_val1 = -1 Then
                                        max_end_x_val1 = Math.Abs(end_x_val1)
                                    Else
                                        If max_end_x_val1 < Math.Abs(end_x_val1) Then
                                            max_end_x_val1 = Math.Abs(end_x_val1)
                                        End If
                                    End If

                                End If

                                If search_mode1 = "only_start_derivate_minus1" Then
                                    end_x_val1 = polynom_obj1.find_x_by_derivative_val(start_derivative1)
                                    start_y1 = polynom_obj1.get_y_val1(end_x_val1)
                                    end_y1 = polynom_obj1.get_y_val1(end_x_val1 + width_of_curve1)
                                    height1 = Math.Abs(end_y1 - start_y1)

                                    If max_end_x_val1 = -1 Then
                                        max_end_x_val1 = Math.Abs(end_x_val1)
                                    Else
                                        If max_end_x_val1 < Math.Abs(end_x_val1) Then
                                            max_end_x_val1 = Math.Abs(end_x_val1)
                                        End If
                                    End If

                                End If


                                If search_mode1 = "find_start_x_val_more_then_width1" Then
                                    start_x_val1 = polynom_obj1.find_x_by_derivative_val(start_derivative1)
                                    start_y1 = polynom_obj1.get_y_val1(end_x_val1)
                                    end_y1 = polynom_obj1.get_y_val1(end_x_val1 - width_of_curve1)
                                    height1 = Math.Abs(end_y1 - start_y1)
                                    Dim diff_width1 As Double = Math.Abs(start_x_val1 - padd_start_x_val1 - width_of_curve1)
                                    If min_diff_start_x_val1 > diff_width1 Then
                                        min_diff_start_x_val1 = diff_width1
                                        min_dist_height_ind1 = polynom_ind1

                                    End If

                                End If

                                If search_mode1 = "only_end_derivate1" Or search_mode1 = "only_start_derivate1" Or search_mode1 = "only_start_derivate_minus1" Then

                                    Dim dist_diff1 As Double = Math.Abs(height1 - height_of_curve1)

                                    If polynom_result_arr1.Count - 1 = last_go_back_ind1 And mode_fix_last_pxl1 = "yes" And search_by_zero_last_derivate1 = "yes" Then

                                        Dim end_derivative3 As Double = polynom_obj1.get_derivative1(Math.Abs(end_x_val1) - width_of_curve1)
                                        If min_last_derivative1 > Math.Abs(end_derivative3) Then

                                            min_last_derivative1 = Math.Abs(end_derivative3)
                                        End If
                                        dist_diff1 = Math.Abs(height1 - height_of_curve1) + Math.Abs(Math.Abs(end_derivative3) - Math.Abs(cur_last_derivative_of_curve1))
                                    End If

                                    If Math.Abs(end_x_val1) >= 150000 And Math.Abs(end_x_val1) <> 9999999 Then
                                        Dim err1 As Integer = 1
                                    End If
                                    Dim dist_diff2 As Double = height1 - height_of_curve1
                                    If Math.Abs(end_x_val1) < 150000 And (Math.Abs(end_x_val1) > Math.Abs(width_of_curve1) Or search_mode1 = "only_start_derivate_minus1") Then
                                        Dim end_derivate_val1 As Double = -1

                                        If search_mode1 = "only_end_derivate1" Then
                                            Dim org_curve1 As ArrayList = dict_prms1("org_curve1")
                                            Dim end_pixel_ind1 As Integer = dict_prms1("end_pixel_ind1")
                                            end_derivate_val1 = polynom_obj1.get_derivative1(end_x_val1)


                                            max_dist_from_curve1 = check_curve_with_m1(org_curve1, end_pixel_ind1, end_pixel_ind1 + width_of_curve1, end_pixel_ind1, (end_x_val1 - start_x_val1) / width_of_curve1, end_derivate_val1)
                                        End If
                                        If search_mode1 = "only_start_derivate_minus1" Then
                                            Dim d2 As Integer = 1
                                        End If

                                        If min_dist_height_ind1 = -1 Then
                                            If min_dist_height1 > dist_diff1 And (min_dist_from_curve1 > max_dist_from_curve1 Or max_dist_from_curve1 <= 0.2) Then
                                                min_dist_height_ind1 = polynom_ind1
                                                min_dist_diff_height1 = height1 - height_of_curve1
                                                min_dist_from_curve1 = max_dist_from_curve1
                                            End If
                                        Else
                                            If min_dist_height1 > dist_diff1 And (min_dist_from_curve1 > max_dist_from_curve1 Or max_dist_from_curve1 <= 0.2) Then
                                                min_dist_height1 = dist_diff1
                                                min_dist_height2 = dist_diff2
                                                min_dist_height_ind1 = polynom_ind1
                                                min_dist_diff_height1 = height1 - height_of_curve1
                                                min_dist_from_curve1 = max_dist_from_curve1
                                            End If
                                        End If
                                    End If

                                End If
                                Dim d1 As Integer = 1
                                If end_x_val1 >= width_of_curve1 Then

                                    polynom_ind1 += 1

                                    Dim dict_polynom_res1 As Dictionary(Of String, Object)

                                    If False Then
                                        If polynoms_res_arr1.Count > polynom_ind1 Then
                                            Try
                                                dict_polynom_res1 = polynoms_res_arr1(polynom_ind1 - 1)

                                            Catch ex As Exception
                                                Dim d16 As Integer = 1
                                            End Try
                                        Else
                                            dict_polynom_res1 = New Dictionary(Of String, Object)
                                            polynoms_res_arr1.Add(dict_polynom_res1)
                                        End If

                                    End If

                                    dict_polynom_res1 = New Dictionary(Of String, Object)

                                    dict_polynom_res1("polynom_obj1") = polynom_obj1
                                    dict_polynom_res1("min_dist_height1") = min_dist_height1
                                    dict_polynom_res1("min_dist_height2") = min_dist_height2
                                    dict_polynom_res1("end_x_val1") = end_x_val1
                                    dict_polynom_res1("end_y1") = end_y1
                                    dict_polynom_res1("start_y1") = start_y1
                                    dict_polynom_res1("max_dist_from_curve1") = max_dist_from_curve1

                                    polynoms_res_arr1.Add(dict_polynom_res1)
                                End If

                            End If

                        Next

                    Next

                Next

            Next


            If min_dist_height_ind1 <> -1 Then


                Dim dict_polynom_res2 As Dictionary(Of String, Object) = polynoms_res_arr1(min_dist_height_ind1)
                init_polynom1 = dict_polynom_res2("polynom_obj1")
                If search_mode1 = "find_start_x_val_more_then_width1" Then
                    If min_diff_start_x_val1 < Math.Pow(10, -10) Then
                        to_stop1 = 1
                        Dim dict_retutn_res1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
                        dict_retutn_res1("polynom_obj1") = init_polynom1
                        Return dict_retutn_res1
                        'last_end_x_polynom1 = dict_polynom_res2("end_x_val1")
                    End If
                Else

                    Dim min_diff_h1 As Double = dict_polynom_res2("min_dist_height1")
                    Dim min_diff_h2 As Double = dict_polynom_res2("min_dist_height2")
                    If last_min_diff_h1 = -1 Then
                        last_min_diff_h1 = min_diff_h1
                    Else
                        'If Math.Abs(min_diff_h1 - last_min_diff_h1) < Math.Pow(10, -10) Then
                        '                        Dim err1 As Integer = 1
                        'Dim dict_return_res1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
                        '                        dict_return_res1("error1") = "yes"
                        'dict_return_res1("min_dist_diff_height1") = min_dist_diff_height1
                        '                        Return dict_return_res1

                        'End If
                    End If

                    Dim delta_min_diff_h1 As Double = Math.Abs(last_min_diff_h1 - min_diff_h1)

                    If delta_min_diff_h1 = last_delta_min_diff_h1 Then
                        Dim err1 As Integer = 1
                    End If

                    last_delta_min_diff_h1 = Math.Abs(last_min_diff_h1 - min_diff_h1)
                    last_min_diff_h1 = min_diff_h1

                    Dim ok_end_derivative2 As String = ""
                    Dim end_derivative3 As Double = init_polynom1.get_derivative1(dict_polynom_res2("end_x_val1") - width_of_curve1)
                    If dict_prms1.ContainsKey("check2") = True Then
                        If ((end_derivative3 < min_last_derivative1 And Math.Abs(end_derivative3 - min_last_derivative1) < min_dist_down_last_derivative1 Or
                            end_derivative3 > min_last_derivative1 And Math.Abs(end_derivative3 - min_last_derivative1) < min_dist_up_last_derivative1)) Then
                            If mode_fix_last_pxl1 = "yes" Then
                                'ok_end_derivative2 = "yes"
                            End If

                            'ok_end_derivative2 = "yes"
                        End If

                    End If

                    If dict_prms1.ContainsKey("check1") = True Then
                        If (end_derivative3 - min_last_derivative1) <= min_diff_last_derivative1 Then
                            'ok_end_derivative2 = "yes"
                            If mode_fix_last_pxl1 = "yes" Then
                                'ok_end_derivative2 = "yes"
                            End If
                        End If

                    End If

                    'ok_end_derivative2 = "yes"

                    Dim last_good_derivative_res1 As String = "yes"
                    If mode_fix_last_pxl1 = "yes" Then
                        If polynom_result_arr1.Count - 1 = last_go_back_ind1 Then
                            If end_derivative3 <= Math.Pow(10, -7) Then
                                last_good_derivative_res1 = ""
                            Else
                                last_good_derivative_res1 = "no"
                            End If
                        End If

                    End If
                    Dim to_save_result1 As String = "yes"
                    If polynom_result_arr1.Count - 1 = last_go_back_ind1 And mode_fix_last_pxl1 = "yes" Then

                        If min_last_derivative1 > Math.Abs(end_derivative3) Then

                            min_last_derivative1 = Math.Abs(end_derivative3)
                        End If


                        to_save_result1 = "yes"
                        If min_last_diff_h1_and_last_deriv1 = 9999 Then
                            min_last_diff_h1_and_last_deriv1 = Math.Abs(min_diff_h1) + Math.Abs(end_derivative3)
                            to_save_result1 = "yes"
                        Else
                            If min_last_diff_h1_and_last_deriv1 > Math.Abs(min_diff_h1) + Math.Abs(end_derivative3) Then
                                min_last_diff_h1_and_last_deriv1 = Math.Abs(min_diff_h1) + Math.Abs(end_derivative3)
                                to_save_result1 = "yes"
                            End If
                        End If
                    End If

                    'If (Math.Abs(min_diff_h1) < Math.Pow(10, -10) Or (loop_ind1 > max_loop_count1 Or add_coef_factor1 < Math.Pow(10, -10) Or ok_end_derivative2 = "yes") And Math.Abs(min_diff_h1) < 1) Then
                    If to_save_result1 = "yes" And Math.Abs(min_diff_h1) < 1 Then


                        If dict_prms1("curve_ind1") = 2 Then
                            Dim d1 As Integer = 2
                        End If

                        Dim polynom_curve1a As ArrayList
                        Dim last_x_val2a As Double = -999
                        If search_mode1 = "only_start_derivate1" Then
                            polynom_curve1a = create_curve_from_polynom1(init_polynom1, dict_polynom_res2("end_x_val1") - width_of_curve1, dict_polynom_res2("end_x_val1"), width_of_curve1)
                            Dim start_derivative1c As Double = init_polynom1.get_derivative1(dict_polynom_res2("end_x_val1"))
                            last_x_val2a = dict_polynom_res2("end_x_val1") - width_of_curve1
                        ElseIf search_mode1 = "only_start_derivate_minus1" Then

                            polynom_curve1a = create_curve_from_polynom1(init_polynom1, dict_polynom_res2("end_x_val1"), dict_polynom_res2("end_x_val1") + width_of_curve1, width_of_curve1)
                            last_x_val2a = dict_polynom_res2("end_x_val1")
                        Else

                            polynom_curve1a = create_curve_from_polynom1(init_polynom1, dict_polynom_res2("end_x_val1") + width_of_curve1, dict_polynom_res2("end_x_val1"), width_of_curve1)
                            last_x_val2a = dict_polynom_res2("end_x_val1")
                        End If
                        If search_mode1 = "only_start_derivate_minus1" Then
                            last_x_val2a = dict_polynom_res2("end_x_val1") + width_of_curve1

                        End If


                        If search_mode1 = "only_start_derivate_minus1" Then
                            Dim d2 As Integer = 1
                        End If


                        last_end_x_polynom1 = dict_polynom_res2("end_x_val1")
                        init_polynom1 = dict_polynom_res2("polynom_obj1")
                        Dim dict_return_res1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)





                        dict_return_res1("dict_polynom_res2") = dict_polynom_res2

                        dict_return_res1("start_x_val1") = dict_polynom_res2("end_x_val1")
                        dict_return_res1("end_x_val1") = dict_polynom_res2("end_x_val1") - width_of_curve1
                        dict_return_res1("end_derivative1") = init_polynom1.get_derivative1(dict_polynom_res2("end_x_val1") - width_of_curve1)
                        dict_return_res1("start_derivative1") = init_polynom1.get_derivative1(dict_polynom_res2("end_x_val1"))
                        dict_return_res1("polynom_obj1") = init_polynom1
                        dict_return_res1("last_end_x_polynom1") = last_end_x_polynom1
                        dict_return_res1("min_dist_from_curve1") = min_dist_from_curve1
                        Dim end_derivative2 As Double = init_polynom1.get_derivative1(last_x_val2a)
                        dict_return_res1("end_derivative2") = end_derivative2
                        dict_return_res1("polynom_curve1a") = polynom_curve1a
                        dict_return_res1("curve_pxls_arr1") = curve_pxls_arr1

                        If (min_diff_h2 < 0) Then
                            min_diff_h1 *= -1
                        End If
                        dict_return_res1("min_diff_h1") = min_diff_h1
                        'dict_return_res1("min_diff_h2") = min_diff_h2

                        dict_return_res1("width_of_curve1") = width_of_curve1
                        dict_return_res1("height_of_curve1") = height_of_curve1
                        dict_return_res1("search_mode1") = search_mode1
                        dict_return_res1("min_last_derivative1") = min_last_derivative1
                        dict_return_res1("min_diff_last_derivative1") = Math.Abs(Math.Abs(cur_last_derivative_of_curve1) - Math.Abs(dict_return_res1("end_derivative1")))


                        last_dict_return_res1 = dict_return_res1

                    End If

                    If (Math.Abs(min_diff_h1) < min_min_diff_h1 Or (loop_ind1 > max_loop_count1 Or add_coef_factor1 < min_add_coef_factor1 Or ok_end_derivative2 = "yes") And Math.Abs(min_diff_h1) < 1) Then

                        CGlobals1.add_to_txt_log1("end_find_polynom_coeafs1")

                        Dim dict_polynom_res2b As Dictionary(Of String, Object) = last_dict_return_res1("dict_polynom_res2")
                        Dim polynom_curve1a As ArrayList = last_dict_return_res1("polynom_curve1a")

                        Dim curve_ind1 As Integer = dict_prms1("curve_ind1")
                        polynom_curve1a = rotate_curve_vertical1(polynom_curve1a)

                        polynom_curve1a = move_left_botton_curve_to_cord_xy1(polynom_curve1a, New Double() {100, 100})

                        Dim y_val1a As Double = init_polynom1.get_y_val1(dict_polynom_res2b("end_x_val1") + width_of_curve1)
                        Dim y_val2a As Double = init_polynom1.get_y_val1(dict_polynom_res2b("end_x_val1"))

                        Dim bmp1a As Bitmap = CGlobals1.create_fill_bitmap(1500, 1000, Color.FromArgb(255, 255, 255))
                        CGlobals1.form_obj1.markingfldimg_obj1.set_double_pixel_arr_on_bmp2(polynom_curve1a, bmp1a, Color.FromArgb(200, 30, 70))
                        bmp1a.Save(CGlobals1.global_path1 + "sobel_pics1\c1a_" + curve_ind1.ToString() + ".bmp")

                        Dim curve_pxls_arr1a As ArrayList = last_dict_return_res1("curve_pxls_arr1")
                        curve_pxls_arr1a = move_left_botton_curve_to_cord_xy1(curve_pxls_arr1a, New Double() {100, 105})
                        Dim bmp1b As Bitmap = CGlobals1.create_fill_bitmap(1500, 1000, Color.FromArgb(255, 255, 255))
                        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(curve_pxls_arr1, bmp1a, Color.FromArgb(40, 40, 250))


                        bmp1a.Save(CGlobals1.global_path1 + "sobel_pics1\c2a_" + curve_ind1.ToString() + ".bmp")


                        to_stop1 = 1

                        'CGlobals1.add_to_txt_log2("create_polynom_objs_count1=" + create_polynom_objs_count1.ToString())

                        Return last_dict_return_res1
                    End If


                End If

                Dim d4 As Integer = 1

            Else
                If add_coef_factor1 < min_add_coef_factor1 Then

                    Dim dict_polynom_res2b As Dictionary(Of String, Object)
                    If last_dict_return_res1 Is Nothing Then
                        Dim dict_return_res1b As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
                        dict_return_res1b("error1") = "yes"
                        dict_return_res1b("min_dist_diff_height1") = min_dist_diff_height1

                        CGlobals1.add_to_txt_log1("end_find_polynom_coeafs1-err1")

                        Return dict_return_res1b
                    End If
                    Try
                        dict_polynom_res2b = last_dict_return_res1("dict_polynom_res2")

                    Catch ex As Exception

                        Dim dict_return_res1b As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
                        dict_return_res1b("error1") = "yes"
                        dict_return_res1b("min_dist_diff_height1") = min_dist_diff_height1
                        CGlobals1.add_to_txt_log1("end_find_polynom_coeafs1-err2")
                        Return dict_return_res1b
                    End Try



                    CGlobals1.add_to_txt_log1("end_find_polynom_coeafs2")

                    Dim polynom_curve1a As ArrayList = last_dict_return_res1("polynom_curve1a")
                    Dim curve_ind1 As Integer = dict_prms1("curve_ind1")
                    polynom_curve1a = rotate_curve_vertical1(polynom_curve1a)

                    polynom_curve1a = move_left_botton_curve_to_cord_xy1(polynom_curve1a, New Double() {100, 100})

                    Dim y_val1a As Double = init_polynom1.get_y_val1(dict_polynom_res2b("end_x_val1") + width_of_curve1)
                    Dim y_val2a As Double = init_polynom1.get_y_val1(dict_polynom_res2b("end_x_val1"))

                    Dim bmp1a As Bitmap = CGlobals1.create_fill_bitmap(1500, 1000, Color.FromArgb(255, 255, 255))
                    CGlobals1.form_obj1.markingfldimg_obj1.set_double_pixel_arr_on_bmp2(polynom_curve1a, bmp1a, Color.FromArgb(200, 30, 70))
                    bmp1a.Save(CGlobals1.global_path1 + "sobel_pics1\c1a_" + curve_ind1.ToString() + ".bmp")

                    Dim curve_pxls_arr1a As ArrayList = last_dict_return_res1("curve_pxls_arr1")
                    curve_pxls_arr1a = move_left_botton_curve_to_cord_xy1(curve_pxls_arr1a, New Double() {100, 105})
                    Dim bmp1b As Bitmap = CGlobals1.create_fill_bitmap(1500, 1000, Color.FromArgb(255, 255, 255))
                    CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(curve_pxls_arr1, bmp1a, Color.FromArgb(40, 40, 250))


                    bmp1a.Save(CGlobals1.global_path1 + "sobel_pics1\c2a_" + curve_ind1.ToString() + ".bmp")


                    'CGlobals1.add_to_txt_log2("create_polynom_objs_count1=" + create_polynom_objs_count1.ToString())

                    Return last_dict_return_res1




                    Dim dict_return_res1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
                    dict_return_res1("error1") = "yes"
                    dict_return_res1("min_dist_diff_height1") = min_dist_diff_height1
                    Return dict_return_res1
                End If
                add_coef_factor1 /= 2
            End If

            If loop_ind1 > max_loop_count1 Then

                CGlobals1.add_to_txt_log1("end_find_polynom_coeafs3")


                Dim dict_polynom_res2b As Dictionary(Of String, Object)

                Try
                    If last_dict_return_res1 IsNot Nothing Then
                        dict_polynom_res2b = last_dict_return_res1("dict_polynom_res2")
                    Else
                        Dim dict_return_res_err1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
                        dict_return_res_err1("error1") = "yes"
                        dict_return_res_err1("error_type1") = "loop"
                        dict_return_res_err1("min_dist_diff_height1") = min_dist_diff_height1
                        Return dict_return_res_err1

                    End If

                Catch ex As Exception


                    Dim dict_return_res_err1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
                    dict_return_res_err1("error1") = "yes"
                    dict_return_res_err1("error_type1") = "loop"
                    dict_return_res_err1("min_dist_diff_height1") = min_dist_diff_height1
                    Return dict_return_res_err1

                    Dim d34 As Integer = 1
                End Try

                Dim polynom_curve1a As ArrayList = last_dict_return_res1("polynom_curve1a")
                Dim curve_ind1 As Integer = dict_prms1("curve_ind1")
                polynom_curve1a = rotate_curve_vertical1(polynom_curve1a)

                polynom_curve1a = move_left_botton_curve_to_cord_xy1(polynom_curve1a, New Double() {100, 100})

                Dim y_val1a As Double = init_polynom1.get_y_val1(dict_polynom_res2b("end_x_val1") + width_of_curve1)
                Dim y_val2a As Double = init_polynom1.get_y_val1(dict_polynom_res2b("end_x_val1"))

                Dim bmp1a As Bitmap = CGlobals1.create_fill_bitmap(1500, 1000, Color.FromArgb(255, 255, 255))
                CGlobals1.form_obj1.markingfldimg_obj1.set_double_pixel_arr_on_bmp2(polynom_curve1a, bmp1a, Color.FromArgb(200, 30, 70))
                bmp1a.Save(CGlobals1.global_path1 + "sobel_pics1\c1a_" + curve_ind1.ToString() + ".bmp")

                Dim curve_pxls_arr1a As ArrayList = last_dict_return_res1("curve_pxls_arr1")
                curve_pxls_arr1a = move_left_botton_curve_to_cord_xy1(curve_pxls_arr1a, New Double() {100, 105})
                Dim bmp1b As Bitmap = CGlobals1.create_fill_bitmap(1500, 1000, Color.FromArgb(255, 255, 255))
                CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(curve_pxls_arr1, bmp1a, Color.FromArgb(40, 40, 250))


                bmp1a.Save(CGlobals1.global_path1 + "sobel_pics1\c2a_" + curve_ind1.ToString() + ".bmp")


                'CGlobals1.add_to_txt_log2("create_polynom_objs_count1=" + create_polynom_objs_count1.ToString())

                Return last_dict_return_res1

                Dim dict_return_res1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
                dict_return_res1("error1") = "yes"
                dict_return_res1("error_type1") = "loop"
                dict_return_res1("min_dist_diff_height1") = min_dist_diff_height1
                Return dict_return_res1

            End If
        End While

        'init_polynom1.get_derivative1()
        Dim polynom_curve1 As ArrayList = create_curve_from_polynom1(init_polynom1, last_end_x_polynom1 + width_of_curve1, last_end_x_polynom1, width_of_curve1)
        If search_mode1 = "only_start_derivate1" Then
            polynom_curve1 = create_curve_from_polynom1(init_polynom1, last_end_x_polynom1, last_end_x_polynom1 - width_of_curve1, width_of_curve1)
            Dim last_derivative1 As Double = init_polynom1.get_derivative1(last_end_x_polynom1 - width_of_curve1)
            Dim d7 As Integer = 1
        End If
        Dim ind3 As Integer

        For ind3 = 0 To polynom_curve1.Count - 1
            'polynom_curve1(ind3) = (300 + CGlobals1.get_cord_xy_in_pixels_arr1(polynom_curve1, ind3)(0)).ToString() + "," + (300 + CGlobals1.get_cord_xy_in_pixels_arr1(polynom_curve1, ind3)(1)).ToString()
            polynom_curve1(ind3) = (300 + ind3).ToString() + "," + (300 + CGlobals1.get_cord_xy_in_pixels_arr1(polynom_curve1, ind3)(1)).ToString()
        Next

        Dim bmp1 As Bitmap = CGlobals1.create_fill_bitmap(1500, 1000, Color.FromArgb(255, 255, 255))
        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(polynom_curve1, bmp1, Color.FromArgb(200, 30, 70))
        bmp1.Save(CGlobals1.global_path1 + "sobel_pics1\c1a.bmp")

        Dim bmp2 As Bitmap = CGlobals1.create_fill_bitmap(1500, 1000, Color.FromArgb(255, 255, 255))
        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(curve_pxls_arr1, bmp2, Color.FromArgb(200, 30, 70))
        bmp2.Save(CGlobals1.global_path1 + "sobel_pics1\c1b.bmp")

        Dim d3 As Integer = 1
    End Function


    Public Function create_result_for_polynom1(init_polynom1 As CPolynom2, last_end_x_polynom1 As Double, new_width_of_curve1 As Integer, curve_pxls_arr1 As ArrayList)
        'last_end_x_polynom1 = dict_polynom_res2("end_x_val1")
        'init_polynom1 = dict_polynom_res2("polynom_obj1")
        Dim dict_return_res1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
        dict_return_res1("polynom_obj1") = init_polynom1
        dict_return_res1("last_end_x_polynom1") = last_end_x_polynom1


        'dict_return_res1("min_dist_from_curve1") = min_dist_from_curve1


        Dim end_derivative2 As Double = init_polynom1.get_derivative1(last_end_x_polynom1 + new_width_of_curve1 + 1)
        dict_return_res1("end_derivative2") = end_derivative2
        Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, 0)
        Dim cord_xy2 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, new_width_of_curve1)
        Dim height_of_new_curve1 As Integer = cord_xy1(1) - cord_xy2(1)

        Dim last_y_val_polynom1 As Double = init_polynom1.get_y_val1(last_end_x_polynom1)
        Dim start_y_val_polynom1 As Double = init_polynom1.get_y_val1(last_end_x_polynom1 + new_width_of_curve1)
        Dim height_of_new_polynom1 As Double = start_y_val_polynom1 - last_y_val_polynom1
        '***dict_return_res1("polynom_curve1a") = polynom_curve1a


        dict_return_res1("min_diff_h1") = height_of_new_polynom1 - height_of_new_curve1 'min_diff_h1

        dict_return_res1("width_of_curve1") = new_width_of_curve1


        dict_return_res1("height_of_curve1") = height_of_new_curve1
        'dict_return_res1("search_mode1") = search_mode1
        dict_return_res1("search_mode1") = "only_start_derivate1"
        Return dict_return_res1
    End Function

    Public Function search_for_last_ind1(dict_min_derivative As Dictionary(Of Integer, Double), start_ind1 As Integer, delta_add_last_ind1 As Integer, frame_pixels_arr1 As ArrayList, last_delta_height1 As Double)


        Dim last_ind1 As Integer = start_ind1 + delta_add_last_ind1
        Dim start_imd_derivate1 As Double
        Try
            start_imd_derivate1 = dict_min_derivative(start_ind1)
        Catch ex As Exception
            Dim err1 As Integer = 1
        End Try
        Try
            While start_imd_derivate1 <= dict_min_derivative(last_ind1)
                last_ind1 += 1
            End While

        Catch ex As Exception
            last_ind1 = dict_min_derivative.Keys(dict_min_derivative.Keys.Count - 1)

        End Try

        Dim curve_pxls_arr1 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, start_ind1, last_ind1)


        Dim cord_xy_start1b As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, 0)
        Dim cord_xy_end1b As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, curve_pxls_arr1.Count - 1)

        Dim m1b As Double = -(cord_xy_start1b(1) - cord_xy_end1b(1) - last_delta_height1) / (cord_xy_start1b(0) - cord_xy_end1b(0))

        While m1b > dict_min_derivative(start_ind1)
            curve_pxls_arr1 = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, start_ind1, last_ind1)


            cord_xy_start1b = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, 0)
            cord_xy_end1b = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, curve_pxls_arr1.Count - 1)

            m1b = -(cord_xy_start1b(1) - cord_xy_end1b(1) - last_delta_height1) / (cord_xy_start1b(0) - cord_xy_end1b(0))
            last_ind1 += 1

            If last_ind1 >= frame_pixels_arr1.Count Then

                Return (frame_pixels_arr1.Count - 1)
                Dim err1 As Integer = 1
            End If
        End While

        'last_ind1 += 5

        If last_ind1 >= frame_pixels_arr1.Count Then
            last_ind1 = frame_pixels_arr1.Count - 1
        End If
        Return last_ind1
    End Function

    Public Function set_cur_path_of_curve1()
        cur_path_ind1 = -1
        For path_ind1 = 0 To 8
            path_arr1(path_ind1) = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + suffix_path_arr1(path_ind1)
            If suffix_path_arr1(path_ind1) = suffix_path1 Then
                cur_path_ind1 = path_ind1
            End If

        Next
    End Function


    Public Function find_first_turn_pixel_point1(turn_pxl_point_num1 As Integer)

        Dim path1 As String = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + suffix_path1


        Dim path2 As String = CGlobals1.get_current_glass_folder1()

        Dim frame_pixels_arr1 As ArrayList = CGlobals1.form_obj1.markingfldimg_obj1.load_2d_pixels_arr1(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_frame4.txt")

        If turn_pxl_point_num1 = 2 Then
            frame_pixels_arr1 = flip_curve_horizontal1(frame_pixels_arr1)
            frame_pixels_arr1.Reverse()

        End If

        'Dim curve_pxls_arr1 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, curve_start_ind1, last_right_ind1)


        'curve_pxls_arr1 = single_pixel_in_every_x_min_y(curve_pxls_arr1)

        Dim bmp5 As Bitmap = CGlobals1.create_fill_bitmap(4000, 3000, Color.FromArgb(255, 255, 255))
        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(frame_pixels_arr1, bmp5, Color.FromArgb(24, 230, 50))
        bmp5.Save(path1 + "\" + "frame4a.bmp")



        Dim dict_rect_frame1 As Dictionary(Of String, Object) = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(frame_pixels_arr1)


        Dim center_x1 As Integer = (dict_rect_frame1("min_x1") + dict_rect_frame1("max_x1")) / 2

        Dim ind1 As Integer = 0

        While CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1, ind1)(0) < center_x1
            ind1 += 1
        End While


        Dim ind2 As Integer = ind1 + 2

        While CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1, ind2)(0) > center_x1
            ind2 += 1
        End While
        Dim right_frame1 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, ind1, ind2)

        frame_pixels_arr1 = right_frame1




        bmp5 = CGlobals1.create_fill_bitmap(4000, 3000, Color.FromArgb(255, 255, 255))
        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(frame_pixels_arr1, bmp5, Color.FromArgb(24, 230, 50))
        bmp5.Save(path1 + "\" + "curve_turn_pixel1a.bmp")

        Dim dict_rect_frame2 As Dictionary(Of String, Object) = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(frame_pixels_arr1)

        Dim top_y1 As Integer = dict_rect_frame2("min_y1")



        Dim ind3 As Integer = 0

        While CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1, ind3)(1) > top_y1
            ind3 += 1
        End While

        frame_pixels_arr1 = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, 0, ind3)


        frame_pixels_arr1 = clear_curve_by_monotonic_down1(frame_pixels_arr1)


        bmp5 = CGlobals1.create_fill_bitmap(4000, 3000, Color.FromArgb(255, 255, 255))
        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(frame_pixels_arr1, bmp5, Color.FromArgb(24, 230, 50))
        bmp5.Save(path1 + "\" + "curve_turn_pixel2.bmp")

        Dim pxl_driv_ind1 As Integer
        Dim deriv_arr1 As ArrayList = New ArrayList()

        Dim start_m1 As Double = 2
        Dim deriv_dict1 As Dictionary(Of Integer, Double) = New Dictionary(Of Integer, Double)
        Dim derivs_str1 As String = ""

        If System.IO.File.Exists(path1 + "\deriv_for_turn_pixel" + turn_pxl_point_num1.ToString() + ".txt") = True Then
            derivs_str1 = System.IO.File.ReadAllText(path1 + "\deriv_for_turn_pixel" + turn_pxl_point_num1.ToString() + ".txt")
            Dim str_val1 As String() = derivs_str1.Split("#")

            Dim i2 As Integer

            For i2 = 0 To str_val1.Count - 2
                Dim str_val2 As String() = str_val1(i2).Split(",")
                deriv_dict1(Integer.Parse(str_val2(0))) = Double.Parse(str_val2(1))
            Next
        Else


            For pxl_driv_ind1 = 5 To frame_pixels_arr1.Count - 20

                Dim derivative1 As Double = compute_derivate_of_pixel_on_curve2(frame_pixels_arr1, pxl_driv_ind1, 500, 10, 0.01, start_m1)
                deriv_dict1(pxl_driv_ind1) = derivative1
                start_m1 = derivative1 + 1
                deriv_arr1.Add(derivative1)
                CGlobals1.add_to_txt_log1("d(" + pxl_driv_ind1.ToString() + ")=" + derivative1.ToString())
                derivs_str1 += pxl_driv_ind1.ToString() + "," + derivative1.ToString() + "#"
            Next
            System.IO.File.WriteAllText(path1 + "\deriv_for_turn_pixel" + turn_pxl_point_num1.ToString() + ".txt", derivs_str1)
        End If

        Dim sorted1 = From pair In deriv_dict1
                      Order By pair.Value
        Dim sortedDictionary1 As Dictionary(Of Integer, Double) = sorted1.ToDictionary(Function(p) p.Key, Function(p) p.Value)

        Dim i3 As Integer

        Dim max_ind1 As Integer = -1
        For i3 = sortedDictionary1.Keys.Count - 10 To sortedDictionary1.Keys.Count - 1
            If max_ind1 < sortedDictionary1.Keys(i3) Then
                max_ind1 = sortedDictionary1.Keys(i3)
            End If
        Next

        Dim turn_pxl_point_cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1, max_ind1)

        CGlobals1.draw_sqr_around_pixels2(bmp5, turn_pxl_point_cord_xy1(0), turn_pxl_point_cord_xy1(1), 2, Color.FromArgb(100, 100, 120))

        bmp5.Save(path1 + "\" + "curve_turn_pixel" + turn_pxl_point_num1.ToString() + ".bmp")


        Dim slice1 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, 0, max_ind1)
        Dim slice2 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, max_ind1, frame_pixels_arr1.Count - 1)
        'Dim s1 As Double = sortedDictionary1.Keys(CType(sortedDictionary2.Keys.Count * 0.4, Integer))


        Dim dict_ret_res1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)

        dict_ret_res1("slice1") = slice1
        dict_ret_res1("slice2") = slice2
        dict_ret_res1("max_ind1") = max_ind1
        dict_ret_res1("start_derivative1") = sortedDictionary1(max_ind1)
        Return dict_ret_res1
    End Function


    Public Function find_turn_pixels_points()

        Dim path1 As String = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "compute_turn_pixels_points"
        CGlobals1.create_folder1(path1)
        Dim frame_pixels_arr1 As ArrayList = CGlobals1.form_obj1.markingfldimg_obj1.load_2d_pixels_arr1(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_frame4.txt")


        'Dim curve_pxls_arr1 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, curve_start_ind1, last_right_ind1)


        'curve_pxls_arr1 = single_pixel_in_every_x_min_y(curve_pxls_arr1)

        Dim bmp5 As Bitmap = CGlobals1.create_fill_bitmap(4000, 3000, Color.FromArgb(255, 255, 255))
        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(frame_pixels_arr1, bmp5, Color.FromArgb(24, 230, 50))
        bmp5.Save(path1 + "\" + "right_frame1.bmp")



        Dim dict_rect_frame1 As Dictionary(Of String, Object) = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(frame_pixels_arr1)


        Dim center_x1 As Integer = (dict_rect_frame1("min_x1") + dict_rect_frame1("max_x1")) / 2

        Dim ind1 As Integer = 0

        While CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1, ind1)(0) < center_x1
            ind1 += 1
        End While


        Dim ind2 As Integer = ind1 + 2

        While CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1, ind2)(0) > center_x1
            ind2 += 1
        End While
        Dim right_frame1 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, ind1, ind2)

        Dim rect_dict1 As Dictionary(Of String, Object) = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(right_frame1)
        Dim top_ind1 As Integer
        Dim top_ind2 As Integer

        top_ind1 = 0

        While CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, top_ind1)(1) > rect_dict1("min_y1")
            top_ind1 += 1
        End While

        top_ind2 = top_ind1
        While CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, top_ind2)(1) = rect_dict1("min_y1")
            top_ind2 += 1
        End While


        bmp5 = CGlobals1.create_fill_bitmap(4000, 3000, Color.FromArgb(255, 255, 255))
        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(right_frame1, bmp5, Color.FromArgb(24, 230, 50))
        bmp5.Save(path1 + "\" + "right_frame2.bmp")

        Dim dervative_ind1 As Integer

        Dim dict_deriv_val1 As Dictionary(Of Integer, Double) = New Dictionary(Of Integer, Double)
        For dervative_ind1 = 1715 To 1900
            Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, dervative_ind1)
            Dim cord_xy2 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, dervative_ind1 + 2)


            ' 3 | 0
            ' 2 | 1
            Dim sqr_num1 As Integer = 0

            Dim deriv_val1 As Double = 0

            If cord_xy2(0) > cord_xy1(0) And cord_xy2(1) = cord_xy1(1) Then

                deriv_val1 = 0
            ElseIf cord_xy2(0) = cord_xy1(0) And cord_xy2(1) > cord_xy1(1) Then

                deriv_val1 = 90
            ElseIf cord_xy2(0) < cord_xy1(0) And cord_xy2(1) = cord_xy1(1) Then

                deriv_val1 = 180
            ElseIf cord_xy2(0) = cord_xy1(0) And cord_xy2(1) < cord_xy1(1) Then

                deriv_val1 = 270
            ElseIf cord_xy2(0) > cord_xy1(0) And cord_xy2(1) > cord_xy1(1) Then
                    sqr_num1 = 1
                ElseIf cord_xy2(0) < cord_xy1(0) And cord_xy2(1) > cord_xy1(1) Then
                    sqr_num1 = 2
                ElseIf cord_xy2(0) < cord_xy1(0) And cord_xy2(1) > cord_xy1(1) Then
                    sqr_num1 = 3
            End If


            Dim deriv1 As Double = Math.Atan((cord_xy1(1) - cord_xy2(1)) / (cord_xy1(0) - cord_xy2(0))) * 180.0 / Math.PI
            dict_deriv_val1(dervative_ind1) = deriv1


            'For deriv_val1 = 0 To 999
            'Dim m2 As Double = check_dist_curve_with_line_m2(right_frame1, dervative_ind1, dervative_ind1 + 5, 2, 1, deriv_val1, "")
            'dcit_deriv_val1(deriv_val1) = m2
            'Next
        Next
        Dim first_ind1 As Integer = 0
        Dim last_ind1 As Integer = first_ind1 + 10

        Dim to_stop1 As Integer = 0
        Dim last_dir1 As String = ""
        Dim percent_dir1 As Double = 0
        Dim max_dist_above1 As Double = 0
        Dim max_dist_below1 As Double = 0

        Dim max_dist_above_ind1 As Double = 0
        Dim max_dist_below_ind1 As Double = 0

        While to_stop1 = 0
            Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, first_ind1)
            Dim cord_xy2 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, last_ind1)


            Dim vec_3d_obj1 As vec_3d1 = New vec_3d1()
            vec_3d_obj1.p1 = New point_3d1()
            vec_3d_obj1.p1.x1 = cord_xy1(0)
            vec_3d_obj1.p1.y1 = cord_xy1(1)


            vec_3d_obj1.p2 = New point_3d1()
            vec_3d_obj1.p2.x1 = cord_xy1(0)
            vec_3d_obj1.p2.y1 = cord_xy1(1)
            vec_3d_obj1.p2.z1 = -10

            Dim rot_angle1 As Double = Math.Atan((cord_xy2(1) - cord_xy1(1)) / (cord_xy2(0) - cord_xy1(0))) * 180.0 / Math.PI

            Dim rot_right_frame1 As ArrayList = CGlobals1.form_obj1.markingfldimg_obj1.rotate_2d_pixels_arr(right_frame1, vec_3d_obj1, -rot_angle1)




            Dim count_above1 As Integer = 0
            Dim count_equal1 As Integer = 0
            Dim count_below1 As Integer = 0

            Dim ind3 As Integer
            For ind3 = first_ind1 To last_ind1
                Dim cord_xy3 As Double() = CGlobals1.get_double_cord_xy_in_pixels_arr2(rot_right_frame1, ind3)
                If cord_xy3(1) > cord_xy1(1) Then
                    If max_dist_below1 < (cord_xy3(1) - cord_xy1(1)) Then
                        max_dist_below1 = (cord_xy3(1) - cord_xy1(1))
                        max_dist_above_ind1 = ind3
                    End If
                    count_below1 += 1
                ElseIf cord_xy3(1) = cord_xy1(1) Then
                    count_equal1 += 1
                Else
                    If max_dist_above1 < (cord_xy1(1) - cord_xy3(1)) Then
                        max_dist_above1 = (cord_xy1(1) - cord_xy3(1))
                        max_dist_below_ind1 = ind3
                    End If
                    count_above1 += 1
                End If
            Next

            If count_below1 < count_above1 Then
                If last_dir1 = "" Then
                    last_dir1 = "above"
                    percent_dir1 = count_below1 / count_above1
                End If
            End If

            If count_below1 > count_above1 Then
                If last_dir1 = "" Then
                    last_dir1 = "below"
                    percent_dir1 = count_above1 / count_below1
                End If

            End If

            If last_dir1 = "above" Then
                percent_dir1 = count_below1 / count_above1

            End If

            If last_dir1 = "below" Then
                percent_dir1 = count_above1 / count_below1

            End If

            last_ind1 += 1
            Dim d1 As Integer = 1

            If last_ind1 = top_ind1 Then
                bmp5 = CGlobals1.create_fill_bitmap(4000, 3000, Color.FromArgb(255, 255, 255))
                CGlobals1.form_obj1.markingfldimg_obj1.set_double_pixel_arr_on_bmp2(right_frame1, bmp5, Color.FromArgb(24, 230, 50))
                CGlobals1.draw_sqr_around_pixels2(bmp5, CGlobals1.get_double_cord_xy_in_pixels_arr2(right_frame1, max_dist_above_ind1)(0), CGlobals1.get_double_cord_xy_in_pixels_arr2(right_frame1, max_dist_above_ind1)(1), 2, Color.FromArgb(200, 40, 100))
                bmp5.Save(path1 + "\" + "rot_right_frame2.bmp")
                to_stop1 = 1
            End If
            'Dim rot_pixels_arr1 As ArrayList = rotate_2d_pixels_arr(pixel_arr1, vec_3d_obj1, rot_angle1)
        End While

    End Function
    Public Function cut_slice_of_curve1()

        'Public suffix_path_arr1 As String() = {"_front_top_0_frame1", "_front_top_1_frame1", "_front_top_2_frame1", "_front_right_1_frame1", "_front_right_2_frame1", "_front_bottom_1_frame1", "_front_bottom_2_frame1", "_front_bottom_3_frame1", "_front_bottom_4_frame1"}



        Dim path1 As String = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + suffix_path1

        set_cur_path_of_curve1()



        Dim frame_pixels_arr1 As ArrayList = CGlobals1.form_obj1.markingfldimg_obj1.load_2d_pixels_arr1(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_frame4.txt")


        'Dim curve_pxls_arr1 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, curve_start_ind1, last_right_ind1)


        'curve_pxls_arr1 = single_pixel_in_every_x_min_y(curve_pxls_arr1)

        Dim bmp5 As Bitmap = CGlobals1.create_fill_bitmap(4000, 3000, Color.FromArgb(255, 255, 255))
        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(frame_pixels_arr1, bmp5, Color.FromArgb(24, 230, 50))
        bmp5.Save(path1 + "\" + "frame4a.bmp")



        Dim dict_rect_frame1 As Dictionary(Of String, Object) = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(frame_pixels_arr1)


        Dim center_x1 As Integer = (dict_rect_frame1("min_x1") + dict_rect_frame1("max_x1")) / 2

        Dim ind1 As Integer = 0

        While CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1, ind1)(0) < center_x1
            ind1 += 1
        End While


        Dim ind2 As Integer = ind1 + 2

        While CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1, ind2)(0) > center_x1
            ind2 += 1
        End While
        Dim right_frame1 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, ind1, ind2)

        Dim dict_rect_right_frame1 As Dictionary(Of String, Object) = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(right_frame1)

        Dim vec_3d_obj1 As vec_3d1 = New vec_3d1()
        vec_3d_obj1.p1 = New point_3d1()
        vec_3d_obj1.p1.x1 = (dict_rect_right_frame1("min_x1") + dict_rect_right_frame1("max_x1")) / 2
        vec_3d_obj1.p1.y1 = (dict_rect_right_frame1("min_y1") + dict_rect_right_frame1("max_y1")) / 2


        vec_3d_obj1.p2 = New point_3d1()
        vec_3d_obj1.p2.x1 = (dict_rect_right_frame1("min_x1") + dict_rect_right_frame1("max_x1")) / 2
        vec_3d_obj1.p2.y1 = (dict_rect_right_frame1("min_y1") + dict_rect_right_frame1("max_y1")) / 2
        vec_3d_obj1.p2.z1 = -10



        If suffix_path1 = "_front_top_2_frame1" Then

        End If


        If suffix_path1 = "_front_right_2_frame1" Or suffix_path1 = "_front_right_1_frame1" Then
            right_frame1 = CGlobals1.form_obj1.markingfldimg_obj1.rotate_2d_pixels_arr(right_frame1, vec_3d_obj1, -90)

        End If

        If suffix_path1 = "_front_bottom_1_frame1" Or suffix_path1 = "_front_bottom_2_frame1" Then
            right_frame1 = CGlobals1.form_obj1.markingfldimg_obj1.rotate_2d_pixels_arr(right_frame1, vec_3d_obj1, -180)

        End If
        If suffix_path1 = "_front_bottom_3_frame1" Then
            right_frame1 = CGlobals1.form_obj1.markingfldimg_obj1.rotate_2d_pixels_arr(right_frame1, vec_3d_obj1, -270)
        End If


        If suffix_path1 = "_front_bottom_4_frame1" Then
            right_frame1 = CGlobals1.form_obj1.markingfldimg_obj1.rotate_2d_pixels_arr(right_frame1, vec_3d_obj1, -90)
        End If


        Dim dict_rect_right_frame2 As Dictionary(Of String, Object) = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(right_frame1)


        right_frame1 = CGlobals1.form_obj1.markingfldimg_obj1.move_pixels_arr1(right_frame1, 0, -dict_rect_right_frame2("min_y1") + 10)

        bmp5 = CGlobals1.create_fill_bitmap(4000, 3000, Color.FromArgb(255, 255, 255))
        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(right_frame1, bmp5, Color.FromArgb(24, 230, 50))

        bmp5.Save(path1 + "\" + "frame4b.bmp")





        Dim dict_rect_frame2 As Dictionary(Of String, Object) = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(right_frame1)

        Dim ind3 As Integer = 0

        While CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, ind3)(1) > dict_rect_frame2("min_y1")
            ind3 += 1
        End While



        Dim ind4 As Integer = ind3

        While CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, ind4)(1) = dict_rect_frame2("min_y1")
            ind4 += 1
        End While


        Dim center_top_ind1 As Integer = (ind3 + ind4) / 2





        If suffix_path1 = "_front_top_1_frame1" Or suffix_path1 = "_front_right_1_frame1" Or suffix_path1 = "_front_bottom_1_frame1" Then
            System.IO.File.WriteAllText(path1 + "\center_top_ind1.txt", center_top_ind1.ToString())
        End If


        bmp5 = CGlobals1.create_fill_bitmap(4000, 3000, Color.FromArgb(255, 255, 255))
        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(right_frame1, bmp5, Color.FromArgb(24, 230, 50))

        bmp5.Save(path1 + "\" + "right_frame1c.bmp")

        If suffix_path1 = "_front_bottom_3_frame1" Then
            center_top_ind1 = right_frame1.Count - 1
        End If




        Dim dict_res1 As Dictionary(Of String, Object) = find_45_degree_ind_from_curve_pxl_arr_by_long_seq_45_1(right_frame1, center_top_ind1, -1)



        'Dim dict_res1 As Dictionary(Of String, Object) = find_45_degree_ind_from_curve_pxl_arr1(right_frame1, center_top_ind1, -1)



        Dim first_ind_derivative_45_1 As Integer = dict_res1("first_ind_derivative_45")
        Dim last_ind_derivative_45_1 As Integer = dict_res1("last_ind_derivative_45")

        Dim left_pxl_ind1 As Integer = (first_ind_derivative_45_1 + last_ind_derivative_45_1) / 2


        If suffix_path1 = "_front_top_2_frame1" Then
            left_pxl_ind1 = Integer.Parse(System.IO.File.ReadAllText(path_arr1(1) + "\right_pxl_ind1.txt"))

        End If
        'If cur_path_ind1 = 2 Then
        'left_pxl_ind1 = Integer.Parse(System.IO.File.ReadAllText(path_arr1(1) + "\right_pxl_ind1.txt"))
        'End If


        If suffix_path1 = "_front_right_2_frame1" Then
            left_pxl_ind1 = Integer.Parse(System.IO.File.ReadAllText(path_arr1(3) + "\right_pxl_ind1.txt"))
        End If

        If suffix_path1 = "_front_bottom_2_frame1" Then
            left_pxl_ind1 = Integer.Parse(System.IO.File.ReadAllText(path_arr1(3) + "\right_pxl_ind1.txt"))
        End If



        'If cur_path_ind1 = 4 Then
        'left_pxl_ind1 = Integer.Parse(System.IO.File.ReadAllText(path_arr1(3) + "\right_pxl_ind1.txt"))
        'End If

        System.IO.File.WriteAllText(path1 + "\left_pxl_ind1.txt", left_pxl_ind1.ToString())

        'Dim dict_res2 As Dictionary(Of String, Object) = find_45_degree_ind_from_curve_pxl_arr1(right_frame1, center_top_ind1, 1)
        Dim dict_res2 As Dictionary(Of String, Object) = find_45_degree_ind_from_curve_pxl_arr_by_long_seq_45_1(right_frame1, center_top_ind1, 1)



        Dim first_ind_derivative_45_2 As Integer = dict_res2("first_ind_derivative_45")
        Dim last_ind_derivative_45_2 As Integer = dict_res2("last_ind_derivative_45")
        Dim right_pxl_ind1 As Integer = (first_ind_derivative_45_2 + last_ind_derivative_45_2) / 2

        If suffix_path1 = "_front_bottom_2_frame1" Then
            right_pxl_ind1 -= 10
        End If

        System.IO.File.WriteAllText(path1 + "\right_pxl_ind1.txt", right_pxl_ind1.ToString())

        If suffix_path1 = "_front_bottom_3_frame1" Then
            left_pxl_ind1 = Integer.Parse(System.IO.File.ReadAllText(path_arr1(CGlobals1.form_obj1.inds_orders_arr1(CGlobals1.form_obj1.curve_ind1 - 1)) + "\right_pxl_ind1.txt"))
        End If


        Dim left_curve_pxl_arr1 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(right_frame1, left_pxl_ind1, center_top_ind1)
        Dim right_curve_pxl_arr1 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(right_frame1, center_top_ind1, right_pxl_ind1)



        bmp5 = CGlobals1.create_fill_bitmap(4000, 3000, Color.FromArgb(255, 255, 255))
        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(left_curve_pxl_arr1, bmp5, Color.FromArgb(24, 230, 50))



        bmp5.Save(path1 + "\" + "left_curve_pxl_arr1.bmp")

        bmp5 = CGlobals1.create_fill_bitmap(4000, 3000, Color.FromArgb(255, 255, 255))
        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(right_curve_pxl_arr1, bmp5, Color.FromArgb(24, 230, 50))

        bmp5.Save(path1 + "\" + "right_curve_pxl_arr1.bmp")


        'Dim dict_ret_res1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)

        'dict_ret_res1("first_ind_derivative_45") = first_ind_derivative_45
        'dict_ret_res1("last_ind_derivative_45") = last_ind_derivative_45
        right_curve_pxl_arr1 = flip_curve_vertical1(right_curve_pxl_arr1)
        right_curve_pxl_arr1.Reverse()

        bmp5 = CGlobals1.create_fill_bitmap(4000, 3000, Color.FromArgb(255, 255, 255))
        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(right_curve_pxl_arr1, bmp5, Color.FromArgb(24, 230, 50))

        bmp5.Save(path1 + "\" + "right_curve4b.bmp")



        If suffix_path1 = "_front_bottom_3_frame1" Then
            'Dim first_turn_point1 As Integer = find_first_turn_pixel_point1(1)

            Dim dict_res3 As Dictionary(Of String, Object) = find_first_turn_pixel_point1(2)
            Dim end_ind1 As Integer = right_frame1.Count - dict_res3("max_ind1")
            Dim start_curve_deriv_45 As Double = Integer.Parse(System.IO.File.ReadAllText(path_arr1(CGlobals1.form_obj1.inds_orders_arr1(CGlobals1.form_obj1.curve_ind1 - 1)) + "\right_pxl_ind1.txt"))
            right_frame1 = CGlobals1.get_arr_from_ind_to_ind1(right_frame1, start_curve_deriv_45, end_ind1)


            System.IO.File.WriteAllText(path1 + "\turn_pixel_ind1.txt", end_ind1.ToString())
            Return right_frame1
        End If


        If suffix_path1 = "_front_bottom_4_frame1" Then
            Dim end_ind1 As Integer = Integer.Parse(System.IO.File.ReadAllText(path_arr1(CGlobals1.form_obj1.inds_orders_arr1(CGlobals1.form_obj1.curve_ind1 - 1)) + "\turn_pixel_ind1.txt"))
            Dim bottom_4_frame1 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(right_frame1, end_ind1, right_frame1.Count - 1)
            bottom_4_frame1 = flip_curve_vertical1(bottom_4_frame1)
            bmp5 = CGlobals1.create_fill_bitmap(4000, 3000, Color.FromArgb(255, 255, 255))
            CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(bottom_4_frame1, bmp5, Color.FromArgb(24, 230, 50))



            bmp5.Save(path1 + "\" + "bottom_4_frame1.bmp")
            'bottom_4_frame1.Reverse()
            Dim dict_res3 As Dictionary(Of String, Object) = find_45_degree_ind_from_curve_pxl_arr_by_long_seq_45_1(bottom_4_frame1, 0, 1)


            bottom_4_frame1 = CGlobals1.form_obj1.markingfldimg_obj1.rotate_2d_pixels_arr(bottom_4_frame1, vec_3d_obj1, -90)

            bmp5 = CGlobals1.create_fill_bitmap(4000, 3000, Color.FromArgb(255, 255, 255))
            CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(bottom_4_frame1, bmp5, Color.FromArgb(24, 230, 50))
            bmp5.Save(path1 + "\" + "bottom_4_frame2.bmp")
            'Dim first_turn_point1 As Integer = find_first_turn_pixel_point1(1)

            'Dim dict_res3 As Dictionary(Of String, Object) = find_first_turn_pixel_point1(2)
            'Dim end_ind1 As Integer = right_frame1.Count - dict_res3("max_ind1")
            'Dim start_curve_deriv_45 As Double = Integer.Parse(System.IO.File.ReadAllText(path_arr1(CGlobals1.form_obj1.inds_orders_arr1(CGlobals1.form_obj1.curve_ind1 - 1)) + "\right_pxl_ind1.txt"))
            'right_frame1 = CGlobals1.get_arr_from_ind_to_ind1(right_frame1, start_curve_deriv_45, end_ind1)


            'System.IO.File.WriteAllText(path1 + "\turn_pixel_ind1.txt", end_ind1.ToString())
            'Return right_frame1
        End If




        If suffix_path1 = "_front_top_1_frame1" Then
            'Dim first_turn_point1 As Integer = find_first_turn_pixel_point1(1)

            Dim dict_res3 As Dictionary(Of String, Object) = find_first_turn_pixel_point1(1)
            Dim max_ind1 As Integer = dict_res3("max_ind1")

            right_frame1 = CGlobals1.get_arr_from_ind_to_ind1(right_frame1, max_ind1 - count_remove_start_pxls1, center_top_ind1)

            Return right_frame1
        End If


        If suffix_path1 = "_front_top_0_frame1" Then
            'Dim first_turn_point1 As Integer = find_first_turn_pixel_point1(1)

            Dim dict_res3 As Dictionary(Of String, Object) = find_first_turn_pixel_point1(1)
            Dim max_ind1 As Integer = dict_res3("max_ind1")

            right_frame1 = CGlobals1.get_arr_from_ind_to_ind1(right_frame1, 0, max_ind1 + count_remove_start_pxls1)
            right_frame1 = CGlobals1.form_obj1.markingfldimg_obj1.rotate_2d_pixels_arr(right_frame1, vec_3d_obj1, -180)
            right_frame1.Reverse()
            Return right_frame1
        End If


        If suffix_path1 = "_front_right_1_frame1" Then
            Return left_curve_pxl_arr1
        End If

        If suffix_path1 = "_front_bottom_1_frame1" Then
            Return left_curve_pxl_arr1

        End If


        If suffix_path1 = "_front_top_2_frame1" Then
            Return right_curve_pxl_arr1
        End If
        Return right_curve_pxl_arr1
        Return left_curve_pxl_arr1
    End Function

    Public Function remove_start_pxls1(dict_res1 As Dictionary(Of String, Object))
        Dim dict_ret_res3 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
        Dim derivative_dict1 As Dictionary(Of Integer, Double) = dict_res1("derivatives_arr1")
        Dim new_curve2 As ArrayList = dict_res1("curve_pxls_arr1")

        Dim new_curve3 As ArrayList = New ArrayList()

        Dim ind1 As Integer
        Dim new_derivative_dict1 As Dictionary(Of Integer, Double) = New Dictionary(Of Integer, Double)

        Dim cur_ind1 As Integer = 0
        For ind1 = count_remove_start_pxls1 To new_curve2.Count - 1
            Dim str1 As String() = new_curve2(ind1).ToString().Split(",")
            new_curve3.Add(new_curve2(ind1))
            new_derivative_dict1(cur_ind1) = derivative_dict1(cur_ind1 + count_remove_start_pxls1)
            cur_ind1 += 1
        Next

        dict_ret_res3("derivatives_arr1") = new_derivative_dict1
        dict_ret_res3("curve_pxls_arr1") = new_curve3
        Return dict_ret_res3
    End Function
    Public Function pre_proccessing_curve2()
        Dim path1 As String = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + suffix_path1
        If System.IO.Directory.Exists(path1) = False Then
            System.IO.Directory.CreateDirectory(path1)
            System.IO.Directory.CreateDirectory(path1 + "\data1")
        End If

        Dim derivative_dict1 As Dictionary(Of Integer, Double) = New Dictionary(Of Integer, Double)
        If System.IO.File.Exists(path1 + "\derivs1.txt") Then

            derivative_dict1 = load_derivatives_of_curve1(path1 + "\derivs1.txt")


            Dim new_curve2 As ArrayList = CGlobals1.form_obj1.markingfldimg_obj1.load_2d_pixels_arr1(path1 + "\curve1.txt")

            Dim deriv_ind1 As Integer

            If suffix_path1 = "_front_bottom_3_frame1" Then
                cur_last_derivative_of_curve1 = derivative_dict1(derivative_dict1.Count - 1)

                For deriv_ind1 = derivative_dict1.Count To new_curve2.Count - 1
                    derivative_dict1(deriv_ind1) = derivative_dict1(deriv_ind1 - 1)
                Next

            Else
                For deriv_ind1 = derivative_dict1.Count To new_curve2.Count - 1
                    derivative_dict1(deriv_ind1) = 0
                Next

            End If
            Dim dict_ret_res3 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
            dict_ret_res3("derivatives_arr1") = derivative_dict1
            dict_ret_res3("curve_pxls_arr1") = new_curve2



            Return dict_ret_res3
        End If




        Dim new_curve1 As ArrayList = cut_slice_of_curve1()


        Dim rect_of_curve1 As Dictionary(Of String, Object) = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(new_curve1)
        Dim w1 As Integer = Math.Abs(rect_of_curve1("max_x1") - rect_of_curve1("min_x1")) + 1
        Dim h1 As Integer = Math.Abs(rect_of_curve1("max_y1") - rect_of_curve1("min_y1")) + 1

        If suffix_path1 = "_front_right_1_frame1" Then
            new_curve1 = close_hole_in_curve1(new_curve1, 0, new_curve1.Count - 1)
        End If


        Dim bmp5 As Bitmap = CGlobals1.create_fill_bitmap(4000, 3000, Color.FromArgb(255, 255, 255))
        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(new_curve1, bmp5, Color.FromArgb(24, 230, 50))
        bmp5.Save(path1 + "\" + "close_hole1.bmp")

        new_curve1 = clear_curve_by_monotonic_down1(new_curve1)

        CGlobals1.global_vars_dict1("crop_bmp2_path1") = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_crop1.jpg"
        'new_curve1 = CGlobals1.form_obj1.markingfldimg_obj1.complete_uncomplete_pixels_curve_with_lines(new_curve1)


        'Dim dict_res3 As Dictionary(Of String, Object) = CGlobals1.form_obj1.markingfldimg_obj1.complete_uncomplete_pixels_curve_with_lines(new_curve1)
        'new_curve1 = dict_res3("new_complete_curve1")



        bmp5 = CGlobals1.create_fill_bitmap(4000, 3000, Color.FromArgb(255, 255, 255))
        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(new_curve1, bmp5, Color.FromArgb(24, 230, 50))
        CGlobals1.draw_sqr_around_pixels2(bmp5, CGlobals1.get_cord_xy_in_pixels_arr1(new_curve1, 0)(0), CGlobals1.get_cord_xy_in_pixels_arr1(new_curve1, 0)(1), 2, Color.FromArgb(255, 100, 40))
        bmp5.Save(path1 + "\" + "monotonic_down1.bmp")


        Dim to_stop1 As Integer = 0


        CGlobals1.form_obj1.markingfldimg_obj1.save_2d_pixels_arr1(path1 + "\curve1.txt", new_curve1)

        derivative_dict1 = compute_derivative_of_curve2(new_curve1, path1 + "\derivs1.txt")




        Dim dict_ret_res2 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)


        dict_ret_res2("derivatives_arr1") = derivative_dict1
        dict_ret_res2("curve_pxls_arr1") = new_curve1

        Return dict_ret_res2

    End Function



    Public Function load_derivatives_of_curve1(path1 As String)


        Dim derivative_dict1 As Dictionary(Of Integer, Double) = New Dictionary(Of Integer, Double)

        If System.IO.File.Exists(path1) = True Then

            Dim derivatives_inds_str1 As String = System.IO.File.ReadAllText(path1)
            If derivatives_inds_str1 <> "" Then
                Dim last_derivate_more_the_zero1 As Double = -9999
                Dim derivative_ind1 As Integer
                Dim devivatives_inds1 As String() = derivatives_inds_str1.Split("#")
                derivative_dict1(0) = 1
                For derivative_ind1 = 1 To devivatives_inds1.Length - 2
                    derivative_dict1(Integer.Parse(devivatives_inds1(derivative_ind1).Split(",")(0))) = Double.Parse(devivatives_inds1(derivative_ind1).Split(",")(1))

                    If last_derivate_more_the_zero1 = -9999 Then

                        last_derivate_more_the_zero1 = Double.Parse(devivatives_inds1(derivative_ind1).Split(",")(1))
                    Else
                        If Double.Parse(devivatives_inds1(derivative_ind1).Split(",")(1)) > 0 Then
                            last_derivate_more_the_zero1 = Double.Parse(devivatives_inds1(derivative_ind1).Split(",")(1))
                        End If
                    End If
                Next
            End If



            Return derivative_dict1
        End If

    End Function


    Public Function compute_derivative_of_curve2(new_curve1 As ArrayList, path_to_save As String)

        Dim derivative_dict1 As Dictionary(Of Integer, Double) = New Dictionary(Of Integer, Double)

        Dim pxl_driv_ind1 As Integer = 0
        Dim to_stop1 As Integer = 0
        Dim last_derivatives1 As Double = -9999

        Dim start_measure_ind1 As Integer = 3



        Dim deriv_arr_str1 As String = ""
        Dim start_m2 As Double = 20


        start_m2 = 7

        While to_stop1 = 0

            If pxl_driv_ind1 = 21 Then
                Dim d1 As Integer = 1
            End If

            Dim derivative1_dict1 As Dictionary(Of Integer, Double) = New Dictionary(Of Integer, Double)
            Dim deriv_ind1 As Integer = 0
            Dim cur_start_measure_ind1 As Integer = start_measure_ind1
            Dim derivative1 As Double = 0
            For deriv_ind1 = cur_start_measure_ind1 To 9
                Try
                    derivative1 = compute_derivate_of_pixel_on_curve(new_curve1, pxl_driv_ind1, deriv_ind1, 0.01, start_m2)

                Catch ex As Exception
                    derivative1 = last_derivatives1
                End Try
                derivative1_dict1(deriv_ind1) = derivative1
            Next


            Dim new_start_measure_ind1 As Integer = -1
            For deriv_ind1 = 1 To derivative1_dict1.Keys.Count - 1
                If derivative1_dict1(derivative1_dict1.Keys(deriv_ind1 - 1)) <> derivative1_dict1(derivative1_dict1.Keys(deriv_ind1)) Then

                    If new_start_measure_ind1 = -1 Then
                        new_start_measure_ind1 = derivative1_dict1.Keys(deriv_ind1 - 1)

                    End If

                End If

            Next

            If new_start_measure_ind1 = -1 Then
                new_start_measure_ind1 = derivative1_dict1.Keys(derivative1_dict1.Keys.Count - 1)
            End If
            start_measure_ind1 = new_start_measure_ind1
            Try
                derivative1 = derivative1_dict1(start_measure_ind1)

            Catch ex As Exception
                Dim err1 As Integer = 1
            End Try
            'Dim derivative2 As Double = compute_derivate_of_pixel_on_curve(new_curve1, pxl_driv_ind1, start_measure_ind2, 0.05, start_m2)
            'Dim derivative3 As Double = compute_derivate_of_pixel_on_curve(new_curve1, pxl_driv_ind1, start_measure_ind3, 0.05, start_m2)
            'Dim derivative4 As Double = compute_derivate_of_pixel_on_curve(new_curve1, pxl_driv_ind1, start_measure_ind4, 0.05, start_m2)
            If derivative1 < 0 Then
                derivative1 = 0
            End If
            CGlobals1.form_obj1.lbl_progress1.Text = pxl_driv_ind1.ToString() + "/" + new_curve1.Count.ToString() + "=" + derivative1.ToString()
            Application.DoEvents()







            If pxl_driv_ind1 = 10 Then

                If suffix_path1 = "_front_top_0_frame1" Then
                    last_derivatives1 = Double.Parse(System.IO.File.ReadAllText(path_arr1(1) + "\start_derivative.txt"))
                End If

                'If suffix_path1 = "_front_top_1_frame1" Or suffix_path1 = "_front_top_0_frame1" Then
                'dict_res1 = remove_start_pxls1(dict_res1)
                'End If


                'last_derivatives1 = 0.57833557128906254
            End If
            If last_derivatives1 = -9999 Then
                last_derivatives1 = derivative1
            Else
                If last_derivatives1 < derivative1 Then
                    derivative1 = last_derivatives1
                Else
                    last_derivatives1 = derivative1
                End If

            End If

            CGlobals1.form_obj1.lbl_progress1.Text = pxl_driv_ind1.ToString() + "/" + new_curve1.Count.ToString() + "=" + derivative1.ToString()
            Application.DoEvents()



            start_m2 = derivative1 + 5

            If pxl_driv_ind1 = 0 Then
                derivative1 = 1
            End If
            derivative_dict1(pxl_driv_ind1) = derivative1
            'derivative_arr1.Add(derivative1)
            deriv_arr_str1 += pxl_driv_ind1.ToString() + "," + derivative1.ToString() + "#"
            System.IO.File.WriteAllText(path_to_save, deriv_arr_str1)
            pxl_driv_ind1 += 1
            If pxl_driv_ind1 >= new_curve1.Count - 1 Then
                to_stop1 = 1
            End If
            If derivative1 <= 0 Then
                to_stop1 = 1
            End If

        End While

        Return derivative_dict1
    End Function

    Public Function find_45_degree_ind_from_curve_pxl_arr1(curve_pxls_arr1 As ArrayList, start_ind1 As Integer, dir1 As Integer)
        Dim pxl_ind6 As Integer = start_ind1
        Dim to_stop6 As Integer = 0
        Dim first_ind_derivative_45 As Integer = -1
        Dim last_ind_derivative_45 As Integer = -1

        While to_stop6 = 0
            Dim cord_xya_1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, pxl_ind6 - 1)
            Dim cord_xya_2 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, pxl_ind6)
            Dim cord_xya_3 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, pxl_ind6 + 1)
            Dim is_45 As String = ""
            If cord_xya_3(0) = cord_xya_2(0) + 1 And cord_xya_2(0) = cord_xya_1(0) + 1 Then
                If cord_xya_3(1) - dir1 = cord_xya_2(1) And cord_xya_2(1) - dir1 = cord_xya_1(1) Then
                    is_45 = "yes"
                    If first_ind_derivative_45 = -1 Then
                        first_ind_derivative_45 = pxl_ind6

                    End If

                End If
            End If
            If first_ind_derivative_45 <> -1 And is_45 = "" Then
                last_ind_derivative_45 = pxl_ind6 - dir1
                to_stop6 = 1
            End If
            If to_stop6 = 0 Then
                pxl_ind6 += dir1

            End If
        End While

        Dim dict_ret_res1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)

        dict_ret_res1("first_ind_derivative_45") = first_ind_derivative_45
        dict_ret_res1("last_ind_derivative_45") = last_ind_derivative_45
        Return dict_ret_res1

    End Function


    Public Function find_45_degree_ind_from_curve_pxl_arr_by_long_seq_45_1(curve_pxls_arr1 As ArrayList, start_ind1 As Integer, dir1 As Integer)

        Dim path1 As String = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + suffix_path1

        Dim pxl_ind6 As Integer = start_ind1
        Dim to_stop6 As Integer = 0
        Dim first_ind_derivative_45 As Integer = -1
        Dim last_ind_derivative_45 As Integer = -1
        Dim max_seq_arr1 As ArrayList = New ArrayList()
        While to_stop6 = 0
            Dim seq_by_45_degree_arr1 As ArrayList = New ArrayList()
            Dim cord_xya_1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, pxl_ind6)
            seq_by_45_degree_arr1.Add(pxl_ind6)
            Dim ind2 As Integer = pxl_ind6 + dir1
            Dim to_stop2 As Integer = 0
            Try
                If CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, ind2)(0) = cord_xya_1(0) And CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, ind2)(1) > cord_xya_1(1) Then
                    to_stop2 = 1
                    to_stop6 = 1
                End If
                While to_stop2 = 0 And ((CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, ind2)(0) > cord_xya_1(0) And dir1 = 1) Or (CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, ind2)(0) < cord_xya_1(0) And dir1 = -1)) And CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, ind2)(1) > cord_xya_1(1)
                    seq_by_45_degree_arr1.Add(ind2)

                    cord_xya_1 = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, ind2)
                    ind2 += dir1

                    If ind2 Mod 50 = 0 Then
                        Dim d1 As Integer = 1
                    End If
                    If ind2 >= curve_pxls_arr1.Count - 1 Then
                        to_stop2 = 1
                    End If
                End While
            Catch ex As Exception
                Dim d1 As Integer = 1
            End Try

            If max_seq_arr1.Count < seq_by_45_degree_arr1.Count Then
                max_seq_arr1 = seq_by_45_degree_arr1.Clone()
            End If
            pxl_ind6 += dir1

            If pxl_ind6 >= curve_pxls_arr1.Count - 1 Or pxl_ind6 < 1 Then
                to_stop6 = 1
            End If

        End While



        Dim bmp5 As Bitmap = CGlobals1.create_fill_bitmap(4000, 3000, Color.FromArgb(255, 255, 255))
        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(curve_pxls_arr1, bmp5, Color.FromArgb(24, 230, 50))
        CGlobals1.draw_sqr_around_pixels2(bmp5, CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, max_seq_arr1(0))(0), CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, max_seq_arr1(0))(1), 2, Color.FromArgb(140, 90, 70))
        CGlobals1.draw_sqr_around_pixels2(bmp5, CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, max_seq_arr1(max_seq_arr1.Count - 1))(0), CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, max_seq_arr1(max_seq_arr1.Count - 1))(1), 2, Color.FromArgb(190, 90, 70))
        bmp5.Save(path1 + "\" + "degree_45_1.bmp")


        Dim dict_ret_res1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)



        dict_ret_res1("first_ind_derivative_45") = max_seq_arr1(0)
        dict_ret_res1("last_ind_derivative_45") = max_seq_arr1(max_seq_arr1.Count - 1)


        Return dict_ret_res1

    End Function



    Public Function pre_proccessing_curve1()
        Dim path1 As String = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_front_right_corner1"
        If System.IO.Directory.Exists(path1) = False Then
            System.IO.Directory.CreateDirectory(path1)
        End If

        Dim derivative_dict1 As Dictionary(Of Integer, Double) = New Dictionary(Of Integer, Double)

        If System.IO.File.Exists(path1 + "\derivs1.txt") = True Then

            Dim derivatives_inds_str1 As String = System.IO.File.ReadAllText(path1 + "\derivs1.txt")
            If derivatives_inds_str1 <> "" Then
                Dim last_derivate_more_the_zero1 As Double = -9999
                Dim derivative_ind1 As Integer
                Dim devivatives_inds1 As String() = derivatives_inds_str1.Split("#")
                derivative_dict1(0) = 1
                For derivative_ind1 = 1 To devivatives_inds1.Length - 2
                    derivative_dict1(Integer.Parse(devivatives_inds1(derivative_ind1).Split(",")(0))) = Double.Parse(devivatives_inds1(derivative_ind1).Split(",")(1))

                    If last_derivate_more_the_zero1 = -9999 Then

                        last_derivate_more_the_zero1 = Double.Parse(devivatives_inds1(derivative_ind1).Split(",")(1))
                    Else
                        If Double.Parse(devivatives_inds1(derivative_ind1).Split(",")(1)) > 0 Then
                            last_derivate_more_the_zero1 = Double.Parse(devivatives_inds1(derivative_ind1).Split(",")(1))
                        End If
                    End If
                Next

            End If

            Dim new_curve2 As ArrayList = CGlobals1.form_obj1.markingfldimg_obj1.load_2d_pixels_arr1(path1 + "\curve1.txt")


            Dim dict_ret_res3 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
            dict_ret_res3("derivatives_arr1") = derivative_dict1
            dict_ret_res3("curve_pxls_arr1") = new_curve2

            Return dict_ret_res3
        End If



        Dim frame_pixels_arr1 As ArrayList = CGlobals1.form_obj1.markingfldimg_obj1.load_2d_pixels_arr1(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_frame4.txt")


        'Dim curve_pxls_arr1 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, curve_start_ind1, last_right_ind1)


        'curve_pxls_arr1 = single_pixel_in_every_x_min_y(curve_pxls_arr1)

        Dim bmp5 As Bitmap = CGlobals1.create_fill_bitmap(4000, 3000, Color.FromArgb(255, 255, 255))
        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(frame_pixels_arr1, bmp5, Color.FromArgb(24, 230, 50))
        bmp5.Save(path1 + "\" + "frame4a.bmp")


        Dim dict_rect_frame1 As Dictionary(Of String, Object) = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(frame_pixels_arr1)

        Dim center_x1 As Integer = (dict_rect_frame1("min_x1") + dict_rect_frame1("max_x1")) / 2
        Dim center_y1 As Integer = (dict_rect_frame1("min_y1") + dict_rect_frame1("max_y1")) / 2


        'Dim cord_xy1a As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1, 995)
        'Dim cord_xy2a As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1, 995)

        Dim vec_3d_obj1 As vec_3d1 = New vec_3d1()
        vec_3d_obj1.p1 = New point_3d1()
        vec_3d_obj1.p1.x1 = center_x1
        vec_3d_obj1.p1.y1 = center_y1


        vec_3d_obj1.p2 = New point_3d1()
        vec_3d_obj1.p2.x1 = center_x1
        vec_3d_obj1.p2.y1 = center_y1
        vec_3d_obj1.p2.z1 = -10

        frame_pixels_arr1 = CGlobals1.form_obj1.markingfldimg_obj1.rotate_2d_pixels_arr(frame_pixels_arr1, vec_3d_obj1, -90)


        Dim dict_rect_frame2 As Dictionary(Of String, Object) = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(frame_pixels_arr1)

        frame_pixels_arr1 = CGlobals1.form_obj1.markingfldimg_obj1.move_pixels_arr1(frame_pixels_arr1, 0, -dict_rect_frame2("min_y1") + 10)

        bmp5 = CGlobals1.create_fill_bitmap(4000, 3000, Color.FromArgb(255, 255, 255))
        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(frame_pixels_arr1, bmp5, Color.FromArgb(24, 230, 50))
        bmp5.Save(path1 + "\" + "frame4b.bmp")


        Dim dict_rect_frame3 As Dictionary(Of String, Object) = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(frame_pixels_arr1)


        Dim center_y2 As Integer = (dict_rect_frame3("min_y1") + dict_rect_frame3("max_y1")) / 2
        Dim pxl_ind1 As Integer = 0

        While CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1, pxl_ind1)(1) > center_y2
            pxl_ind1 += 1
        End While

        Dim pxl_ind2 As Integer = pxl_ind1 + 1

        While CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1, pxl_ind2)(1) < center_y2
            pxl_ind2 += 1
        End While

        frame_pixels_arr1 = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, pxl_ind1, pxl_ind2)


        bmp5 = CGlobals1.create_fill_bitmap(4000, 3000, Color.FromArgb(255, 255, 255))
        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(frame_pixels_arr1, bmp5, Color.FromArgb(24, 230, 50))
        bmp5.Save(path1 + "\" + "frame4c.bmp")

        Dim dict_rect_frame4 As Dictionary(Of String, Object) = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(frame_pixels_arr1)


        Dim pxl_ind3 As Integer = 0

        While CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1, pxl_ind3)(0) > dict_rect_frame4("min_x1")
            pxl_ind3 += 1
        End While

        Dim pxl_ind4 As Integer = pxl_ind3 + 1

        While CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1, pxl_ind4)(0) = dict_rect_frame4("min_x1")
            pxl_ind4 += 1
        End While

        frame_pixels_arr1 = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, pxl_ind4, frame_pixels_arr1.Count - 1)

        bmp5 = CGlobals1.create_fill_bitmap(4000, 3000, Color.FromArgb(255, 255, 255))
        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(frame_pixels_arr1, bmp5, Color.FromArgb(24, 230, 50))
        bmp5.Save(path1 + "\" + "frame4d.bmp")




        Dim dict_rect_frame5 As Dictionary(Of String, Object) = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(frame_pixels_arr1)

        Dim pxl_ind5 As Integer = 0
        While CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1, pxl_ind5)(1) > dict_rect_frame5("min_y1")
            pxl_ind5 += 1
        End While


        Dim pxl_ind5b As Integer = pxl_ind5
        While CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1, pxl_ind5b)(1) = dict_rect_frame5("min_y1")
            pxl_ind5b += 1
        End While


        Dim pxl_ind6 As Integer = pxl_ind5
        Dim to_stop6 As Integer = 0
        Dim first_ind_derivative_45 As Integer = -1
        Dim last_ind_derivative_45 As Integer = -1

        While to_stop6 = 0
            Dim cord_xya_1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1, pxl_ind6 - 1)
            Dim cord_xya_2 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1, pxl_ind6)
            Dim cord_xya_3 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1, pxl_ind6 + 1)
            Dim is_45 As String = ""
            If cord_xya_3(0) = cord_xya_2(0) + 1 And cord_xya_2(0) = cord_xya_1(0) + 1 Then
                If cord_xya_3(1) + 1 = cord_xya_2(1) And cord_xya_2(1) + 1 = cord_xya_1(1) Then
                    is_45 = "yes"
                    If first_ind_derivative_45 = -1 Then
                        first_ind_derivative_45 = pxl_ind6

                    End If

                End If
            End If
            If first_ind_derivative_45 <> -1 And is_45 = "" Then
                last_ind_derivative_45 = pxl_ind6 - 1
                to_stop6 = 1
            End If
            If to_stop6 = 0 Then
                pxl_ind6 -= 1

            End If
        End While

        Dim start_ind_derivate_45 As Integer = (first_ind_derivative_45 + last_ind_derivative_45) / 2


        Dim new_curve1 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, start_ind_derivate_45, pxl_ind5b)
        new_curve1 = close_hole_in_curve1(new_curve1, 0, new_curve1.Count - 1)




        Dim pxl_driv_ind1 As Integer
        Dim deriv_arr_str1 As String = ""
        Dim start_m2 As Double = 20

        Dim derivative1t As Double = compute_derivate_of_pixel_on_curve(new_curve1, 0, 2, start_m2)

        Dim to_stop1 As Integer = 0


        CGlobals1.form_obj1.markingfldimg_obj1.save_2d_pixels_arr1(path1 + "\curve1.txt", new_curve1)
        pxl_driv_ind1 = 0

        Dim last_derivatives1 As Double = -9999
        While to_stop1 = 0


            Dim derivative1 As Double = compute_derivate_of_pixel_on_curve(new_curve1, pxl_driv_ind1, 3, start_m2)
            If last_derivatives1 = -9999 Then
                last_derivatives1 = derivative1
            Else
                If last_derivatives1 < derivative1 Then
                    derivative1 = last_derivatives1
                Else
                    last_derivatives1 = derivative1
                End If

            End If


            start_m2 = derivative1 + 5
            derivative_dict1(pxl_driv_ind1) = derivative1
            'derivative_arr1.Add(derivative1)
            deriv_arr_str1 += pxl_driv_ind1.ToString() + "," + derivative1.ToString() + "#"
            System.IO.File.WriteAllText(path1 + "\derivs1.txt", deriv_arr_str1)
            pxl_driv_ind1 += 1

            If derivative1 <= 0 Then
                to_stop1 = 1
            End If

        End While






        Dim dict_ret_res2 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
        dict_ret_res2("derivatives_arr1") = derivative_dict1
        dict_ret_res2("curve_pxls_arr1") = new_curve1

        Return dict_ret_res2

    End Function

    Public Function compute_derivate_of_pixel_on_curve(curve_pxls_arr1 As ArrayList, pxl_ind1 As Integer, start_measure_ind1 As Integer, Optional max_dist_from_curve1 As Double = 0.05, Optional start_m2 As Double = 907)
        'Dim start_m2 As Double = 907
        'Dim start_measure_ind1 As Integer = 15
        Dim start_ind2 As Integer = pxl_ind1
        Dim m2 As Double = check_dist_curve_with_line_m2(curve_pxls_arr1, start_ind2, start_ind2 + 100, start_measure_ind1, 1, start_m2)
        Dim add_factor1 As Double = -1
        Dim eps1 As Double = Math.Pow(10, -5)
        'Dim max_dist_from_curve1 As Double = 0.05

        Dim do_log1 As String = ""
        If pxl_ind1 = 21 Then
            'do_log1 = "yes"
        End If
        While Math.Abs(add_factor1) >= eps1 Or Math.Abs(Math.Abs(m2) - max_dist_from_curve1) > eps1
            m2 = check_dist_curve_with_line_m2(curve_pxls_arr1, start_ind2, start_ind2 + 100, start_measure_ind1, 1, start_m2, do_log1)
            If m2 <> -1 Then
                If Math.Abs(m2) > max_dist_from_curve1 Then
                    If add_factor1 < 0 Then
                        add_factor1 = Math.Abs(add_factor1) * 0.5

                    End If
                Else
                    If add_factor1 > 0 Then
                        add_factor1 = Math.Abs(add_factor1) * -0.5

                    End If

                End If
            Else

                add_factor1 = -Math.Abs(add_factor1)
            End If

            start_m2 += add_factor1
            If start_m2 < -0.2 Then
                start_m2 = -0.2
            End If

        End While
        m2 = check_dist_curve_with_line_m2(curve_pxls_arr1, start_ind2, start_ind2 + 100, start_measure_ind1, 1, start_m2, "yes")

        Return start_m2
    End Function



    Public Function compute_derivate_of_pixel_on_curve2(curve_pxls_arr1 As ArrayList, pxl_ind1 As Integer, len_of_measure1 As Integer, start_measure_ind1 As Integer, Optional max_dist_from_curve1 As Double = 0.05, Optional start_m2 As Double = 907)
        'Dim start_m2 As Double = 907
        'Dim start_measure_ind1 As Integer = 15
        Dim start_ind2 As Integer = pxl_ind1
        Dim m2 As Double = check_dist_curve_with_line_m2(curve_pxls_arr1, start_ind2, start_ind2 + len_of_measure1, start_measure_ind1, 1, start_m2, "yes")
        Dim add_factor1 As Double = -1
        Dim eps1 As Double = Math.Pow(10, -5)
        'Dim max_dist_from_curve1 As Double = 0.05

        Dim do_log1 As String = ""
        If pxl_ind1 = 21 Then
            'do_log1 = "yes"
        End If
        While Math.Abs(add_factor1) >= eps1 Or Math.Abs(Math.Abs(m2) - max_dist_from_curve1) > eps1
            m2 = check_dist_curve_with_line_m2(curve_pxls_arr1, start_ind2, start_ind2 + len_of_measure1, start_measure_ind1, 1, start_m2, do_log1)
            If m2 <> -1 Then
                If Math.Abs(m2) > max_dist_from_curve1 Then
                    If add_factor1 < 0 Then
                        add_factor1 = Math.Abs(add_factor1) * 0.5

                    End If
                Else
                    If add_factor1 > 0 Then
                        add_factor1 = Math.Abs(add_factor1) * -0.5

                    End If

                End If
            Else

                add_factor1 = -Math.Abs(add_factor1)
            End If

            start_m2 += add_factor1
            If start_m2 < -0.2 Then
                start_m2 = -0.2
            End If

        End While
        m2 = check_dist_curve_with_line_m2(curve_pxls_arr1, start_ind2, start_ind2 + len_of_measure1, start_measure_ind1, 1, start_m2, "yes")

        Return start_m2
    End Function
    Public Function single_pixel_in_every_x_min_y(curve_arr1 As ArrayList)
        'Dim 
        Dim dict1 As Dictionary(Of Integer, Integer) = CGlobals1.arr_xy_to_dict2(curve_arr1)

        Dim key_ind1 As Integer
        Dim last_x1 As Integer = dict1.Keys(0)
        Dim last_y1 As Integer = dict1(dict1.Keys(0))
        Dim new_curve_arr1 As ArrayList = New ArrayList()
        For key_ind1 = 1 To dict1.Keys.Count - 1
            ' dict1(key_ind1)

            Dim new_x1 As Integer = dict1.Keys(key_ind1)
            Dim new_y1 As Integer = dict1(dict1.Keys(key_ind1))
            If new_x1 <> last_x1 Then
                new_curve_arr1.Add(last_x1.ToString() + "," + last_y1.ToString())
                last_y1 = new_y1
            Else
                If new_y1 > last_y1 Then
                    last_y1 = new_y1
                End If
            End If
            last_x1 = new_x1
        Next

        Return new_curve_arr1
    End Function

    Public Function compute_m1b(slice_curve_pxls_arr1 As ArrayList, last_delta_height1 As Double)
        Dim cord_xy_start1b As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(slice_curve_pxls_arr1, 0)
        Dim cord_xy_end1b As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(slice_curve_pxls_arr1, slice_curve_pxls_arr1.Count - 1)

        Dim m1b As Double = -(cord_xy_start1b(1) - cord_xy_end1b(1) - last_delta_height1 - last_add_height1) / (cord_xy_start1b(0) - cord_xy_end1b(0))

        Return m1b
    End Function


    Public Function dec_derivatives1(dict_min_derivative As Dictionary(Of Integer, Double), dec_factor1 As Double)
        Dim deriv_ind1 As Integer

        For deriv_ind1 = 1 To dict_min_derivative.Keys.Count - 1
            dict_min_derivative(dict_min_derivative.Keys(deriv_ind1)) *= dec_factor1
        Next
        Return dict_min_derivative
    End Function


    Public Function find_last_ind1_with_m1b()


        Dim trace_last_ind_arr1 As ArrayList = New ArrayList()
        Dim dict_ret_res1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)

        Dim dir_add_dec_slice_curve1 As Integer = -1


        If polynom_result_arr1.Count = 5 And do_force1 = "yes" Then
            last_ind1 = 181
            dir_add_dec_slice_curve1 = 1

        End If


        Dim to_stop_find_last_ind1 As Integer = 0
        Dim org_last_ind2 As Integer = last_ind1

        Dim dict_res1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)

        Dim slice_curve_pxls_arr1 As ArrayList = New ArrayList()

        While to_stop_find_last_ind1 = 0


            If last_derivate1 >= m1b Then
                If dict_res1.ContainsKey("error1") = False Then
                    If dict_res1.ContainsKey("end_derivative2") Then
                        If Math.Abs(dict_res1("end_derivative2") - min_last_derivative1) <= min_diff_last_derivative1 Or mode1 = "force_add_height" Then
                            to_stop_find_last_ind1 = 1


                            If last_ind1 = curve_last_ind1 Then
                                Dim d1 As Integer = 3

                                Dim to_stop3 As Integer = 1
                                While to_stop3 = 0

                                    If False Then


                                        init_poynom_obj1.coef_arr1.Clear()

                                        init_poynom_obj1.coef_arr1.Add(0)
                                        init_poynom_obj1.coef_arr1.Add(last_derivate1)
                                        'init_poynom_obj1.coef_arr1.Add(0.000001)
                                        'init_poynom_obj1.coef_arr1.Add(0.000001)
                                        'init_poynom_obj1.coef_arr1.Add(0.000005)
                                        'init_poynom_obj1.coef_arr1.Add(0.000005)
                                        init_poynom_obj1.coef_arr1.Add(Math.Pow(10, -15))
                                        init_poynom_obj1.coef_arr1.Add(0)
                                        init_poynom_obj1.create_derivative1()



                                    End If
                                    init_poynom_obj1.coef_arr1.Clear()
                                    init_poynom_obj1.coef_arr1.Add(0)
                                    init_poynom_obj1.coef_arr1.Add(0.00001)
                                    'init_poynom_obj1.coef_arr1.Add(0.000001)
                                    'init_poynom_obj1.coef_arr1.Add(0.000001)
                                    'init_poynom_obj1.coef_arr1.Add(0.000005)
                                    'init_poynom_obj1.coef_arr1.Add(0.000005)
                                    init_poynom_obj1.coef_arr1.Add(0.00001)
                                    init_poynom_obj1.coef_arr1.Add(0.00001)
                                    init_poynom_obj1.create_derivative1()
                                    'dict_prms1("add_curve_width1") = -0.2
                                    Dim dict_res1t As Dictionary(Of String, Object) = find_polynom_coefs1(init_poynom_obj1, last_derivate1, 99, slice_curve_pxls_arr1, "only_start_derivate1", dict_prms1)
                                End While
                            End If
                            If mode1 = "force_add_height" Then
                            End If
                        End If

                    End If
                End If
            End If


            If to_stop_find_last_ind1 = 0 Then
                If last_ind1 < start_ind1 + max_diff_start_last Then
                    dir_add_dec_slice_curve1 = 1

                    last_ind1 = org_last_ind2 + 1
                End If

            End If


            If is_last_sub_curve1 = "yes" Then
                Dim d1 As Integer = 1
            End If

            If mode_fix_last_pixel1 = "yes" Then
                Dim d1 As Integer = 1
            End If
            Dim is_end_of_curve1 As String = ""
            If to_stop_find_last_ind1 = 0 Then

                'slice_curve_pxls_arr1.RemoveAt(slice_curve_pxls_arr1.Count - 1)
                If mode_fix_last_pixel1 = "yes" Then
                Else


                End If

                last_ind1 += dir_add_dec_slice_curve1
                If dict_min_derivative.ContainsKey(last_ind1) = False Or is_last_sub_curve1 = "yes" Then
                    Dim err1 As Integer = 1
                    is_end_of_curve1 = "yes"
                    If last_ind1 > curve_last_ind1 Then
                        last_ind1 = curve_last_ind1
                    End If
                End If

                If polynom_result_arr1.Count = 1 And False Then
                    last_ind1 = 18
                    mode1 = "force_add_height"
                End If

                If dict_min_derivative(last_ind1) <= 0 Or is_end_of_curve1 = "yes" Then 'Or last_ind1 >= first_top_ind1 Then
                    Dim end_of_curve1 As Integer = 1

                    If mode1 = "force_add_height" Then
                    Else
                        last_ind1 = curve_last_ind1

                    End If

                End If




                If polynom_result_arr1.Count = 4 And do_force1 = "yes" And False Then
                    last_ind1 = 166

                End If


                If suffix_path1 = "_front_right_2_frame1" Then
                    If polynom_result_arr1.Count = 12 Then
                        last_ind1 = curve_last_ind1
                    End If

                End If

                If suffix_path1 = "_front_bottom_1_frame1" Then
                    If polynom_result_arr1.Count = 7 Then
                        last_ind1 = curve_last_ind1
                    End If

                End If

                '"_front_bottom_1_frame1"
                trace_last_ind_arr1.Add(last_ind1)

                If trace_last_ind_arr1.Count > 100 Then
                    'not_found_polynom_curve
                    was_error_in_fix_last_pxl1 = "yes"
                    dict_res1("error1") = "yes"
                    dict_ret_res1("slice_curve_pxls_arr1") = slice_curve_pxls_arr1
                    dict_ret_res1("dict_res1") = dict_res1

                    Return dict_ret_res1
                End If
                min_last_derivative1 = dict_min_derivative(last_ind1)
                slice_curve_pxls_arr1 = CGlobals1.get_arr_from_ind_to_ind1(curve_pxls_arr1, start_ind1, last_ind1)
                m1b = compute_m1b(slice_curve_pxls_arr1, last_delta_height1)
                If last_derivate1 >= m1b Or is_end_of_curve1 = "yes" Or mode_fix_last_pixel1 = "yes" Then

                    init_poynom_obj1.coef_arr1.Clear()

                    init_poynom_obj1.coef_arr1.Add(0)
                    init_poynom_obj1.coef_arr1.Add(0.00001)
                    'init_poynom_obj1.coef_arr1.Add(0.000001)
                    'init_poynom_obj1.coef_arr1.Add(0.000001)
                    'init_poynom_obj1.coef_arr1.Add(0.000005)
                    'init_poynom_obj1.coef_arr1.Add(0.000005)
                    init_poynom_obj1.coef_arr1.Add(0.00001)
                    init_poynom_obj1.coef_arr1.Add(0.00001)
                    init_poynom_obj1.create_derivative1()
                    dict_res1.Remove("error1")

                    If mode1 = "not_change_height1" Then
                        Dim d14a As Integer = 1
                        'dict_prms1("add_height_to_curve1") = 0.4
                    End If
                    dict_prms1("check1") = "yes"
                    dict_res1 = find_polynom_coefs1(init_poynom_obj1, last_derivate1, 99, slice_curve_pxls_arr1, "only_start_derivate1", dict_prms1)
                    If dict_res1.ContainsKey("error1") Then
                        max_loop_count1 = 2000
                        start_coef1 = Math.Pow(10, -6)
                        factor_div_prop1 = 0.95
                        dict_res1 = find_polynom_coefs1(init_poynom_obj1, last_derivate1, 99, slice_curve_pxls_arr1, "only_start_derivate1", dict_prms1)
                        start_coef1 = Math.Pow(10, -5)
                        factor_div_prop1 = 0.9


                        If dict_res1.ContainsKey("error1") Then
                            start_coef1 = Math.Pow(10, -7)
                            factor_div_prop1 = 0.9
                            dict_res1 = find_polynom_coefs1(init_poynom_obj1, last_derivate1, 99, slice_curve_pxls_arr1, "only_start_derivate1", dict_prms1)
                            start_coef1 = Math.Pow(10, -5)
                            factor_div_prop1 = 0.9

                        End If
                    End If
                    Dim test_again1 As Integer = 0
                    While test_again1 = 1
                        dict_res1 = find_polynom_coefs1(init_poynom_obj1, last_derivate1, 99, slice_curve_pxls_arr1, "only_start_derivate1", dict_prms1)
                        Dim d17 As Integer = 1
                    End While
                    dict_prms1.Remove("check1")
                    If mode_fix_last_pxl1 = "yes" Then
                        Dim max_loop_count1 As Integer = 300
                        While dict_res1.ContainsKey("error1") = True And max_loop_count1 >= 200 And False
                            dict_prms1("max_loop_count1") = max_loop_count1
                            dict_res1 = find_polynom_coefs1(init_poynom_obj1, last_derivate1, 99, slice_curve_pxls_arr1, "only_start_derivate1", dict_prms1)
                            dict_prms1.Remove("max_loop_count1")
                            max_loop_count1 -= 30
                        End While

                    End If
                    'CGlobals1.save_dict_prms1(dict_res1)
                    'Dim dist_res_test1 As Dictionary(Of String, Object) = find_polynom_coefs1(init_poynom_obj1, last_derivate1, 99, slice_curve_pxls_arr1, "only_start_derivate1", dict_prms1)

                    If mode_fix_last_pxl1 = "yes" Then
                        to_stop_find_last_ind1 = 1

                        If dict_res1.ContainsKey("error1") = True Then

                            was_error_in_fix_last_pxl1 = "yes"
                            MessageBox.Show("error1")
                        Else
                            If (Math.Abs(dict_res1("end_derivative2")) + Math.Abs(dict_res1("min_diff_h1"))) <= 0.004 Then
                                If polynom_result_arr1.Count = 10 Then
                                    Dim d1a As Integer = 2

                                End If
                            End If
                        End If
                    End If
                    Dim d1 As Integer = 1
                Else
                    Dim not_gott_last_deriv1 As Integer = 1
                End If







            Else



            End If


        End While

        dict_ret_res1("slice_curve_pxls_arr1") = slice_curve_pxls_arr1
        dict_ret_res1("dict_res1") = dict_res1

        Return dict_ret_res1

    End Function
    Public Function analize_polynom2()

        Dim var123 As String = "yes123"
        'Dim var123a As String = "yes123"
        Dim var123v As String = "yes123"
        Dim var1232 As String = "yes123"

        If suffix_path1 = "_front_right_1_frame1" Then
            delta_add_last_ind1 = 12
        End If


        Dim trace1 As StackTrace = New StackTrace()
        Dim frames As StackFrame() = trace1.GetFrames()


        Dim method1 As MethodBase = frames(0).GetMethod()
        Dim body As MethodBody = method1.GetMethodBody()



        'foreach(StackFrame frame In trace.GetFrames())


        Dim field_info As FieldInfo() = GetType(CPolynom_curve1).GetRuntimeFields()
        Dim field_info2 As FieldInfo() = body.GetType().GetRuntimeFields()

        Dim field_info3 As FieldInfo() = frames(0).GetType().GetRuntimeFields()

        Dim mthds As MethodInfo() = GetType(CPolynom_curve1).GetMethods()
        Dim mi As MethodInfo = mthds(22) ' GetType(CPolynom_curve1).GetMethod("analize_polynom2")

        Dim mb As MethodBody = mi.GetMethodBody()
        mb = body
        Dim lvs1 As System.Collections.Generic.IList(Of System.Reflection.LocalVariableInfo) = mb.LocalVariables()
        Dim lvs2 As System.Reflection.LocalVariableInfo = lvs1(1)
        'Dim lvs As System.Collections() = mb.LocalVariables()

        init_poynom_obj1.coef_arr1.Add(0)
        init_poynom_obj1.coef_arr1.Add(0.9)
        'init_poynom_obj1.coef_arr1.Add(0.000001)
        'init_poynom_obj1.coef_arr1.Add(0.000001)
        'init_poynom_obj1.coef_arr1.Add(0.000005)
        'init_poynom_obj1.coef_arr1.Add(0.000005)
        init_poynom_obj1.coef_arr1.Add(0.00001)
        init_poynom_obj1.coef_arr1.Add(0.00001)
        init_poynom_obj1.create_derivative1()
        Dim dict_res1 As Dictionary(Of String, Object)


        'cut_slice_of_curve1()

        ' dict_res1 = pre_proccessing_curve1()



        dict_res1 = pre_proccessing_curve2()
        set_cur_path_of_curve1()

        If suffix_path1 = "_front_top_1_frame1" Then
            System.IO.File.WriteAllText(path_arr1(cur_path_ind1) + "\start_derivative.txt", CType(dict_res1("derivatives_arr1"), Dictionary(Of Integer, Double))(10).ToString())
        End If

        If suffix_path1 = "_front_top_1_frame1" Or suffix_path1 = "_front_top_0_frame1" Then
            dict_res1 = remove_start_pxls1(dict_res1)
        End If




        CGlobals1.delete_files1(path_arr1(cur_path_ind1) + "\data1", "*.bmp")

        curve_pxls_arr1 = dict_res1("curve_pxls_arr1")




        dict_min_derivative = dict_res1("derivatives_arr1")


        If False Then
            Dim diff_curve_derivs1 As Integer = curve_pxls_arr1.Count - dict_min_derivative.Count

            diff_curve_derivs1 /= 2

            While diff_curve_derivs1 > 0
                curve_pxls_arr1.RemoveAt(curve_pxls_arr1.Count - 1)
                diff_curve_derivs1 -= 1
            End While
            While dict_min_derivative.Count < curve_pxls_arr1.Count
                dict_min_derivative(dict_min_derivative.Count) = 0
            End While

        End If



        dict_min_derivative = dec_derivatives1(dict_min_derivative, 1)



        Dim bmp5 As Bitmap = CGlobals1.create_fill_bitmap(4000, 3000, Color.FromArgb(255, 255, 255))
        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(curve_pxls_arr1, bmp5, Color.FromArgb(24, 230, 50))
        bmp5.Save(CGlobals1.global_path1 + CGlobals1.sobel_pics_path1 + "cur_curve1.bmp")



        Dim rect_of_curve1 As Dictionary(Of String, Object) = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(curve_pxls_arr1)
        Dim w1 As Integer = Math.Abs(rect_of_curve1("max_x1") - rect_of_curve1("min_x1")) + 1
        Dim h1 As Integer = Math.Abs(rect_of_curve1("max_y1") - rect_of_curve1("min_y1")) + 1


        last_ind1 = 0
        'delta_add_last_ind1 = 20
        start_ind1 = 0

        Dim tunning_last_point As String = "yes1"
        If tunning_last_point = "yes" Then
            start_ind1 = 162

        End If
        '0.090236168879480411
        last_ind1 = start_ind1 + delta_add_last_ind1
        'last_derivate1 = dict_res1("end_derivative2")

        Dim start_m1 As Double = 1

        'If do_right_corner1 = "yes" Then
        'start_m1 = 9
        'End If



        Dim derivate_arr1 As ArrayList = New ArrayList()

        Dim dict_rect_frame1 As Dictionary(Of String, Object) = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(curve_pxls_arr1)
        Dim do_right_corner1 As String = "yes"


        curve_last_ind1 = curve_pxls_arr1.Count - 1
        last_derivate1 = dict_min_derivative(start_ind1) '  find_min_end_m1(curve_pxls_arr1, start_ind1, start_ind1 + delta_add_last_ind_min_m1, 1, 10, start_m1)

        Dim curve_last_ind As Integer

        Dim all_polynom_result_arr1 As ArrayList = New ArrayList()


        dict_prms1("curve_ind1") = 0
        dict_prms1("curve_ind1") += 1

        dict_res1("error1") = "yes"
        Dim max_proportion1 As Double = -1
        Dim dir_add_to_last_ind1 As Integer = -1
        last_delta_height1 = 0
        last_add_height1 = 0
        Dim last_last_ind1 As Integer = last_ind1
        'start_ind1 = start_ind1 + 10

        Dim org_start_ind As Integer = start_ind1



        Dim polynom_curves_arr1 As ArrayList = New ArrayList()

        Dim m1 As Double = 99
        last_ind1 = search_for_last_ind1(dict_min_derivative, start_ind1, delta_add_last_ind1, curve_pxls_arr1, last_delta_height1)
        If Math.Abs(last_ind1 - start_ind1) < 70 Then
            'last_ind1 = start_ind1 + 70
        End If
        Dim count_loop1 As Integer = 0



        last_derivate1 = dict_min_derivative(start_ind1)


        If tunning_last_point = "yes" Then

            last_derivate1 = 0.090236168879480411
        End If




        Dim sum_width_of_cur_curve1 As Integer = 0
        Dim str_curve_ind1 As String = ""
        Dim find_polynom_coefs1_loop1 As Integer = 0

        Dim slice_curve_pxls_arr1 As ArrayList = New ArrayList()

        Dim force_over_dict_res1 As String = ""

        Dim dict_prms1_arr1 As ArrayList = New ArrayList()

        Dim count_go_back1 As Integer = 0

        Dim last_add_curve_width1_val1 As Double = 9999
        Dim last_add_curve_height1_val1 As Double = 9999

        Dim last_min_diff_and_derivs_arr1 As ArrayList = New ArrayList()

        Dim add_curve_width1_factor1 As Double = 0.1 '0.1
        Dim add_curve_height1_factor1 As Double = 0.1 '0.1
        Dim cur_add_curve_width1 As Double = 0
        Dim cur_add_curve_height1 As Double = 0
        Dim arr_min_diff_h1_and_end_deriv_arr1 As ArrayList = New ArrayList()

        Dim arr_min_diff_h1_arr1 As ArrayList = New ArrayList()
        Dim arr_end_deriv_arr1 As ArrayList = New ArrayList()

        Dim min_diff_h1_and_derivs_arr1 As ArrayList = New ArrayList()

        'Dim dir_arr1 As Double() = {0, 0, -1, -1, 0, -1, 1, -1, -1, 0, 1, 0, -1, 1, 0, 1, 1, 1, 0, 0}


        Dim last_min_diff_h1_val1 As Double = 9999
        Dim last_end_deriv_val1 As Double = 9999

        Dim last_dict_prms_str1 As String = ""

        While dict_res1.ContainsKey("error1")

            count_loop1 += 1
            If count_loop1 = 13 Then
                Dim dl1 As Integer = 1
            End If


            slice_curve_pxls_arr1 = CGlobals1.get_arr_from_ind_to_ind1(curve_pxls_arr1, start_ind1, last_ind1)



            Dim dict_rect1a As Dictionary(Of String, Object) = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(slice_curve_pxls_arr1)
            Dim proportion1 As Double = Math.Abs(dict_rect1a("min_y1") - dict_rect1a("max_y1")) / Math.Abs(dict_rect1a("min_x1") - dict_rect1a("max_x1"))
            'm1 = find_min_end_m1(curve_pxls_arr1, start_ind1, start_ind1 + delta_add_last_ind_min_m1, 1, 1)
            m1 = dict_min_derivative(start_ind1)



            min_last_derivative1 = -1
            Dim ind_of_derivative1 As Integer = last_ind1
            While dict_min_derivative.ContainsKey(ind_of_derivative1) = False
                ind_of_derivative1 -= 1
            End While
            min_last_derivative1 = dict_min_derivative(ind_of_derivative1) 'find_min_end_m1(frame_pixels_arr1, last_ind1, last_ind1 + delta_add_last_ind_min_m1, 1, 15)

            If False Then

                If dict_min_derivative.ContainsKey(last_ind1 - 1) Then
                    If min_last_derivative1 > dict_min_derivative(last_ind1 - 1) Then
                        min_last_derivative1 = dict_min_derivative(last_ind1 - 1)
                    End If
                End If
                dict_min_derivative(last_ind1) = min_last_derivative1

            End If


            If last_ind1 >= first_top_ind1 And False Then
                min_last_derivative1 = 0
                last_ind1 = curve_last_ind1
                slice_curve_pxls_arr1 = CGlobals1.get_arr_from_ind_to_ind1(curve_pxls_arr1, start_ind1, last_ind1)
            End If
            If (last_derivate1 < min_last_derivative1 Or ((start_ind1 + 30) > last_ind1) And do_right_corner1 <> "yes") And dir_add_to_last_ind1 = -1 Then
                Dim err1 As Integer = 1
                'min_last_derivative1 = last_derivate1 * 0.9
                'dir_add_to_last_ind1 = 1
                'last_ind1 = last_last_ind1
            End If

            'Dim m2 As Double = dict_min_derivative(last_ind1)


            m1b = compute_m1b(slice_curve_pxls_arr1, last_delta_height1)
            If mode_fix_last_pixel1 = "yes" Then
                Dim d1 As Integer = 1
            End If
            'curve_pxls_arr1 = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, 600, 700)
            'curve_pxls_arr1 = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, 700, 750)

            'cord_xy_start1 = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, curve_pxls_arr1.Count - 10)
            'cord_xy_end1 = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, curve_pxls_arr1.Count - 1)

            dict_prms1("org_curve1") = curve_pxls_arr1.Clone()
            dict_prms1("end_pixel_ind1") = last_ind1
            dict_prms1("last_delta_height1") = last_delta_height1
            dict_prms1("last_add_height1") = last_add_height1
            If dict_prms1.ContainsKey("add_curve_width1") = False Then
                dict_prms1("add_curve_width1") = 0

            End If


            If dict_prms1.ContainsKey("curve_ind1") = False Then

                dict_prms1("curve_ind1") = 0
            End If

            If polynom_result_arr1.Count = 9 Then
                Dim d1234 As Integer = 2
            End If
            last_dict_prms_str1 = CGlobals1.dict_prm_to_json_str(dict_prms1)


            'min_last_derivative1 = -999
            If dict_prms1("curve_ind1") = 3 Or dict_prms1("curve_ind1") = 2 Then
                Dim d1 As Integer = 5
            End If

            If last_derivate1 <= m1b Then
                Dim m_check1 As Double = 1
                Try
                    m_check1 = find_min_end_m1(slice_curve_pxls_arr1, start_ind1, start_ind1 + delta_add_last_ind_min_m1, 1, 5)
                    Dim err1 As Integer = 1

                Catch ex As Exception
                    'm_check1 = find_min_end_m1(slice_curve_pxls_arr1, start_ind1, start_ind1 + delta_add_last_ind_min_m1, 1, 5)
                End Try


            End If
            If min_last_derivative1 <= m1b Then
                Dim err1 As Integer = 1
            End If


            If polynom_result_arr1.Count = 4 And do_force1 = "yes" And False Then
                dict_prms1("add_curve_height1") = -0.1
            End If
            If (polynom_result_arr1.Count = 4 Or polynom_result_arr1.Count = 5) And do_force1 = "yes" And False Then



                mode1 = "force_add_height"



                'dict_prms1("add_height_to_curve1") = 0.6
            Else

                'mode1 = ""
                'dict_prms1("add_height_to_curve1") = 0
            End If
            Dim found_good_derivative_in_more_height1 As String = "no"



            If polynom_result_arr1.Count = 6 And do_force1 = "yes" And False Then
                last_ind1 = curve_last_ind1
                last_add_height1 = 0
                dict_prms1("add_curve_height1") = 0
                dict_prms1("last_add_height1") = 0
            End If


            If polynom_result_arr1.Count = 9 Then
                Dim d2 As Integer = 1
            End If


            If polynom_result_arr1.Count = 7 Then
                Dim d4 As Integer = 1
            End If
            If polynom_result_arr1.Count = 8 Then
                Dim d4 As Integer = 1
            End If


            If mode_fix_last_pxl1 = "yes" Then
                Dim d1234 As Integer = 2
            End If
            If polynom_result_arr1.Count = 10 Then
                Dim d1234 As Integer = 2
            End If

            If dir_arr_cur_ind1 = 1 Then
                Dim d1 As Integer = 1
            End If
            If mode_fix_last_pxl1 = "yes" Then
                Dim d1234 As Integer = 2
            End If
            Dim dict_res_find_last_ind1_with_m1b As Dictionary(Of String, Object) = find_last_ind1_with_m1b()
            If mode_fix_last_pxl1 = "yes" Then
                Dim d1234 As Integer = 2
            End If
            If polynom_result_arr1.Count = 8 Then
                Dim d4 As Integer = 1
            End If

            dict_res1 = dict_res_find_last_ind1_with_m1b("dict_res1")
            slice_curve_pxls_arr1 = dict_res_find_last_ind1_with_m1b("slice_curve_pxls_arr1")



            If (polynom_result_arr1.Count = 4 Or polynom_result_arr1.Count = 5) And do_force1 = "yes" Then


                last_add_height1 = dict_prms1("add_curve_height1")

                mode1 = "force_add_height"



                'dict_prms1("add_height_to_curve1") = 0.6
            Else
                'mode1 = ""
                'dict_prms1("add_height_to_curve1") = 0
            End If

            If polynom_result_arr1.Count = 5 Then
                'min_last_derivative1 *= 1.35
                'dict_prms1("add_height_to_curve1") = 0.5
            Else
                'dict_prms1("add_height_to_curve1") = 0

                'only if polynom over the max heght of curve
            End If
            If polynom_result_arr1.Count = 3 Then
                Dim d1 As Integer = 1
            End If
            If (last_derivate1 > m1b Or mode_fix_last_pxl1 = "yes") And (max_proportion1 = -1 Or max_proportion1 >= proportion1) Then


                dict_res1("start_ind1") = start_ind1
                dict_res1("last_ind1") = last_ind1
                dict_res1("count_loop1") = find_polynom_coefs1_loop1
                find_polynom_coefs1_loop1 += 1
                all_polynom_result_arr1.Add(dict_res1)

                If dict_res1.ContainsKey("end_derivative2") Then


                    If dict_res1("min_diff_h1") > 4 Then
                        Dim err3 As Integer = 1
                    End If




                    If dict_res1("end_derivative2") < min_last_derivative1 Or dict_res1("min_diff_h1") > 2 Then
                    Else
                        Dim ok1 As Integer = 1

                    End If

                    'If dict_res1("end_derivative2") < min_last_derivative1 Or dict_res1("min_diff_h1") > 2 Then
                    If ((Math.Abs(dict_res1("end_derivative2") - min_last_derivative1) > min_dist_last_derivative1 Or
                       ((dict_res1("end_derivative2") < min_last_derivative1 And Math.Abs(dict_res1("end_derivative2") - min_last_derivative1) < min_dist_down_last_derivative1 Or
                         dict_res1("end_derivative2") > min_last_derivative1 And Math.Abs(dict_res1("end_derivative2") - min_last_derivative1) < min_dist_up_last_derivative1)) = False) Or
                        dict_res1("min_diff_h1") > 2) And mode1 = "" Then

                        'End If
                        Dim to_find_derivate_in_polynom As String = "yes1"


                        Dim polynom_obj As CPolynom2 = dict_res1("polynom_obj1")
                        Dim last_end_x_polynom1 As Double = dict_res1("last_end_x_polynom1")
                        Dim width_of_curve1 As Double = dict_res1("width_of_curve1")
                        Dim y_val1a As Double = polynom_obj.get_y_val1(last_end_x_polynom1)
                        Dim y_val1b As Double = polynom_obj.get_y_val1(last_end_x_polynom1 - width_of_curve1)
                        Dim org_min_diff_h1 As Double = dict_res1("min_diff_h1")
                        Dim first_ok_x_ind1 As Integer = -1
                        If to_find_derivate_in_polynom = "yes" Then
                            'חיפוש זווית תקינה של הפולינום
                            Dim x_ind1 As Integer
                            'last_end_x_polynom1 = הנקודה הראשונה בפולינום
                            'כלומר עם הערך  x הכי גבוה

                            'זאת הנקודה האחרונה והיא עם הערך xהכי נמוך 
                            Dim start_x_val1 As Double = last_end_x_polynom1 - width_of_curve1

                            For x_ind1 = 0 To width_of_curve1 'To 0 Step -1
                                Dim polynom_x_val1 As Double = start_x_val1 + x_ind1 '+ (width_of_curve1 - x_ind1)
                                Dim derivative2 As Double = polynom_obj.get_derivative1(polynom_x_val1)
                                Dim derivative3 As Double = dict_min_derivative(last_ind1 - x_ind1)
                                Dim d1 As Integer = 1
                                If derivative2 >= (derivative3) And first_ok_x_ind1 = -1 Then
                                    first_ok_x_ind1 = width_of_curve1 - x_ind1
                                End If
                            Next
                            If first_ok_x_ind1 > width_of_curve1 / 2 Then
                                last_ind1 = start_ind1 + first_ok_x_ind1
                                Dim new_curve_pxls_arr1 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(curve_pxls_arr1, 0, first_ok_x_ind1)
                                dict_res1 = create_result_for_polynom1(polynom_obj, last_end_x_polynom1, first_ok_x_ind1, new_curve_pxls_arr1)
                                dict_res1 = create_result_for_polynom1(polynom_obj, last_end_x_polynom1, first_ok_x_ind1, new_curve_pxls_arr1)
                                If dict_res1("min_diff_h1") > 5 Then
                                    dict_res1 = create_result_for_polynom1(polynom_obj, last_end_x_polynom1, first_ok_x_ind1, new_curve_pxls_arr1)

                                End If
                                last_derivate1 = dict_res1("end_derivative2")
                            Else
                                dict_res1("error1") = "yes"
                                first_ok_x_ind1 = -1
                            End If
                            If first_ok_x_ind1 > 0 Then
                            Else
                                'dict_res1("error1") = "yes"

                            End If

                        End If

                        Dim found_ok_polynom1 As String = ""
                        Dim dict_prms2 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)

                        dict_prms2("last_delta_height1") = dict_prms1("last_delta_height1")
                        dict_prms2("last_add_height1") = dict_prms1("last_add_height1")
                        dict_prms2("curve_ind1") = dict_prms1("curve_ind1")
                        dict_prms2("add_curve_width1") = dict_prms1("add_curve_width1")


                        If polynom_result_arr1.Count = 7 Then
                            Dim d7 As Integer = 2
                        End If
                        'dict_prms2("add_height_to_curve1") = dict_prms1("add_height_to_curve1")


                        'last_add_height1 = 0
                        Dim dict_res1b As Dictionary(Of String, Object) = dict_res1


                        'If (dict_res1("end_derivative2") < min_last_derivative1 And Math.Abs(dict_res1("end_derivative2") - min_last_derivative1) > min_dist_down_last_derivative1 Or
                        'dict_res1("end_derivative2") > min_last_derivative1 And Math.Abs(dict_res1("end_derivative2") - min_last_derivative1) > min_dist_up_last_derivative1) And first_ok_x_ind1 = -1 Then


                        If ((Math.Abs(dict_res1("end_derivative2") - min_last_derivative1) > min_dist_last_derivative1) Or
                            ((dict_res1("end_derivative2") < min_last_derivative1 And Math.Abs(dict_res1("end_derivative2") - min_last_derivative1) < min_dist_down_last_derivative1 Or
                            dict_res1("end_derivative2") > min_last_derivative1 And Math.Abs(dict_res1("end_derivative2") - min_last_derivative1) < min_dist_up_last_derivative1)) = False) And first_ok_x_ind1 = -1 Then



                            Dim to_stop1 As Integer = 0
                            dict_prms2("add_curve_height1") = 0
                            Dim last_end_derivative2 As Double = dict_res1("end_derivative2")
                            Dim factor_dec_add_height1 As Double = 0.05
                            Dim last_dir1 As Integer = 0
                            Dim last_deriv_val1 As Double = -1
                            Dim loop_num3 As Integer = 0
                            While to_stop1 = 0
                                loop_num3 += 1
                                If loop_num3 = 11 Then
                                    Dim d1 As Integer = 7
                                End If
                                If dict_res1b("end_derivative2") > min_last_derivative1 Then
                                    If last_dir1 = 0 Then
                                        last_dir1 = -1
                                    ElseIf last_dir1 = 1 Then
                                        factor_dec_add_height1 /= 2
                                    End If
                                    dict_prms2("add_curve_height1") -= factor_dec_add_height1

                                Else
                                    If last_dir1 = 0 Then
                                        last_dir1 = 1
                                    ElseIf last_dir1 = -1 Then
                                        factor_dec_add_height1 /= 2
                                    End If

                                    dict_prms2("add_curve_height1") += factor_dec_add_height1

                                End If

                                If polynom_result_arr1.Count = 1 And False Then
                                    dict_prms2("add_curve_height1") = -0.39999999999999997 - 0.003
                                    force_over_dict_res1 = "yes"
                                End If
                                dict_prms2("check1") = "yes"
                                dict_res1b = find_polynom_coefs1(init_poynom_obj1, last_derivate1, 99, slice_curve_pxls_arr1, "only_start_derivate1", dict_prms2)

                                'add fix error loop
                                If dict_res1b.ContainsKey("error1") Then
                                    start_coef1 = Math.Pow(10, -7)
                                    dict_res1b = find_polynom_coefs1(init_poynom_obj1, last_derivate1, 99, slice_curve_pxls_arr1, "only_start_derivate1", dict_prms2)
                                    start_coef1 = Math.Pow(10, -5)
                                End If



                                dict_prms2.Remove("check1")
                                dict_res1b("start_ind1") = start_ind1
                                dict_res1b("last_ind1") = last_ind1
                                dict_res1b("count_loop1") = find_polynom_coefs1_loop1
                                find_polynom_coefs1_loop1 += 1
                                all_polynom_result_arr1.Add(dict_res1b)
                                'If dict_res1b.ContainsKey("end_derivative2") Or dict_res1b.ContainsKey("error_type1") Then
                                If dict_res1b.ContainsKey("end_derivative2") Then

                                    If dict_res1b.ContainsKey("end_derivative2") = False Then
                                        'dict_res1b("end_derivative2") = 999

                                    End If
                                    'last_deriv_val1 = dict_res1b("end_derivative2")
                                    'If dict_res1b("end_derivative2") > min_last_derivative1 And Math.Abs(dict_res1b("end_derivative2") - min_last_derivative1) < min_dist_last_derivative1 Then
                                    'If Math.Abs(dict_res1b("end_derivative2") - min_last_derivative1) < min_dist_last_derivative1 Then

                                    If ((dict_res1b("end_derivative2") < min_last_derivative1 And Math.Abs(dict_res1b("end_derivative2") - min_last_derivative1) < min_dist_down_last_derivative1 Or
                                            dict_res1b("end_derivative2") > min_last_derivative1 And Math.Abs(dict_res1b("end_derivative2") - min_last_derivative1) < min_dist_up_last_derivative1) Or force_over_dict_res1 = "yes") And first_ok_x_ind1 = -1 Then



                                        dict_res1 = dict_res1b
                                        to_stop1 = 1
                                        found_ok_polynom1 = "yes"
                                        last_add_height1 = dict_prms2("add_curve_height1")
                                        found_good_derivative_in_more_height1 = "yes"
                                    Else
                                        If Math.Abs(dict_prms2("add_curve_height1")) >= max_add_curve_height1 Then
                                            to_stop1 = 1
                                        End If
                                    End If
                                    last_end_derivative2 = dict_res1b("end_derivative2")
                                Else
                                    to_stop1 = 1
                                End If

                            End While



                        End If


                    End If
                End If
                If count_loop1 = 3 Then
                    Dim d8 As Integer = 4
                End If
                If dict_res1.ContainsKey("error1") Then
                    'If dict_res1("min_dist_diff_height1") > 0 Then
                    'max_proportion1 = proportion1
                    'End If
                    last_ind1 += dir_add_to_last_ind1 * 10
                ElseIf ((dict_res1("end_derivative2") < min_last_derivative1 And Math.Abs(dict_res1("end_derivative2") - min_last_derivative1) < min_dist_down_last_derivative1 Or
                        dict_res1("end_derivative2") > min_last_derivative1 And Math.Abs(dict_res1("end_derivative2") - min_last_derivative1) < min_dist_up_last_derivative1)) = False And force_over_dict_res1 = "" Then



                    'Math.Abs(dict_res1("end_derivative2") - min_last_derivative1) >= min_dist_last_derivative1 Then
                    last_ind1 += dir_add_to_last_ind1 * 1
                    dict_res1("error1") = "yes"

                Else
                    last_derivate1 = dict_res1("end_derivative2")
                    last_delta_height1 = dict_res1("min_diff_h1") 'אם זה גדול מאפס אז הפולינום יותר גבה מהעקומה
                    If last_delta_height1 > 4 Then
                        Dim err2 As Integer = 1
                    End If
                    derivate_arr1.Add(last_derivate1)

                    Try
                        polynom_curves_arr1.Add(dict_res1("polynom_curve1a"))

                    Catch ex As Exception
                        polynom_curves_arr1.Add(New ArrayList())
                    End Try
                    If last_ind1 = curve_last_ind1 Then
                        Dim d1 As Integer = 1
                    End If
                    If found_good_derivative_in_more_height1 <> "yes" And mode1 = "" Then
                        last_add_height1 = 0
                        dict_prms1("add_curve_height1") = 0
                    End If


                    If polynom_result_arr1.Count = 7 Then
                        Dim d2 As Integer = 1
                    End If


                    If mode1 = "not_change_height1" Then
                        'last_delta_height1 = dict_prms1("add_curve_height1")
                    End If
                    dict_res1("last_add_height1") = last_add_height1

                    dict_res1("last_delta_height1") = dict_prms1("last_delta_height1")
                    dict_res1("found_good_derivative_in_more_height1") = found_good_derivative_in_more_height1
                    CGlobals1.save_dict_prms1(dict_res1, path_arr1(cur_path_ind1) + "\result_" + polynom_result_arr1.Count.ToString() + ".json")

                    'dict_prms1_arr1.Add(CGlobals1.dict_prm_to_json_str(dict_prms1))
                    dict_prms1_arr1.Add(last_dict_prms_str1)

                    polynom_result_arr1.Add(dict_res1)
                    CGlobals1.add_to_txt_log1("add polynom reslut num = " + polynom_result_arr1.Count.ToString())
                    Dim width_of_org_curve1 As Integer = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, curve_start_ind1)(0) - CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, curve_last_ind1)(0)
                    str_curve_ind1 += curve_pxls_arr1(0).ToString() + "->" + curve_pxls_arr1(curve_pxls_arr1.Count - 1).ToString() + ","
                    Dim width_of_cur_curve1 As Integer = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, 0)(0) - CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, curve_pxls_arr1.Count - 1)(0)
                    sum_width_of_cur_curve1 += width_of_cur_curve1
                    'Dim frame_pixels_arr1_from_last_ind As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(the_curve1, 10, the_curve1.Count - 1)
                    'Dim frame_pixels_arr1_from_last_ind As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(the_curve1, 10, last_ind1)
                    Dim frame_pixels_arr1_from_last_ind As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(curve_pxls_arr1, org_start_ind, last_ind1)


                    Dim width_of_org_curve2 As Integer = CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1_from_last_ind, 0)(0) - CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1_from_last_ind, frame_pixels_arr1_from_last_ind.Count - 1)(0)

                    If polynom_result_arr1(polynom_result_arr1.Count - 1)("last_ind1") = curve_last_ind1 Then
                        Dim d1 As Integer = 1
                    End If



                    Dim dict_ret_res1 As Dictionary(Of String, Object) = print_polynom_results1(polynom_result_arr1, polynom_curves_arr1, dict_prms1("curve_ind1"), curve_start_ind1, curve_last_ind1, frame_pixels_arr1_from_last_ind)

                    If last_ind1 < curve_last_ind1 Then
                        dict_res1("error1") = "yes"
                        start_ind1 = last_ind1
                        Try
                            last_ind1 = search_for_last_ind1(dict_min_derivative, start_ind1, delta_add_last_ind1, curve_pxls_arr1, last_delta_height1)

                        Catch ex As Exception
                            Dim err1 As Integer = 1
                            last_ind1 = search_for_last_ind1(dict_min_derivative, start_ind1, delta_add_last_ind1, curve_pxls_arr1, last_delta_height1)
                        End Try

                        Try
                            If dict_min_derivative(last_ind1) <= cur_last_derivative_of_curve1 Then 'Or last_ind1 >= first_top_ind1 Then
                                Dim end_of_curve1 As Integer = 1
                                last_ind1 = curve_last_ind1

                            End If

                        Catch ex As Exception
                            Dim err1 As Integer = 1
                        End Try
                        'last_ind1 = start_ind1 + delta_add_last_ind1
                        last_last_ind1 = last_ind1
                        If last_ind1 >= curve_last_ind1 Then
                            last_ind1 = curve_last_ind1
                            is_last_sub_curve1 = "yes"
                        End If
                        max_proportion1 = -1
                        dir_add_to_last_ind1 = -1
                    Else

                    End If
                    dict_prms1("curve_ind1") += 1

                End If
            Else
                last_ind1 += dir_add_to_last_ind1 * 10


            End If
            If last_ind1 < start_ind1 + max_diff_start_last Then
                last_ind1 = last_last_ind1
                dir_add_to_last_ind1 = 1
            End If
            If last_ind1 > curve_last_ind1 Then
                dict_res1.Remove("error1")
            End If

            If last_ind1 = 221 Then
                'last_ind1 = 224
            End If



            '{[start_x_val1, 43.3296144772321]}
            '{[end_x_val1, 14.329614477232099]}
            '{[end_derivative1, 0.03914657758854722]}
            '{[start_derivative1, 0.07930245038045107]}
            '{[polynom_obj1, {img_bg_clean1.CPolynom2}]}
            '{[last_end_x_polynom1, 43.3296144772321]}
            '{[min_dist_from_curve1, -1]}
            '{[end_derivative2, 0.03914657758854722]}
            '{[polynom_curve1a, Count = 30]}
            '{[min_diff_h1, 0.016291455639041441]}
            '{[width_of_curve1, 29]}
            '{[height_of_curve1, 1.6999999999114332]}
            '{[search_mode1, only_start_derivate1]}
            '{[start_ind1, 191]}
            '{[last_ind1, 220]}
            '{[count_loop1, 27]}
            '{[last_add_height1, 0.25]}
            '{[last_delta_height1, 8.8566931566447238E-11]}
            '{[found_good_derivative_in_more_height1, yes]}
            '{[error1, yes]}


            If polynom_result_arr1.Count = 11 Then

                'MessageBox.Show("change_diff1")
                Dim d7 As Integer = 1
            End If
            If last_ind1 = curve_last_ind1 Then

            End If
            'fix_last_pixel
            Dim ok_last_pxl_point1 As String = ""
            If last_go_back_ind1 <> -1 Then
                If polynom_result_arr1.Count - 2 = last_go_back_ind1 Then

                    CGlobals1.add_to_txt_log1("add_curve_height1_factor1=" + add_curve_height1_factor1.ToString())
                    CGlobals1.add_to_txt_log1("min_diff_h1=" + polynom_result_arr1(last_go_back_ind1 + 2 - 1)("min_diff_h1").ToString() + ",end_derivative1=" + polynom_result_arr1(last_go_back_ind1 + 2 - 1)("end_derivative1").ToString())
                    Dim cur_min_value5 As Double = Math.Abs(Double.Parse(polynom_result_arr1(last_go_back_ind1 + 2 - 1)("min_diff_h1"))) + Math.Abs(Double.Parse(polynom_result_arr1(last_go_back_ind1 + 2 - 1)("min_diff_last_derivative1")))
                    If min_min_value5 > cur_min_value5 Then
                        min_min_value5 = cur_min_value5
                        CGlobals1.add_to_txt_log2("min_min_value5=" + min_min_value5.ToString() + ",add_curve_width1_factor1=" + add_curve_width1_factor1.ToString())
                        CGlobals1.add_to_txt_log2("min_min_diff_h1=" + min_min_diff_h1.ToString() + ",max_loop_count1=" + max_loop_count1.ToString())

                    End If


                    If Math.Abs(polynom_result_arr1(last_go_back_ind1 + 2 - 1)("min_diff_h1")) <= Math.Pow(10, -8) And Math.Abs(polynom_result_arr1(last_go_back_ind1 + 2 - 1)("min_diff_last_derivative1")) <= Math.Pow(10, -8) Then
                        ok_last_pxl_point1 = "yes"
                    End If
                End If

            End If

            If (polynom_result_arr1(polynom_result_arr1.Count - 1)("last_ind1") = curve_last_ind1 Or was_error_in_fix_last_pxl1 = "yes") And ok_last_pxl_point1 = "" Then

                If last_add_height_prm1 = 0 Then
                    last_add_height_prm1 = -polynom_result_arr1(polynom_result_arr1.Count - 2)("last_add_height1")

                End If

                is_last_sub_curve1 = ""
                mode_fix_last_pixel1 = "yes"
                If last_go_back_ind1 = -1 Then
                    last_go_back_ind1 = polynom_result_arr1.Count - 2

                    If last_go_back_ind1 = 0 Then
                        last_go_back_ind1_start_ind1 = 0
                        last_go_back_ind1_last_derivative1 = 1

                    End If

                End If
                'End If
                'If polynom_result_arr1.Count = 11 And count_go_back1 < 1 Or was_error_in_fix_last_pxl1 = "yes" Then




                '"end_derivative1"
                '"end_derivative1"
                '"min_diff_h1"

                Dim min_diff_h1_val1 As Double = 9999

                Dim end_derivative1_val1 As Double = 9999

                If was_error_in_fix_last_pxl1 = "" Then
                    min_diff_h1_val1 = CType(polynom_result_arr1(last_go_back_ind1 + 1), Dictionary(Of String, Object))("min_diff_h1")
                    end_derivative1_val1 = CType(polynom_result_arr1(last_go_back_ind1 + 1), Dictionary(Of String, Object))("min_diff_last_derivative1")

                End If

                Dim good_dir1 As String = ""
                If last_min_diff_h1_val1 >= min_diff_h1_val1 Then
                    last_min_diff_h1_val1 = min_diff_h1_val1
                Else
                    'good_dir1 = "no"
                End If

                If last_end_deriv_val1 >= end_derivative1_val1 Then
                    last_end_deriv_val1 = end_derivative1_val1
                Else
                    'good_dir1 = "no"
                End If

                If good_dir1 = "no" Then
                    min_diff_h1_val1 = 9999
                    end_derivative1_val1 = 9999
                End If
                If mode_fix_last_pxl1 = "yes" Then
                    arr_min_diff_h1_and_end_deriv_arr1.Add(Math.Abs(min_diff_h1_val1) + Math.Abs(end_derivative1_val1))

                    If was_error_in_fix_last_pxl1 = "" Then
                        polynom_result_dir_arr_ind_dicts1(dir_arr_cur_ind1) = polynom_result_arr1(last_go_back_ind1)

                    End If

                    arr_min_diff_h1_arr1.Add(Math.Abs(min_diff_h1_val1))
                    arr_end_deriv_arr1.Add(Math.Abs(end_derivative1_val1))
                    min_diff_h1_and_derivs_arr1.Add(min_diff_h1_val1.ToString() + "," + end_derivative1_val1.ToString())
                    'add_curve_width1 = cur_add_curve_width1 + dir_arr1(dir_arr_cur_ind1 * 2) * add_curve_width1_factor1
                    'add_curve_height1 = cur_add_curve_height1 + dir_arr1(dir_arr_cur_ind1 * 2 + 1) * add_curve_height1_factor1
                    'dir_arr_cur_ind1 += 1

                End If

                Dim goback_len1 As Integer = 2
                dict_prms1 = CGlobals1.json_to_dict_prms1(dict_prms1_arr1(last_go_back_ind1))

                Dim add_curve_width1 As Double = 0.5
                Dim add_curve_height1 As Double = -0.25

                If dir_arr_cur_ind1 = 8 Then
                    'MessageBox.Show("compute2")
                    Dim d1234 As Integer = 2
                End If


                'If last_add_curve_width1_val1 <> 9999 Or was_error_in_fix_last_pxl1 = "yes" Then
                If was_error_in_fix_last_pxl1 = "yes" Or True Then
                    If dir_arr_cur_ind1 = 9 Then
                        'MessageBox.Show("compute1")
                        Dim d1234 As Integer = 1
                        Dim ind5 As Integer
                        Dim min_ind5 As Integer = -1
                        Dim min_value5 As Double = 9999
                        For ind5 = 1 To arr_min_diff_h1_and_end_deriv_arr1.Count - 1
                            If min_value5 > arr_min_diff_h1_and_end_deriv_arr1(ind5) Then
                                min_value5 = arr_min_diff_h1_and_end_deriv_arr1(ind5)

                                min_ind5 = ind5
                            End If
                        Next

                        Dim new_cur_val1 As String = ""
                        If min_diff_h_and_deriv1 = 9999 And min_ind5 <> -1 Then
                            min_diff_h_and_deriv1 = min_value5
                            count_div_step_factor_fix_last_pixel1 = 0
                            best_polynom_3 = CType(polynom_result_arr1(polynom_result_arr1.Count - 2)("polynom_obj1"), CPolynom2).clone1()
                            best_polynom_4 = CType(polynom_result_arr1(polynom_result_arr1.Count - 1)("polynom_obj1"), CPolynom2).clone1()
                            new_cur_val1 = "yes"
                        Else
                            If min_diff_h_and_deriv1 > min_value5 Then
                                min_diff_h_and_deriv1 = min_value5


                                best_polynom_3 = CType(polynom_result_arr1(polynom_result_arr1.Count - 2)("polynom_obj1"), CPolynom2).clone1()
                                best_polynom_4 = CType(polynom_result_arr1(polynom_result_arr1.Count - 1)("polynom_obj1"), CPolynom2).clone1()
                                count_div_step_factor_fix_last_pixel1 = 0
                                CGlobals1.add_to_txt_log1("min_diff_h_and_deriv1=" + min_diff_h_and_deriv1.ToString())
                                new_cur_val1 = "yes"

                            Else

                                If False Then
                                    If dir_arr1(min_ind5 * 2) = 0 Or True Then
                                        add_curve_width1_factor1 /= 2

                                    End If
                                    If dir_arr1(min_ind5 * 2 + 1) = 0 Or True Then
                                        add_curve_height1_factor1 /= 2

                                    End If
                                Else
                                    add_curve_width1_factor1 /= factor_div1
                                    add_curve_height1_factor1 /= factor_div1

                                    count_div_step_factor_fix_last_pixel1 += 1
                                    If count_div_step_factor_fix_last_pixel1 > 1 Then
                                        If max_loop_count1 < 3500 Then
                                            max_loop_count1 += 500

                                        End If

                                        If min_min_diff_h1 > Math.Pow(10, -15) Then
                                            min_min_diff_h1 /= 10
                                        End If
                                        'factor_div1 *= 2
                                    End If
                                    While add_curve_width1_factor1 > min_value5
                                        add_curve_width1_factor1 /= 2
                                        add_curve_height1_factor1 /= 2
                                    End While
                                End If


                                CGlobals1.add_to_txt_log1("add_curve_height1_factor1=" + add_curve_height1_factor1.ToString())

                            End If
                        End If

                        If new_cur_val1 = "yes" And min_ind5 <> -1 Then
                            If cur_add_curve_width1 = 0 Then
                                'cur_add_curve_width1 = 1
                            End If
                            cur_add_curve_width1 = cur_add_curve_width1 + dir_arr1(min_ind5 * 2) * add_curve_width1_factor1
                            cur_add_curve_height1 = cur_add_curve_height1 + dir_arr1(min_ind5 * 2 + 1) * add_curve_height1_factor1

                            cur_min_diff_h1_val1 = min_diff_h1_val1
                            cur_end_deriv_val1 = end_derivative1_val1

                        End If
                        add_curve_width1 = cur_add_curve_width1
                        add_curve_height1 = cur_add_curve_height1

                        dir_arr_cur_ind1 = 0
                        arr_min_diff_h1_and_end_deriv_arr1.Clear()
                        arr_min_diff_h1_arr1.Clear()
                        arr_end_deriv_arr1.Clear()
                        min_diff_h1_and_derivs_arr1.Clear()

                    Else
                        'arr_min_diff_h1_and_end_deriv_arr1.Add((Math.Abs(min_diff_h1_val1) + Math.Abs(end_derivative1_val1)).ToString() + ",[" + last_add_curve_width1_val1.ToString() + "," + last_add_curve_height1_val1.ToString() + "]")
                        'If mode_fix_last_pxl1 = "yes" Then
                        'arr_min_diff_h1_and_end_deriv_arr1.Add(Math.Abs(min_diff_h1_val1) + Math.Abs(end_derivative1_val1))


                        ' End If


                    End If


                    add_curve_width1 = cur_add_curve_width1 + dir_arr1(dir_arr_cur_ind1 * 2) * add_curve_width1_factor1
                    add_curve_height1 = cur_add_curve_height1 + dir_arr1(dir_arr_cur_ind1 * 2 + 1) * add_curve_height1_factor1
                    'add_curve_height1 += 0.549999999
                    dir_arr_cur_ind1 += 1

                    If dir_arr_cur_ind1 = 1 Then
                        Dim d1 As Integer = 1
                    End If
                    If dir_arr_cur_ind1 = 1 Then
                        polynom_result_dir_arr_ind_dicts1.Clear()
                    End If


                    If dir_arr_cur_ind1 = 2 Then
                        Dim d1 As Integer = 1
                    End If
                    If was_error_in_fix_last_pxl1 = "" Then

                    End If

                End If
                If last_add_curve_width1_val1 <> 9999 Then
                    'add_curve_width1 = last_add_curve_width1_val1
                End If


                If last_add_curve_height1_val1 <> 9999 Then
                    'add_curve_height1 = last_add_curve_height1_val1
                End If

                'Dim start_derivative1_val1 As Double = CType(polynom_result_arr1(10), Dictionary(Of String, Object))("start_derivative1")

                last_add_curve_width1_val1 = add_curve_width1
                last_add_curve_height1_val1 = add_curve_height1


                last_min_diff_and_derivs_arr1.Add("add_w1=" + last_add_curve_width1_val1.ToString() + ",add_h1=" + last_add_curve_height1_val1.ToString() + ",min_diff_h1=" + min_diff_h1_val1.ToString() + ",e_d1=" + end_derivative1_val1.ToString())
                dict_prms1("add_curve_width1") = add_curve_width1
                dict_prms1("add_height_to_curve1") = add_curve_height1

                last_ind1 = dict_prms1("end_pixel_ind1")
                last_delta_height1 = dict_prms1("last_delta_height1")
                last_add_height1 = dict_prms1("last_add_height1")


                'Dim dict_res_last1 As Dictionary(Of String, Object) = polynom_result_arr1(polynom_result_arr1.Count - goback_len1)


                dict_res1("error1") = "yes"

                Try
                    start_ind1 = polynom_result_arr1(last_go_back_ind1 - 1)("start_ind1") - go_back_last_ind1



                Catch ex As Exception
                    start_ind1 = last_go_back_ind1_start_ind1 - go_back_last_ind1
                    Dim err1 As Integer = 1
                End Try
                'last_ind1 = polynom_result_arr1(polynom_result_arr1.Count - goback_len1)("last_ind1")

                'last_add_height1 = polynom_result_arr1(polynom_result_arr1.Count - 1)("last_add_height1")
                Try
                    last_derivate1 = polynom_result_arr1(last_go_back_ind1 - 1)("end_derivative1")

                Catch ex As Exception
                    last_derivate1 = last_go_back_ind1_last_derivative1
                End Try
                'last_delta_height1 = polynom_result_arr1(polynom_result_arr1.Count - 1)("last_delta_height1")

                Dim clr_ind1 As Integer
                While polynom_result_arr1.Count > last_go_back_ind1
                    polynom_result_arr1.RemoveAt(polynom_result_arr1.Count - 1)
                    'dict_prms1_arr1.RemoveAt(dict_prms1_arr1.Count - 1)

                End While


                While dict_prms1_arr1.Count > (last_go_back_ind1 + 1)
                    'polynom_result_arr1.RemoveAt(polynom_result_arr1.Count - 1)
                    dict_prms1_arr1.RemoveAt(dict_prms1_arr1.Count - 1)

                End While
                Try
                    If polynom_result_arr1.Count > 0 Then





                        If polynom_result_arr1.Count - 2 = last_go_back_ind1 Then
                            start_ind1 = polynom_result_arr1(polynom_result_arr1.Count - 1)("last_ind1") - go_back_last_ind1

                            dict_prms1("last_add_height1") = 0
                            last_add_height1 = 0
                        Else
                            start_ind1 = polynom_result_arr1(polynom_result_arr1.Count - 1)("last_ind1")
                            dict_prms1("last_add_height1") = last_add_height_prm1
                            last_add_height1 = last_add_height_prm1
                        End If
                        last_derivate1 = polynom_result_arr1(polynom_result_arr1.Count - 1)("end_derivative1")




                    End If

                Catch ex As Exception

                End Try

                'For clr_ind1 = 1 To goback_len1
                'polynom_result_arr1.RemoveAt(polynom_result_arr1.Count - 1)
                'dict_prms1_arr1.RemoveAt(dict_prms1_arr1.Count - 1)

                'Next

                Dim d2 As Integer = 1
                'count_go_back1 += 1
                mode1 = "not_change_height1"
                force_over_dict_res1 = "yes"

                was_error_in_fix_last_pxl1 = ""

                mode_fix_last_pxl1 = "yes"
                'do_force1 = "yes"
            Else

                If mode_fix_last_pixel1 = "yes" Then

                    If dict_prms1.ContainsKey("add_curve_width1") = True Then

                        If Math.Abs(dict_prms1("add_curve_width1")) > 0 Then
                            dict_prms1("add_curve_width1") = -dict_prms1("add_curve_width1")
                        End If
                    End If

                    If dict_prms1.ContainsKey("add_height_to_curve1") = True Then

                        If Math.Abs(dict_prms1("add_height_to_curve1")) > 0 Then
                            dict_prms1("add_height_to_curve1") = -dict_prms1("add_height_to_curve1")
                        End If
                    End If


                    dict_prms1("last_add_height1") = -last_add_height_prm1
                    last_add_height1 = -last_add_height_prm1

                    mode1 = ""
                    force_over_dict_res1 = ""

                    dict_res1("error1") = "yes"
                End If
            End If

        End While

        CGlobals1.add_to_txt_log1("end: " + Me.suffix_path1)
        CGlobals1.add_to_txt_log1("------------------------")


        'MessageBox.Show("end_curve_approximation_by_polynom1")


    End Function



    Public Function draw_polynoms1()

        set_cur_path_of_curve1()

        Dim frame_pixels_arr1 As ArrayList = CGlobals1.form_obj1.markingfldimg_obj1.load_2d_pixels_arr1(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_frame4.txt")




        Dim dict_rect_frame1 As Dictionary(Of String, Object) = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(frame_pixels_arr1)


        Dim center_x1 As Integer = (dict_rect_frame1("min_x1") + dict_rect_frame1("max_x1")) / 2

        Dim ind1 As Integer = 0

        While CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1, ind1)(0) < center_x1
            ind1 += 1
        End While


        Dim ind2 As Integer = ind1 + 2

        While CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1, ind2)(0) > center_x1
            ind2 += 1
        End While
        Dim right_frame1 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, ind1, ind2)


        frame_pixels_arr1 = right_frame1



        frame_pixels_arr1 = CGlobals1.zoom_curve1(frame_pixels_arr1, curve_zoom1)
        Dim ref_move1 As Double() = CGlobals1.get_double_cord_xy_in_pixels_arr2(frame_pixels_arr1, 0)
        frame_pixels_arr1 = CGlobals1.form_obj1.markingfldimg_obj1.move_double_pixels_arr1(frame_pixels_arr1, 100, 100)

        Dim slice_pxl_arr1 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, 459, 748)
        Dim dict_rect_slice_pxl_arr1 As Dictionary(Of String, Object) = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(slice_pxl_arr1)

        Dim w1s As Integer = Math.Abs(dict_rect_slice_pxl_arr1("max_x1") - dict_rect_slice_pxl_arr1("min_x1")) + 1
        Dim h1s As Integer = Math.Abs(dict_rect_slice_pxl_arr1("max_y1") - dict_rect_slice_pxl_arr1("min_y1")) + 1


        Dim start_cord1 As Double() = CGlobals1.get_double_cord_xy_in_pixels_arr2(slice_pxl_arr1, 0)
        Dim end_cord1 As Double() = CGlobals1.get_double_cord_xy_in_pixels_arr2(slice_pxl_arr1, slice_pxl_arr1.Count - 1)
        'Dim frame_pixels_arr1 As ArrayList = CGlobals1.form_obj1.markingfldimg_obj1.load_2d_pixels_arr1(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_frame4.txt")


        'Dim curve_pxls_arr1 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, curve_start_ind1, last_right_ind1)


        'curve_pxls_arr1 = single_pixel_in_every_x_min_y(curve_pxls_arr1)







        Dim bmp5 As Bitmap = CGlobals1.create_fill_bitmap(9000, 7000, Color.FromArgb(255, 255, 255))
        Dim bmp_polynom1 As Bitmap = CGlobals1.create_fill_bitmap(9000, 7000, Color.FromArgb(255, 255, 255))
        Dim bmp_curve_and_polynom1 As Bitmap = CGlobals1.create_fill_bitmap(9000, 7000, Color.FromArgb(255, 255, 255))

        'frame_pixels_arr1
        CGlobals1.form_obj1.markingfldimg_obj1.set_double_pixel_arr_on_bmp2(frame_pixels_arr1, bmp5, Color.FromArgb(24, 23, 50))
        CGlobals1.form_obj1.markingfldimg_obj1.set_double_pixel_arr_on_bmp2(frame_pixels_arr1, bmp_curve_and_polynom1, Color.FromArgb(24, 23, 50))

        'curve_zoom1
        Dim path_of_result1 As String = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_zoom_" + curve_zoom1.ToString()
        If System.IO.Directory.Exists(path_of_result1) = False Then
            System.IO.Directory.CreateDirectory(path_of_result1)

        End If

        bmp5.Save(path_of_result1 + "\curve1.bmp")



        'bmp5.Save(CGlobals1.global_path1 + CGlobals1.sobel_pics_path1 + "frame4.bmp")
        Dim curves_arr1 As ArrayList = New ArrayList()
        Dim cords_arr1 As ArrayList = New ArrayList()
        Dim relative_cord1(2) As Integer

        Dim relative_cord1_arr1 As ArrayList = New ArrayList()

        For path_ind1 = 0 To 5
            Dim cur_path1 As String = path_arr1(path_ind1)

            Dim cur_pxls_curve_arr1 As ArrayList = CGlobals1.form_obj1.markingfldimg_obj1.load_double_2d_pixels_arr1(path_arr1(path_ind1) + "\complete_polynom_curve1.txt")

            Dim pxl_ind2 As Integer
            Dim new_cur_pxls_curve_arr1 As ArrayList = New ArrayList()

            For pxl_ind2 = 0 To cur_pxls_curve_arr1.Count - 1
                Dim cord_xy1 As Double() = CGlobals1.get_double_cord_xy_in_pixels_arr2(cur_pxls_curve_arr1, pxl_ind2)

                new_cur_pxls_curve_arr1.Add(CType(cord_xy1(0), Integer).ToString() + "," + CType(cord_xy1(1), Integer).ToString())
            Next
            cur_pxls_curve_arr1 = new_cur_pxls_curve_arr1




            Dim rect_of_curve1 As Dictionary(Of String, Object) = CGlobals1.form_obj1.macros_obj1.find_double_rect_of_pixels_arr(cur_pxls_curve_arr1)
            Dim w1b As Integer = Math.Abs(rect_of_curve1("max_x1") - rect_of_curve1("min_x1")) + 1
            Dim h1b As Integer = Math.Abs(rect_of_curve1("max_y1") - rect_of_curve1("min_y1")) + 1


            'Public suffix_path_arr1 As String() = {
            '"_front_top_0_frame1", 
            '"_front_top_1_frame1", 
            '"_front_top_2_frame1", 
            '"_front_right_1_frame1", 
            '"_front_right_2_frame1", 
            '"_front_bottom_1_frame1", 
            '"_front_bottom_2_frame1"}

            If suffix_path_arr1(path_ind1) = "_front_top_2_frame1" Or suffix_path_arr1(path_ind1) = "_front_right_2_frame1" Or suffix_path_arr1(path_ind1) = "_front_bottom_2_frame1" Then
                cur_pxls_curve_arr1.Reverse()
                cur_pxls_curve_arr1 = flip_curve_vertical1(cur_pxls_curve_arr1)

            End If


            'If path_ind1 = 1 Or path_ind1 = 3 Or path_ind1 = 5 Then
            'cur_pxls_curve_arr1.Reverse()
            'cur_pxls_curve_arr1 = flip_curve_vertical1(cur_pxls_curve_arr1)


            'End If

            If suffix_path_arr1(path_ind1) = "_front_right_1_frame1" Or suffix_path_arr1(path_ind1) = "_front_right_2_frame1" Then
                Dim cord_xy1a As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(cur_pxls_curve_arr1, 0)



                Dim vec_3d_obj1 As vec_3d1 = New vec_3d1()
                vec_3d_obj1.p1 = New point_3d1()
                vec_3d_obj1.p1.x1 = cord_xy1a(0)
                vec_3d_obj1.p1.y1 = cord_xy1a(1)


                vec_3d_obj1.p2 = New point_3d1()
                vec_3d_obj1.p2.x1 = cord_xy1a(0)
                vec_3d_obj1.p2.y1 = cord_xy1a(1)
                vec_3d_obj1.p2.z1 = -10

                cur_pxls_curve_arr1 = CGlobals1.form_obj1.markingfldimg_obj1.rotate_2d_pixels_arr(cur_pxls_curve_arr1, vec_3d_obj1, 90)






            End If


            If suffix_path_arr1(path_ind1) = "_front_top_0_frame1" Or suffix_path_arr1(path_ind1) = "_front_bottom_1_frame1" Or suffix_path_arr1(path_ind1) = "_front_bottom_2_frame1" Then
                Dim cord_xy1a As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(cur_pxls_curve_arr1, 0)

                relative_cord1 = cord_xy1a
                relative_cord1_arr1.Add(relative_cord1.Clone())
                Dim vec_3d_obj1 As vec_3d1 = New vec_3d1()
                vec_3d_obj1.p1 = New point_3d1()
                vec_3d_obj1.p1.x1 = cord_xy1a(0)
                vec_3d_obj1.p1.y1 = cord_xy1a(1)


                vec_3d_obj1.p2 = New point_3d1()
                vec_3d_obj1.p2.x1 = cord_xy1a(0)
                vec_3d_obj1.p2.y1 = cord_xy1a(1)
                vec_3d_obj1.p2.z1 = -10

                cur_pxls_curve_arr1 = CGlobals1.form_obj1.markingfldimg_obj1.rotate_2d_pixels_arr(cur_pxls_curve_arr1, vec_3d_obj1, 180)






            End If


            If suffix_path_arr1(path_ind1) = "_front_top_0_frame1" Then
                'Dim center_top_ind1 As Integer = Integer.Parse(System.IO.File.ReadAllText(path_arr1(path_ind1) + "\center_top_ind1.txt"))

                Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1, 0)
                relative_cord1 = cord_xy1
                relative_cord1_arr1.Add(relative_cord1.Clone())


                cords_arr1.Add(cord_xy1)
                Dim rect1 As Dictionary(Of String, Object) = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(cur_pxls_curve_arr1)


                Dim w1 As Integer = Math.Abs(rect1("min_x1") - rect1("max_x1")) + 1
                Dim h1 As Integer = Math.Abs(rect1("min_y1") - rect1("max_y1")) + 1

                cords_arr1.Add("w1=" + w1.ToString() + "," + "h1=" + h1.ToString())


                cur_pxls_curve_arr1 = CGlobals1.form_obj1.markingfldimg_obj1.move_double_pixels_arr1(cur_pxls_curve_arr1, -rect1("min_x1") + cord_xy1(0), -rect1("max_y1") + cord_xy1(1))


                Dim rect1d As Dictionary(Of String, Object) = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(cur_pxls_curve_arr1)


                Dim w1d As Integer = Math.Abs(rect1("min_x1") - rect1("max_x1")) + 1
                Dim h1d As Integer = Math.Abs(rect1("min_y1") - rect1("max_y1")) + 1



                curves_arr1.Add(cur_pxls_curve_arr1)
                CGlobals1.form_obj1.markingfldimg_obj1.set_double_pixel_arr_on_bmp2(cur_pxls_curve_arr1, bmp_polynom1, Color.FromArgb(24, 230, 50))
                CGlobals1.form_obj1.markingfldimg_obj1.set_double_pixel_arr_on_bmp2(cur_pxls_curve_arr1, bmp_curve_and_polynom1, Color.FromArgb(24, 230, 50))

            End If



            If suffix_path_arr1(path_ind1) = "_front_top_1_frame1" Then
                Dim center_top_ind1 As Integer = Integer.Parse(System.IO.File.ReadAllText(path_arr1(path_ind1) + "\center_top_ind1.txt"))

                Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1, center_top_ind1)
                relative_cord1 = cord_xy1
                relative_cord1_arr1.Add(relative_cord1.Clone())


                cords_arr1.Add(cord_xy1)
                Dim rect1 As Dictionary(Of String, Object) = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(cur_pxls_curve_arr1)


                Dim w1 As Integer = Math.Abs(rect1("min_x1") - rect1("max_x1")) + 1
                Dim h1 As Integer = Math.Abs(rect1("min_y1") - rect1("max_y1")) + 1

                cords_arr1.Add("w1=" + w1.ToString() + "," + "h1=" + h1.ToString())


                cur_pxls_curve_arr1 = CGlobals1.form_obj1.markingfldimg_obj1.move_double_pixels_arr1(cur_pxls_curve_arr1, -rect1("max_x1") + cord_xy1(0), -rect1("min_y1") + cord_xy1(1))


                Dim rect1d As Dictionary(Of String, Object) = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(cur_pxls_curve_arr1)


                Dim w1d As Integer = Math.Abs(rect1("min_x1") - rect1("max_x1")) + 1
                Dim h1d As Integer = Math.Abs(rect1("min_y1") - rect1("max_y1")) + 1



                curves_arr1.Add(cur_pxls_curve_arr1)
                CGlobals1.form_obj1.markingfldimg_obj1.set_double_pixel_arr_on_bmp2(cur_pxls_curve_arr1, bmp_polynom1, Color.FromArgb(24, 230, 50))
                CGlobals1.form_obj1.markingfldimg_obj1.set_double_pixel_arr_on_bmp2(cur_pxls_curve_arr1, bmp_curve_and_polynom1, Color.FromArgb(24, 230, 50))

            End If



            If suffix_path_arr1(path_ind1) = "_front_top_2_frame1" Then
                Dim center_top_ind1 As Integer = Integer.Parse(System.IO.File.ReadAllText(path_arr1(path_ind1 - 1) + "\center_top_ind1.txt"))

                Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1, center_top_ind1)
                relative_cord1 = cord_xy1
                relative_cord1_arr1.Add(relative_cord1.Clone())


                cords_arr1.Add(cord_xy1)
                Dim rect1 As Dictionary(Of String, Object) = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(cur_pxls_curve_arr1)


                Dim w1 As Integer = Math.Abs(rect1("min_x1") - rect1("max_x1")) + 1
                Dim h1 As Integer = Math.Abs(rect1("min_y1") - rect1("max_y1")) + 1

                cords_arr1.Add("w1=" + w1.ToString() + "," + "h1=" + h1.ToString())


                cur_pxls_curve_arr1 = CGlobals1.form_obj1.markingfldimg_obj1.move_double_pixels_arr1(cur_pxls_curve_arr1, -rect1("min_x1") + cord_xy1(0), -rect1("min_y1") + cord_xy1(1))


                Dim rect1d As Dictionary(Of String, Object) = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(cur_pxls_curve_arr1)


                Dim w1d As Integer = Math.Abs(rect1("min_x1") - rect1("max_x1")) + 1
                Dim h1d As Integer = Math.Abs(rect1("min_y1") - rect1("max_y1")) + 1



                curves_arr1.Add(cur_pxls_curve_arr1)
                CGlobals1.form_obj1.markingfldimg_obj1.set_double_pixel_arr_on_bmp2(cur_pxls_curve_arr1, bmp_polynom1, Color.FromArgb(24, 230, 50))
                CGlobals1.form_obj1.markingfldimg_obj1.set_double_pixel_arr_on_bmp2(cur_pxls_curve_arr1, bmp_curve_and_polynom1, Color.FromArgb(24, 230, 50))


            End If


            If suffix_path_arr1(path_ind1) = "_front_bottom_2_frame1" Then
                Dim center_top_ind1 As Integer = Integer.Parse(System.IO.File.ReadAllText(path_arr1(path_ind1 - 1) + "\center_top_ind1.txt"))

                Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1, center_top_ind1)
                relative_cord1 = cord_xy1
                relative_cord1_arr1.Add(relative_cord1.Clone())

                cords_arr1.Add(cord_xy1)
                Dim rect1 As Dictionary(Of String, Object) = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(cur_pxls_curve_arr1)


                Dim w1 As Integer = Math.Abs(rect1("min_x1") - rect1("max_x1")) + 1
                Dim h1 As Integer = Math.Abs(rect1("min_y1") - rect1("max_y1")) + 1

                cords_arr1.Add("w1=" + w1.ToString() + "," + "h1=" + h1.ToString())


                cur_pxls_curve_arr1 = CGlobals1.form_obj1.markingfldimg_obj1.move_double_pixels_arr1(cur_pxls_curve_arr1, -rect1("max_x1") + cord_xy1(0), -rect1("max_y1") + cord_xy1(1))

                curves_arr1.Add(cur_pxls_curve_arr1)
                CGlobals1.form_obj1.markingfldimg_obj1.set_double_pixel_arr_on_bmp2(cur_pxls_curve_arr1, bmp_polynom1, Color.FromArgb(24, 230, 50))
                CGlobals1.form_obj1.markingfldimg_obj1.set_double_pixel_arr_on_bmp2(cur_pxls_curve_arr1, bmp_curve_and_polynom1, Color.FromArgb(24, 230, 50))

            End If


            If suffix_path_arr1(path_ind1) = "_front_right_2_frame1" Then
                Dim center_top_ind1 As Integer = Integer.Parse(System.IO.File.ReadAllText(path_arr1(path_ind1 - 1) + "\center_top_ind1.txt"))

                Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1, center_top_ind1)

                cords_arr1.Add(cord_xy1)

                Dim rect1 As Dictionary(Of String, Object) = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(cur_pxls_curve_arr1)

                cur_pxls_curve_arr1 = CGlobals1.form_obj1.markingfldimg_obj1.move_double_pixels_arr1(cur_pxls_curve_arr1, -rect1("max_x1") + cord_xy1(0), -rect1("min_y1") + cord_xy1(1))

                curves_arr1.Add(cur_pxls_curve_arr1)
                CGlobals1.form_obj1.markingfldimg_obj1.set_double_pixel_arr_on_bmp2(cur_pxls_curve_arr1, bmp_polynom1, Color.FromArgb(24, 230, 50))
                CGlobals1.form_obj1.markingfldimg_obj1.set_double_pixel_arr_on_bmp2(cur_pxls_curve_arr1, bmp_curve_and_polynom1, Color.FromArgb(24, 230, 50))

            End If


            If suffix_path_arr1(path_ind1) = "_front_right_1_frame1" Then
                Dim center_top_ind1 As Integer = Integer.Parse(System.IO.File.ReadAllText(path_arr1(path_ind1 - 1) + "\right_pxl_ind1.txt"))

                Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1, center_top_ind1)
                relative_cord1 = cord_xy1
                relative_cord1_arr1.Add(relative_cord1.Clone())

                cords_arr1.Add(cord_xy1)


                Dim rect1 As Dictionary(Of String, Object) = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(cur_pxls_curve_arr1)

                cur_pxls_curve_arr1 = CGlobals1.form_obj1.markingfldimg_obj1.move_double_pixels_arr1(cur_pxls_curve_arr1, -rect1("min_x1") + cord_xy1(0), -rect1("min_y1") + cord_xy1(1))



                'cur_pxls_curve_arr1 = CGlobals1.form_obj1.markingfldimg_obj1.move_double_pixels_arr1(cur_pxls_curve_arr1, cord_xy1(0), cord_xy1(1))
                curves_arr1.Add(cur_pxls_curve_arr1)

                CGlobals1.form_obj1.markingfldimg_obj1.set_double_pixel_arr_on_bmp2(cur_pxls_curve_arr1, bmp_polynom1, Color.FromArgb(24, 230, 50))
                CGlobals1.form_obj1.markingfldimg_obj1.set_double_pixel_arr_on_bmp2(cur_pxls_curve_arr1, bmp_curve_and_polynom1, Color.FromArgb(24, 230, 50))

            End If


            If suffix_path_arr1(path_ind1) = "_front_bottom_1_frame1" Then ' path_ind1 = 4 Then
                Dim center_top_ind1 As Integer = Integer.Parse(System.IO.File.ReadAllText(path_arr1(path_ind1 - 1) + "\right_pxl_ind1.txt"))

                Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1, center_top_ind1)

                cords_arr1.Add(cord_xy1)


                Dim rect1 As Dictionary(Of String, Object) = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(cur_pxls_curve_arr1)

                cur_pxls_curve_arr1 = CGlobals1.form_obj1.markingfldimg_obj1.move_double_pixels_arr1(cur_pxls_curve_arr1, -rect1("max_x1") + cord_xy1(0), -rect1("min_y1") + cord_xy1(1))



                'cur_pxls_curve_arr1 = CGlobals1.form_obj1.markingfldimg_obj1.move_double_pixels_arr1(cur_pxls_curve_arr1, cord_xy1(0), cord_xy1(1))
                curves_arr1.Add(cur_pxls_curve_arr1)

                CGlobals1.form_obj1.markingfldimg_obj1.set_double_pixel_arr_on_bmp2(cur_pxls_curve_arr1, bmp_polynom1, Color.FromArgb(24, 230, 50))
                CGlobals1.form_obj1.markingfldimg_obj1.set_double_pixel_arr_on_bmp2(cur_pxls_curve_arr1, bmp_curve_and_polynom1, Color.FromArgb(24, 230, 50))

            End If


            'bmp5.Save(path_of_result1 + "\polynom1.bmp")
            bmp_polynom1.Save(path_of_result1 + "\polynom1.bmp")
            'bmp_polynom1.Save(CGlobals1.global_path1 + CGlobals1.sobel_pics_path1 + "polynom1.bmp")
            'bmp_curve_and_polynom1.SetPixel(relative_cord1(0), relative_cord1(1), Color.FromArgb(200, 100, 150))

            bmp_curve_and_polynom1.Save(path_of_result1 + "\curve_and_polynom1.bmp")


        Next
    End Function

    Public Function create_polynom_from_curve1()


        Dim i1 As Integer

        For i1 = 0 To 200000
            Dim polynom_iobj1 As CPolynom2 = New CPolynom2()
            Dim dict1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
        Next

        CGlobals1.delete_files1(CGlobals1.global_path1 + CGlobals1.sobel_pics_path1, "*.bmp")

        CGlobals1.add_to_txt_log1("start: " + Me.suffix_path1)
        Dim dict_res2 As Dictionary(Of String, Object) = analize_polynom2()
        Return 1
        'dict_ret_res1("derivatives_arr1") = derivative_dict1
        'dict_ret_res1("curve_pxls_arr1") = new_curve1



        Dim init_poynom_obj1 As CPolynom2 = New CPolynom2()
        init_poynom_obj1.coef_arr1.Add(0)
        init_poynom_obj1.coef_arr1.Add(0.9)
        'init_poynom_obj1.coef_arr1.Add(0.000001)
        'init_poynom_obj1.coef_arr1.Add(0.000001)
        'init_poynom_obj1.coef_arr1.Add(0.000005)
        'init_poynom_obj1.coef_arr1.Add(0.000005)
        init_poynom_obj1.coef_arr1.Add(0.00001)
        init_poynom_obj1.coef_arr1.Add(0.00001)
        init_poynom_obj1.create_derivative1()


        Dim dict_min_derivative As Dictionary(Of Integer, Double) = New Dictionary(Of Integer, Double)
        Dim count_loop1 As Integer = 0
        Dim start_ind1 As Integer = 0
        Dim frame_pixels_arr1 As ArrayList = New ArrayList()

        Dim delta_add_last_ind1 As Integer = 10
        Dim last_delta_height1 As Double = 0
        Dim last_ind1 As Integer = search_for_last_ind1(dict_min_derivative, start_ind1, delta_add_last_ind1, frame_pixels_arr1, last_delta_height1)

        Dim first_top_ind1 As Integer = 0
        Dim min_dist_last_derivative1 As Double = 0.05
        'Dim min_last_derivative1 As Double = 0

        Dim polynom_result_arr1 As ArrayList = New ArrayList()
        Dim polynom_curves_arr1 As ArrayList = New ArrayList()

        Dim max_add_curve_height1 As Double = 0.9

        Dim last_last_ind1 As Integer = 1
        Dim last_add_height1 As Double = 0
        Dim curve_last_ind1 As Integer = frame_pixels_arr1.Count - 1
        Dim curve_start_ind1 As Integer = 0
        Dim max_proportion1 As Double = 0
        Dim max_diff_start_last As Integer = 4
        Dim delta_add_last_ind_min_m1 As Integer = 10
        Dim factor_dec_add_last_ind1 As Integer = 3
        Dim curve_pxls_arr1 As ArrayList = New ArrayList()

        Dim all_polynom_result_arr1 As ArrayList = New ArrayList()
        Dim org_start_ind As Integer = 0

        Dim dict_prms1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
        Dim derivate_arr1 As ArrayList = New ArrayList()

        Dim last_derivate1 As Double = dict_min_derivative(start_ind1)
        Dim dict_res1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
        dict_res1("error1") = "yes"
        Dim sum_width_of_cur_curve1 As Integer = 0
        Dim str_curve_ind1 As String = ""
        Dim find_polynom_coefs1_loop1 As Integer = 0
        Dim m1 As Double = 0
        Dim dir_add_to_last_ind1 As Integer = -1

        While dict_res1.ContainsKey("error1")

            count_loop1 += 1
            If count_loop1 = 13 Then
                Dim dl1 As Integer = 1
            End If


            curve_pxls_arr1 = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, start_ind1, last_ind1)



            Dim dict_rect1a As Dictionary(Of String, Object) = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(curve_pxls_arr1)
            Dim proportion1 As Double = Math.Abs(dict_rect1a("min_y1") - dict_rect1a("max_y1")) / Math.Abs(dict_rect1a("min_x1") - dict_rect1a("max_x1"))
            m1 = find_min_end_m1(frame_pixels_arr1, start_ind1, start_ind1 + delta_add_last_ind_min_m1, 1, 1)
            m1 = dict_min_derivative(start_ind1)

            If last_ind1 = 289 Then
                Dim e1 As Integer = 1
            End If


            Dim min_last_derivative1 As Double = -1
            Dim ind_of_derivative1 As Integer = last_ind1
            While dict_min_derivative.ContainsKey(ind_of_derivative1) = False
                ind_of_derivative1 -= 1
            End While
            min_last_derivative1 = dict_min_derivative(ind_of_derivative1) 'find_min_end_m1(frame_pixels_arr1, last_ind1, last_ind1 + delta_add_last_ind_min_m1, 1, 15)

            If False Then

                If dict_min_derivative.ContainsKey(last_ind1 - 1) Then
                    If min_last_derivative1 > dict_min_derivative(last_ind1 - 1) Then
                        min_last_derivative1 = dict_min_derivative(last_ind1 - 1)
                    End If
                End If
                dict_min_derivative(last_ind1) = min_last_derivative1

            End If


            If last_ind1 >= first_top_ind1 And False Then
                min_last_derivative1 = 0
                last_ind1 = curve_last_ind1
                curve_pxls_arr1 = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, start_ind1, last_ind1)
            End If
            If (last_derivate1 < min_last_derivative1 Or ((start_ind1 + max_diff_start_last) > last_ind1)) And dir_add_to_last_ind1 = -1 Then
                Dim err1 As Integer = 1
                'min_last_derivative1 = last_derivate1 * 0.9
                dir_add_to_last_ind1 = 1
                last_ind1 = last_last_ind1
            End If

            'Dim m2 As Double = dict_min_derivative(last_ind1)

            Dim cord_xy_start1b As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, 0)
            Dim cord_xy_end1b As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, curve_pxls_arr1.Count - 1)

            Dim m1b As Double = -(cord_xy_start1b(1) - cord_xy_end1b(1) - last_delta_height1) / (cord_xy_start1b(0) - cord_xy_end1b(0))

            'curve_pxls_arr1 = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, 600, 700)
            'curve_pxls_arr1 = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, 700, 750)

            'cord_xy_start1 = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, curve_pxls_arr1.Count - 10)
            'cord_xy_end1 = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, curve_pxls_arr1.Count - 1)

            dict_prms1("org_curve1") = frame_pixels_arr1.Clone()
            dict_prms1("end_pixel_ind1") = last_ind1
            dict_prms1("last_delta_height1") = last_delta_height1
            dict_prms1("last_add_height1") = last_add_height1



            'min_last_derivative1 = -999
            If dict_prms1("curve_ind1") = 3 Or dict_prms1("curve_ind1") = 2 Then
                Dim d1 As Integer = 5
            End If

            If last_derivate1 <= m1b Then

                Dim m_check1 As Double = find_min_end_m1(frame_pixels_arr1, start_ind1, start_ind1 + delta_add_last_ind_min_m1, 1, 5)
                Dim err1 As Integer = 1


            End If
            If min_last_derivative1 <= m1b Then
                Dim err1 As Integer = 1
            End If

            If count_loop1 = 12 Then
                Dim d9 As Integer = 2
            End If

            Dim found_good_derivative_in_more_height1 As String = "no"

            If last_derivate1 > m1b And (max_proportion1 = -1 Or max_proportion1 >= proportion1) Then

                dict_res1 = find_polynom_coefs1(init_poynom_obj1, last_derivate1, 99, curve_pxls_arr1, "only_start_derivate1", dict_prms1)
                dict_res1("start_ind1") = start_ind1
                dict_res1("last_ind1") = last_ind1
                dict_res1("count_loop1") = find_polynom_coefs1_loop1
                find_polynom_coefs1_loop1 += 1
                all_polynom_result_arr1.Add(dict_res1)
                If dict_res1.ContainsKey("end_derivative2") = False Then
                    Dim err1 As Integer = 1
                    init_poynom_obj1.coef_arr1.Clear()

                    init_poynom_obj1.coef_arr1.Add(0)
                    init_poynom_obj1.coef_arr1.Add(0.00001)
                    'init_poynom_obj1.coef_arr1.Add(0.000001)
                    'init_poynom_obj1.coef_arr1.Add(0.000001)
                    'init_poynom_obj1.coef_arr1.Add(0.000005)
                    'init_poynom_obj1.coef_arr1.Add(0.000005)
                    init_poynom_obj1.coef_arr1.Add(0.00001)
                    init_poynom_obj1.coef_arr1.Add(0.00001)
                    init_poynom_obj1.create_derivative1()

                    dict_res1 = find_polynom_coefs1(init_poynom_obj1, last_derivate1, 99, curve_pxls_arr1, "only_start_derivate1", dict_prms1)
                End If
                If dict_res1.ContainsKey("end_derivative2") Then


                    If dict_res1("min_diff_h1") > 4 Then
                        Dim err3 As Integer = 1
                    End If
                    If polynom_result_arr1.Count = 3 Then
                        'min_last_derivative1 *= 0.7
                        'only if polynom over the max heght of curve
                    End If
                    If polynom_result_arr1.Count = 4 Then
                        min_last_derivative1 *= 0.9
                        'only if polynom over the max heght of curve
                    End If
                    If dict_res1("end_derivative2") < min_last_derivative1 Or Math.Abs(dict_res1("end_derivative2") - min_last_derivative1) >= min_dist_last_derivative1 Or dict_res1("min_diff_h1") > 2 Then
                    Else
                        Dim ok1 As Integer = 1

                    End If

                    If dict_res1("end_derivative2") >= min_last_derivative1 And Math.Abs(dict_res1("end_derivative2") - min_last_derivative1) >= min_dist_last_derivative1 Then
                        factor_dec_add_last_ind1 = 1
                    Else
                        factor_dec_add_last_ind1 = 3
                    End If

                    If dict_res1("end_derivative2") < min_last_derivative1 Or Math.Abs(dict_res1("end_derivative2") - min_last_derivative1) >= min_dist_last_derivative1 Or dict_res1("min_diff_h1") > 2 Then
                        Dim to_find_derivate_in_polynom As String = "yes1"


                        Dim polynom_obj As CPolynom2 = dict_res1("polynom_obj1")
                        Dim last_end_x_polynom1 As Double = dict_res1("last_end_x_polynom1")
                        Dim width_of_curve1 As Double = dict_res1("width_of_curve1")
                        Dim y_val1a As Double = polynom_obj.get_y_val1(last_end_x_polynom1)
                        Dim y_val1b As Double = polynom_obj.get_y_val1(last_end_x_polynom1 - width_of_curve1)
                        Dim org_min_diff_h1 As Double = dict_res1("min_diff_h1")
                        Dim first_ok_x_ind1 As Integer = -1
                        If to_find_derivate_in_polynom = "yes" Then
                            'חיפוש זווית תקינה של הפולינום
                            Dim x_ind1 As Integer
                            'last_end_x_polynom1 = הנקודה הראשונה בפולינום
                            'כלומר עם הערך  x הכי גבוה

                            'זאת הנקודה האחרונה והיא עם הערך xהכי נמוך 
                            Dim start_x_val1 As Double = last_end_x_polynom1 - width_of_curve1

                            For x_ind1 = 0 To width_of_curve1 'To 0 Step -1
                                Dim polynom_x_val1 As Double = start_x_val1 + x_ind1 '+ (width_of_curve1 - x_ind1)
                                Dim derivative2 As Double = polynom_obj.get_derivative1(polynom_x_val1)
                                Dim derivative3 As Double = dict_min_derivative(last_ind1 - x_ind1)
                                Dim d1 As Integer = 1
                                If derivative2 >= (derivative3) And first_ok_x_ind1 = -1 Then
                                    first_ok_x_ind1 = width_of_curve1 - x_ind1
                                End If
                            Next
                            If first_ok_x_ind1 > width_of_curve1 / 2 Then
                                last_ind1 = start_ind1 + first_ok_x_ind1
                                Dim new_curve_pxls_arr1 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(curve_pxls_arr1, 0, first_ok_x_ind1)
                                dict_res1 = create_result_for_polynom1(polynom_obj, last_end_x_polynom1, first_ok_x_ind1, new_curve_pxls_arr1)
                                dict_res1 = create_result_for_polynom1(polynom_obj, last_end_x_polynom1, first_ok_x_ind1, new_curve_pxls_arr1)
                                If dict_res1("min_diff_h1") > 5 Then
                                    dict_res1 = create_result_for_polynom1(polynom_obj, last_end_x_polynom1, first_ok_x_ind1, new_curve_pxls_arr1)

                                End If
                                last_derivate1 = dict_res1("end_derivative2")
                            Else
                                dict_res1("error1") = "yes"
                                first_ok_x_ind1 = -1
                            End If
                            If first_ok_x_ind1 > 0 Then
                            Else
                                'dict_res1("error1") = "yes"

                            End If

                        End If

                        Dim found_ok_polynom1 As String = ""
                        Dim dict_prms2 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)

                        dict_prms2("last_delta_height1") = dict_prms1("last_delta_height1")
                        dict_prms2("last_add_height1") = dict_prms1("last_add_height1")
                        dict_prms2("curve_ind1") = dict_prms1("curve_ind1")
                        'last_add_height1 = 0
                        Dim dict_res1b As Dictionary(Of String, Object) = dict_res1
                        If Math.Abs(dict_res1("end_derivative2") - min_last_derivative1) <= 0.15 And first_ok_x_ind1 = -1 Then
                            factor_dec_add_last_ind1 = 3
                            Dim to_stop1 As Integer = 0
                            dict_prms2("add_curve_height1") = 0
                            Dim last_end_derivative2 As Double = dict_res1("end_derivative2")
                            Dim factor_dec_add_height1 As Double = 0.05
                            Dim last_dir1 As Integer = 0
                            While to_stop1 = 0

                                If dict_res1b("end_derivative2") > min_last_derivative1 Then
                                    If last_dir1 = 0 Then
                                        last_dir1 = -1
                                    ElseIf last_dir1 = 1 Then
                                        factor_dec_add_height1 /= 2
                                    End If
                                    dict_prms2("add_curve_height1") -= factor_dec_add_height1

                                Else
                                    If last_dir1 = 0 Then
                                        last_dir1 = 1
                                    ElseIf last_dir1 = -1 Then
                                        factor_dec_add_height1 /= 2
                                    End If

                                    dict_prms2("add_curve_height1") += factor_dec_add_height1

                                End If
                                dict_res1b = find_polynom_coefs1(init_poynom_obj1, last_derivate1, 99, curve_pxls_arr1, "only_start_derivate1", dict_prms2)

                                dict_res1b("start_ind1") = start_ind1
                                dict_res1b("last_ind1") = last_ind1
                                dict_res1b("count_loop1") = find_polynom_coefs1_loop1
                                find_polynom_coefs1_loop1 += 1
                                all_polynom_result_arr1.Add(dict_res1b)
                                If dict_res1b.ContainsKey("end_derivative2") Then

                                    'If dict_res1b("end_derivative2") > min_last_derivative1 And Math.Abs(dict_res1b("end_derivative2") - min_last_derivative1) < min_dist_last_derivative1 Then
                                    If Math.Abs(dict_res1b("end_derivative2") - min_last_derivative1) < min_dist_last_derivative1 Then
                                        dict_res1 = dict_res1b
                                        to_stop1 = 1
                                        found_ok_polynom1 = "yes"
                                        last_add_height1 = dict_prms2("add_curve_height1")
                                        found_good_derivative_in_more_height1 = "yes"
                                    Else
                                        If Math.Abs(dict_prms2("add_curve_height1")) >= max_add_curve_height1 Then
                                            to_stop1 = 1
                                        End If
                                    End If
                                    last_end_derivative2 = dict_res1b("end_derivative2")
                                Else
                                    to_stop1 = 1
                                End If

                            End While

                        End If


                    End If
                End If

                If count_loop1 = 3 Then
                    Dim d8 As Integer = 4
                End If
                If dict_res1.ContainsKey("error1") Then
                    'If dict_res1("min_dist_diff_height1") > 0 Then
                    'max_proportion1 = proportion1
                    'End If
                    last_ind1 += dir_add_to_last_ind1 * factor_dec_add_last_ind1
                    'ElseIf dict_res1("end_derivative2") < min_last_derivative1 Or Math.Abs(dict_res1("end_derivative2") - min_last_derivative1) > min_dist_last_derivative1 Then
                ElseIf Math.Abs(dict_res1("end_derivative2") - min_last_derivative1) > min_dist_last_derivative1 Then
                    last_ind1 += dir_add_to_last_ind1 * factor_dec_add_last_ind1
                    dict_res1("error1") = "yes"

                Else
                    last_derivate1 = dict_res1("end_derivative2")
                    last_delta_height1 = dict_res1("min_diff_h1")
                    If last_delta_height1 > 4 Then
                        Dim err2 As Integer = 1
                    End If
                    derivate_arr1.Add(last_derivate1)

                    Try
                        polynom_curves_arr1.Add(dict_res1("polynom_curve1a"))

                    Catch ex As Exception
                        polynom_curves_arr1.Add(New ArrayList())
                    End Try
                    If last_ind1 = curve_last_ind1 Then
                        Dim d1 As Integer = 1
                    End If
                    If found_good_derivative_in_more_height1 <> "yes" Then
                        last_add_height1 = 0
                    End If


                    If polynom_result_arr1.Count = 2 Then
                        Dim d2 As Integer = 1
                    End If
                    dict_res1("last_add_height1") = last_add_height1

                    dict_res1("last_delta_height1") = dict_prms1("last_delta_height1")
                    dict_res1("found_good_derivative_in_more_height1") = found_good_derivative_in_more_height1
                    polynom_result_arr1.Add(dict_res1)
                    CGlobals1.add_to_txt_log1("and polynom results: result num=" + polynom_result_arr1.Count.ToString())
                    Dim width_of_org_curve1 As Integer = CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1, curve_start_ind1)(0) - CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1, curve_last_ind1)(0)
                    str_curve_ind1 += curve_pxls_arr1(0).ToString() + "->" + curve_pxls_arr1(curve_pxls_arr1.Count - 1).ToString() + ","
                    Dim width_of_cur_curve1 As Integer = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, 0)(0) - CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, curve_pxls_arr1.Count - 1)(0)

                    Dim start_cord_x1 As Integer = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, 0)(0)
                    Dim end_cord_x1 As Integer = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, curve_pxls_arr1.Count - 1)(0)
                    Dim total_width1 As Integer = end_cord_x1 - start_cord_x1 + 1
                    sum_width_of_cur_curve1 += width_of_cur_curve1
                    'Dim frame_pixels_arr1_from_last_ind As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(the_curve1, 10, the_curve1.Count - 1)
                    'Dim frame_pixels_arr1_from_last_ind As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(the_curve1, 10, last_ind1)
                    Dim frame_pixels_arr1_from_last_ind As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, org_start_ind, last_ind1)


                    Dim width_of_org_curve2 As Integer = CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1_from_last_ind, 0)(0) - CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1_from_last_ind, frame_pixels_arr1_from_last_ind.Count - 1)(0)
                    Dim dict_ret_res1 As Dictionary(Of String, Object) = print_polynom_results1(polynom_result_arr1, polynom_curves_arr1, dict_prms1("curve_ind1"), curve_start_ind1, curve_last_ind1, frame_pixels_arr1_from_last_ind)

                    If last_ind1 < curve_last_ind1 Then
                        dict_res1("error1") = "yes"
                        start_ind1 = last_ind1
                        last_ind1 = search_for_last_ind1(dict_min_derivative, start_ind1, delta_add_last_ind1, frame_pixels_arr1, last_delta_height1)
                        If dict_min_derivative(last_ind1) < 0 Or last_ind1 >= first_top_ind1 Then
                            Dim end_of_curve1 As Integer = 1
                            last_ind1 = curve_last_ind1

                        End If
                        'last_ind1 = start_ind1 + delta_add_last_ind1
                        last_last_ind1 = last_ind1
                        If last_ind1 >= curve_last_ind1 Then
                            last_ind1 = curve_last_ind1
                        End If
                        max_proportion1 = -1
                        dir_add_to_last_ind1 = -1
                    Else

                    End If
                    dict_prms1("curve_ind1") += 1

                End If
            Else
                last_ind1 += dir_add_to_last_ind1 * factor_dec_add_last_ind1


            End If
            If last_ind1 < start_ind1 + max_diff_start_last And dir_add_to_last_ind1 = -1 Then
                last_ind1 = last_last_ind1
                dir_add_to_last_ind1 = 1
            End If
            If last_ind1 > curve_last_ind1 Then
                dict_res1.Remove("error1")
            End If

            If last_ind1 = 221 Then
                last_ind1 = 224
            End If
        End While
        CGlobals1.add_to_txt_log1("end: " + Me.suffix_path1)
        CGlobals1.add_to_txt_log1("------------------------")
        'MessageBox.Show("end_curve_approximation_by_polynom1")


    End Function
    Public Function analize_polynom1_right_corner()
        'pre_proccessing_curve1()
        Dim init_poynom_obj1 As CPolynom2 = New CPolynom2()
        init_poynom_obj1.coef_arr1.Add(0)
        init_poynom_obj1.coef_arr1.Add(0.9)
        'init_poynom_obj1.coef_arr1.Add(0.000001)
        'init_poynom_obj1.coef_arr1.Add(0.000001)
        'init_poynom_obj1.coef_arr1.Add(0.000005)
        'init_poynom_obj1.coef_arr1.Add(0.000005)
        init_poynom_obj1.coef_arr1.Add(0.00001)
        init_poynom_obj1.coef_arr1.Add(0.00001)
        init_poynom_obj1.create_derivative1()
        Dim curve_pxls_arr1 As ArrayList = New ArrayList()
        Dim frame_pixels_arr1 As ArrayList = CGlobals1.form_obj1.markingfldimg_obj1.load_2d_pixels_arr1(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_frame4.txt")

        Dim do_right_corner1 As String = "yes"
        If do_right_corner1 = "yes" Then

            Dim cord_xy1a As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1, 995)
            Dim cord_xy2a As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1, 995)


            Dim vec_3d_obj1 As vec_3d1 = New vec_3d1()
            vec_3d_obj1.p1 = New point_3d1()
            vec_3d_obj1.p1.x1 = cord_xy1a(0)
            vec_3d_obj1.p1.y1 = cord_xy1a(1)


            vec_3d_obj1.p2 = New point_3d1()
            vec_3d_obj1.p2.x1 = cord_xy1a(0)
            vec_3d_obj1.p2.y1 = cord_xy1a(1)
            vec_3d_obj1.p2.z1 = -10

            frame_pixels_arr1 = CGlobals1.form_obj1.markingfldimg_obj1.rotate_2d_pixels_arr(frame_pixels_arr1, vec_3d_obj1, -90)

        End If

        'CGlobals1.form_obj1.markingfldimg_obj1.rotate_2d_pixels_arr()
        Dim bmp5 As Bitmap = CGlobals1.create_fill_bitmap(4000, 3000, Color.FromArgb(255, 255, 255))
        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(frame_pixels_arr1, bmp5, Color.FromArgb(24, 230, 50))
        bmp5.Save(CGlobals1.global_path1 + CGlobals1.sobel_pics_path1 + "frame4.bmp")
        Dim delta_add_last_ind_min_m1 As Integer = 50
        delta_add_last_ind_min_m1 = 5
        Dim delta_add_last_ind1 As Integer = 50 '45
        delta_add_last_ind1 = 5
        Dim curve_start_ind1 As Integer = 1015
        Dim curve_last_ind1 As Integer = 1050

        If do_right_corner1 = "yes" Then
            'curve_start_ind1 = 995
            'curve_last_ind1 = 1145
            'delta_add_last_ind1 = 5
        End If


        Dim last_ind1 As Integer = curve_start_ind1 + delta_add_last_ind1
        Dim curve_pxls_arr1b As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, curve_start_ind1, curve_last_ind1)
        Dim bmp_f1 As Bitmap = CGlobals1.create_fill_bitmap(3000, 2000, Color.FromArgb(255, 255, 255))
        'CGlobals1.form_obj1.markingfldimg_obj1.set_pixels_arr_and_save2(curve_pxls_arr1b, bmp_f1, Color.FromArgb(255, 100, 70), CGlobals1.global_path1 + CGlobals1.sobel_pics_path1 + "f1.bmp")
        'curve_pxls_arr1b = clear_curve_by_monotonic_down1(curve_pxls_arr1b)
        Dim max_diff_start_last As Integer = 5 'מיניום רוחב של פולינום
        Dim max_add_curve_height1 As Double = 0.9 'כמה אפשר להגדיל את גובה העקומה כדי לתקן זווית קטנה מידי של הפולינום
        Dim right_curve1 As String = "yes"
        If right_curve1 = "yes" Then
            'curve_pxls_arr1b = rotate_curve_vertical2(curve_pxls_arr1b)
        End If


        Dim dict_rect_frame1 As Dictionary(Of String, Object) = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(curve_pxls_arr1b)
        Dim first_top_ind1 As Integer = 0
        Dim last_top_ind1 As Integer = 0




        'curve_pxls_arr1b = clear_curve_by_monotonic_down1(curve_pxls_arr1b)

        Dim bmp1g As Bitmap = CGlobals1.create_fill_bitmap(2500, 1000, Color.FromArgb(255, 255, 255))



        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(curve_pxls_arr1b, bmp1g, Color.FromArgb(200, 30, 70))

        bmp1g.Save(CGlobals1.global_path1 + "sobel_pics1\monotonic_curve1a.bmp")


        While CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1b, first_top_ind1)(1) <> dict_rect_frame1("min_y1")
            first_top_ind1 += 1
        End While

        last_top_ind1 = first_top_ind1

        While CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1b, last_top_ind1)(1) = dict_rect_frame1("min_y1")
            last_top_ind1 += 1
        End While
        curve_pxls_arr1b = CGlobals1.get_arr_from_ind_to_ind1(curve_pxls_arr1b, 0, last_top_ind1)

        If right_curve1 = "yes" Then
            'curve_pxls_arr1b = CGlobals1.form_obj1.markingfldimg_obj1.only_complete_missing_pixels_in_curve2(curve_pxls_arr1b)

        End If

        frame_pixels_arr1 = curve_pxls_arr1b

        CGlobals1.form_obj1.markingfldimg_obj1.set_pixels_arr_and_save2(curve_pxls_arr1b, bmp_f1, Color.FromArgb(255, 100, 70), CGlobals1.global_path1 + CGlobals1.sobel_pics_path1 + "f1.bmp")
        curve_start_ind1 = 0
        curve_last_ind1 = 300


        Dim bmp1c As Bitmap = CGlobals1.create_fill_bitmap(2500, 1000, Color.FromArgb(255, 255, 255))



        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(curve_pxls_arr1b, bmp1c, Color.FromArgb(200, 30, 70))

        bmp1c.Save(CGlobals1.global_path1 + "sobel_pics1\monotonic_curve1.bmp")

        'מקטע ראשון
        last_ind1 = curve_start_ind1 + delta_add_last_ind1

        curve_pxls_arr1 = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, curve_start_ind1, last_ind1)
        'curve_pxls_arr1 = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, 600, 700)
        'curve_pxls_arr1 = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, 700, 750)
        Dim cord_xy_start1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, 0)
        Dim cord_xy_end1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, curve_pxls_arr1.Count - 1)

        Dim m1 As Double = -(cord_xy_start1(1) - cord_xy_end1(1)) / (cord_xy_start1(0) - cord_xy_end1(0))
        'm1 = 0.3

        Dim dict_prms1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)


        Dim dict_res1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)




        dict_res1("error1") = "yes"
        Dim minus_m1 As Double = 0.01

        Dim last_derivate1 As Double = -1
        dict_prms1("curve_ind1") = 0


        Dim polynom_curves_arr1 As ArrayList = New ArrayList()
        Dim derivate_arr1 As ArrayList = New ArrayList()
        Dim polynom_result_arr1 As ArrayList = New ArrayList()

        Dim all_polynom_result_arr1 As ArrayList = New ArrayList()
        'last_ind1 = curve_start_ind1 + 30




        'polynom_curves_arr1.Add(dict_res1("polynom_curve1a"))
        last_ind1 = 0

        curve_last_ind1 = (first_top_ind1 + last_top_ind1) / 2

        Dim the_curve1 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, curve_start_ind1, curve_last_ind1)
        Dim bmp1d As Bitmap = CGlobals1.create_fill_bitmap(2500, 1000, Color.FromArgb(255, 255, 255))
        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(the_curve1, bmp1d, Color.FromArgb(200, 30, 70))

        bmp1d.Save(CGlobals1.global_path1 + "sobel_pics1\the_curve1.bmp")

        Dim start_ind1 As Integer = last_ind1 + 1

        last_ind1 = start_ind1 + delta_add_last_ind1
        'last_derivate1 = dict_res1("end_derivative2")

        Dim start_m1 As Double = 10

        If do_right_corner1 = "yes" Then
            start_m1 = 9
        End If
        last_derivate1 = find_min_end_m1(frame_pixels_arr1, start_ind1, start_ind1 + delta_add_last_ind_min_m1, 1, 10, start_m1)


        Dim derivatives_inds_str1 As String = ""
        Try
            derivatives_inds_str1 = System.IO.File.ReadAllText(CGlobals1.global_path1 + CGlobals1.sobel_pics_path1 + "drvs1.txt")

        Catch ex As Exception
            derivatives_inds_str1 = ""
        End Try

        Dim dict_min_derivative As Dictionary(Of Integer, Double) = New Dictionary(Of Integer, Double)
        Dim derivative_ind1 As Integer
        'derivatives_inds_str1 = ""
        Dim last_derivate_more_the_zero1 As Double = -9999
        Dim gap_back_measure_derivative1 As Integer = 3
        If derivatives_inds_str1 = "" Then

            Dim last_derivate_val1 As Double = -1
            delta_add_last_ind_min_m1 = 100
            For derivative_ind1 = start_ind1 + gap_back_measure_derivative1 To curve_last_ind1

                Dim start_check_ind1 As Double = 1
                If do_right_corner1 = "yes" Then
                    start_check_ind1 = 0
                End If
                m1 = find_min_end_m1(frame_pixels_arr1, derivative_ind1, derivative_ind1 + delta_add_last_ind_min_m1, 1, start_check_ind1, start_m1)
                start_m1 = m1 + 1
                CGlobals1.form_obj1.lbl_progress1.Text = "m_ind=" + derivative_ind1.ToString()
                Application.DoEvents()
                'show_derivative_line1(frame_pixels_arr1, derivative_ind1, m1, "f1")
                If last_derivate_val1 = -1 Then
                    last_derivate_val1 = m1
                Else
                    If m1 > last_derivate_val1 Then
                        m1 = last_derivate_val1

                    End If
                End If
                'show_derivative_line1(frame_pixels_arr1, derivative_ind1, m1, "f2")
                last_derivate_val1 = m1
                dict_min_derivative(derivative_ind1 - gap_back_measure_derivative1) = m1
                If derivatives_inds_str1 <> "" Then
                    derivatives_inds_str1 += "#"

                End If
                derivatives_inds_str1 += (derivative_ind1 - gap_back_measure_derivative1).ToString() + "," + m1.ToString()
            Next
            System.IO.File.WriteAllText(CGlobals1.global_path1 + CGlobals1.sobel_pics_path1 + "drvs1.txt", derivatives_inds_str1)

        Else
            Dim devivatives_inds1 As String() = derivatives_inds_str1.Split("#")
            For derivative_ind1 = 0 To devivatives_inds1.Length - 1
                dict_min_derivative(Integer.Parse(devivatives_inds1(derivative_ind1).Split(",")(0))) = Double.Parse(devivatives_inds1(derivative_ind1).Split(",")(1))
                If last_derivate_more_the_zero1 = -9999 Then
                    last_derivate_more_the_zero1 = Double.Parse(devivatives_inds1(derivative_ind1).Split(",")(1))
                Else
                    If Double.Parse(devivatives_inds1(derivative_ind1).Split(",")(1)) > 0 Then
                        last_derivate_more_the_zero1 = Double.Parse(devivatives_inds1(derivative_ind1).Split(",")(1))
                    End If
                End If
            Next
        End If

        derivate_arr1.Add(last_derivate1)
        dict_prms1("curve_ind1") += 1

        dict_res1("error1") = "yes"

        Dim factor_dec_add_last_ind1 As Integer = 3
        Dim min_dist_last_derivative1 As Double = 0.02
        Dim max_proportion1 As Double = -1
        Dim dir_add_to_last_ind1 As Integer = -1
        Dim last_delta_height1 As Double = 0
        Dim last_add_height1 As Double = 0
        Dim last_last_ind1 As Integer = last_ind1
        'start_ind1 = start_ind1 + 7

        Dim org_start_ind As Integer = start_ind1
        last_ind1 = search_for_last_ind1(dict_min_derivative, start_ind1, delta_add_last_ind1, frame_pixels_arr1, last_delta_height1)
        If Math.Abs(last_ind1 - start_ind1) < 70 Then
            'last_ind1 = start_ind1 + 70
        End If
        Dim count_loop1 As Integer = 0
        last_derivate1 = dict_min_derivative(start_ind1)

        Dim sum_width_of_cur_curve1 As Integer = 0
        Dim str_curve_ind1 As String = ""
        Dim find_polynom_coefs1_loop1 As Integer = 0
        While dict_res1.ContainsKey("error1")

            count_loop1 += 1
            If count_loop1 = 13 Then
                Dim dl1 As Integer = 1
            End If
            If do_right_corner1 = "yes" Then
                'If start_ind1 + 10 < last_ind1 Then
                'last_ind1 = start_ind1 + 10

                'End If
            End If

            curve_pxls_arr1 = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, start_ind1, last_ind1)



            Dim dict_rect1a As Dictionary(Of String, Object) = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(curve_pxls_arr1)
            Dim proportion1 As Double = Math.Abs(dict_rect1a("min_y1") - dict_rect1a("max_y1")) / Math.Abs(dict_rect1a("min_x1") - dict_rect1a("max_x1"))
            m1 = find_min_end_m1(frame_pixels_arr1, start_ind1, start_ind1 + delta_add_last_ind_min_m1, 1, 1)
            m1 = dict_min_derivative(start_ind1)

            If last_ind1 = 289 Then
                Dim e1 As Integer = 1
            End If
            If CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1, last_ind1)(1) < dict_rect_frame1("min_y1") + 2 Then
                Dim end_s_top1 As Integer = 1

            End If

            Dim min_last_derivative1 As Double = -1
            Dim ind_of_derivative1 As Integer = last_ind1
            While dict_min_derivative.ContainsKey(ind_of_derivative1) = False
                ind_of_derivative1 -= 1
            End While
            min_last_derivative1 = dict_min_derivative(ind_of_derivative1) 'find_min_end_m1(frame_pixels_arr1, last_ind1, last_ind1 + delta_add_last_ind_min_m1, 1, 15)

            If False Then

                If dict_min_derivative.ContainsKey(last_ind1 - 1) Then
                    If min_last_derivative1 > dict_min_derivative(last_ind1 - 1) Then
                        min_last_derivative1 = dict_min_derivative(last_ind1 - 1)
                    End If
                End If
                dict_min_derivative(last_ind1) = min_last_derivative1

            End If


            If last_ind1 >= first_top_ind1 And False Then
                min_last_derivative1 = 0
                last_ind1 = curve_last_ind1
                curve_pxls_arr1 = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, start_ind1, last_ind1)
            End If
            If (last_derivate1 < min_last_derivative1 Or ((start_ind1 + max_diff_start_last) > last_ind1) And do_right_corner1 <> "yes") And dir_add_to_last_ind1 = -1 Then
                Dim err1 As Integer = 1
                'min_last_derivative1 = last_derivate1 * 0.9
                dir_add_to_last_ind1 = 1
                last_ind1 = last_last_ind1
            End If

            'Dim m2 As Double = dict_min_derivative(last_ind1)

            Dim cord_xy_start1b As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, 0)
            Dim cord_xy_end1b As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, curve_pxls_arr1.Count - 1)

            Dim m1b As Double = -(cord_xy_start1b(1) - cord_xy_end1b(1) - last_delta_height1) / (cord_xy_start1b(0) - cord_xy_end1b(0))

            'curve_pxls_arr1 = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, 600, 700)
            'curve_pxls_arr1 = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, 700, 750)

            'cord_xy_start1 = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, curve_pxls_arr1.Count - 10)
            'cord_xy_end1 = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, curve_pxls_arr1.Count - 1)

            dict_prms1("org_curve1") = frame_pixels_arr1.Clone()
            dict_prms1("end_pixel_ind1") = last_ind1
            dict_prms1("last_delta_height1") = last_delta_height1
            dict_prms1("last_add_height1") = last_add_height1



            'min_last_derivative1 = -999
            If dict_prms1("curve_ind1") = 3 Or dict_prms1("curve_ind1") = 2 Then
                Dim d1 As Integer = 5
            End If

            If last_derivate1 <= m1b Then

                Dim m_check1 As Double = find_min_end_m1(frame_pixels_arr1, start_ind1, start_ind1 + delta_add_last_ind_min_m1, 1, 5)
                Dim err1 As Integer = 1


            End If
            If min_last_derivative1 <= m1b Then
                Dim err1 As Integer = 1
            End If

            If count_loop1 = 12 Then
                Dim d9 As Integer = 2
            End If

            Dim found_good_derivative_in_more_height1 As String = "no"

            If last_derivate1 > m1b And (max_proportion1 = -1 Or max_proportion1 >= proportion1) Then

                dict_res1 = find_polynom_coefs1(init_poynom_obj1, last_derivate1, 99, curve_pxls_arr1, "only_start_derivate1", dict_prms1)
                dict_res1("start_ind1") = start_ind1
                dict_res1("last_ind1") = last_ind1
                dict_res1("count_loop1") = find_polynom_coefs1_loop1
                find_polynom_coefs1_loop1 += 1
                all_polynom_result_arr1.Add(dict_res1)
                If dict_res1.ContainsKey("end_derivative2") = False Then
                    Dim err1 As Integer = 1
                    init_poynom_obj1.coef_arr1.Clear()

                    init_poynom_obj1.coef_arr1.Add(0)
                    init_poynom_obj1.coef_arr1.Add(0.00001)
                    'init_poynom_obj1.coef_arr1.Add(0.000001)
                    'init_poynom_obj1.coef_arr1.Add(0.000001)
                    'init_poynom_obj1.coef_arr1.Add(0.000005)
                    'init_poynom_obj1.coef_arr1.Add(0.000005)
                    init_poynom_obj1.coef_arr1.Add(0.00001)
                    init_poynom_obj1.coef_arr1.Add(0.00001)
                    init_poynom_obj1.create_derivative1()

                    dict_res1 = find_polynom_coefs1(init_poynom_obj1, last_derivate1, 99, curve_pxls_arr1, "only_start_derivate1", dict_prms1)
                End If
                If dict_res1.ContainsKey("end_derivative2") Then


                    If dict_res1("min_diff_h1") > 4 Then
                        Dim err3 As Integer = 1
                    End If
                    If polynom_result_arr1.Count = 3 Then
                        'min_last_derivative1 *= 0.7
                        'only if polynom over the max heght of curve
                    End If
                    If polynom_result_arr1.Count = 4 Then
                        min_last_derivative1 *= 0.9
                        'only if polynom over the max heght of curve
                    End If
                    If dict_res1("end_derivative2") < min_last_derivative1 Or Math.Abs(dict_res1("end_derivative2") - min_last_derivative1) >= min_dist_last_derivative1 Or dict_res1("min_diff_h1") > 2 Then
                    Else
                        Dim ok1 As Integer = 1

                    End If

                    If dict_res1("end_derivative2") >= min_last_derivative1 And Math.Abs(dict_res1("end_derivative2") - min_last_derivative1) >= min_dist_last_derivative1 Then
                        factor_dec_add_last_ind1 = 1
                    Else
                        factor_dec_add_last_ind1 = 3
                    End If

                    If dict_res1("end_derivative2") < min_last_derivative1 Or Math.Abs(dict_res1("end_derivative2") - min_last_derivative1) >= min_dist_last_derivative1 Or dict_res1("min_diff_h1") > 2 Then
                        Dim to_find_derivate_in_polynom As String = "yes1"


                        Dim polynom_obj As CPolynom2 = dict_res1("polynom_obj1")
                        Dim last_end_x_polynom1 As Double = dict_res1("last_end_x_polynom1")
                        Dim width_of_curve1 As Double = dict_res1("width_of_curve1")
                        Dim y_val1a As Double = polynom_obj.get_y_val1(last_end_x_polynom1)
                        Dim y_val1b As Double = polynom_obj.get_y_val1(last_end_x_polynom1 - width_of_curve1)
                        Dim org_min_diff_h1 As Double = dict_res1("min_diff_h1")
                        Dim first_ok_x_ind1 As Integer = -1
                        If to_find_derivate_in_polynom = "yes" Then
                            'חיפוש זווית תקינה של הפולינום
                            Dim x_ind1 As Integer
                            'last_end_x_polynom1 = הנקודה הראשונה בפולינום
                            'כלומר עם הערך  x הכי גבוה

                            'זאת הנקודה האחרונה והיא עם הערך xהכי נמוך 
                            Dim start_x_val1 As Double = last_end_x_polynom1 - width_of_curve1

                            For x_ind1 = 0 To width_of_curve1 'To 0 Step -1
                                Dim polynom_x_val1 As Double = start_x_val1 + x_ind1 '+ (width_of_curve1 - x_ind1)
                                Dim derivative2 As Double = polynom_obj.get_derivative1(polynom_x_val1)
                                Dim derivative3 As Double = dict_min_derivative(last_ind1 - x_ind1)
                                Dim d1 As Integer = 1
                                If derivative2 >= (derivative3) And first_ok_x_ind1 = -1 Then
                                    first_ok_x_ind1 = width_of_curve1 - x_ind1
                                End If
                            Next
                            If first_ok_x_ind1 > width_of_curve1 / 2 Then
                                last_ind1 = start_ind1 + first_ok_x_ind1
                                Dim new_curve_pxls_arr1 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(curve_pxls_arr1, 0, first_ok_x_ind1)
                                dict_res1 = create_result_for_polynom1(polynom_obj, last_end_x_polynom1, first_ok_x_ind1, new_curve_pxls_arr1)
                                dict_res1 = create_result_for_polynom1(polynom_obj, last_end_x_polynom1, first_ok_x_ind1, new_curve_pxls_arr1)
                                If dict_res1("min_diff_h1") > 5 Then
                                    dict_res1 = create_result_for_polynom1(polynom_obj, last_end_x_polynom1, first_ok_x_ind1, new_curve_pxls_arr1)

                                End If
                                last_derivate1 = dict_res1("end_derivative2")
                            Else
                                dict_res1("error1") = "yes"
                                first_ok_x_ind1 = -1
                            End If
                            If first_ok_x_ind1 > 0 Then
                            Else
                                'dict_res1("error1") = "yes"

                            End If

                        End If

                        Dim found_ok_polynom1 As String = ""
                        Dim dict_prms2 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)

                        dict_prms2("last_delta_height1") = dict_prms1("last_delta_height1")
                        dict_prms2("last_add_height1") = dict_prms1("last_add_height1")
                        dict_prms2("curve_ind1") = dict_prms1("curve_ind1")
                        'last_add_height1 = 0
                        Dim dict_res1b As Dictionary(Of String, Object) = dict_res1
                        If Math.Abs(dict_res1("end_derivative2") - min_last_derivative1) <= 0.15 And first_ok_x_ind1 = -1 Then
                            factor_dec_add_last_ind1 = 3
                            Dim to_stop1 As Integer = 0
                            dict_prms2("add_curve_height1") = 0
                            Dim last_end_derivative2 As Double = dict_res1("end_derivative2")
                            Dim factor_dec_add_height1 As Double = 0.05
                            Dim last_dir1 As Integer = 0
                            While to_stop1 = 0

                                If dict_res1b("end_derivative2") > min_last_derivative1 Then
                                    If last_dir1 = 0 Then
                                        last_dir1 = -1
                                    ElseIf last_dir1 = 1 Then
                                        factor_dec_add_height1 /= 2
                                    End If
                                    dict_prms2("add_curve_height1") -= factor_dec_add_height1

                                Else
                                    If last_dir1 = 0 Then
                                        last_dir1 = 1
                                    ElseIf last_dir1 = -1 Then
                                        factor_dec_add_height1 /= 2
                                    End If

                                    dict_prms2("add_curve_height1") += factor_dec_add_height1

                                End If
                                If polynom_result_arr1.Count = 1 Then
                                    dict_prms2("add_curve_height1") = -0.8
                                End If
                                dict_res1b = find_polynom_coefs1(init_poynom_obj1, last_derivate1, 99, curve_pxls_arr1, "only_start_derivate1", dict_prms2)

                                dict_res1b("start_ind1") = start_ind1
                                dict_res1b("last_ind1") = last_ind1
                                dict_res1b("count_loop1") = find_polynom_coefs1_loop1
                                find_polynom_coefs1_loop1 += 1
                                all_polynom_result_arr1.Add(dict_res1b)
                                If dict_res1b.ContainsKey("end_derivative2") Then

                                    'If dict_res1b("end_derivative2") > min_last_derivative1 And Math.Abs(dict_res1b("end_derivative2") - min_last_derivative1) < min_dist_last_derivative1 Then
                                    If Math.Abs(dict_res1b("end_derivative2") - min_last_derivative1) < min_dist_last_derivative1 Then
                                        dict_res1 = dict_res1b
                                        to_stop1 = 1
                                        found_ok_polynom1 = "yes"
                                        last_add_height1 = dict_prms2("add_curve_height1")
                                        found_good_derivative_in_more_height1 = "yes"
                                    Else
                                        If Math.Abs(dict_prms2("add_curve_height1")) >= max_add_curve_height1 Then
                                            to_stop1 = 1
                                        End If
                                    End If
                                    last_end_derivative2 = dict_res1b("end_derivative2")
                                Else
                                    to_stop1 = 1
                                End If

                            End While

                        End If


                    End If
                End If

                If count_loop1 = 3 Then
                    Dim d8 As Integer = 4
                End If
                If dict_res1.ContainsKey("error1") Then
                    'If dict_res1("min_dist_diff_height1") > 0 Then
                    'max_proportion1 = proportion1
                    'End If
                    last_ind1 += dir_add_to_last_ind1 * factor_dec_add_last_ind1
                    'ElseIf dict_res1("end_derivative2") < min_last_derivative1 Or Math.Abs(dict_res1("end_derivative2") - min_last_derivative1) > min_dist_last_derivative1 Then
                ElseIf Math.Abs(dict_res1("end_derivative2") - min_last_derivative1) > min_dist_last_derivative1 Then
                    last_ind1 += dir_add_to_last_ind1 * factor_dec_add_last_ind1
                    dict_res1("error1") = "yes"

                Else
                    last_derivate1 = dict_res1("end_derivative2")
                    last_delta_height1 = dict_res1("min_diff_h1")
                    If last_delta_height1 > 4 Then
                        Dim err2 As Integer = 1
                    End If
                    derivate_arr1.Add(last_derivate1)

                    Try
                        polynom_curves_arr1.Add(dict_res1("polynom_curve1a"))

                    Catch ex As Exception
                        polynom_curves_arr1.Add(New ArrayList())
                    End Try
                    If last_ind1 = curve_last_ind1 Then
                        Dim d1 As Integer = 1
                    End If
                    If found_good_derivative_in_more_height1 <> "yes" Then
                        last_add_height1 = 0
                    End If


                    If polynom_result_arr1.Count = 2 Then
                        Dim d2 As Integer = 1
                    End If
                    dict_res1("last_add_height1") = last_add_height1

                    dict_res1("last_delta_height1") = dict_prms1("last_delta_height1")
                    dict_res1("found_good_derivative_in_more_height1") = found_good_derivative_in_more_height1
                    polynom_result_arr1.Add(dict_res1)

                    Dim width_of_org_curve1 As Integer = CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1, curve_start_ind1)(0) - CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1, curve_last_ind1)(0)
                    str_curve_ind1 += curve_pxls_arr1(0).ToString() + "->" + curve_pxls_arr1(curve_pxls_arr1.Count - 1).ToString() + ","
                    Dim width_of_cur_curve1 As Integer = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, 0)(0) - CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, curve_pxls_arr1.Count - 1)(0)

                    Dim start_cord_x1 As Integer = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, 0)(0)
                    Dim end_cord_x1 As Integer = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, curve_pxls_arr1.Count - 1)(0)
                    Dim total_width1 As Integer = end_cord_x1 - start_cord_x1 + 1
                    sum_width_of_cur_curve1 += width_of_cur_curve1
                    'Dim frame_pixels_arr1_from_last_ind As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(the_curve1, 10, the_curve1.Count - 1)
                    'Dim frame_pixels_arr1_from_last_ind As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(the_curve1, 10, last_ind1)
                    Dim frame_pixels_arr1_from_last_ind As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, org_start_ind, last_ind1)


                    Dim width_of_org_curve2 As Integer = CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1_from_last_ind, 0)(0) - CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1_from_last_ind, frame_pixels_arr1_from_last_ind.Count - 1)(0)
                    Dim dict_ret_res1 As Dictionary(Of String, Object) = print_polynom_results1(polynom_result_arr1, polynom_curves_arr1, dict_prms1("curve_ind1"), curve_start_ind1, curve_last_ind1, frame_pixels_arr1_from_last_ind)

                    If last_ind1 < curve_last_ind1 Then
                        dict_res1("error1") = "yes"
                        start_ind1 = last_ind1
                        last_ind1 = search_for_last_ind1(dict_min_derivative, start_ind1, delta_add_last_ind1, frame_pixels_arr1, last_delta_height1)
                        If dict_min_derivative(last_ind1) < 0 Or last_ind1 >= first_top_ind1 Then
                            Dim end_of_curve1 As Integer = 1
                            last_ind1 = curve_last_ind1

                        End If
                        'last_ind1 = start_ind1 + delta_add_last_ind1
                        last_last_ind1 = last_ind1
                        If last_ind1 >= curve_last_ind1 Then
                            last_ind1 = curve_last_ind1
                        End If
                        max_proportion1 = -1
                        dir_add_to_last_ind1 = -1
                    Else

                    End If
                    dict_prms1("curve_ind1") += 1

                End If
            Else
                last_ind1 += dir_add_to_last_ind1 * factor_dec_add_last_ind1


            End If
            If last_ind1 < start_ind1 + max_diff_start_last And dir_add_to_last_ind1 = -1 Then
                last_ind1 = last_last_ind1
                dir_add_to_last_ind1 = 1
            End If
            If last_ind1 > curve_last_ind1 Then
                dict_res1.Remove("error1")
            End If

            If last_ind1 = 221 Then
                last_ind1 = 224
            End If
        End While

        MessageBox.Show("end_curve_approximation_by_polynom1")
        Return 1
        'curve_last_ind1 = 900
        Dim do_minus_derivative As String = "yes1"
        'minus derivative
        If do_minus_derivative = "yes" Then

            last_derivate1 = 0
            start_ind1 = 730
            last_ind1 = start_ind1 + delta_add_last_ind1
            dict_res1("error1") = "yes"
            While dict_res1.ContainsKey("error1")


                curve_pxls_arr1 = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, start_ind1, last_ind1)


                '---
                Dim bmp5b As Bitmap = CGlobals1.create_fill_bitmap(4000, 3000, Color.FromArgb(255, 255, 255))
                CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(curve_pxls_arr1, bmp5b, Color.FromArgb(24, 230, 50))
                bmp5b.Save(CGlobals1.global_path1 + CGlobals1.sobel_pics_path1 + "frame_" + start_ind1.ToString() + "_" + last_ind1.ToString() + ".bmp")
                '---


                Dim dict_rect1a As Dictionary(Of String, Object) = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(curve_pxls_arr1)
                Dim proportion1 As Double = Math.Abs(dict_rect1a("min_y1") - dict_rect1a("max_y1")) / Math.Abs(dict_rect1a("min_x1") - dict_rect1a("max_x1"))
                m1 = find_min_end_m1(frame_pixels_arr1, start_ind1, last_ind1 + delta_add_last_ind1, 1, 1)

                Dim cord_xy_start1b As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, 0)
                Dim cord_xy_end1b As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, curve_pxls_arr1.Count - 1)

                Dim m1b As Double = -(cord_xy_start1b(1) - cord_xy_end1b(1)) / (cord_xy_start1b(0) - cord_xy_end1b(0))

                'curve_pxls_arr1 = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, 600, 700)
                'curve_pxls_arr1 = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, 700, 750)

                'cord_xy_start1 = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, curve_pxls_arr1.Count - 10)
                'cord_xy_end1 = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, curve_pxls_arr1.Count - 1)

                dict_prms1("org_curve1") = frame_pixels_arr1.Clone()
                dict_prms1("end_pixel_ind1") = last_ind1
                dict_prms1("last_delta_height1") = last_delta_height1
                dict_prms1("last_delta_height1") = last_delta_height1
                If dict_prms1("curve_ind1") = 3 Or dict_prms1("curve_ind1") = 2 Then
                    Dim d1 As Integer = 5
                End If
                If last_derivate1 < Math.Abs(m1b) And (max_proportion1 = -1 Or max_proportion1 >= proportion1) Then

                    dict_res1 = find_polynom_coefs1(init_poynom_obj1, last_derivate1, 99, curve_pxls_arr1, "only_start_derivate_minus1", dict_prms1)



                    If dict_res1.ContainsKey("error1") Then
                        If dict_res1("min_dist_diff_height1") > 0 Then
                            'max_proportion1 = proportion1
                        End If
                        last_ind1 += dir_add_to_last_ind1
                    Else
                        last_derivate1 = dict_res1("end_derivative2")
                        last_delta_height1 = dict_res1("min_diff_h1")
                        derivate_arr1.Add(last_derivate1)

                        polynom_curves_arr1.Add(dict_res1("polynom_curve1a"))

                        polynom_result_arr1.Add(dict_res1)
                        print_polynom_results1(polynom_result_arr1, polynom_curves_arr1, dict_prms1("curve_ind1"), curve_start_ind1, curve_last_ind1, frame_pixels_arr1)

                        If last_ind1 < curve_last_ind1 Then
                            dict_res1("error1") = "yes"
                            start_ind1 = last_ind1
                            last_ind1 = start_ind1 + delta_add_last_ind1
                            If last_ind1 >= curve_last_ind1 Then
                                last_ind1 = curve_last_ind1
                            End If
                            max_proportion1 = -1
                            dir_add_to_last_ind1 = -1
                        Else

                        End If
                        dict_prms1("curve_ind1") += 1

                    End If
                Else
                    last_ind1 += dir_add_to_last_ind1
                    If last_ind1 < start_ind1 + 20 Then
                        dir_add_to_last_ind1 = 1
                    End If

                End If

                If last_ind1 > curve_last_ind1 Then
                    dict_res1.Remove("error1")
                End If
            End While

        End If

        'print_polynom_results1(polynom_result_arr1, polynom_curves_arr1, 1)
        Return 1

        '-----------

        Dim polynom_ind1 As Integer
        Dim complete_curve1 As ArrayList = New ArrayList()
        Dim last_cord_xy1 As Double()


        Dim x_step_val1 As Double = 1 / curve_zoom1
        Dim complete_polynom_curve1 As ArrayList = New ArrayList()
        Dim x_ind_complete_polynom_curve1 As Integer = 10
        Dim last_y_val_polynom1 As Double = 999
        For polynom_ind1 = 0 To polynom_result_arr1.Count - 1
            Dim dict_res2 As Dictionary(Of String, Object) = polynom_result_arr1(polynom_ind1)
            If dict_res2("search_mode1") = "only_end_derivate1" Then
                Dim d8 As Integer = 3
                Dim polynom_obj1 As CPolynom2 = CType(dict_res2("polynom_obj1"), CPolynom2).clone1()
                polynom_obj1.mul_coefs1(curve_zoom1)
                Dim start_x_val1 As Double = dict_res2("last_end_x_polynom1") + dict_res2("width_of_curve1") - (curve_zoom1 - 1)
                Dim end_x_val1 As Double = dict_res2("last_end_x_polynom1")
                Dim start_derivative_val1 As Double = polynom_obj1.get_derivative1(start_x_val1)
                Dim end_derivative_val1 As Double = polynom_obj1.get_derivative1(end_x_val1)

                Dim d4 As Integer = 5
                Dim x_ind1 As Integer
                Dim x_val1 As Double = start_x_val1
                Dim len1 As Integer = dict_res2("width_of_curve1") * curve_zoom1 + (curve_zoom1 - 1)
                For x_ind1 = 0 To len1
                    Dim y_val1 As Double = polynom_obj1.get_y_val1(x_val1)
                    If x_ind1 = len1 Then
                        last_y_val_polynom1 = y_val1
                        polynom_obj1.create_derivative1()
                        Dim end_derivative_val3 As Double = polynom_obj1.get_derivative1(x_val1)
                    End If
                    complete_polynom_curve1.Add(x_ind_complete_polynom_curve1.ToString() + "," + y_val1.ToString())
                    If complete_polynom_curve1.Count = 533 Then
                        Dim d1b As Integer = 1
                    End If
                    x_ind_complete_polynom_curve1 += 1
                    x_val1 -= x_step_val1
                Next
            ElseIf dict_res2("search_mode1") = "only_start_derivate_minus1" Then
                Dim d8 As Integer = 3
                Dim polynom_obj1 As CPolynom2 = CType(dict_res2("polynom_obj1"), CPolynom2).clone1()
                polynom_obj1.mul_coefs1(curve_zoom1)
                Dim start_x_val1 As Double = dict_res2("last_end_x_polynom1")
                Dim end_x_val1 As Double = dict_res2("last_end_x_polynom1") + dict_res2("width_of_curve1") - (curve_zoom1 - 1)

                Dim start_derivative_val1 As Double = polynom_obj1.get_derivative1(start_x_val1)
                Dim end_derivative_val1 As Double = polynom_obj1.get_derivative1(end_x_val1)


                Dim d4 As Integer = 5
                Dim x_ind1 As Integer
                Dim x_val1 As Double = start_x_val1

                Dim delta_y_val1 As Double = polynom_obj1.get_y_val1(x_val1) - last_y_val_polynom1

                Dim len1 As Integer = dict_res2("width_of_curve1") * curve_zoom1 + (curve_zoom1 - 1)
                For x_ind1 = 0 To len1
                    Dim y_val1 As Double = polynom_obj1.get_y_val1(x_val1) - delta_y_val1
                    If x_ind1 = len1 Then
                        last_y_val_polynom1 = y_val1
                        polynom_obj1.create_derivative1()
                        Dim end_derivative_val3 As Double = polynom_obj1.get_derivative1(x_val1)
                    End If
                    complete_polynom_curve1.Add(x_ind_complete_polynom_curve1.ToString() + "," + y_val1.ToString())
                    If complete_polynom_curve1.Count = 533 Then
                        Dim d1a As Integer = 1
                    End If

                    x_ind_complete_polynom_curve1 += 1
                    x_val1 += x_step_val1
                Next

            Else
                Dim d8 As Integer = 3
                Dim polynom_obj1 As CPolynom2 = CType(dict_res2("polynom_obj1"), CPolynom2).clone1()
                polynom_obj1.mul_coefs1(curve_zoom1)
                Dim start_x_val1 As Double = dict_res2("last_end_x_polynom1")
                Dim end_x_val1 As Double = dict_res2("last_end_x_polynom1") - dict_res2("width_of_curve1") + (curve_zoom1 - 1)
                Dim start_derivative_val1 As Double = polynom_obj1.get_derivative1(start_x_val1)
                Dim end_derivative_val1 As Double = polynom_obj1.get_derivative1(end_x_val1)
                Dim d5 As Integer = 5



                Dim x_ind1 As Integer
                Dim x_val1 As Double = start_x_val1


                Dim delta_y_val1 As Double = polynom_obj1.get_y_val1(x_val1) - last_y_val_polynom1

                polynom_obj1.create_derivative1()
                Dim start_derivative_val3 As Double = polynom_obj1.get_derivative1(x_val1)

                Dim len1 As Integer = dict_res2("width_of_curve1") * curve_zoom1 + (curve_zoom1 - 1)
                For x_ind1 = 0 To len1

                    Dim y_val1 As Double = polynom_obj1.get_y_val1(x_val1) - delta_y_val1
                    If x_ind1 = len1 Then
                        last_y_val_polynom1 = y_val1
                    End If
                    complete_polynom_curve1.Add(x_ind_complete_polynom_curve1.ToString() + "," + y_val1.ToString())
                    If complete_polynom_curve1.Count = 533 Then
                        Dim d1c As Integer = 1
                    End If

                    x_ind_complete_polynom_curve1 += 1
                    x_val1 -= x_step_val1
                Next



            End If
            Dim d1 As Integer = 1



            '            +		(0)	{[polynom_obj1, {img_bg_clean1.CPolynom2}]}	System.Collections.Generic.KeyValuePair(Of String, Object)
            '+		(1)	{[last_end_x_polynom1, 194.69167522632051]}	System.Collections.Generic.KeyValuePair(Of String, Object)
            '+		(2)	{[min_dist_from_curve1, 0.10265565315638314]}	System.Collections.Generic.KeyValuePair(Of String, Object)
            '+		(3)	{[end_derivative2, 0.22814814817903453]}	System.Collections.Generic.KeyValuePair(Of String, Object)
            '+		(4)	{[polynom_curve1a, Count = 99]}	System.Collections.Generic.KeyValuePair(Of String, Object)
            '+		(5)	{[min_diff_h1, 0.24024314815493142]}	System.Collections.Generic.KeyValuePair(Of String, Object)
            '+		(6)	{[width_of_curve1, 99]}	System.Collections.Generic.KeyValuePair(Of String, Object)
            '+		(7)	{[height_of_curve1, 34]}	System.Collections.Generic.KeyValuePair(Of String, Object)
            '+		(8)	{[search_mode1, only_end_derivate1]}	System.Collections.Generic.KeyValuePair(Of String, Object)
            '+		(9)	{[error1, yes]}	System.Collections.Generic.KeyValuePair(Of String, Object)

        Next

        Dim bmp1f As Bitmap = CGlobals1.create_fill_bitmap(3500, 1000, Color.FromArgb(255, 255, 255))

        complete_polynom_curve1 = move_left_botton_curve_to_cord_xy1(complete_polynom_curve1, New Double() {30, 500})


        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(complete_polynom_curve1, bmp1f, Color.FromArgb(200, 30, 70))

        bmp1f.Save(CGlobals1.global_path1 + "sobel_pics1\c1fa.bmp")





        For polynom_ind1 = 0 To polynom_curves_arr1.Count - 1
            Dim ind1 As Integer
            Dim polynom_curve1 As ArrayList = polynom_curves_arr1(polynom_ind1)
            If polynom_ind1 > 0 Then

                polynom_curve1 = move_left_botton_curve_to_cord_xy1(polynom_curve1, last_cord_xy1)
            End If
            For ind1 = 0 To polynom_curve1.Count - 1
                complete_curve1.Add(polynom_curve1(ind1))
            Next
            'last_cord_xy1 = 
            Dim last_x1 As Double = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(polynom_curve1)("max_x1")
            Dim last_y1 As Double = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(polynom_curve1)("min_y1")

            last_cord_xy1 = New Double() {last_x1, last_y1}
        Next

        CGlobals1.form_obj1.markingfldimg_obj1.save_2d_pixels_arr1(CGlobals1.global_path1 + "sobel_pics1\polynom_curve1.txt", complete_curve1)
        System.IO.File.WriteAllText(CGlobals1.global_path1 + "sobel_pics1\curve_start_ind1.txt", curve_start_ind1.ToString())
        System.IO.File.WriteAllText(CGlobals1.global_path1 + "sobel_pics1\curve_last_ind1.txt", curve_last_ind1.ToString())
        Dim curve_pxls_arr1f As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, curve_start_ind1, curve_last_ind1)

        Dim move_x1 As Integer = 0
        Dim move_y1 As Integer = 0


        Dim cord_xy3 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1f, 0)

        move_x1 = (cord_xy3(0) * curve_zoom1) - 100
        move_y1 = (cord_xy3(1) * curve_zoom1) - 500

        For i1 = 0 To curve_pxls_arr1f.Count - 1
            cord_xy3 = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1f, i1)
            curve_pxls_arr1f(i1) = (cord_xy3(0) * curve_zoom1 - move_x1).ToString() + "," + (cord_xy3(1) * curve_zoom1 - move_y1).ToString()
        Next


        Dim bmp1 As Bitmap = CGlobals1.create_fill_bitmap(3000, 1000, Color.FromArgb(255, 255, 255))
        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(curve_pxls_arr1f, bmp1, Color.FromArgb(80, 50, 250))
        bmp1.Save(CGlobals1.global_path1 + "sobel_pics1\c1f_1.bmp")

        Dim dict_rect1 As Dictionary(Of String, Object) = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(curve_pxls_arr1f)
        Dim move_cord_xy1 As Double() = New Double() {dict_rect1("min_x1"), dict_rect1("max_y1")}
        complete_polynom_curve1 = move_left_botton_curve_to_cord_xy1(complete_polynom_curve1, move_cord_xy1)

        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(complete_polynom_curve1, bmp1, Color.FromArgb(200, 30, 70))

        bmp1.Save(CGlobals1.global_path1 + "sobel_pics1\c1f_2.bmp")


    End Function



    Public Function analize_polynom1()
        'pre_proccessing_curve1()
        Dim init_poynom_obj1 As CPolynom2 = New CPolynom2()
        init_poynom_obj1.coef_arr1.Add(0)
        init_poynom_obj1.coef_arr1.Add(0.9)
        'init_poynom_obj1.coef_arr1.Add(0.000001)
        'init_poynom_obj1.coef_arr1.Add(0.000001)
        'init_poynom_obj1.coef_arr1.Add(0.000005)
        'init_poynom_obj1.coef_arr1.Add(0.000005)
        init_poynom_obj1.coef_arr1.Add(0.00001)
        init_poynom_obj1.coef_arr1.Add(0.00001)
        init_poynom_obj1.create_derivative1()
        Dim curve_pxls_arr1 As ArrayList = New ArrayList()
        Dim frame_pixels_arr1 As ArrayList = CGlobals1.form_obj1.markingfldimg_obj1.load_2d_pixels_arr1(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_frame4.txt")

        Dim do_right_corner1 As String = "yes1"
        If do_right_corner1 = "yes" Then

            Dim cord_xy1a As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1, 995)
            Dim cord_xy2a As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1, 995)


            Dim vec_3d_obj1 As vec_3d1 = New vec_3d1()
            vec_3d_obj1.p1 = New point_3d1()
            vec_3d_obj1.p1.x1 = cord_xy1a(0)
            vec_3d_obj1.p1.y1 = cord_xy1a(1)


            vec_3d_obj1.p2 = New point_3d1()
            vec_3d_obj1.p2.x1 = cord_xy1a(0)
            vec_3d_obj1.p2.y1 = cord_xy1a(1)
            vec_3d_obj1.p2.z1 = -10

            frame_pixels_arr1 = CGlobals1.form_obj1.markingfldimg_obj1.rotate_2d_pixels_arr(frame_pixels_arr1, vec_3d_obj1, -90)

        End If

        'CGlobals1.form_obj1.markingfldimg_obj1.rotate_2d_pixels_arr()
        Dim bmp5 As Bitmap = CGlobals1.create_fill_bitmap(4000, 3000, Color.FromArgb(255, 255, 255))
        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(frame_pixels_arr1, bmp5, Color.FromArgb(24, 230, 50))
        bmp5.Save(CGlobals1.global_path1 + CGlobals1.sobel_pics_path1 + "frame4.bmp")
        Dim delta_add_last_ind_min_m1 As Integer = 50
        Dim delta_add_last_ind1 As Integer = 50 '45
        Dim curve_start_ind1 As Integer = 450
        Dim curve_last_ind1 As Integer = 1028

        If do_right_corner1 = "yes" Then
            curve_start_ind1 = 995
            curve_last_ind1 = 1145
            delta_add_last_ind1 = 5
        End If


        Dim last_ind1 As Integer = curve_start_ind1 + delta_add_last_ind1
        Dim curve_pxls_arr1b As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, curve_start_ind1, curve_last_ind1)
        Dim bmp_f1 As Bitmap = CGlobals1.create_fill_bitmap(3000, 2000, Color.FromArgb(255, 255, 255))
        'CGlobals1.form_obj1.markingfldimg_obj1.set_pixels_arr_and_save2(curve_pxls_arr1b, bmp_f1, Color.FromArgb(255, 100, 70), CGlobals1.global_path1 + CGlobals1.sobel_pics_path1 + "f1.bmp")
        'curve_pxls_arr1b = clear_curve_by_monotonic_down1(curve_pxls_arr1b)
        Dim max_diff_start_last As Integer = 10 'מיניום רוחב של פולינום
        Dim max_add_curve_height1 As Double = 0.9 'כמה אפשר להגדיל את גובה העקומה כדי לתקן זווית קטנה מידי של הפולינום
        Dim right_curve1 As String = "yes"
        If right_curve1 = "yes" Then
            curve_pxls_arr1b = rotate_curve_vertical2(curve_pxls_arr1b)
        End If


        Dim dict_rect_frame1 As Dictionary(Of String, Object) = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(curve_pxls_arr1b)
        Dim first_top_ind1 As Integer = 0
        Dim last_top_ind1 As Integer = 0

        While CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1b, first_top_ind1)(1) <> dict_rect_frame1("min_y1")
            first_top_ind1 += 1
        End While

        last_top_ind1 = first_top_ind1

        While CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1b, last_top_ind1)(1) = dict_rect_frame1("min_y1")
            last_top_ind1 += 1
        End While


        'curve_pxls_arr1b = clear_curve_by_monotonic_down1(curve_pxls_arr1b)

        Dim bmp1g As Bitmap = CGlobals1.create_fill_bitmap(2500, 1000, Color.FromArgb(255, 255, 255))



        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(curve_pxls_arr1b, bmp1g, Color.FromArgb(200, 30, 70))

        bmp1g.Save(CGlobals1.global_path1 + "sobel_pics1\monotonic_curve1a.bmp")


        curve_pxls_arr1b = CGlobals1.get_arr_from_ind_to_ind1(curve_pxls_arr1b, 0, last_top_ind1)

        If right_curve1 = "yes" Then
            'curve_pxls_arr1b = CGlobals1.form_obj1.markingfldimg_obj1.only_complete_missing_pixels_in_curve2(curve_pxls_arr1b)

        End If

        frame_pixels_arr1 = curve_pxls_arr1b

        CGlobals1.form_obj1.markingfldimg_obj1.set_pixels_arr_and_save2(curve_pxls_arr1b, bmp_f1, Color.FromArgb(255, 100, 70), CGlobals1.global_path1 + CGlobals1.sobel_pics_path1 + "f1.bmp")
        curve_start_ind1 = 0
        curve_last_ind1 = 300


        Dim bmp1c As Bitmap = CGlobals1.create_fill_bitmap(2500, 1000, Color.FromArgb(255, 255, 255))



        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(curve_pxls_arr1b, bmp1c, Color.FromArgb(200, 30, 70))

        bmp1c.Save(CGlobals1.global_path1 + "sobel_pics1\monotonic_curve1.bmp")

        'מקטע ראשון
        last_ind1 = curve_start_ind1 + delta_add_last_ind1

        curve_pxls_arr1 = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, curve_start_ind1, last_ind1)
        'curve_pxls_arr1 = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, 600, 700)
        'curve_pxls_arr1 = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, 700, 750)
        Dim cord_xy_start1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, 0)
        Dim cord_xy_end1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, curve_pxls_arr1.Count - 1)

        Dim m1 As Double = -(cord_xy_start1(1) - cord_xy_end1(1)) / (cord_xy_start1(0) - cord_xy_end1(0))
        'm1 = 0.3

        Dim dict_prms1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)


        Dim dict_res1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)




        dict_res1("error1") = "yes"
        Dim minus_m1 As Double = 0.01

        Dim last_derivate1 As Double = -1
        dict_prms1("curve_ind1") = 0


        Dim polynom_curves_arr1 As ArrayList = New ArrayList()
        Dim derivate_arr1 As ArrayList = New ArrayList()
        Dim polynom_result_arr1 As ArrayList = New ArrayList()

        Dim all_polynom_result_arr1 As ArrayList = New ArrayList()
        'last_ind1 = curve_start_ind1 + 30




        'polynom_curves_arr1.Add(dict_res1("polynom_curve1a"))
        last_ind1 = 0

        curve_last_ind1 = (first_top_ind1 + last_top_ind1) / 2

        Dim the_curve1 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, curve_start_ind1, curve_last_ind1)
        Dim bmp1d As Bitmap = CGlobals1.create_fill_bitmap(2500, 1000, Color.FromArgb(255, 255, 255))
        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(the_curve1, bmp1d, Color.FromArgb(200, 30, 70))

        bmp1d.Save(CGlobals1.global_path1 + "sobel_pics1\the_curve1.bmp")

        Dim start_ind1 As Integer = last_ind1 + 1

        last_ind1 = start_ind1 + delta_add_last_ind1
        'last_derivate1 = dict_res1("end_derivative2")

        Dim start_m1 As Double = 10

        If do_right_corner1 = "yes" Then
            start_m1 = 9
        End If
        last_derivate1 = find_min_end_m1(frame_pixels_arr1, start_ind1, start_ind1 + delta_add_last_ind_min_m1, 1, 10, start_m1)


        Dim derivatives_inds_str1 As String = ""
        Try
            derivatives_inds_str1 = System.IO.File.ReadAllText(CGlobals1.global_path1 + CGlobals1.sobel_pics_path1 + "drvs1.txt")

        Catch ex As Exception
            derivatives_inds_str1 = ""
        End Try

        Dim dict_min_derivative As Dictionary(Of Integer, Double) = New Dictionary(Of Integer, Double)
        Dim derivative_ind1 As Integer
        'derivatives_inds_str1 = ""
        Dim last_derivate_more_the_zero1 As Double = -9999
        Dim gap_back_measure_derivative1 As Integer = 5
        If derivatives_inds_str1 = "" Then

            Dim last_derivate_val1 As Double = -1
            delta_add_last_ind_min_m1 = 100
            For derivative_ind1 = start_ind1 + gap_back_measure_derivative1 To curve_last_ind1

                Dim start_check_ind1 As Double = 2
                If do_right_corner1 = "yes" Then
                    start_check_ind1 = 0
                End If
                m1 = find_min_end_m1(frame_pixels_arr1, derivative_ind1, derivative_ind1 + delta_add_last_ind_min_m1, 1, start_check_ind1, start_m1)
                start_m1 = m1 + 1
                CGlobals1.form_obj1.lbl_progress1.Text = "m_ind=" + derivative_ind1.ToString()
                Application.DoEvents()
                'show_derivative_line1(frame_pixels_arr1, derivative_ind1, m1, "f1")
                If last_derivate_val1 = -1 Then
                    last_derivate_val1 = m1
                Else
                    If m1 > last_derivate_val1 Then
                        m1 = last_derivate_val1

                    End If
                End If
                'show_derivative_line1(frame_pixels_arr1, derivative_ind1, m1, "f2")
                last_derivate_val1 = m1
                dict_min_derivative(derivative_ind1 - gap_back_measure_derivative1) = m1
                If derivatives_inds_str1 <> "" Then
                    derivatives_inds_str1 += "#"

                End If
                derivatives_inds_str1 += (derivative_ind1 - gap_back_measure_derivative1).ToString() + "," + m1.ToString()
            Next
            System.IO.File.WriteAllText(CGlobals1.global_path1 + CGlobals1.sobel_pics_path1 + "drvs1.txt", derivatives_inds_str1)

        Else
            Dim devivatives_inds1 As String() = derivatives_inds_str1.Split("#")
            For derivative_ind1 = 0 To devivatives_inds1.Length - 1
                dict_min_derivative(Integer.Parse(devivatives_inds1(derivative_ind1).Split(",")(0))) = Double.Parse(devivatives_inds1(derivative_ind1).Split(",")(1))
                If last_derivate_more_the_zero1 = -9999 Then
                    last_derivate_more_the_zero1 = Double.Parse(devivatives_inds1(derivative_ind1).Split(",")(1))
                Else
                    If Double.Parse(devivatives_inds1(derivative_ind1).Split(",")(1)) > 0 Then
                        last_derivate_more_the_zero1 = Double.Parse(devivatives_inds1(derivative_ind1).Split(",")(1))
                    End If
                End If
            Next
        End If

        derivate_arr1.Add(last_derivate1)
        dict_prms1("curve_ind1") += 1

        dict_res1("error1") = "yes"

        Dim factor_dec_add_last_ind1 As Integer = 10
        Dim min_dist_last_derivative1 As Double = 0.02
        Dim max_proportion1 As Double = -1
        Dim dir_add_to_last_ind1 As Integer = -1
        Dim last_delta_height1 As Double = 0
        Dim last_add_height1 As Double = 0
        Dim last_last_ind1 As Integer = last_ind1
        start_ind1 = start_ind1 + 7

        Dim org_start_ind As Integer = start_ind1
        last_ind1 = search_for_last_ind1(dict_min_derivative, start_ind1, delta_add_last_ind1, frame_pixels_arr1, last_delta_height1)
        If Math.Abs(last_ind1 - start_ind1) < 70 Then
            'last_ind1 = start_ind1 + 70
        End If
        Dim count_loop1 As Integer = 0
        last_derivate1 = dict_min_derivative(start_ind1)

        Dim sum_width_of_cur_curve1 As Integer = 0
        Dim str_curve_ind1 As String = ""
        Dim find_polynom_coefs1_loop1 As Integer = 0
        While dict_res1.ContainsKey("error1")

            count_loop1 += 1
            If count_loop1 = 13 Then
                Dim dl1 As Integer = 1
            End If
            If do_right_corner1 = "yes" Then
                'If start_ind1 + 10 < last_ind1 Then
                'last_ind1 = start_ind1 + 10

                'End If
            End If

            curve_pxls_arr1 = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, start_ind1, last_ind1)



            Dim dict_rect1a As Dictionary(Of String, Object) = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(curve_pxls_arr1)
            Dim proportion1 As Double = Math.Abs(dict_rect1a("min_y1") - dict_rect1a("max_y1")) / Math.Abs(dict_rect1a("min_x1") - dict_rect1a("max_x1"))
            m1 = find_min_end_m1(frame_pixels_arr1, start_ind1, start_ind1 + delta_add_last_ind_min_m1, 1, 1)
            m1 = dict_min_derivative(start_ind1)

            If last_ind1 = 289 Then
                Dim e1 As Integer = 1
            End If
            If CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1, last_ind1)(1) < dict_rect_frame1("min_y1") + 2 Then
                Dim end_s_top1 As Integer = 1

            End If

            Dim min_last_derivative1 As Double = -1
            Dim ind_of_derivative1 As Integer = last_ind1
            While dict_min_derivative.ContainsKey(ind_of_derivative1) = False
                ind_of_derivative1 -= 1
            End While
            min_last_derivative1 = dict_min_derivative(ind_of_derivative1) 'find_min_end_m1(frame_pixels_arr1, last_ind1, last_ind1 + delta_add_last_ind_min_m1, 1, 15)

            If False Then

                If dict_min_derivative.ContainsKey(last_ind1 - 1) Then
                    If min_last_derivative1 > dict_min_derivative(last_ind1 - 1) Then
                        min_last_derivative1 = dict_min_derivative(last_ind1 - 1)
                    End If
                End If
                dict_min_derivative(last_ind1) = min_last_derivative1

            End If


            If last_ind1 >= first_top_ind1 And False Then
                min_last_derivative1 = 0
                last_ind1 = curve_last_ind1
                curve_pxls_arr1 = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, start_ind1, last_ind1)
            End If
            If (last_derivate1 < min_last_derivative1 Or ((start_ind1 + max_diff_start_last) > last_ind1) And do_right_corner1 <> "yes") And dir_add_to_last_ind1 = -1 Then
                Dim err1 As Integer = 1
                'min_last_derivative1 = last_derivate1 * 0.9
                dir_add_to_last_ind1 = 1
                last_ind1 = last_last_ind1
            End If

            'Dim m2 As Double = dict_min_derivative(last_ind1)

            Dim cord_xy_start1b As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, 0)
            Dim cord_xy_end1b As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, curve_pxls_arr1.Count - 1)

            Dim m1b As Double = -(cord_xy_start1b(1) - cord_xy_end1b(1) - last_delta_height1) / (cord_xy_start1b(0) - cord_xy_end1b(0))

            'curve_pxls_arr1 = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, 600, 700)
            'curve_pxls_arr1 = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, 700, 750)

            'cord_xy_start1 = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, curve_pxls_arr1.Count - 10)
            'cord_xy_end1 = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, curve_pxls_arr1.Count - 1)

            dict_prms1("org_curve1") = frame_pixels_arr1.Clone()
            dict_prms1("end_pixel_ind1") = last_ind1
            dict_prms1("last_delta_height1") = last_delta_height1
            dict_prms1("last_add_height1") = last_add_height1



            'min_last_derivative1 = -999
            If dict_prms1("curve_ind1") = 3 Or dict_prms1("curve_ind1") = 2 Then
                Dim d1 As Integer = 5
            End If

            If last_derivate1 <= m1b Then

                Dim m_check1 As Double = find_min_end_m1(frame_pixels_arr1, start_ind1, start_ind1 + delta_add_last_ind_min_m1, 1, 5)
                Dim err1 As Integer = 1


            End If
            If min_last_derivative1 <= m1b Then
                Dim err1 As Integer = 1
            End If

            If count_loop1 = 12 Then
                Dim d9 As Integer = 2
            End If

            Dim found_good_derivative_in_more_height1 As String = "no"

            If last_derivate1 > m1b And (max_proportion1 = -1 Or max_proportion1 >= proportion1) Then

                dict_res1 = find_polynom_coefs1(init_poynom_obj1, last_derivate1, 99, curve_pxls_arr1, "only_start_derivate1", dict_prms1)
                dict_res1("start_ind1") = start_ind1
                dict_res1("last_ind1") = last_ind1
                dict_res1("count_loop1") = find_polynom_coefs1_loop1
                find_polynom_coefs1_loop1 += 1
                all_polynom_result_arr1.Add(dict_res1)
                If dict_res1.ContainsKey("end_derivative2") = False Then
                    Dim err1 As Integer = 1
                    init_poynom_obj1.coef_arr1.Clear()

                    init_poynom_obj1.coef_arr1.Add(0)
                    init_poynom_obj1.coef_arr1.Add(0.00001)
                    'init_poynom_obj1.coef_arr1.Add(0.000001)
                    'init_poynom_obj1.coef_arr1.Add(0.000001)
                    'init_poynom_obj1.coef_arr1.Add(0.000005)
                    'init_poynom_obj1.coef_arr1.Add(0.000005)
                    init_poynom_obj1.coef_arr1.Add(0.00001)
                    init_poynom_obj1.coef_arr1.Add(0.00001)
                    init_poynom_obj1.create_derivative1()

                    dict_res1 = find_polynom_coefs1(init_poynom_obj1, last_derivate1, 99, curve_pxls_arr1, "only_start_derivate1", dict_prms1)
                End If
                If dict_res1.ContainsKey("end_derivative2") Then


                    If dict_res1("min_diff_h1") > 4 Then
                        Dim err3 As Integer = 1
                    End If
                    If polynom_result_arr1.Count = 3 Then
                        'min_last_derivative1 *= 0.7
                        'only if polynom over the max heght of curve
                    End If
                    If polynom_result_arr1.Count = 4 Then
                        min_last_derivative1 *= 0.9
                        'only if polynom over the max heght of curve
                    End If
                    If dict_res1("end_derivative2") < min_last_derivative1 Or Math.Abs(dict_res1("end_derivative2") - min_last_derivative1) >= min_dist_last_derivative1 Or dict_res1("min_diff_h1") > 2 Then
                    Else
                        Dim ok1 As Integer = 1

                    End If

                    If dict_res1("end_derivative2") >= min_last_derivative1 And Math.Abs(dict_res1("end_derivative2") - min_last_derivative1) >= min_dist_last_derivative1 Then
                        factor_dec_add_last_ind1 = 1
                    Else
                        factor_dec_add_last_ind1 = 10
                    End If

                    If dict_res1("end_derivative2") < min_last_derivative1 Or Math.Abs(dict_res1("end_derivative2") - min_last_derivative1) >= min_dist_last_derivative1 Or dict_res1("min_diff_h1") > 2 Then
                        Dim to_find_derivate_in_polynom As String = "yes1"


                        Dim polynom_obj As CPolynom2 = dict_res1("polynom_obj1")
                        Dim last_end_x_polynom1 As Double = dict_res1("last_end_x_polynom1")
                        Dim width_of_curve1 As Double = dict_res1("width_of_curve1")
                        Dim y_val1a As Double = polynom_obj.get_y_val1(last_end_x_polynom1)
                        Dim y_val1b As Double = polynom_obj.get_y_val1(last_end_x_polynom1 - width_of_curve1)
                        Dim org_min_diff_h1 As Double = dict_res1("min_diff_h1")
                        Dim first_ok_x_ind1 As Integer = -1
                        If to_find_derivate_in_polynom = "yes" Then
                            'חיפוש זווית תקינה של הפולינום
                            Dim x_ind1 As Integer
                            'last_end_x_polynom1 = הנקודה הראשונה בפולינום
                            'כלומר עם הערך  x הכי גבוה

                            'זאת הנקודה האחרונה והיא עם הערך xהכי נמוך 
                            Dim start_x_val1 As Double = last_end_x_polynom1 - width_of_curve1

                            For x_ind1 = 0 To width_of_curve1 'To 0 Step -1
                                Dim polynom_x_val1 As Double = start_x_val1 + x_ind1 '+ (width_of_curve1 - x_ind1)
                                Dim derivative2 As Double = polynom_obj.get_derivative1(polynom_x_val1)
                                Dim derivative3 As Double = dict_min_derivative(last_ind1 - x_ind1)
                                Dim d1 As Integer = 1
                                If derivative2 >= (derivative3) And first_ok_x_ind1 = -1 Then
                                    first_ok_x_ind1 = width_of_curve1 - x_ind1
                                End If
                            Next
                            If first_ok_x_ind1 > width_of_curve1 / 2 Then
                                last_ind1 = start_ind1 + first_ok_x_ind1
                                Dim new_curve_pxls_arr1 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(curve_pxls_arr1, 0, first_ok_x_ind1)
                                dict_res1 = create_result_for_polynom1(polynom_obj, last_end_x_polynom1, first_ok_x_ind1, new_curve_pxls_arr1)
                                dict_res1 = create_result_for_polynom1(polynom_obj, last_end_x_polynom1, first_ok_x_ind1, new_curve_pxls_arr1)
                                If dict_res1("min_diff_h1") > 5 Then
                                    dict_res1 = create_result_for_polynom1(polynom_obj, last_end_x_polynom1, first_ok_x_ind1, new_curve_pxls_arr1)

                                End If
                                last_derivate1 = dict_res1("end_derivative2")
                            Else
                                dict_res1("error1") = "yes"
                                first_ok_x_ind1 = -1
                            End If
                            If first_ok_x_ind1 > 0 Then
                            Else
                                'dict_res1("error1") = "yes"

                            End If

                        End If

                        Dim found_ok_polynom1 As String = ""
                        Dim dict_prms2 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)

                        dict_prms2("last_delta_height1") = dict_prms1("last_delta_height1")
                        dict_prms2("last_add_height1") = dict_prms1("last_add_height1")
                        dict_prms2("curve_ind1") = dict_prms1("curve_ind1")

                        If polynom_result_arr1.Count = 3 Then
                            Dim d3 As Integer = 1
                        End If
                        'last_add_height1 = 0
                        Dim dict_res1b As Dictionary(Of String, Object) = dict_res1
                        If Math.Abs(dict_res1("end_derivative2") - min_last_derivative1) <= 0.15 And first_ok_x_ind1 = -1 Then
                            factor_dec_add_last_ind1 = 10
                            Dim to_stop1 As Integer = 0
                            dict_prms2("add_curve_height1") = 0
                            Dim last_end_derivative2 As Double = dict_res1("end_derivative2")
                            Dim factor_dec_add_height1 As Double = 0.05
                            Dim last_dir1 As Integer = 0
                            While to_stop1 = 0

                                If dict_res1b("end_derivative2") > min_last_derivative1 Then
                                    If last_dir1 = 0 Then
                                        last_dir1 = -1
                                    ElseIf last_dir1 = 1 Then
                                        factor_dec_add_height1 /= 2
                                    End If
                                    dict_prms2("add_curve_height1") -= factor_dec_add_height1

                                Else
                                    If last_dir1 = 0 Then
                                        last_dir1 = 1
                                    ElseIf last_dir1 = -1 Then
                                        factor_dec_add_height1 /= 2
                                    End If

                                    dict_prms2("add_curve_height1") += factor_dec_add_height1

                                End If
                                dict_res1b = find_polynom_coefs1(init_poynom_obj1, last_derivate1, 99, curve_pxls_arr1, "only_start_derivate1", dict_prms2)

                                dict_res1b("start_ind1") = start_ind1
                                dict_res1b("last_ind1") = last_ind1
                                dict_res1b("count_loop1") = find_polynom_coefs1_loop1
                                find_polynom_coefs1_loop1 += 1
                                all_polynom_result_arr1.Add(dict_res1b)
                                If dict_res1b.ContainsKey("end_derivative2") Then

                                    'If dict_res1b("end_derivative2") > min_last_derivative1 And Math.Abs(dict_res1b("end_derivative2") - min_last_derivative1) < min_dist_last_derivative1 Then
                                    If Math.Abs(dict_res1b("end_derivative2") - min_last_derivative1) < min_dist_last_derivative1 Then
                                        dict_res1 = dict_res1b
                                        to_stop1 = 1
                                        found_ok_polynom1 = "yes"
                                        last_add_height1 = dict_prms2("add_curve_height1")
                                        found_good_derivative_in_more_height1 = "yes"
                                    Else
                                        If Math.Abs(dict_prms2("add_curve_height1")) >= max_add_curve_height1 Then
                                            to_stop1 = 1
                                        End If
                                    End If
                                    last_end_derivative2 = dict_res1b("end_derivative2")
                                Else
                                    to_stop1 = 1
                                End If

                            End While

                        End If


                    End If
                End If

                If count_loop1 = 3 Then
                    Dim d8 As Integer = 4
                End If
                If dict_res1.ContainsKey("error1") Then
                    'If dict_res1("min_dist_diff_height1") > 0 Then
                    'max_proportion1 = proportion1
                    'End If
                    last_ind1 += dir_add_to_last_ind1 * factor_dec_add_last_ind1
                    'ElseIf dict_res1("end_derivative2") < min_last_derivative1 Or Math.Abs(dict_res1("end_derivative2") - min_last_derivative1) > min_dist_last_derivative1 Then
                ElseIf Math.Abs(dict_res1("end_derivative2") - min_last_derivative1) > min_dist_last_derivative1 Then
                    last_ind1 += dir_add_to_last_ind1 * factor_dec_add_last_ind1
                    dict_res1("error1") = "yes"

                Else
                    last_derivate1 = dict_res1("end_derivative2")
                    last_delta_height1 = dict_res1("min_diff_h1")
                    If last_delta_height1 > 4 Then
                        Dim err2 As Integer = 1
                    End If
                    derivate_arr1.Add(last_derivate1)

                    Try
                        polynom_curves_arr1.Add(dict_res1("polynom_curve1a"))

                    Catch ex As Exception
                        polynom_curves_arr1.Add(New ArrayList())
                    End Try
                    If last_ind1 = curve_last_ind1 Then
                        Dim d1 As Integer = 1
                    End If
                    If found_good_derivative_in_more_height1 <> "yes" Then
                        last_add_height1 = 0
                    End If


                    If polynom_result_arr1.Count = 2 Then
                        Dim d2 As Integer = 1
                    End If
                    dict_res1("last_add_height1") = last_add_height1

                    dict_res1("last_delta_height1") = dict_prms1("last_delta_height1")
                    dict_res1("found_good_derivative_in_more_height1") = found_good_derivative_in_more_height1
                    polynom_result_arr1.Add(dict_res1)

                    Dim width_of_org_curve1 As Integer = CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1, curve_start_ind1)(0) - CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1, curve_last_ind1)(0)
                    str_curve_ind1 += curve_pxls_arr1(0).ToString() + "->" + curve_pxls_arr1(curve_pxls_arr1.Count - 1).ToString() + ","
                    Dim width_of_cur_curve1 As Integer = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, 0)(0) - CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, curve_pxls_arr1.Count - 1)(0)

                    Dim start_cord_x1 As Integer = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, 0)(0)
                    Dim end_cord_x1 As Integer = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, curve_pxls_arr1.Count - 1)(0)
                    Dim total_width1 As Integer = end_cord_x1 - start_cord_x1 + 1
                    sum_width_of_cur_curve1 += width_of_cur_curve1
                    'Dim frame_pixels_arr1_from_last_ind As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(the_curve1, 10, the_curve1.Count - 1)
                    'Dim frame_pixels_arr1_from_last_ind As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(the_curve1, 10, last_ind1)
                    Dim frame_pixels_arr1_from_last_ind As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, org_start_ind, last_ind1)


                    Dim width_of_org_curve2 As Integer = CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1_from_last_ind, 0)(0) - CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1_from_last_ind, frame_pixels_arr1_from_last_ind.Count - 1)(0)
                    Dim dict_ret_res1 As Dictionary(Of String, Object) = print_polynom_results1(polynom_result_arr1, polynom_curves_arr1, dict_prms1("curve_ind1"), curve_start_ind1, curve_last_ind1, frame_pixels_arr1_from_last_ind)

                    If last_ind1 < curve_last_ind1 Then
                        dict_res1("error1") = "yes"
                        start_ind1 = last_ind1
                        last_ind1 = search_for_last_ind1(dict_min_derivative, start_ind1, delta_add_last_ind1, frame_pixels_arr1, last_delta_height1)
                        If dict_min_derivative(last_ind1) < 0 Or last_ind1 >= first_top_ind1 Then
                            Dim end_of_curve1 As Integer = 1
                            last_ind1 = curve_last_ind1

                        End If
                        'last_ind1 = start_ind1 + delta_add_last_ind1
                        last_last_ind1 = last_ind1
                        If last_ind1 >= curve_last_ind1 Then
                            last_ind1 = curve_last_ind1
                        End If
                        max_proportion1 = -1
                        dir_add_to_last_ind1 = -1
                    Else

                    End If
                    dict_prms1("curve_ind1") += 1

                End If
            Else
                last_ind1 += dir_add_to_last_ind1 * factor_dec_add_last_ind1


            End If
            If last_ind1 < start_ind1 + max_diff_start_last Then
                last_ind1 = last_last_ind1
                dir_add_to_last_ind1 = 1
            End If
            If last_ind1 > curve_last_ind1 Then
                dict_res1.Remove("error1")
            End If

            If last_ind1 = 221 Then
                last_ind1 = 224
            End If
        End While

        MessageBox.Show("end_curve_approximation_by_polynom1")
        Return 1
        'curve_last_ind1 = 900
        Dim do_minus_derivative As String = "yes1"
        'minus derivative
        If do_minus_derivative = "yes" Then

            last_derivate1 = 0
            start_ind1 = 730
            last_ind1 = start_ind1 + delta_add_last_ind1
            dict_res1("error1") = "yes"
            While dict_res1.ContainsKey("error1")


                curve_pxls_arr1 = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, start_ind1, last_ind1)


                '---
                Dim bmp5b As Bitmap = CGlobals1.create_fill_bitmap(4000, 3000, Color.FromArgb(255, 255, 255))
                CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(curve_pxls_arr1, bmp5b, Color.FromArgb(24, 230, 50))
                bmp5b.Save(CGlobals1.global_path1 + CGlobals1.sobel_pics_path1 + "frame_" + start_ind1.ToString() + "_" + last_ind1.ToString() + ".bmp")
                '---


                Dim dict_rect1a As Dictionary(Of String, Object) = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(curve_pxls_arr1)
                Dim proportion1 As Double = Math.Abs(dict_rect1a("min_y1") - dict_rect1a("max_y1")) / Math.Abs(dict_rect1a("min_x1") - dict_rect1a("max_x1"))
                m1 = find_min_end_m1(frame_pixels_arr1, start_ind1, last_ind1 + delta_add_last_ind1, 1, 1)

                Dim cord_xy_start1b As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, 0)
                Dim cord_xy_end1b As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, curve_pxls_arr1.Count - 1)

                Dim m1b As Double = -(cord_xy_start1b(1) - cord_xy_end1b(1)) / (cord_xy_start1b(0) - cord_xy_end1b(0))

                'curve_pxls_arr1 = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, 600, 700)
                'curve_pxls_arr1 = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, 700, 750)

                'cord_xy_start1 = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, curve_pxls_arr1.Count - 10)
                'cord_xy_end1 = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, curve_pxls_arr1.Count - 1)

                dict_prms1("org_curve1") = frame_pixels_arr1.Clone()
                dict_prms1("end_pixel_ind1") = last_ind1
                dict_prms1("last_delta_height1") = last_delta_height1
                dict_prms1("last_delta_height1") = last_delta_height1
                If dict_prms1("curve_ind1") = 3 Or dict_prms1("curve_ind1") = 2 Then
                    Dim d1 As Integer = 5
                End If
                If last_derivate1 < Math.Abs(m1b) And (max_proportion1 = -1 Or max_proportion1 >= proportion1) Then

                    dict_res1 = find_polynom_coefs1(init_poynom_obj1, last_derivate1, 99, curve_pxls_arr1, "only_start_derivate_minus1", dict_prms1)



                    If dict_res1.ContainsKey("error1") Then
                        If dict_res1("min_dist_diff_height1") > 0 Then
                            'max_proportion1 = proportion1
                        End If
                        last_ind1 += dir_add_to_last_ind1
                    Else
                        last_derivate1 = dict_res1("end_derivative2")
                        last_delta_height1 = dict_res1("min_diff_h1")
                        derivate_arr1.Add(last_derivate1)

                        polynom_curves_arr1.Add(dict_res1("polynom_curve1a"))

                        polynom_result_arr1.Add(dict_res1)
                        print_polynom_results1(polynom_result_arr1, polynom_curves_arr1, dict_prms1("curve_ind1"), curve_start_ind1, curve_last_ind1, frame_pixels_arr1)

                        If last_ind1 < curve_last_ind1 Then
                            dict_res1("error1") = "yes"
                            start_ind1 = last_ind1
                            last_ind1 = start_ind1 + delta_add_last_ind1
                            If last_ind1 >= curve_last_ind1 Then
                                last_ind1 = curve_last_ind1
                            End If
                            max_proportion1 = -1
                            dir_add_to_last_ind1 = -1
                        Else

                        End If
                        dict_prms1("curve_ind1") += 1

                    End If
                Else
                    last_ind1 += dir_add_to_last_ind1
                    If last_ind1 < start_ind1 + 20 Then
                        dir_add_to_last_ind1 = 1
                    End If

                End If

                If last_ind1 > curve_last_ind1 Then
                    dict_res1.Remove("error1")
                End If
            End While

        End If

        'print_polynom_results1(polynom_result_arr1, polynom_curves_arr1, 1)
        Return 1

        '-----------

        Dim polynom_ind1 As Integer
        Dim complete_curve1 As ArrayList = New ArrayList()
        Dim last_cord_xy1 As Double()

        Dim curve_zoom1 As Double = 3 '1 ' 2.8
        Dim x_step_val1 As Double = 1 / curve_zoom1
        Dim complete_polynom_curve1 As ArrayList = New ArrayList()
        Dim x_ind_complete_polynom_curve1 As Integer = 10
        Dim last_y_val_polynom1 As Double = 999
        For polynom_ind1 = 0 To polynom_result_arr1.Count - 1
            Dim dict_res2 As Dictionary(Of String, Object) = polynom_result_arr1(polynom_ind1)
            If dict_res2("search_mode1") = "only_end_derivate1" Then
                Dim d8 As Integer = 3
                Dim polynom_obj1 As CPolynom2 = CType(dict_res2("polynom_obj1"), CPolynom2).clone1()
                polynom_obj1.mul_coefs1(curve_zoom1)
                Dim start_x_val1 As Double = dict_res2("last_end_x_polynom1") + dict_res2("width_of_curve1") - (curve_zoom1 - 1)
                Dim end_x_val1 As Double = dict_res2("last_end_x_polynom1")
                Dim start_derivative_val1 As Double = polynom_obj1.get_derivative1(start_x_val1)
                Dim end_derivative_val1 As Double = polynom_obj1.get_derivative1(end_x_val1)

                Dim d4 As Integer = 5
                Dim x_ind1 As Integer
                Dim x_val1 As Double = start_x_val1
                Dim len1 As Integer = dict_res2("width_of_curve1") * curve_zoom1 + (curve_zoom1 - 1)
                For x_ind1 = 0 To len1
                    Dim y_val1 As Double = polynom_obj1.get_y_val1(x_val1)
                    If x_ind1 = len1 Then
                        last_y_val_polynom1 = y_val1
                        polynom_obj1.create_derivative1()
                        Dim end_derivative_val3 As Double = polynom_obj1.get_derivative1(x_val1)
                    End If
                    complete_polynom_curve1.Add(x_ind_complete_polynom_curve1.ToString() + "," + y_val1.ToString())
                    If complete_polynom_curve1.Count = 533 Then
                        Dim d1b As Integer = 1
                    End If
                    x_ind_complete_polynom_curve1 += 1
                    x_val1 -= x_step_val1
                Next
            ElseIf dict_res2("search_mode1") = "only_start_derivate_minus1" Then
                Dim d8 As Integer = 3
                Dim polynom_obj1 As CPolynom2 = CType(dict_res2("polynom_obj1"), CPolynom2).clone1()
                polynom_obj1.mul_coefs1(curve_zoom1)
                Dim start_x_val1 As Double = dict_res2("last_end_x_polynom1")
                Dim end_x_val1 As Double = dict_res2("last_end_x_polynom1") + dict_res2("width_of_curve1") - (curve_zoom1 - 1)

                Dim start_derivative_val1 As Double = polynom_obj1.get_derivative1(start_x_val1)
                Dim end_derivative_val1 As Double = polynom_obj1.get_derivative1(end_x_val1)


                Dim d4 As Integer = 5
                Dim x_ind1 As Integer
                Dim x_val1 As Double = start_x_val1

                Dim delta_y_val1 As Double = polynom_obj1.get_y_val1(x_val1) - last_y_val_polynom1

                Dim len1 As Integer = dict_res2("width_of_curve1") * curve_zoom1 + (curve_zoom1 - 1)
                For x_ind1 = 0 To len1
                    Dim y_val1 As Double = polynom_obj1.get_y_val1(x_val1) - delta_y_val1
                    If x_ind1 = len1 Then
                        last_y_val_polynom1 = y_val1
                        polynom_obj1.create_derivative1()
                        Dim end_derivative_val3 As Double = polynom_obj1.get_derivative1(x_val1)
                    End If
                    complete_polynom_curve1.Add(x_ind_complete_polynom_curve1.ToString() + "," + y_val1.ToString())
                    If complete_polynom_curve1.Count = 533 Then
                        Dim d1a As Integer = 1
                    End If

                    x_ind_complete_polynom_curve1 += 1
                    x_val1 += x_step_val1
                Next

            Else
                Dim d8 As Integer = 3
                Dim polynom_obj1 As CPolynom2 = CType(dict_res2("polynom_obj1"), CPolynom2).clone1()
                polynom_obj1.mul_coefs1(curve_zoom1)
                Dim start_x_val1 As Double = dict_res2("last_end_x_polynom1")
                Dim end_x_val1 As Double = dict_res2("last_end_x_polynom1") - dict_res2("width_of_curve1") + (curve_zoom1 - 1)
                Dim start_derivative_val1 As Double = polynom_obj1.get_derivative1(start_x_val1)
                Dim end_derivative_val1 As Double = polynom_obj1.get_derivative1(end_x_val1)
                Dim d5 As Integer = 5



                Dim x_ind1 As Integer
                Dim x_val1 As Double = start_x_val1


                Dim delta_y_val1 As Double = polynom_obj1.get_y_val1(x_val1) - last_y_val_polynom1

                polynom_obj1.create_derivative1()
                Dim start_derivative_val3 As Double = polynom_obj1.get_derivative1(x_val1)

                Dim len1 As Integer = dict_res2("width_of_curve1") * curve_zoom1 + (curve_zoom1 - 1)
                For x_ind1 = 0 To len1

                    Dim y_val1 As Double = polynom_obj1.get_y_val1(x_val1) - delta_y_val1
                    If x_ind1 = len1 Then
                        last_y_val_polynom1 = y_val1
                    End If
                    complete_polynom_curve1.Add(x_ind_complete_polynom_curve1.ToString() + "," + y_val1.ToString())
                    If complete_polynom_curve1.Count = 533 Then
                        Dim d1c As Integer = 1
                    End If

                    x_ind_complete_polynom_curve1 += 1
                    x_val1 -= x_step_val1
                Next



            End If
            Dim d1 As Integer = 1



            '            +		(0)	{[polynom_obj1, {img_bg_clean1.CPolynom2}]}	System.Collections.Generic.KeyValuePair(Of String, Object)
            '+		(1)	{[last_end_x_polynom1, 194.69167522632051]}	System.Collections.Generic.KeyValuePair(Of String, Object)
            '+		(2)	{[min_dist_from_curve1, 0.10265565315638314]}	System.Collections.Generic.KeyValuePair(Of String, Object)
            '+		(3)	{[end_derivative2, 0.22814814817903453]}	System.Collections.Generic.KeyValuePair(Of String, Object)
            '+		(4)	{[polynom_curve1a, Count = 99]}	System.Collections.Generic.KeyValuePair(Of String, Object)
            '+		(5)	{[min_diff_h1, 0.24024314815493142]}	System.Collections.Generic.KeyValuePair(Of String, Object)
            '+		(6)	{[width_of_curve1, 99]}	System.Collections.Generic.KeyValuePair(Of String, Object)
            '+		(7)	{[height_of_curve1, 34]}	System.Collections.Generic.KeyValuePair(Of String, Object)
            '+		(8)	{[search_mode1, only_end_derivate1]}	System.Collections.Generic.KeyValuePair(Of String, Object)
            '+		(9)	{[error1, yes]}	System.Collections.Generic.KeyValuePair(Of String, Object)

        Next

        Dim bmp1f As Bitmap = CGlobals1.create_fill_bitmap(3500, 1000, Color.FromArgb(255, 255, 255))

        complete_polynom_curve1 = move_left_botton_curve_to_cord_xy1(complete_polynom_curve1, New Double() {30, 500})


        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(complete_polynom_curve1, bmp1f, Color.FromArgb(200, 30, 70))

        bmp1f.Save(CGlobals1.global_path1 + "sobel_pics1\c1fa.bmp")





        For polynom_ind1 = 0 To polynom_curves_arr1.Count - 1
            Dim ind1 As Integer
            Dim polynom_curve1 As ArrayList = polynom_curves_arr1(polynom_ind1)
            If polynom_ind1 > 0 Then

                polynom_curve1 = move_left_botton_curve_to_cord_xy1(polynom_curve1, last_cord_xy1)
            End If
            For ind1 = 0 To polynom_curve1.Count - 1
                complete_curve1.Add(polynom_curve1(ind1))
            Next
            'last_cord_xy1 = 
            Dim last_x1 As Double = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(polynom_curve1)("max_x1")
            Dim last_y1 As Double = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(polynom_curve1)("min_y1")

            last_cord_xy1 = New Double() {last_x1, last_y1}
        Next

        CGlobals1.form_obj1.markingfldimg_obj1.save_2d_pixels_arr1(CGlobals1.global_path1 + "sobel_pics1\polynom_curve1.txt", complete_curve1)
        System.IO.File.WriteAllText(CGlobals1.global_path1 + "sobel_pics1\curve_start_ind1.txt", curve_start_ind1.ToString())
        System.IO.File.WriteAllText(CGlobals1.global_path1 + "sobel_pics1\curve_last_ind1.txt", curve_last_ind1.ToString())
        Dim curve_pxls_arr1f As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, curve_start_ind1, curve_last_ind1)

        Dim move_x1 As Integer = 0
        Dim move_y1 As Integer = 0


        Dim cord_xy3 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1f, 0)

        move_x1 = (cord_xy3(0) * curve_zoom1) - 100
        move_y1 = (cord_xy3(1) * curve_zoom1) - 500

        For i1 = 0 To curve_pxls_arr1f.Count - 1
            cord_xy3 = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1f, i1)
            curve_pxls_arr1f(i1) = (cord_xy3(0) * curve_zoom1 - move_x1).ToString() + "," + (cord_xy3(1) * curve_zoom1 - move_y1).ToString()
        Next


        Dim bmp1 As Bitmap = CGlobals1.create_fill_bitmap(3000, 1000, Color.FromArgb(255, 255, 255))
        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(curve_pxls_arr1f, bmp1, Color.FromArgb(80, 50, 250))
        bmp1.Save(CGlobals1.global_path1 + "sobel_pics1\c1f_1.bmp")

        Dim dict_rect1 As Dictionary(Of String, Object) = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(curve_pxls_arr1f)
        Dim move_cord_xy1 As Double() = New Double() {dict_rect1("min_x1"), dict_rect1("max_y1")}
        complete_polynom_curve1 = move_left_botton_curve_to_cord_xy1(complete_polynom_curve1, move_cord_xy1)

        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(complete_polynom_curve1, bmp1, Color.FromArgb(200, 30, 70))

        bmp1.Save(CGlobals1.global_path1 + "sobel_pics1\c1f_2.bmp")


    End Function


    Public Function show_derivative_line1(curve1 As ArrayList, start_ind1 As Integer, m1 As Double, sign_file_str1 As String)
        Dim curve2 As ArrayList = move_left_botton_curve_to_cord_xy1(curve1, New Double() {100, 100})
        Dim line1 As ArrayList = New ArrayList()
        Dim x_start_val1 As Double = CGlobals1.get_cord_xy_in_pixels_arr1(curve2, start_ind1)(0)
        Dim y_start_val1 As Double = CGlobals1.get_cord_xy_in_pixels_arr1(curve2, start_ind1)(1)

        Dim x_ind1 As Integer
        For x_ind1 = 0 To 100
            If x_ind1 > 0 Then
                y_start_val1 -= m1

            End If
            line1.Add((x_start_val1 + x_ind1).ToString() + "," + y_start_val1.ToString())
        Next

        Dim bmp1 As Bitmap = CGlobals1.create_fill_bitmap(3000, 1000, Color.FromArgb(255, 255, 255))

        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(curve2, bmp1, Color.FromArgb(255, 100, 50))
        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(line1, bmp1, Color.FromArgb(55, 160, 50))

        bmp1.Save(CGlobals1.global_path1 + CGlobals1.sobel_pics_path1 + "line_" + start_ind1.ToString() + "_" + sign_file_str1 + ".bmp")
    End Function
    Public Function print_polynom_results1(polynom_result_arr1 As ArrayList, polynom_curves_arr1 As ArrayList, curve_ind1 As Integer, curve_start_ind1 As Integer, curve_last_ind1 As Integer, frame_pixels_arr1 As ArrayList)
        Dim polynom_ind1 As Integer

        Dim org_frame_pixels_arr1 As ArrayList = frame_pixels_arr1.Clone()
        Dim complete_curve1 As ArrayList = New ArrayList()
        Dim last_cord_xy1 As Double()

        'Dim curve_zoom1 As Double = 2 '1 ' 2.8
        Dim x_step_val1 As Double = 1 / curve_zoom1
        Dim complete_polynom_curve1 As ArrayList = New ArrayList()
        Dim x_ind_complete_polynom_curve1 As Integer = 10
        Dim last_y_val_polynom1 As Double = 999

        Dim sum_width_of_curve1 As Integer = 0
        Dim last_derivative_val1 As Double = -999


        Dim last_start_y_val1 As Double = 999
        Dim last_start_y_val2 As Double = 999
        Dim last_end_y_val1 As Double = 999

        Dim global_start_y_val1 As Double = -1
        Dim global_last_y_val1 As Double = -1
        Dim heights_of_polynoms_arr1 As ArrayList = New ArrayList()
        Dim abs_height_of_polynom_arr1 As ArrayList = New ArrayList()

        Dim width_curve_arr1 As ArrayList = New ArrayList()

        For polynom_ind1 = 0 To polynom_result_arr1.Count - 1
            Dim dict_res2 As Dictionary(Of String, Object) = polynom_result_arr1(polynom_ind1)
            If dict_res2("search_mode1") = "only_end_derivate1" Then
                Dim d8 As Integer = 3
                Dim polynom_obj1 As CPolynom2 = CType(dict_res2("polynom_obj1"), CPolynom2).clone1()
                polynom_obj1.mul_coefs1(curve_zoom1)
                Dim start_x_val1 As Double = dict_res2("last_end_x_polynom1") + dict_res2("width_of_curve1") - (curve_zoom1 - 1)
                Dim end_x_val1 As Double = dict_res2("last_end_x_polynom1")
                Dim start_derivative_val1 As Double = polynom_obj1.get_derivative1(start_x_val1)
                Dim end_derivative_val1 As Double = polynom_obj1.get_derivative1(end_x_val1)

                Dim d4 As Integer = 5
                Dim x_ind1 As Integer
                Dim x_val1 As Double = start_x_val1
                Dim len1 As Integer = dict_res2("width_of_curve1") * curve_zoom1 + (curve_zoom1 - 1)
                For x_ind1 = 0 To len1
                    Dim y_val1 As Double = polynom_obj1.get_y_val1(x_val1)
                    If x_ind1 = len1 Then
                        last_y_val_polynom1 = y_val1
                        polynom_obj1.create_derivative1()
                        Dim end_derivative_val3 As Double = polynom_obj1.get_derivative1(x_val1)
                    End If
                    complete_polynom_curve1.Add(x_ind_complete_polynom_curve1.ToString() + "," + y_val1.ToString())
                    If complete_polynom_curve1.Count = 533 Then
                        Dim d1b As Integer = 1
                    End If
                    x_ind_complete_polynom_curve1 += 1
                    x_val1 -= x_step_val1
                Next
            ElseIf dict_res2("search_mode1") = "only_start_derivate_minus1" Then
                Dim d8 As Integer = 3
                Dim polynom_obj1 As CPolynom2 = CType(dict_res2("polynom_obj1"), CPolynom2).clone1()
                polynom_obj1.mul_coefs1(curve_zoom1)
                Dim start_x_val1 As Double = dict_res2("last_end_x_polynom1")
                Dim end_x_val1 As Double = dict_res2("last_end_x_polynom1") + dict_res2("width_of_curve1") + 1 - (curve_zoom1 - 1)

                Dim start_derivative_val1 As Double = polynom_obj1.get_derivative1(start_x_val1)
                Dim end_derivative_val1 As Double = polynom_obj1.get_derivative1(end_x_val1)


                Dim d4 As Integer = 5
                Dim x_ind1 As Integer
                Dim x_val1 As Double = start_x_val1

                Dim delta_y_val1 As Double = polynom_obj1.get_y_val1(x_val1) - last_y_val_polynom1

                Dim len1 As Integer = dict_res2("width_of_curve1") * curve_zoom1 + (curve_zoom1 - 1)
                For x_ind1 = 0 To len1
                    Dim y_val1 As Double = polynom_obj1.get_y_val1(x_val1) - delta_y_val1
                    If x_ind1 = len1 Then
                        last_y_val_polynom1 = y_val1
                        polynom_obj1.create_derivative1()
                        Dim end_derivative_val3 As Double = polynom_obj1.get_derivative1(x_val1)
                    End If
                    complete_polynom_curve1.Add(x_ind_complete_polynom_curve1.ToString() + "," + y_val1.ToString())
                    If complete_polynom_curve1.Count = 533 Then
                        Dim d1a As Integer = 1
                    End If

                    x_ind_complete_polynom_curve1 += 1
                    x_val1 += x_step_val1
                Next

            Else


                If polynom_result_arr1.Count = 3 Then
                    Dim d5b As Integer = 1
                End If

                Dim abs_height_of_polynom As Double = dict_res2("height_of_curve1") - dict_res2("min_diff_h1")
                abs_height_of_polynom_arr1.Add(abs_height_of_polynom)
                If polynom_result_arr1.Count = 8 Then
                    If polynom_ind1 = polynom_result_arr1.Count - 1 Then
                        Dim d2 As Integer = 1
                    End If




                End If
                If polynom_result_arr1.Count = 2 Then
                    Dim d456 As Integer = 12
                End If
                Dim d8 As Integer = 3
                Dim polynom_obj1 As CPolynom2 = CType(dict_res2("polynom_obj1"), CPolynom2).clone1()
                polynom_obj1.mul_coefs1(curve_zoom1)
                polynom_obj1.create_derivative1()
                Dim start_x_val1 As Double = dict_res2("last_end_x_polynom1")
                'Dim end_x_val1 As Double = dict_res2("last_end_x_polynom1") - dict_res2("width_of_curve1") + (curve_zoom1 - 1)
                Dim end_x_val1 As Double = dict_res2("last_end_x_polynom1") - dict_res2("width_of_curve1") ' + (curve_zoom1 - 1)
                Dim start_derivative_val1 As Double = polynom_obj1.get_derivative1(start_x_val1)
                If last_derivative_val1 <> -999 Then

                    Dim diff_derivative2 As Double = Math.Abs(start_derivative_val1 - last_derivative_val1)
                    If diff_derivative2 > Math.Pow(10, -10) Then
                        Dim err1 As Integer = 1
                    End If
                End If
                Dim end_derivative_val1 As Double = polynom_obj1.get_derivative1(end_x_val1)
                Dim d5 As Integer = 5



                Dim x_ind1 As Integer
                Dim x_val1 As Double = start_x_val1


                Dim delta_y_val1 As Double = polynom_obj1.get_y_val1(x_val1) - last_y_val_polynom1


                Dim start_derivative_val3 As Double = polynom_obj1.get_derivative1(x_val1)
                Dim diff_derivative1 As Double = Math.Abs(last_derivative_val1 - start_derivative_val3)
                If diff_derivative1 > Math.Pow(10, -9) And diff_derivative1 < 990 Then
                    Dim err1 As Integer = 1
                End If

                'Dim len1 As Integer = (dict_res2("width_of_curve1") + 1) * curve_zoom1 + (curve_zoom1 - 1)
                'Dim len1 As Integer = (dict_res2("width_of_curve1")) * curve_zoom1 + (curve_zoom1 - 1)
                Dim len1 As Integer = (dict_res2("width_of_curve1")) * curve_zoom1 '+ (curve_zoom1 - 1)
                'If sum_width_of_curve1 > 0 Then
                'sum_width_of_curve1 -= 1
                'len1 -= 1
                'End If

                If sum_width_of_curve1 = 0 Then
                    'sum_width_of_curve1 -= 1
                    'len1 -= 1
                End If

                Dim start_y_val1 As Double = polynom_obj1.get_y_val1(x_val1)
                Dim start_y_val2 As Double = polynom_obj1.get_y_val1(x_val1)
                Dim end_y_val1 As Double = polynom_obj1.get_y_val1(x_val1)

                Dim width_in_double1 = end_x_val1 - start_x_val1
                If (len1 + 1) * x_step_val1 <> width_in_double1 Then
                    Dim change_len1 As Integer = 1
                End If


                Dim start_ind1 As Integer = polynom_result_arr1(polynom_ind1)("start_ind1")
                Dim last_ind1 As Integer = polynom_result_arr1(polynom_ind1)("last_ind1")

                Dim start_x_offset1 As Double = CGlobals1.get_double_cord_xy_in_pixels_arr2(org_frame_pixels_arr1, 0)(0)

                Dim org_frame_pixels_arr2 As ArrayList = CGlobals1.add_val_to_pxls_arr1(org_frame_pixels_arr1, -start_x_offset1, 0)
                Dim zoom_frame_pixels_arr1 As ArrayList = CGlobals1.zoom_curve1(org_frame_pixels_arr2, curve_zoom1)
                Dim curve_pxls_arr2c As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(zoom_frame_pixels_arr1, start_ind1, last_ind1)

                Dim w2 As Double = CGlobals1.get_double_cord_xy_in_pixels_arr2(curve_pxls_arr2c, curve_pxls_arr2c.Count - 1)(0) - CGlobals1.get_double_cord_xy_in_pixels_arr2(curve_pxls_arr2c, 0)(0)

                'Dim start_x_offset1 As Double = 0 ' CGlobals1.get_double_cord_xy_in_pixels_arr2(curve_pxls_arr2c, 0)(0)
                Dim start_x1 As Double = (CGlobals1.get_double_cord_xy_in_pixels_arr2(curve_pxls_arr2c, 0)(0))
                Dim end_x1 As Double = (CGlobals1.get_double_cord_xy_in_pixels_arr2(curve_pxls_arr2c, curve_pxls_arr2c.Count - 1)(0))


                Dim width_curve1 As Integer = CType(end_x1, Integer) - CType(start_x1, Integer)


                width_curve_arr1.Add("start_x1=" + CType(start_x1, Integer).ToString() + ",end_x1=" + CType(end_x1, Integer).ToString())
                width_curve_arr1.add(width_curve1)
                'len1 = curve_pxls_arr2c.Count * curve_zoom1
                'len1 = Math.Floor(width_curve1) + 1
                Dim org_len1 As Integer = len1
                len1 = CType(width_curve1, Integer)
                'x_step_val1 = width_curve1 / (CType(org_len1 + 1, Double) / CType(len1 + 1, Double))
                x_step_val1 = (Math.Abs(CType(last_ind1, Double) - CType(start_ind1, Double))) / (width_curve1)


                Dim polynom_vals_arr1 As ArrayList = New ArrayList()

                For x_ind1 = 0 To len1

                    Dim y_val1 As Double = polynom_obj1.get_y_val1(x_val1) - delta_y_val1

                    If x_val1 >= end_x_val1 Then

                    Else
                        'x_val1 = end_x_val1

                    End If

                    If x_ind1 = len1 Then
                        If x_val1 > end_x_val1 Then
                            'x_val1 = end_x_val1
                        End If
                    End If






                    If x_ind1 = 0 Then
                        'sum_y_val1 += polynom_obj1.get_y_val1(x_val1)
                        start_y_val1 = y_val1
                        last_start_y_val1 = start_y_val1

                        If polynom_ind1 = 0 Then
                            global_start_y_val1 = y_val1
                        End If



                    End If


                    If x_ind1 = 1 Then
                        'sum_y_val1 += polynom_obj1.get_y_val1(x_val1)
                        start_y_val2 = y_val1
                        last_start_y_val2 = start_y_val2
                    End If

                    If x_ind1 = len1 Then
                        'sum_y_val1 += polynom_obj1.get_y_val1(x_val1)
                        end_y_val1 = y_val1
                        last_end_y_val1 = end_y_val1

                        If polynom_ind1 = polynom_result_arr1.Count - 1 Then
                            global_last_y_val1 = y_val1
                        End If

                    End If

                    If x_ind1 = len1 Then
                        If polynom_ind1 = 1 Then
                            Dim d3 As Integer = 1
                        End If
                        last_y_val_polynom1 = y_val1
                        last_derivative_val1 = polynom_obj1.get_derivative1(x_val1)


                    End If
                    If polynom_ind1 > 0 And x_ind1 = 0 Then
                    Else
                        complete_polynom_curve1.Add(x_ind_complete_polynom_curve1.ToString() + "," + y_val1.ToString())

                        Dim derivative_val1 As Double = polynom_obj1.get_derivative1(x_val1)
                        polynom_vals_arr1.Add("x_val1=" + x_val1.ToString() + ",x_ind1=" + x_ind1.ToString() + ",derivative_val1=" + derivative_val1.ToString())
                        x_ind_complete_polynom_curve1 += 1


                    End If
                    If complete_polynom_curve1.Count = 533 Then
                        Dim d1c As Integer = 1
                    End If


                    'If x_ind1 = len1 Then


                    'End If

                    If x_ind1 = len1 Then
                        If x_val1 <> end_x_val1 Then
                            Dim d2 As Integer = 1

                            'x_val1 = end_x_val1
                        End If
                    End If

                    x_val1 -= x_step_val1




                Next

                Dim total_polynom_height1 As Double = end_y_val1 - start_y_val1

                'If sum_width_of_curve1 > 0 Then
                'last_derivative_val1 = polynom_obj1.get_derivative1(x_val1)

                'End If


                sum_width_of_curve1 += len1
                Dim height_of_current_polynom1 As Double = end_y_val1 - start_y_val1


                Dim min_diff_h1 As Double = dict_res2("height_of_curve1") - Math.Abs(height_of_current_polynom1)
                heights_of_polynoms_arr1.Add(height_of_current_polynom1)
            End If

            If heights_of_polynoms_arr1.Count > 1 Then
                Dim diff_height_from_curve3 As Double = heights_of_polynoms_arr1(1) + 0.1 - 0.015628804627698667
                'Math.abs(heights_of_polynoms_arr1(1)) - 0.1 + 0.015628804627698667
                Dim diff_err1 As Double = Math.Abs(heights_of_polynoms_arr1(heights_of_polynoms_arr1.Count - 1)) - Math.Abs(polynom_result_arr1(polynom_result_arr1.Count - 1)("height_of_curve1"))
            End If

            If polynom_result_arr1.Count = 2 Then
                Dim d182 As Integer = 1
            End If


            If polynom_result_arr1.Count = 3 Then
                Dim d1822 As Integer = 1
            End If

            If heights_of_polynoms_arr1.Count = 3 Then
                Dim d18 As Integer = 1
            End If
            Dim total_height_of_polynom1 As Double = global_start_y_val1 - global_last_y_val1


            '3-(New System.Collections.ArrayList.ArrayListDebugView(polynom_result_arr1).Items(1)("height_of_curve1")-0.1-New System.Collections.ArrayList.ArrayListDebugView(polynom_result_arr1).Items(1)("last_delta_height1"))
            'last_add_height1
            'Dim diff_height_from_curve As Double = polynom_result_arr1(polynom_result_arr1.Count - 1)("height_of_curve1")
            Dim diff_height_from_curve As Double = Math.Abs(heights_of_polynoms_arr1(heights_of_polynoms_arr1.Count - 1))
            diff_height_from_curve += polynom_result_arr1(polynom_result_arr1.Count - 1)("last_delta_height1")
            diff_height_from_curve += polynom_result_arr1(polynom_result_arr1.Count - 1)("last_add_height1")
            diff_height_from_curve -= polynom_result_arr1(polynom_result_arr1.Count - 1)("height_of_curve1")


            'Math.abs(heights_of_polynoms_arr1(1)) - 0.1 + 0.015628804627698667
            Dim delta_err_from_min_diff_h1 As Double = polynom_result_arr1(polynom_result_arr1.Count - 1)("min_diff_h1") - diff_height_from_curve
            'Dim diff_height_from_curve As Double = total_height_of_polynom1 - last_add_height1 - polynom_result_arr1(polynom_result_arr1.Count - 1)("min_diff_h1") - 0.1
            Dim d1 As Integer = 1



            '            +		(0)	{[polynom_obj1, {img_bg_clean1.CPolynom2}]}	System.Collections.Generic.KeyValuePair(Of String, Object)
            '+		(1)	{[last_end_x_polynom1, 194.69167522632051]}	System.Collections.Generic.KeyValuePair(Of String, Object)
            '+		(2)	{[min_dist_from_curve1, 0.10265565315638314]}	System.Collections.Generic.KeyValuePair(Of String, Object)
            '+		(3)	{[end_derivative2, 0.22814814817903453]}	System.Collections.Generic.KeyValuePair(Of String, Object)
            '+		(4)	{[polynom_curve1a, Count = 99]}	System.Collections.Generic.KeyValuePair(Of String, Object)
            '+		(5)	{[min_diff_h1, 0.24024314815493142]}	System.Collections.Generic.KeyValuePair(Of String, Object)
            '+		(6)	{[width_of_curve1, 99]}	System.Collections.Generic.KeyValuePair(Of String, Object)
            '+		(7)	{[height_of_curve1, 34]}	System.Collections.Generic.KeyValuePair(Of String, Object)
            '+		(8)	{[search_mode1, only_end_derivate1]}	System.Collections.Generic.KeyValuePair(Of String, Object)
            '+		(9)	{[error1, yes]}	System.Collections.Generic.KeyValuePair(Of String, Object)

        Next







        For polynom_ind1 = 0 To polynom_curves_arr1.Count - 1
            Dim ind1 As Integer
            Dim polynom_curve1 As ArrayList = polynom_curves_arr1(polynom_ind1)
            If polynom_ind1 > 0 Then

                polynom_curve1 = move_left_botton_curve_to_cord_xy1(polynom_curve1, last_cord_xy1)
            End If
            For ind1 = 0 To polynom_curve1.Count - 1
                complete_curve1.Add(polynom_curve1(ind1))
            Next
            'last_cord_xy1 = 
            Dim last_x1 As Double = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(polynom_curve1)("max_x1")
            Dim last_y1 As Double = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(polynom_curve1)("min_y1")

            last_cord_xy1 = New Double() {last_x1, last_y1}
        Next

        CGlobals1.form_obj1.markingfldimg_obj1.save_2d_pixels_arr1(CGlobals1.global_path1 + "sobel_pics1\polynom_curve1.txt", complete_curve1)
        System.IO.File.WriteAllText(CGlobals1.global_path1 + "sobel_pics1\curve_start_ind1.txt", curve_start_ind1.ToString())
        System.IO.File.WriteAllText(CGlobals1.global_path1 + "sobel_pics1\curve_last_ind1.txt", curve_last_ind1.ToString())
        Dim curve_pxls_arr1f As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, curve_start_ind1, curve_last_ind1)

        Dim move_x1 As Double = 0
        Dim move_y1 As Double = 0


        Dim cord_xy3 As Double() = CGlobals1.get_double_cord_xy_in_pixels_arr2(curve_pxls_arr1f, 0)

        move_x1 = (cord_xy3(0) * curve_zoom1) - 10
        move_y1 = (cord_xy3(1) * curve_zoom1) - 500

        Dim x_vals_arr1 As ArrayList = New ArrayList()

        If polynom_result_arr1.Count = 3 Then
            Dim d1822 As Integer = 1
        End If



        Dim org_pxls_curve2c As ArrayList = curve_pxls_arr1f.Clone()

        Dim org_pxls_curve2c_1 As ArrayList = curve_pxls_arr1f.Clone()
        Dim start_x2 As Integer = CGlobals1.get_double_cord_xy_in_pixels_arr2(org_pxls_curve2c, 0)(0) - 1
        For i1 = 0 To org_pxls_curve2c.Count - 1
            org_pxls_curve2c(i1) = (CGlobals1.get_double_cord_xy_in_pixels_arr2(org_pxls_curve2c, i1)(0) - start_x2).ToString() + "," + (CGlobals1.get_double_cord_xy_in_pixels_arr2(org_pxls_curve2c, i1)(1) - start_x2).ToString()
            org_pxls_curve2c_1(i1) = ((CGlobals1.get_double_cord_xy_in_pixels_arr2(org_pxls_curve2c, i1)(0)) * curve_zoom1).ToString() + "," + (CGlobals1.get_double_cord_xy_in_pixels_arr2(org_pxls_curve2c, i1)(1) - start_x2).ToString()
        Next
        If polynom_result_arr1.Count = 13 Then
            Dim d18222 As Integer = 1
        End If


        For i1 = 0 To curve_pxls_arr1f.Count - 1
            cord_xy3 = CGlobals1.get_double_cord_xy_in_pixels_arr2(curve_pxls_arr1f, i1)
            curve_pxls_arr1f(i1) = (cord_xy3(0) * curve_zoom1 - move_x1).ToString() + "," + (cord_xy3(1) * curve_zoom1 - move_y1).ToString()

            Dim x_val1 As Integer = Double.Parse(curve_pxls_arr1f(i1).ToString().Split(",")(0))
            x_vals_arr1.Add(x_val1)

            If i1 = curve_pxls_arr1f.Count - 1 Then
                Dim d144 As Integer = 1
            End If
        Next
        If polynom_result_arr1.Count = 4 Then
            Dim d18222 As Integer = 1
        End If

        Dim bmp1 As Bitmap = CGlobals1.create_fill_bitmap(3000, 1000, Color.FromArgb(255, 255, 255))
        CGlobals1.form_obj1.markingfldimg_obj1.set_double_pixel_arr_on_bmp2(curve_pxls_arr1f, bmp1, Color.FromArgb(80, 50, 250))
        bmp1.Save(CGlobals1.global_path1 + "sobel_pics1\c1f_1_" + curve_ind1.ToString() + ".bmp")
        bmp1.Save(path_arr1(cur_path_ind1) + "\data1\c1f_1_" + curve_ind1.ToString() + ".bmp")

        Dim dict_rect1 As Dictionary(Of String, Object) = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(curve_pxls_arr1f)
        Dim move_cord_xy1 As Double() = New Double() {dict_rect1("min_x1"), dict_rect1("max_y1") + 5}
        complete_polynom_curve1 = move_left_botton_curve_to_cord_xy1(complete_polynom_curve1, move_cord_xy1)



        If False Then
            While CGlobals1.get_double_cord_xy_in_pixels_arr2(complete_polynom_curve1, complete_polynom_curve1.Count - 1)(0) > (CType(CGlobals1.get_double_cord_xy_in_pixels_arr2(curve_pxls_arr1f, curve_pxls_arr1f.Count - 1)(0), Integer))
                complete_polynom_curve1.RemoveAt(complete_polynom_curve1.Count - 1)

            End While
        End If

        CGlobals1.form_obj1.markingfldimg_obj1.set_double_pixel_arr_on_bmp2(complete_polynom_curve1, bmp1, Color.FromArgb(200, 30, 70))


        If last_ind1 = curve_last_ind1 Then
            CGlobals1.form_obj1.markingfldimg_obj1.save_2d_pixels_arr1(path_arr1(cur_path_ind1) + "\complete_polynom_curve1.txt", complete_polynom_curve1)



            Dim rect_of_curve1 As Dictionary(Of String, Object) = CGlobals1.form_obj1.macros_obj1.find_double_rect_of_pixels_arr(complete_polynom_curve1)
            Dim w1 As Integer = Math.Abs(rect_of_curve1("max_x1") - rect_of_curve1("min_x1")) + 1
            Dim h1 As Integer = Math.Abs(rect_of_curve1("max_y1") - rect_of_curve1("min_y1")) + 1


        End If
        bmp1.Save(CGlobals1.global_path1 + "sobel_pics1\c1f_2_" + curve_ind1.ToString() + ".bmp")
        bmp1.Save(path_arr1(cur_path_ind1) + "\data1\c1f_2_" + curve_ind1.ToString() + ".bmp")




        Dim bmp1f As Bitmap = CGlobals1.create_fill_bitmap(3500, 1000, Color.FromArgb(255, 255, 255))

        complete_polynom_curve1 = move_left_botton_curve_to_cord_xy1(complete_polynom_curve1, New Double() {30, 500})


        CGlobals1.form_obj1.markingfldimg_obj1.set_double_pixel_arr_on_bmp2(complete_polynom_curve1, bmp1f, Color.FromArgb(200, 30, 70))

        bmp1f.Save(CGlobals1.global_path1 + "sobel_pics1\c1fa_" + curve_ind1.ToString() + ".bmp")


        Dim dict_ret_res1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)

        dict_ret_res1("sum_width_of_curve1") = sum_width_of_curve1




        Return dict_ret_res1
    End Function


    Public Function dist_between_point_and_line1(m1_line As Double, n1_line As Double, x0 As Double, y0 As Double)
        Dim a1 As Double = (m1_line * x0 - y0 + n1_line)
        Dim b1 As Double = (Math.Pow(Math.Pow(m1_line, 2) + 1, 0.5))
        Dim dist1 As Double = Math.Abs(a1 / b1)

        Return dist1
    End Function


    Public Function check_dist_curve_with_line_m2(org_curve1 As ArrayList, start_ind1 As Integer, end_ind1 As Integer, start_measure_ind1 As Integer, step_x1 As Double, m1 As Double, Optional do_log1 As String = "")

        If m1 < 4 Then
            Dim d1 As Integer = 1
        End If
        'm1 = 20
        Dim curve_ind1 As Integer
        Dim start_y_val1 As Double = 0
        Dim last_ind_polynom_below_curve1 As Integer
        Dim last_ind_polynom_on_curve1 As Integer
        Dim first_cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(org_curve1, start_ind1)
        Dim max_dist_curve_above_polynom1 As Double = -1
        Dim max_dist_curve_on_polynom1 As Double = -1
        Dim line_curve1 As ArrayList = New ArrayList()
        Dim curve_pxls1 As ArrayList = New ArrayList()
        Dim start_delta_x1 As Integer = -9999

        Dim dict_max_y_of_curve1 As Dictionary(Of Integer, Integer) = New Dictionary(Of Integer, Integer)
        Dim dict_max_y_of_line1 As Dictionary(Of Integer, Double) = New Dictionary(Of Integer, Double)

        Dim dict_rect1 As Dictionary(Of String, Object) = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(org_curve1)


        'CGlobals1.save_pxl_arr_log1(org_curve1, CGlobals1.global_path1 + CGlobals1.sobel_pics_path1 + "org_curve1.bmp")
        org_curve1 = flip_curve_horizontal1(org_curve1)
        ' CGlobals1.save_pxl_arr_log1(org_curve1, CGlobals1.global_path1 + CGlobals1.sobel_pics_path1 + "flip_org_curve1.bmp")


        Dim max_x1 As Double = dict_rect1("max_x1")
        Dim min_y1 As Double = dict_rect1("min_y1")
        Dim max_x2 As Double = dict_rect1("min_x1") + 25


        Dim start_cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(org_curve1, start_ind1)

        If max_x2 = start_cord_xy1(0) Then
            max_x2 += 1
        End If
        Dim max_y1 As Double = (max_x1 - start_cord_xy1(0)) * m1 + start_cord_xy1(1)
        Dim max_y2 As Double = (max_x2 - start_cord_xy1(0)) * m1 + start_cord_xy1(1)

        Dim y_line1a As Double = CGlobals1.form_obj1.markingfldimg_obj1.get_line_x_by_y1(m1, start_cord_xy1(1), (max_x1 - start_cord_xy1(0)))
        'Dim x_line2 As Double = CGlobals1.form_obj1.markingfldimg_obj1.get_line_x_by_y1(m1, start_cord_xy1(1), (max_x1 - start_cord_xy1(0)))


        Dim y_line1 As Double = (10) * m1 + start_cord_xy1(1)
        Dim y_line2 As Double = (30) * m1 + start_cord_xy1(1)


        Dim line_2_pixels As ArrayList = New ArrayList()
        Dim vec_3d_obj1 As vec_3d1 = New vec_3d1()
        vec_3d_obj1.p1 = New point_3d1()
        vec_3d_obj1.p1.x1 = start_cord_xy1(0)
        vec_3d_obj1.p1.y1 = start_cord_xy1(1)
        vec_3d_obj1.p1.z1 = 0

        vec_3d_obj1.p2 = New point_3d1()
        vec_3d_obj1.p2.x1 = start_cord_xy1(0)
        vec_3d_obj1.p2.y1 = start_cord_xy1(1)
        vec_3d_obj1.p2.z1 = -10

        line_2_pixels.Add(New point_3d1(start_cord_xy1(0), start_cord_xy1(1), 0))
        line_2_pixels.Add(New point_3d1(max_x2, max_y2, 0))

        Dim line_2_pixels_2 As ArrayList = New ArrayList()

        line_2_pixels_2.Add(CType(line_2_pixels(0), point_3d1).clone1())
        line_2_pixels_2.Add(CType(line_2_pixels(1), point_3d1).clone1())
        CGlobals1.form_obj1.markingfldimg_obj1.rotate_3d_points_arr2(line_2_pixels_2, vec_3d_obj1, -90)

        If CType(line_2_pixels_2(0), point_3d1).x1 = CType(line_2_pixels_2(1), point_3d1).x1 Then
            Dim err1 As Integer = 1
        End If
        Dim vec_3d_obj2 As vec_3d1 = New vec_3d1()
        vec_3d_obj2.p1 = CType(line_2_pixels_2(0), point_3d1)
        vec_3d_obj2.p2 = CType(line_2_pixels_2(1), point_3d1)

        Dim vec_3d_obj3 As vec_3d1 = New vec_3d1()


        Dim dict_line1 As Dictionary(Of String, Object) = vec_3d_obj2.create_2d_line_equ1()

        Dim m_line2 As Double = (CType(line_2_pixels_2(0), point_3d1).y1 - CType(line_2_pixels_2(1), point_3d1).y1) / (CType(line_2_pixels_2(0), point_3d1).x1 - CType(line_2_pixels_2(1), point_3d1).x1)

        'y=m_line2*x1+b =>b=y-m_line2*x1
        Dim rot_pxl_line1 As ArrayList = CGlobals1.form_obj1.markingfldimg_obj1.create_pixel_arr_line_from_2_2d_points_in_double_with_len_limit1(CType(line_2_pixels_2(0), point_3d1).x1, CType(line_2_pixels_2(0), point_3d1).y1, CType(line_2_pixels_2(1), point_3d1).x1, CType(line_2_pixels_2(1), point_3d1).y1, 20)

        Dim m_rot_line1 As Double = CGlobals1.get_cord_xy_in_pixels_arr1(rot_pxl_line1, rot_pxl_line1.Count - 1)(1) - CGlobals1.get_cord_xy_in_pixels_arr1(rot_pxl_line1, 0)(1)
        m_rot_line1 /= CGlobals1.get_cord_xy_in_pixels_arr1(rot_pxl_line1, rot_pxl_line1.Count - 1)(0) - CGlobals1.get_cord_xy_in_pixels_arr1(rot_pxl_line1, 0)(0)

        'Dim b_line2 As Double = CType(line_2_pixels_2(0), point_3d1).y1 - m_line2 * CType(line_2_pixels_2(0), point_3d1).x1


        CGlobals1.form_obj1.markingfldimg_obj1.compute_cut_line_point1(dict_line1("m1"), dict_line1("b1"), m1, start_cord_xy1(1))

        'x*m_line2+b_line2=x*m1+ start_cord_xy1(1)
        'x*(m_line2/m1)+(b_line2/m1)=x+(start_cord_xy1(1)/m1)
        'x*((m_line2/m1)-1)=(start_cord_xy1(1)/m1)-(b_line2/m1)
        'x=[(start_cord_xy1(1)/m1)-(b_line2/m1)]/((m_line2/m1)-1)
        'Dim x_cut_line_cord1 As Double = ((start_cord_xy1(1) / m1) - (b_line2 / m1)) / ((m_line2 / m1) - 1)
        'Dim y_cut_line_cord1 As Double = x_cut_line_cord1 * m1 + start_cord_xy1(1)


        'y1=x1*m1+b1
        'y2=x2*m2+b2



        'x1*m1+b1=x2*m2+b2
        'x1*m1=x2*m2+b2-b1
        'x1=x2*m2/m1+(b2-b1)/m1



        Dim pxls_line_vals1 As ArrayList = CGlobals1.form_obj1.markingfldimg_obj1.create_pixel_arr_line_from_2_2d_points_in_double_with_len_limit1(start_cord_xy1(0), start_cord_xy1(1), max_x1, max_y1, 400)
        Dim pxls_line1 As ArrayList = New ArrayList()
        If do_log1 = "yes" Then
            pxls_line1 = CGlobals1.form_obj1.markingfldimg_obj1.create_pixel_arr_line_from_2_2d_points_with_len_limit(start_cord_xy1(0), start_cord_xy1(1), max_x1, max_y1, 1000)
        End If




        Dim log_img1 As String = "yes"
        Dim bmp1d As Bitmap = CGlobals1.create_fill_bitmap(3000, 2000, Color.FromArgb(255, 255, 255))

        If do_log1 = "yes" Then

            CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(org_curve1, bmp1d, Color.FromArgb(250, 100, 50))
            CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(pxls_line1, bmp1d, Color.FromArgb(50, 100, 150))
            CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(rot_pxl_line1, bmp1d, Color.FromArgb(250, 150, 150))


            'bmp1d = CGlobals1.draw_sqr_around_pixels(bmp1d, x_cut_line_cord1, y_cut_line_cord1, 5, Color.FromArgb(50, 100, 150))
            'CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(curve_pxls1, bmp1, Color.FromArgb(250, 100, 50))
            bmp1d.Save(CGlobals1.global_path1 + CGlobals1.sobel_pics_path1 + "log_line1\line_m3_" + m1.ToString() + ".bmp")

        End If


        Dim dict_line_eqa2 As Dictionary(Of String, Object) = vec_3d_obj3.create_2d_line_equ_from_m1_and_xy_cord(New Double() {start_cord_xy1(0), start_cord_xy1(1)}, m1)


        Dim ind1 As Integer
        Dim start_pxl_line_ind As Integer = 0

        Dim max_dist_pxl_line_below_curve1 As Double = -1

        Dim min_dist1 As Double = -1

        Dim to_stop1 As Integer = 0
        ind1 = start_ind1 + start_measure_ind1
        Dim m_dist_line_arr1 As ArrayList = New ArrayList()
        While to_stop1 = 0
            If ind1 >= org_curve1.Count Then
                Dim err1 As Integer = 1
            End If
            Dim curve_cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(org_curve1, ind1)

            Dim dict_line_eqa1 As Dictionary(Of String, Object) = vec_3d_obj3.create_2d_line_equ_from_m1_and_xy_cord(New Double() {curve_cord_xy1(0), curve_cord_xy1(1)}, m_line2)

            'Dim pxls_line2 As ArrayList = CGlobals1.form_obj1.markingfldimg_obj1.create_pxl_line_from_two_x_and_line_eqa1(dict_line_eqa1, curve_cord_xy1(0), curve_cord_xy1(0) + 100)


            Dim dict_cut_cord_xy1 As Dictionary(Of String, Object) = CGlobals1.form_obj1.markingfldimg_obj1.compute_cut_line_point1(dict_line_eqa1("m1"), dict_line_eqa1("b1"), dict_line_eqa2("m1"), dict_line_eqa2("b1"))

            If ind1 Mod 1 = 0 And False Then
                Dim deriv_pxls_line1 As ArrayList = CGlobals1.form_obj1.markingfldimg_obj1.create_pixel_arr_line_from_2_2d_points(curve_cord_xy1(0), curve_cord_xy1(1), dict_cut_cord_xy1("x"), dict_cut_cord_xy1("y"))
                CGlobals1.draw_sqr_around_pixels2(bmp1d, curve_cord_xy1(0), curve_cord_xy1(1), 2, Color.FromArgb(200, 50, 200))
                CGlobals1.draw_sqr_around_pixels2(bmp1d, dict_cut_cord_xy1("x"), dict_cut_cord_xy1("y"), 1, Color.FromArgb(100, 50, 200))
                If curve_cord_xy1(0) < dict_cut_cord_xy1("x") Then

                    Dim d1 As Integer = 1
                Else
                    Dim d2 As Integer = 1

                End If

                If curve_cord_xy1(1) < dict_cut_cord_xy1("y") Then

                    Dim d1 As Integer = 1
                Else
                    Dim d2 As Integer = 1

                End If

                CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(deriv_pxls_line1, bmp1d, Color.FromArgb(200, 67, 90))
                'CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(pxls_line2, bmp1d, Color.FromArgb(20, 67, 230))
                bmp1d.Save(CGlobals1.global_path1 + CGlobals1.sobel_pics_path1 + "line_m3_" + m1.ToString() + ".bmp")



            End If

            Dim m_dist_line As Double = (dict_cut_cord_xy1("y") - curve_cord_xy1(1)) / Math.Abs((dict_cut_cord_xy1("x") - curve_cord_xy1(0)))
            m_dist_line_arr1.Add(m_dist_line.ToString() + ",x=>" + dict_cut_cord_xy1("x").ToString() + "," + curve_cord_xy1(0).ToString() + ",y=>" + dict_cut_cord_xy1("y").ToString() + "," + curve_cord_xy1(1).ToString())
            Dim y_val_line1 As Double = (curve_cord_xy1(0) - start_cord_xy1(0)) * m1 + start_cord_xy1(1)
            If m_dist_line < 0 Then

            End If
            'If y_val_line1 <= curve_cord_xy1(1) Then
            If m_dist_line < 0 Then
                'Dim dist1 As Double = dist_between_point_and_line1(m1, (curve_cord_xy1(0) - start_cord_xy1(0)), curve_cord_xy1(0), curve_cord_xy1(1))
                'Dim dist1 As Double = dist_between_point_and_line1(m1, (curve_cord_xy1(0)), curve_cord_xy1(0), curve_cord_xy1(1))
                Dim dist2 As Double = CGlobals1.form_obj1.markingfldimg_obj1.get_dist_between_2_cords_xy2(New Double() {dict_cut_cord_xy1("x"), dict_cut_cord_xy1("y")}, New Double() {curve_cord_xy1(0), curve_cord_xy1(1)})

                If min_dist1 < dist2 Then
                    min_dist1 = dist2
                End If
            End If
            Dim to_stop2 As Integer = 0



            ind1 += 1
            If ind1 >= org_curve1.Count - 1 Then
                to_stop1 = 1
            End If
        End While


        Return min_dist1
    End Function



    Public Function check_curve_with_m1(org_curve1 As ArrayList, start_ind1 As Integer, end_ind1 As Integer, start_measure_ind1 As Integer, step_x1 As Double, m1 As Double)

        If m1 < 4 Then
            Dim d1 As Integer = 1
        End If
        Dim curve_ind1 As Integer
        Dim start_y_val1 As Double = 0
        Dim last_ind_polynom_below_curve1 As Integer
        Dim last_ind_polynom_on_curve1 As Integer
        Dim first_cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(org_curve1, start_ind1)
        Dim max_dist_curve_above_polynom1 As Double = -1
        Dim max_dist_curve_on_polynom1 As Double = -1
        Dim line_curve1 As ArrayList = New ArrayList()
        Dim curve_pxls1 As ArrayList = New ArrayList()
        Dim start_delta_x1 As Integer = -9999
        For curve_ind1 = start_ind1 To end_ind1
            Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(org_curve1, Math.Min(curve_ind1, org_curve1.Count - 1))
            Dim y_val_curve1 As Integer = -cord_xy1(1) + first_cord_xy1(1)
            If curve_ind1 >= start_measure_ind1 Then

                If (y_val_curve1) > start_y_val1 Then
                    last_ind_polynom_below_curve1 = curve_ind1 - start_ind1
                    If max_dist_curve_above_polynom1 = -1 Then
                        max_dist_curve_above_polynom1 = y_val_curve1 - start_y_val1
                    Else
                        If max_dist_curve_above_polynom1 < y_val_curve1 - start_y_val1 Then
                            max_dist_curve_above_polynom1 = y_val_curve1 - start_y_val1

                        End If
                    End If
                Else

                    If start_y_val1 = y_val_curve1 Or curve_ind1 = start_ind1 Then
                        last_ind_polynom_on_curve1 = curve_ind1 - start_ind1
                    Else
                        If Math.Floor(start_y_val1) = y_val_curve1 And last_ind_polynom_on_curve1 = curve_ind1 - start_ind1 - 1 Then
                            last_ind_polynom_on_curve1 = curve_ind1 - start_ind1
                        End If
                    End If

                End If
            End If


            line_curve1.Add((curve_ind1 - start_ind1).ToString() + "," + Math.Floor(start_y_val1).ToString())
            'curve_pxls1.Add((curve_ind1 - start_ind1).ToString() + "," + Math.Floor(y_val_curve1).ToString())

            If start_delta_x1 = -9999 Then
                start_delta_x1 = (curve_ind1 - start_ind1) - (cord_xy1(0) - start_ind1)
            End If
            curve_pxls1.Add((cord_xy1(0) - start_ind1 + start_delta_x1).ToString() + "," + Math.Floor(y_val_curve1).ToString())

            start_y_val1 += step_x1 * m1
        Next
        Dim d8 As Integer = 1
        If max_dist_curve_above_polynom1 <= 0 Then
            Dim d2 As Integer = 1
        End If
        Dim show_img1 As String = ""
        If show_img1 = "" Then
            Return max_dist_curve_above_polynom1

        End If

        Dim bmp1 As Bitmap = CGlobals1.create_fill_bitmap(3000, 2000, Color.FromArgb(255, 255, 255))

        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(line_curve1, bmp1, Color.FromArgb(50, 100, 150))
        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(curve_pxls1, bmp1, Color.FromArgb(250, 100, 50))
        bmp1.Save(CGlobals1.global_path1 + CGlobals1.sobel_pics_path1 + "line_m2.bmp")

        Return max_dist_curve_above_polynom1
    End Function


    Public Function flip_curve_horizontal1(curve_pxl_arr1 As ArrayList)
        Dim dict_rect1 As Dictionary(Of String, Object) = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(curve_pxl_arr1)
        Dim max_x1 As Double = dict_rect1("max_x1")
        Dim min_y1 As Double = dict_rect1("min_y1")
        Dim max_y1 As Double = dict_rect1("max_y1")

        Dim center_y1 As Double = Math.Floor((min_y1 + max_y1) / 2)
        Dim flip_curve1 As ArrayList = New ArrayList()

        Dim ind1 As Integer
        Dim first_cord_xy1a As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxl_arr1, 0)
        For ind1 = 0 To curve_pxl_arr1.Count - 1

            If ind1 >= curve_pxl_arr1.Count - 50 Then
                Dim d1 As Integer = 1
            End If
            Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxl_arr1, ind1)
            Dim new_y1 As Integer = cord_xy1(1)
            If cord_xy1(1) > center_y1 Then
                new_y1 = center_y1 - Math.Abs(cord_xy1(1) - center_y1)
            ElseIf cord_xy1(1) < center_y1 Then
                new_y1 = center_y1 + Math.Abs(cord_xy1(1) - center_y1)

            End If
            'Dim new_y1 As Integer = Math.Abs(cord_xy1(1) - first_cord_xy1a(1)) + first_cord_xy1a(1)

            flip_curve1.Add(cord_xy1(0).ToString() + "," + new_y1.ToString())
        Next

        Return flip_curve1
    End Function


    Public Function flip_curve_vertical1(curve_pxl_arr1 As ArrayList)
        Dim dict_rect1 As Dictionary(Of String, Object) = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(curve_pxl_arr1)
        Dim min_x1 As Double = dict_rect1("min_x1")
        Dim max_x1 As Double = dict_rect1("max_x1")
        Dim min_y1 As Double = dict_rect1("min_y1")
        Dim max_y1 As Double = dict_rect1("max_y1")

        Dim center_x1 As Double = Math.Floor((min_x1 + max_x1) / 2)
        Dim flip_curve1 As ArrayList = New ArrayList()

        Dim ind1 As Integer
        Dim first_cord_xy1a As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxl_arr1, 0)
        For ind1 = 0 To curve_pxl_arr1.Count - 1

            If ind1 >= curve_pxl_arr1.Count - 50 Then
                Dim d1 As Integer = 1
            End If
            Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxl_arr1, ind1)
            Dim new_x1 As Integer = cord_xy1(0)
            If cord_xy1(0) > center_x1 Then
                new_x1 = center_x1 - Math.Abs(cord_xy1(0) - center_x1)
            ElseIf cord_xy1(0) < center_x1 Then
                new_x1 = center_x1 + Math.Abs(cord_xy1(0) - center_x1)

            End If
            'Dim new_y1 As Integer = Math.Abs(cord_xy1(1) - first_cord_xy1a(1)) + first_cord_xy1a(1)

            flip_curve1.Add(new_x1.ToString() + "," + cord_xy1(1).ToString())
        Next

        Return flip_curve1
    End Function


    Public Function check_curve_with_m2(org_curve1 As ArrayList, start_ind1 As Integer, end_ind1 As Integer, start_measure_ind1 As Integer, step_x1 As Double, m1 As Double)

        If m1 < 4 Then
            Dim d1 As Integer = 1
        End If
        'm1 = 20
        Dim curve_ind1 As Integer
        Dim start_y_val1 As Double = 0
        Dim last_ind_polynom_below_curve1 As Integer
        Dim last_ind_polynom_on_curve1 As Integer
        Dim first_cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(org_curve1, start_ind1)
        Dim max_dist_curve_above_polynom1 As Double = -1
        Dim max_dist_curve_on_polynom1 As Double = -1
        Dim line_curve1 As ArrayList = New ArrayList()
        Dim curve_pxls1 As ArrayList = New ArrayList()
        Dim start_delta_x1 As Integer = -9999

        Dim dict_max_y_of_curve1 As Dictionary(Of Integer, Integer) = New Dictionary(Of Integer, Integer)
        Dim dict_max_y_of_line1 As Dictionary(Of Integer, Double) = New Dictionary(Of Integer, Double)

        Dim dict_rect1 As Dictionary(Of String, Object) = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(org_curve1)

        org_curve1 = flip_curve_horizontal1(org_curve1)


        Dim max_x1 As Double = dict_rect1("max_x1")
        Dim min_y1 As Double = dict_rect1("min_y1")


        Dim start_cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(org_curve1, start_ind1)

        Dim max_y1 As Double = (max_x1 - start_cord_xy1(0)) * m1 + start_cord_xy1(1)


        Dim pxls_line_vals1 As ArrayList = CGlobals1.form_obj1.markingfldimg_obj1.create_pixel_arr_line_from_2_2d_points_in_double(start_cord_xy1(0), start_cord_xy1(1), max_x1, max_y1)
        Dim pxls_line1 As ArrayList = CGlobals1.form_obj1.markingfldimg_obj1.create_pixel_arr_line_from_2_2d_points(start_cord_xy1(0), start_cord_xy1(1), max_x1, max_y1)

        Dim log_img1 As String = ""

        If log_img1 = "yes" Then
            Dim bmp1d As Bitmap = CGlobals1.create_fill_bitmap(3000, 2000, Color.FromArgb(255, 255, 255))

            CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(org_curve1, bmp1d, Color.FromArgb(250, 100, 50))
            CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(pxls_line1, bmp1d, Color.FromArgb(50, 100, 150))
            'CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(curve_pxls1, bmp1, Color.FromArgb(250, 100, 50))
            bmp1d.Save(CGlobals1.global_path1 + CGlobals1.sobel_pics_path1 + "line_m3.bmp")

        End If

        Dim ind1 As Integer
        Dim start_pxl_line_ind As Integer = 0

        Dim max_dist_pxl_line_below_curve1 As Double = -1


        Dim to_stop1 As Integer = 0
        ind1 = start_measure_ind1
        While to_stop1 = 0
            Dim curve_cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(org_curve1, ind1)
            Dim to_stop2 As Integer = 0

            While to_stop2 = 0
                Dim line_cord_xy1 As Double() = CGlobals1.get_double_cord_xy_in_pixels_arr2(pxls_line_vals1, start_pxl_line_ind)
                If Math.Floor(line_cord_xy1(0)) > curve_cord_xy1(0) Then
                    start_pxl_line_ind -= 1
                    to_stop2 = 1
                Else
                    start_pxl_line_ind += 1
                End If

                If start_pxl_line_ind >= pxls_line_vals1.Count - 1 Then
                    start_pxl_line_ind = pxls_line_vals1.Count - 1
                    to_stop2 = 1
                End If
            End While
            Dim line_cord_xy2 As Double() = CGlobals1.get_double_cord_xy_in_pixels_arr2(pxls_line_vals1, start_pxl_line_ind)
            If line_cord_xy2(1) < curve_cord_xy1(1) Then
                Dim dist_pxl_line_below_curve1 As Double = Math.Abs(curve_cord_xy1(1) - line_cord_xy2(1))
                If max_dist_pxl_line_below_curve1 < dist_pxl_line_below_curve1 Then
                    max_dist_pxl_line_below_curve1 = dist_pxl_line_below_curve1
                End If

            End If
            ind1 += 1
            If ind1 >= org_curve1.Count Then
                to_stop1 = 1
            End If
        End While


        Return max_dist_pxl_line_below_curve1
        For ind1 = start_measure_ind1 To end_ind1
            Dim curve_cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(org_curve1, ind1)
            Dim to_stop2 As Integer = 0

            While to_stop2 = 0
                Dim line_cord_xy1 As Double() = CGlobals1.get_double_cord_xy_in_pixels_arr2(pxls_line1, start_pxl_line_ind)
                If line_cord_xy1(0) >= curve_cord_xy1(0) Then
                    to_stop2 = 1
                Else
                    start_pxl_line_ind += 1
                End If
            End While
            Dim line_cord_xy2 As Double() = CGlobals1.get_double_cord_xy_in_pixels_arr2(pxls_line1, start_pxl_line_ind)
            If line_cord_xy2(1) < curve_cord_xy1(1) Then
                Dim dist_pxl_line_below_curve1 As Double = curve_cord_xy1(1) - line_cord_xy2(1)
            End If
        Next

        For curve_ind1 = start_ind1 To end_ind1
            Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(org_curve1, Math.Min(curve_ind1, org_curve1.Count - 1))
            Dim y_val_curve1 As Integer = -cord_xy1(1) + first_cord_xy1(1)
            curve_pxls1.Add((cord_xy1(0) - start_ind1 + start_delta_x1).ToString() + "," + Math.Floor(y_val_curve1).ToString())

            If start_delta_x1 = -9999 Then
                start_delta_x1 = (curve_ind1 - start_ind1) - (cord_xy1(0) - start_ind1)
            End If

            If dict_max_y_of_curve1.ContainsKey((cord_xy1(0) - start_ind1 + start_delta_x1)) = False Then
                dict_max_y_of_curve1((cord_xy1(0) - start_ind1 + start_delta_x1)) = Math.Floor(y_val_curve1)
            Else
                If dict_max_y_of_curve1((cord_xy1(0) - start_ind1 + start_delta_x1)) < Math.Floor(y_val_curve1) Then
                    dict_max_y_of_curve1((cord_xy1(0) - start_ind1 + start_delta_x1)) = Math.Floor(y_val_curve1)
                End If
            End If

            line_curve1.Add((curve_ind1 - start_ind1).ToString() + "," + Math.Floor(start_y_val1).ToString())




            If dict_max_y_of_line1.ContainsKey((curve_ind1 - start_ind1)) = False Then
                dict_max_y_of_line1((curve_ind1 - start_ind1)) = Math.Floor(start_y_val1)
            Else
                If dict_max_y_of_line1((curve_ind1 - start_ind1)) < Math.Floor(start_y_val1) Then
                    dict_max_y_of_line1((curve_ind1 - start_ind1)) = Math.Floor(start_y_val1)
                End If
            End If

            start_y_val1 += step_x1 * m1
        Next

        For curve_ind1 = start_ind1 To end_ind1
            Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(org_curve1, Math.Min(curve_ind1, org_curve1.Count - 1))
            Dim y_val_curve1 As Integer = -cord_xy1(1) + first_cord_xy1(1)
            If curve_ind1 >= start_measure_ind1 Then

                If (y_val_curve1) > start_y_val1 Then
                    last_ind_polynom_below_curve1 = curve_ind1 - start_ind1
                    If max_dist_curve_above_polynom1 = -1 Then
                        max_dist_curve_above_polynom1 = y_val_curve1 - start_y_val1
                    Else
                        If max_dist_curve_above_polynom1 < y_val_curve1 - start_y_val1 Then
                            max_dist_curve_above_polynom1 = y_val_curve1 - start_y_val1

                        End If
                    End If
                Else

                    If start_y_val1 = y_val_curve1 Or curve_ind1 = start_ind1 Then
                        last_ind_polynom_on_curve1 = curve_ind1 - start_ind1
                    Else
                        If Math.Floor(start_y_val1) = y_val_curve1 And last_ind_polynom_on_curve1 = curve_ind1 - start_ind1 - 1 Then
                            last_ind_polynom_on_curve1 = curve_ind1 - start_ind1
                        End If
                    End If

                End If
            End If


            line_curve1.Add((curve_ind1 - start_ind1).ToString() + "," + Math.Floor(start_y_val1).ToString())
            'curve_pxls1.Add((curve_ind1 - start_ind1).ToString() + "," + Math.Floor(y_val_curve1).ToString())

            If start_delta_x1 = -9999 Then
                start_delta_x1 = (curve_ind1 - start_ind1) - (cord_xy1(0) - start_ind1)
            End If
            curve_pxls1.Add((cord_xy1(0) - start_ind1 + start_delta_x1).ToString() + "," + Math.Floor(y_val_curve1).ToString())

            start_y_val1 += step_x1 * m1
        Next
        Dim d8 As Integer = 1
        If max_dist_curve_above_polynom1 <= 0 Then
            Dim d2 As Integer = 1
        End If
        Dim show_img1 As String = ""
        If show_img1 = "" Then
            Return max_dist_curve_above_polynom1

        End If

        Dim bmp1 As Bitmap = CGlobals1.create_fill_bitmap(3000, 2000, Color.FromArgb(255, 255, 255))

        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(line_curve1, bmp1, Color.FromArgb(50, 100, 150))
        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(curve_pxls1, bmp1, Color.FromArgb(250, 100, 50))
        bmp1.Save(CGlobals1.global_path1 + CGlobals1.sobel_pics_path1 + "line_m2.bmp")

        Return max_dist_curve_above_polynom1
    End Function



    Public Function find_min_end_m1_b1(curve As ArrayList, start_ind1 As Integer, end_ind1 As Integer, step_x1 As Double)
        Dim m1 As Double = 1
        Dim m1_add_factor1 As Double = 0.1
        Dim max_dist_curve_above_polynom1_delta1 As Double = 0
        Dim start_check_ind1 As Integer = 15
        Dim max_dist_curve_above_polynom1 As Double = check_curve_with_m1(curve, start_ind1, end_ind1, start_ind1 + start_check_ind1, 1, m1)

        While max_dist_curve_above_polynom1 = -1
            max_dist_curve_above_polynom1 = check_curve_with_m1(curve, start_ind1, end_ind1, start_ind1 + start_check_ind1, 1, m1)
            m1 -= m1_add_factor1
        End While

        m1 -= m1_add_factor1

        While max_dist_curve_above_polynom1 < max_dist_curve_above_polynom1_delta1 And m1_add_factor1 > Math.Pow(10, -10)
            m1 -= m1_add_factor1
            max_dist_curve_above_polynom1 = check_curve_with_m1(curve, start_ind1, end_ind1, start_ind1 + start_check_ind1, 1, m1)
            If max_dist_curve_above_polynom1 > max_dist_curve_above_polynom1_delta1 Then
                m1 += m1_add_factor1
                m1_add_factor1 /= 2
                max_dist_curve_above_polynom1 = check_curve_with_m1(curve, start_ind1, end_ind1, start_ind1 + start_check_ind1, 1, m1)

            End If

        End While

        'Return m1

        Dim bmp1 As Bitmap = CGlobals1.create_fill_bitmap(3000, 2000, Color.FromArgb(255, 255, 255))
        Dim i1 As Integer
        Dim sub_curve1 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(curve, start_ind1, end_ind1)
        Dim first_cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(sub_curve1, 0)
        Dim line_pxls1 As ArrayList = New ArrayList()
        For i1 = 0 To (end_ind1 - start_ind1)
            Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(sub_curve1, i1)

            Dim line_y_val1 As Double = first_cord_xy1(1) - m1 * (cord_xy1(0) - first_cord_xy1(0))
            line_pxls1.Add(cord_xy1(0).ToString() + "," + line_y_val1.ToString())

        Next
        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(sub_curve1, bmp1, Color.FromArgb(50, 100, 150))
        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(line_pxls1, bmp1, Color.FromArgb(250, 100, 50))
        bmp1.Save(CGlobals1.global_path1 + CGlobals1.sobel_pics_path1 + "line_m1.bmp")
        Return m1
    End Function



    Public Function find_min_end_m1(curve As ArrayList, start_ind1 As Integer, end_ind1 As Integer, step_x1 As Double, start_check_ind1 As Integer, Optional start_m1 As Double = -1)
        Dim m1 As Double = 1
        If start_m1 > -1 Then
            m1 = start_m1
        End If
        Dim m1_add_factor1 As Double = 0.1
        Dim max_dist_curve_above_polynom1_delta1 As Double = 0
        'Dim start_check_ind1 As Integer = 5



        Dim max_dist_curve_above_polynom2 As Double = check_curve_with_m2(curve, start_ind1, end_ind1, start_ind1 + start_check_ind1, 1, m1)

        Dim max_dist_curve_above_polynom1 As Double = check_curve_with_m1(curve, start_ind1, end_ind1, start_ind1 + start_check_ind1, 1, m1)

        'While max_dist_curve_above_polynom1 = -1
        'max_dist_curve_above_polynom1 = check_curve_with_m1(curve, start_ind1 + start_check_ind1, end_ind1, 1, m1)
        'm1 -= m1_add_factor1
        'End While

        'm1 -= m1_add_factor1
        Dim last_dir1 As Integer = 1
        While Math.Abs(max_dist_curve_above_polynom1 - max_dist_curve_above_polynom1_delta1) > Math.Pow(10, -9) And m1_add_factor1 > Math.Pow(10, -10)
            If max_dist_curve_above_polynom1 < max_dist_curve_above_polynom1_delta1 Or max_dist_curve_above_polynom1 = -1 Then
                If last_dir1 = -1 Then
                    m1_add_factor1 /= 2
                End If
                m1 -= m1_add_factor1
                last_dir1 = 1
            Else
                If last_dir1 = 1 Then
                    m1_add_factor1 /= 2
                End If
                m1 += m1_add_factor1
                last_dir1 = -1
            End If

            'max_dist_curve_above_polynom1 = check_curve_with_m1(curve, start_ind1, end_ind1, start_ind1 + start_check_ind1, 1, m1)
            max_dist_curve_above_polynom1 = check_curve_with_m2(curve, start_ind1, end_ind1, start_ind1 + start_check_ind1, 1, m1)

        End While

        'Return m1

        Dim bmp1 As Bitmap = CGlobals1.create_fill_bitmap(3000, 2000, Color.FromArgb(255, 255, 255))
        Dim i1 As Integer
        Dim sub_curve1 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(curve, start_ind1, end_ind1)
        Dim first_cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(sub_curve1, 0)
        Dim line_pxls1 As ArrayList = New ArrayList()
        For i1 = 0 To (end_ind1 - start_ind1)
            Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(sub_curve1, Math.Min(i1, sub_curve1.Count - 1))

            Dim line_y_val1 As Double = first_cord_xy1(1) - m1 * (cord_xy1(0) - first_cord_xy1(0))
            line_pxls1.Add(cord_xy1(0).ToString() + "," + line_y_val1.ToString())

        Next
        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(sub_curve1, bmp1, Color.FromArgb(50, 100, 150))
        bmp1.Save(CGlobals1.global_path1 + CGlobals1.sobel_pics_path1 + "log_line1\line_m1a_" + start_ind1.ToString() + ".bmp")
        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(line_pxls1, bmp1, Color.FromArgb(250, 100, 50))
        bmp1.Save(CGlobals1.global_path1 + CGlobals1.sobel_pics_path1 + "log_line1\line_m1b_" + start_ind1.ToString() + ".bmp")
        Return m1
    End Function


    Public Function rotate_curve_vertical1(curve_arr1 As ArrayList)
        Dim dict_rect1 As Dictionary(Of String, Object) = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(curve_arr1)
        Dim new_curve_pxl_arr1 As ArrayList = New ArrayList()
        Dim i1 As Integer

        For i1 = 0 To curve_arr1.Count - 1
            Dim cord_xy1 As Double() = CGlobals1.get_double_cord_xy_in_pixels_arr2(curve_arr1, i1)
            Dim new_x_val1 As Double = dict_rect1("max_x1") - cord_xy1(0) + dict_rect1("min_x1")
            new_curve_pxl_arr1.Add(new_x_val1.ToString() + "," + cord_xy1(1).ToString())
        Next
        Return new_curve_pxl_arr1
    End Function


    Public Function rotate_curve_vertical2(curve_arr1 As ArrayList)
        Dim dict_rect1 As Dictionary(Of String, Object) = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(curve_arr1)
        Dim new_curve_pxl_arr1 As ArrayList = New ArrayList()
        Dim i1 As Integer
        Dim x_cords_arr1 As ArrayList = New ArrayList()

        Dim dict_new_x_cords1 As Dictionary(Of Integer, Integer) = New Dictionary(Of Integer, Integer)
        Dim x_cord_ind1 As Integer = 0
        For i1 = curve_arr1.Count - 1 To 0 Step -1
            dict_new_x_cords1(i1) = dict_rect1("max_x1") - CGlobals1.get_cord_xy_in_pixels_arr1(curve_arr1, i1)(0)
            'x_cords_arr1.Add(dict_rect1("max_x1") - CGlobals1.get_cord_xy_in_pixels_arr1(curve_arr1, i1)(0).ToString())
        Next

        For i1 = curve_arr1.Count - 1 To 0 Step -1
            Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_arr1, i1)
            new_curve_pxl_arr1.Add((dict_new_x_cords1(i1) + 20).ToString() + "," + cord_xy1(1).ToString())
            'x_cords_arr1(x_cord_ind1) = CGlobals1.get_double_cord_xy_in_pixels_arr2(curve_arr1, i1)
        Next


        Return new_curve_pxl_arr1
    End Function


    Public Function move_left_botton_curve_to_cord_xy1(curve_arr1 As ArrayList, left_botton_cord_xy1 As Double())
        Dim dict_rect1 As Dictionary(Of String, Object) = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(curve_arr1)

        Dim new_curve_pxl_arr1 As ArrayList = New ArrayList()
        Dim i1 As Integer

        For i1 = 0 To curve_arr1.Count - 1
            Dim cord_xy1 As Double() = CGlobals1.get_double_cord_xy_in_pixels_arr2(curve_arr1, i1)
            Dim new_x_val1 As Double = cord_xy1(0) - dict_rect1("min_x1") + left_botton_cord_xy1(0)
            Dim new_y_val1 As Double = cord_xy1(1) - dict_rect1("max_y1") + left_botton_cord_xy1(1)
            new_curve_pxl_arr1.Add(new_x_val1.ToString() + "," + new_y_val1.ToString())
        Next
        Return new_curve_pxl_arr1

    End Function


    Public Function clear_curve_by_monotonic_down1(curve_pxls_arr1 As ArrayList)

        Dim bmp1 As Bitmap = CGlobals1.create_fill_bitmap(3000, 2000, Color.FromArgb(255, 255, 255))
        Dim i1 As Integer
        Dim last_x_val1 As Integer = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, 0)(0)
        Dim last_y_val1 As Integer = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, 0)(1)
        Dim new_monotonic_curve1 As ArrayList = New ArrayList()
        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(curve_pxls_arr1, bmp1, Color.FromArgb(200, 100, 50))

        new_monotonic_curve1.Add(curve_pxls_arr1(0))

        For i1 = 1 To curve_pxls_arr1.Count - 1

            Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, i1)
            If cord_xy1(0) > last_x_val1 Then
                If cord_xy1(1) > last_y_val1 Then
                    cord_xy1(1) = last_y_val1
                ElseIf cord_xy1(1) < last_y_val1 Then
                    last_y_val1 = cord_xy1(1)

                End If
                last_x_val1 = cord_xy1(0)

                new_monotonic_curve1.Add(cord_xy1(0).ToString() + "," + cord_xy1(1).ToString())
            End If
        Next
        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(new_monotonic_curve1, bmp1, Color.FromArgb(20, 10, 50))
        bmp1.Save(CGlobals1.global_path1 + CGlobals1.sobel_pics_path1 + "monotonic1.bmp")
        Return new_monotonic_curve1
    End Function

    Public Function replace_slice_of_curve_with_polynom_curve1(org_curve1 As ArrayList, start_ind1 As Integer, end_ind1 As Integer, polynom_curve1 As ArrayList)
        Dim start_cord1 As Double() = CGlobals1.get_double_cord_xy_in_pixels_arr2(org_curve1, start_ind1)
        Dim new_polynom_curve1 As ArrayList = move_left_botton_curve_to_cord_xy1(polynom_curve1, start_cord1)
        Dim dict_res1 As Dictionary(Of String, Object) = CGlobals1.form_obj1.markingfldimg_obj1.check_min_dist_to_curve2(org_curve1, CGlobals1.get_double_cord_xy_in_pixels_arr2(new_polynom_curve1, new_polynom_curve1.Count - 1), 5)
        polynom_curve1 = new_polynom_curve1
        'Return 1
        Dim i1 As Integer
        Dim min_dist1 As Double = 999
        Dim min_dist_ind1 As Integer = -1
        For i1 = end_ind1 - 20 To end_ind1 + 20
            Dim cord_of_curve1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(org_curve1, i1)
            'CGlobals1.form_obj1.markingfldimg_obj1.check_min_dist_to_curve1()
        Next

        Dim new_org_curve1 As ArrayList = New ArrayList()

        For i1 = 0 To start_ind1 - 1
            new_org_curve1.Add(org_curve1(i1))
        Next
        For i1 = 0 To polynom_curve1.Count - 1
            new_org_curve1.Add(polynom_curve1(i1))

        Next

        For i1 = dict_res1("min_dist_ind1") To org_curve1.Count - 1
            new_org_curve1.Add(org_curve1(i1))



        Next


        CGlobals1.global_suffix_file_name1 = "_frame1"
        Dim path_sign_sobel_ind1 As String = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_sign_sobel_ind1" + CGlobals1.global_suffix_file_name1 + ".txt"


        Dim sobel_ind1 As Integer = Integer.Parse(System.IO.File.ReadAllText(path_sign_sobel_ind1))

        Dim path_of_bmp1 As String = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_sobel_cache1\" + sobel_ind1.ToString() + ".jpg"
        Dim bmp1 As Bitmap = New Bitmap(path_of_bmp1)




        Dim pixels_arr1 As ArrayList = CGlobals1.form_obj1.markingfldimg_obj1.load_2d_pixels_arr1(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_2d_pixels_sobel_" + sobel_ind1.ToString() + CGlobals1.global_suffix_file_name1 + ".txt")
        pixels_arr1 = new_org_curve1
        System.IO.File.Copy(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_2d_pixels_sobel_" + sobel_ind1.ToString() + CGlobals1.global_suffix_file_name1 + ".txt", CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_frame4.txt", True)
        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(pixels_arr1, bmp1, Color.FromArgb(200, 60, 90))
        bmp1.Save(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_frame2_polynom1a.bmp")
        Dim bmp2 As Bitmap = New Bitmap(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_crop1.jpg")
        Dim bmp3 As Bitmap = CGlobals1.create_fill_bitmap(bmp2.Width, bmp2.Height, Color.FromArgb(255, 255, 255))
        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(pixels_arr1, bmp3, Color.FromArgb(200, 60, 90))


        bmp3 = CGlobals1.form_obj1.markingfldimg_obj1.paint_recursive3(bmp3, 20, 20, Color.FromArgb(200, 60, 90), Color.FromArgb(55, 100, 70))
        Dim org_bmp1 As Bitmap = New Bitmap(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_crop1.jpg")

        org_bmp1 = CGlobals1.form_obj1.markingfldimg_obj1.set_pixels_by_mask1(bmp3, Color.FromArgb(255, 255, 255), org_bmp1)
        CGlobals1.form_obj1.PictureBox1.Image = CGlobals1.form_obj1.zoom_img1(org_bmp1, 3)
        org_bmp1.Save(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_frame2_polynom1.bmp")


    End Function


    Public Function close_hole_in_curve1(curve_pxl_arr1 As ArrayList, start_ind1 As Integer, end_ind1 As Integer)
        Dim ind1 As Integer
        Dim ind2 As Integer

        ind1 = start_ind1
        ind2 = start_ind1 + 2
        Dim to_stop1 As Integer = 0


        Dim max_last_size_of_hole1 As Integer = 0

        Dim hole_inds_arr1 As ArrayList = New ArrayList()

        While to_stop1 = 0

            Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxl_arr1, ind1)
            Dim cord_xy2 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxl_arr1, ind2)
            Dim rot_curve_pxls_arr1 As ArrayList = curve_pxl_arr1
            Dim derivate1 As Double = 0
            Dim derivate_add_factor1 As Double = 5
            If cord_xy2(0) <> cord_xy1(0) Then
                derivate1 = (Math.Atan((cord_xy2(1) - cord_xy1(1)) / Math.Abs((cord_xy2(0) - cord_xy1(0)))) * 180.0 / Math.PI)

                Dim to_stop2 As Integer = 0

                While to_stop2 = 0


                    Dim vec_3d_obj1 As vec_3d1 = New vec_3d1()
                    vec_3d_obj1.p1 = New point_3d1()
                    vec_3d_obj1.p1.x1 = cord_xy1(0)
                    vec_3d_obj1.p1.y1 = cord_xy1(1)


                    vec_3d_obj1.p2 = New point_3d1()
                    vec_3d_obj1.p2.x1 = cord_xy1(0)
                    vec_3d_obj1.p2.y1 = cord_xy1(1)
                    vec_3d_obj1.p2.z1 = -10


                    rot_curve_pxls_arr1 = CGlobals1.form_obj1.markingfldimg_obj1.rotate_2d_pixels_arr(curve_pxl_arr1, vec_3d_obj1, derivate1)


                    Dim cord_xy1a As Double() = CGlobals1.get_double_cord_xy_in_pixels_arr2(rot_curve_pxls_arr1, ind1)
                    Dim cord_xy2a As Double() = CGlobals1.get_double_cord_xy_in_pixels_arr2(rot_curve_pxls_arr1, ind2)

                    If cord_xy1a(0) > cord_xy2a(0) Then
                        If derivate_add_factor1 < 0 Then
                            derivate_add_factor1 /= 2
                        End If
                        derivate_add_factor1 = Math.Abs(derivate_add_factor1)
                        derivate1 += derivate_add_factor1
                    ElseIf cord_xy1a(0) < cord_xy2a(0) Then
                        If derivate_add_factor1 > 0 Then
                            derivate_add_factor1 /= 2
                        End If
                        derivate_add_factor1 = -Math.Abs(derivate_add_factor1)

                        derivate1 += derivate_add_factor1
                    Else
                        to_stop2 = 1
                    End If

                    If Math.Abs(cord_xy1a(0) - cord_xy2a(0)) <= Math.Pow(10, -10) Then
                        to_stop2 = 1
                    End If
                End While



            End If


            Dim i1 As Integer
            Dim pixel_in_hole1 As String = ""
            For i1 = ind1 To ind2
                If CGlobals1.get_cord_xy_in_pixels_arr1(rot_curve_pxls_arr1, i1)(0) > cord_xy1(0) And Math.Abs(CGlobals1.get_cord_xy_in_pixels_arr1(rot_curve_pxls_arr1, i1)(0) - cord_xy1(0)) > 0.9 Then
                    pixel_in_hole1 = "yes"
                End If
            Next

            For i1 = ind1 To ind2
                If CGlobals1.get_cord_xy_in_pixels_arr1(rot_curve_pxls_arr1, i1)(0) < cord_xy1(0) And Math.Abs(CGlobals1.get_cord_xy_in_pixels_arr1(rot_curve_pxls_arr1, i1)(0) - cord_xy1(0)) > 0.9 Then
                    pixel_in_hole1 = "no"
                End If
            Next


            If pixel_in_hole1 = "yes" Then

                If max_last_size_of_hole1 < Math.Abs(ind2 - ind1 + 1) Then
                    max_last_size_of_hole1 = Math.Abs(ind2 - ind1 + 1)
                End If

                Dim org_curve1 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(curve_pxl_arr1, ind1, ind2)
                Dim bmp_log2 As Bitmap = CGlobals1.save_pxl_arr_log1(org_curve1, CGlobals1.global_path1 + CGlobals1.sobel_pics_path1 + "org_curve1a.bmp")
                Dim cord_xy1r As Double() = CGlobals1.get_double_cord_xy_in_pixels_arr2(rot_curve_pxls_arr1, ind1)
                Dim cord_xy2r As Double() = CGlobals1.get_double_cord_xy_in_pixels_arr2(rot_curve_pxls_arr1, ind2)

                Dim int_rot_pxl_arr1 As ArrayList = New ArrayList()
                For i1 = 0 To rot_curve_pxls_arr1.Count - 1
                    Dim cord_xy3 As Double() = CGlobals1.get_double_cord_xy_in_pixels_arr2(rot_curve_pxls_arr1, i1)
                    int_rot_pxl_arr1.Add(Math.Floor(cord_xy3(0)).ToString() + "," + Math.Floor(cord_xy3(1)).ToString())

                Next
                'Dim bmp_log1 As Bitmap = CGlobals1.save_pxl_arr_log1(int_rot_pxl_arr1, CGlobals1.global_path1 + CGlobals1.sobel_pics_path1 + "rot_curve1.bmp")
                'CGlobals1.draw_sqr_around_pixels2(bmp_log1, cord_xy1r(0) + 10, cord_xy1r(1), 1, Color.FromArgb(200, 50, 100))
                Try
                    'CGlobals1.draw_sqr_around_pixels2(bmp_log1, cord_xy2r(0) + 10, cord_xy2r(1), 1, Color.FromArgb(200, 50, 100))

                Catch ex As Exception
                    Dim err1 As Integer = 1
                End Try

                ' bmp_log1.Save(CGlobals1.global_path1 + CGlobals1.sobel_pics_path1 + "rot_curve1b.bmp")
            End If
            ind2 += 1

            If Math.Abs(ind2 - ind1) > max_delta_inds_for_hole1 Or pixel_in_hole1 = "no" Then
                If max_last_size_of_hole1 > 0 Then
                    hole_inds_arr1.Add(ind1.ToString() + "," + (ind1 + max_last_size_of_hole1).ToString())

                    ind1 += max_last_size_of_hole1

                Else
                    ind1 += 1
                End If
                ind2 = ind1 + 2

                max_last_size_of_hole1 = 0
            End If

            If ind2 >= (end_ind1 - 2) Then
                to_stop1 = 1
            End If


        End While

        Dim dict_of_hole_inds1 As Dictionary(Of Integer, Integer) = New Dictionary(Of Integer, Integer)

        Dim i2 As Integer
        Dim bmp_log3 As Bitmap = CGlobals1.save_pxl_arr_log1(curve_pxl_arr1, CGlobals1.global_path1 + CGlobals1.sobel_pics_path1 + "org_curve_fix1.bmp")
        For i2 = 0 To hole_inds_arr1.Count - 1
            Dim start_line_ind1 As Integer = Integer.Parse(hole_inds_arr1(i2).ToString().Split(",")(0))
            Dim end_line_ind1 As Integer = Integer.Parse(hole_inds_arr1(i2).ToString().Split(",")(1))

            Dim i3 As Integer

            For i3 = start_line_ind1 + 1 To end_line_ind1 - 1
                dict_of_hole_inds1(i3) = 1
            Next
            Dim pixel_line_arr1 As ArrayList = CGlobals1.form_obj1.markingfldimg_obj1.create_pixel_arr_line_from_2_2d_points2(CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxl_arr1, start_line_ind1), CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxl_arr1, end_line_ind1))

            CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(pixel_line_arr1, bmp_log3, Color.FromArgb(240, 30, 100))
            bmp_log3.Save(CGlobals1.global_path1 + CGlobals1.sobel_pics_path1 + "org_curve_fix2.bmp")
            'Dim bmp_log2 As Bitmap = CGlobals1.save_pxl_arr_log1(pixel_line_arr1, CGlobals1.global_path1 + CGlobals1.sobel_pics_path1 + "org_curve_fix2.bmp")
        Next


        Dim i4 As Integer

        For i4 = curve_pxl_arr1.Count - 1 To 0 Step -1
            If dict_of_hole_inds1.ContainsKey(i4) = True Then
                curve_pxl_arr1.RemoveAt(i4)
            End If
        Next

        Dim bmp_log4 As Bitmap = CGlobals1.save_pxl_arr_log1(curve_pxl_arr1, CGlobals1.global_path1 + CGlobals1.sobel_pics_path1 + "org_curve_fix3.bmp")


        Dim curve_pxls_arr2 As ArrayList = CGlobals1.form_obj1.markingfldimg_obj1.only_complete_missing_pixels_in_curve2(curve_pxl_arr1)

        Dim bmp_log5 As Bitmap = CGlobals1.save_pxl_arr_log1(curve_pxls_arr2, CGlobals1.global_path1 + CGlobals1.sobel_pics_path1 + "org_curve_fix4.bmp")
        Return curve_pxls_arr2
    End Function
End Class
